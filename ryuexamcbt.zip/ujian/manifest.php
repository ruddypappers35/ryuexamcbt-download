<?php
require_once __DIR__ . '/database.php';
$settings = get_settings();
$school_name = !empty($settings['school_name']) ? trim($settings['school_name']) : 'RyuExam CBT';
$school_desc = !empty($settings['school_description']) ? trim($settings['school_description']) : 'Aplikasi Ujian Berbasis Komputer (CBT) Online';

header('Content-Type: application/manifest+json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

$manifest = [
    'name' => $school_name . ' - CBT Ujian Online',
    'short_name' => mb_strimwidth($school_name, 0, 15, ''),
    'description' => $school_desc,
    'start_url' => 'index.php',
    'scope' => './',
    'display' => 'standalone',
    'background_color' => '#1F7FAB',
    'theme_color' => '#1F7FAB',
    'orientation' => 'portrait-primary',
    'lang' => 'id',
    'icons' => [
        [
            'src' => 'icon-192.png',
            'sizes' => '192x192',
            'type' => 'image/png',
            'purpose' => 'any'
        ],
        [
            'src' => 'icon-192.png',
            'sizes' => '192x192',
            'type' => 'image/png',
            'purpose' => 'maskable'
        ],
        [
            'src' => 'icon-512.png',
            'sizes' => '512x512',
            'type' => 'image/png',
            'purpose' => 'any'
        ],
        [
            'src' => 'icon-512.png',
            'sizes' => '512x512',
            'type' => 'image/png',
            'purpose' => 'maskable'
        ]
    ]
];

echo json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
