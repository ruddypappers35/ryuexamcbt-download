<?php
session_start();
require_once 'database.php';

// Validasi autentikasi: Hanya Admin atau Guru yang dapat mengakses halaman pratinjau ini
if (empty($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit;
}

$bank_id = (int)($_GET['bank_id'] ?? 0);
$settings = get_settings();
$school_name = !empty($settings['school_name']) ? $settings['school_name'] : 'CBT ONLINE';
$school_desc = !empty($settings['school_description']) ? $settings['school_description'] : 'Computer Based Test Application';

$bank_soal_list = get_bank_soal();
$current_bank = null;
foreach ($bank_soal_list as $b) {
    if ((int)$b['id'] === $bank_id) {
        $current_bank = $b;
        break;
    }
}

$bank_name = $current_bank ? $current_bank['name'] : ($bank_id > 0 ? 'Bank Soal #' . $bank_id : 'Pratinjau Soal');
$questions_raw = $bank_id > 0 ? get_questions_db($bank_id) : [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview Soal Siswa: <?= htmlspecialchars($bank_name) ?> - <?= htmlspecialchars($school_name) ?></title>
    <?php 
    $fav = !empty($settings['favicon']) ? $settings['favicon'] : (!empty($settings['school_logo']) ? $settings['school_logo'] : '');
    if(!empty($fav)): 
        $favVersion = file_exists($fav) ? filemtime($fav) : '1.0';
    ?>
        <link rel="icon" type="image/png" href="<?= htmlspecialchars($fav) ?>?v=<?= $favVersion ?>">
    <?php endif; ?>
    <meta name="theme-color" content="#1F7FAB">

    <!-- Google Fonts, Tailwind & Bootstrap Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="style.css?v=<?= time() ?>">

    <!-- KaTeX & MathJax Support for Mathematics & LaTeX Formulas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js" onload="if(window.triggerMathRender) window.triggerMathRender();"></script>
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']],
                processEscapes: true
            },
            options: {
                skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code', 'annotation', 'annotation-xml'],
                ignoreHtmlClass: 'tex2jax_ignore|katex'
            }
        };
        function renderMath(target) {
            if (!target) target = document.body;
            var rendered = false;
            if (typeof renderMathInElement === 'function') {
                try {
                    renderMathInElement(target, {
                        delimiters: [
                            {left: '$$', right: '$$', display: true},
                            {left: '\\[', right: '\\]', display: true},
                            {left: '$', right: '$', display: false},
                            {left: '\\(', right: '\\)', display: false},
                            {left: '[math]', right: '[/math]', display: false}
                        ],
                        throwOnError: false,
                        ignoredTags: ["script", "noscript", "style", "textarea", "pre", "code", "option"]
                    });
                    rendered = true;
                } catch (e) {
                    console.warn('KaTeX render warning:', e);
                }
            }
            if (!rendered && (typeof renderMathInElement !== 'function')) {
                var retries = 0;
                var retryTimer = setInterval(function() {
                    retries++;
                    if (typeof renderMathInElement === 'function') {
                        clearInterval(retryTimer);
                        renderMath(target);
                    } else if (retries > 25) {
                        clearInterval(retryTimer);
                    }
                }, 100);
            }
            if (window.MathJax && window.MathJax.typesetPromise) {
                try {
                    window.MathJax.typesetPromise([target]).catch(function(err) {});
                } catch(e) {}
            }
        }
        window.renderMath = renderMath;
        window.triggerMathRender = function() {
            var el = document.getElementById('single-question-container');
            if (el && typeof renderMath === 'function') {
                renderMath(el);
            }
        };
        window.addEventListener('load', function() {
            if (window.triggerMathRender) window.triggerMathRender();
        });
    </script>
    <script async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        .katex-display {
            overflow-x: auto;
            overflow-y: hidden;
            padding: 4px 0;
            margin: 0.5em 0;
        }
        .katex {
            font-size: 1.05em;
        }
        body {
            background-color: #f4f6f9;
        }
        .header-bg {
            background-color: #1F7FAB;
            background-image: 
                linear-gradient(to right, rgba(255, 255, 255, 0.06) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(255, 255, 255, 0.06) 1px, transparent 1px),
                radial-gradient(circle at center, #1F7FAB 0%, #14597b 50%, #0d3d54 100%);
            background-size: 24px 24px, 24px 24px, auto;
        }
        .preview-top-toolbar {
            background: #1e293b;
            color: #ffffff;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .preview-kunci-badge {
            background-color: #10B981;
            color: #ffffff;
            font-size: 0.72rem;
            padding: 2px 7px;
            border-radius: 4px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-left: 8px;
        }
        .option-label.is-correct-key {
            border-color: #10B981 !important;
            background: #ECFDF5 !important;
            box-shadow: 0 0 0 1.5px #10B981;
        }
        .option-label.is-correct-key .option-text {
            color: #065F46;
            font-weight: 600;
        }

        /* Override Tailwind CSS Reset for Tables in Questions & Options */
        .q-text, .option-text, .complex-label-text, .match-premise-text {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .q-text table,
        .option-text table,
        .complex-label-text table,
        .match-premise-text table,
        .question-card table,
        #single-question-container table,
        table.table-bordered,
        table.table {
            display: table !important;
            border-collapse: collapse !important;
            border-spacing: 0 !important;
            margin: 12px 0 16px 0 !important;
            background-color: #ffffff !important;
            border: 1px solid #cbd5e1 !important;
            max-width: 100% !important;
            box-sizing: border-box !important;
        }
        .q-text table th,
        .q-text table td,
        .option-text table th,
        .option-text table td,
        .complex-label-text table th,
        .complex-label-text table td,
        .match-premise-text table th,
        .match-premise-text table td,
        .question-card table th,
        .question-card table td,
        #single-question-container table th,
        #single-question-container table td,
        table.table-bordered th,
        table.table-bordered td,
        table.table th,
        table.table td {
            border: 1px solid #cbd5e1 !important;
            padding: 8px 12px !important;
            vertical-align: middle !important;
            font-size: 0.95rem !important;
            line-height: 1.5 !important;
            color: #1e293b !important;
            box-sizing: border-box !important;
        }
        .q-text table th,
        .option-text table th,
        .complex-label-text table th,
        .match-premise-text table th,
        .question-card table th,
        #single-question-container table th,
        table.table-bordered th,
        table.table th {
            background-color: #f1f5f9 !important;
            font-weight: 700 !important;
            color: #0f172a !important;
            text-align: center !important;
        }
        .q-text table tr:nth-child(even),
        #single-question-container table tr:nth-child(even),
        table.table-bordered tr:nth-child(even) {
            background-color: #f8fafc;
        }
        .q-text table tr:hover,
        #single-question-container table tr:hover,
        table.table-bordered tr:hover {
            background-color: #f1f5f9;
        }
    </style>
</head>
<body class="font-sans text-[#333333] antialiased">
    <!-- Top Admin Preview Control Bar -->
    <header class="preview-top-toolbar py-2 px-3 sm:px-6 sticky top-0 z-50 flex items-center justify-between flex-wrap gap-2 text-xs sm:text-sm">
        <div class="flex items-center gap-2 sm:gap-3 flex-wrap">
            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                <i class="fas fa-eye text-amber-400"></i> MODE PRATINJAU SISWA
            </span>
            <span class="text-slate-300 hidden md:inline">&bull;</span>
            <span class="text-slate-200 font-medium truncate max-w-[240px] sm:max-w-[400px]">
                <?= htmlspecialchars($bank_name) ?>
            </span>
            <span class="bg-blue-600/30 text-blue-300 px-2 py-0.5 rounded text-xs border border-blue-500/30 font-semibold">
                <?= count($questions_raw) ?> Butir Soal
            </span>
        </div>

        <div class="flex items-center gap-2 sm:gap-3 ml-auto flex-wrap">
            <!-- Toggle Kunci Jawaban -->
            <label class="inline-flex items-center gap-1.5 cursor-pointer bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded border border-slate-700 transition select-none text-slate-200">
                <input type="checkbox" id="chk-toggle-kunci" class="accent-emerald-500 w-4 h-4 cursor-pointer" onchange="toggleKunciDisplay(this.checked)">
                <span class="font-medium text-xs sm:text-sm"><i class="fas fa-key text-emerald-400 mr-1"></i> Tampilkan Kunci</span>
            </label>

            <!-- Tombol Kembali ke Admin -->
            <a href="admin.php?page=soal&open_bank_id=<?= $bank_id ?>&open_bank_name=<?= urlencode($bank_name) ?>" class="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-rose-600 hover:bg-rose-700 text-white font-medium transition text-xs sm:text-sm">
                <i class="fas fa-arrow-left"></i> <span>Kembali ke Bank Soal</span>
            </a>
        </div>
    </header>

    <div id="app" class="relative min-h-screen">
        <!-- EXAM SCREEN (STUDENT INTERFACE) -->
        <div id="exam-screen" class="w-full">
            <!-- Blue Header Background -->
            <div class="absolute top-0 left-0 w-full h-[240px] sm:h-[250px] md:h-[265px] header-bg -z-10 shadow-inner"></div>

            <div class="min-h-screen flex flex-col items-center pb-8 w-full">
                <!-- STICKY TOP CONTAINER -->
                <div class="sticky top-[42px] sm:top-[44px] z-30 w-full flex flex-col items-center shadow-md">
                    <!-- Sticky Logo Section -->
                    <div class="w-full flex justify-center header-bg pt-3 sm:pt-4 pb-3 sm:pb-4 px-3 sm:px-4">
                        <div class="flex items-center justify-between text-white w-full max-w-[850px]">
                            <!-- Header Kiri: Nama Aplikasi RyuExam & Logo Monitor -->
                            <a href="https://ryuexamcbt.web.id" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 sm:gap-3 cursor-pointer hover:opacity-90 transition-opacity" title="Kunjungi Website Resmi RyuExam CBT">
                                <i class="bi bi-display text-[24px] sm:text-[30px] md:text-[34px] text-sky-300 drop-shadow-md"></i>
                                <span class="text-[18px] sm:text-[22px] md:text-[24px] font-extrabold tracking-wide drop-shadow-md">
                                    <span style="color: #DF2463;">Ryu</span><span style="color: #38bdf8;">Exam</span>
                                </span>
                            </a>
                            <!-- Header Kanan: Logo Sekolah & Nama Sekolah -->
                            <div class="flex items-center gap-2 sm:gap-3 text-right">
                                <div class="flex flex-col justify-center min-w-0">
                                    <h1 class="text-[13px] sm:text-[16px] md:text-[18px] font-bold tracking-wide leading-tight drop-shadow-md truncate max-w-[160px] sm:max-w-[320px]">
                                        <?= htmlspecialchars($school_name) ?>
                                    </h1>
                                    <?php if (!empty($school_desc)): ?>
                                    <p class="text-[10px] sm:text-[11px] text-[#e0e0e0] drop-shadow-sm font-medium truncate max-w-[160px] sm:max-w-[320px]">
                                        <?= htmlspecialchars($school_desc) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($settings['school_logo']) && file_exists($settings['school_logo'])): ?>
                                    <img alt="Logo Sekolah" class="h-[36px] sm:h-[46px] md:h-[52px] w-auto drop-shadow-md object-contain shrink-0 bg-white/10 rounded p-1" src="<?= htmlspecialchars($settings['school_logo']) ?>?v=<?= filemtime($settings['school_logo']) ?>">
                                <?php else: ?>
                                    <i class="bi bi-mortarboard-fill text-[28px] sm:text-[36px] text-sky-300 shrink-0"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Sticky Student Info & Timer Bar -->
                    <div class="w-full max-w-[850px] bg-[#F8FAFC] px-4 sm:px-6 py-3 border-b border-gray-200 flex justify-between items-center exam-header sm:rounded-t-md">
                        <div class="student-info">
                            <span id="display-name" class="fw-700 text-gray-800 text-[14px] sm:text-lg block mb-1">
                                Siswa Simulasi (Pratinjau)
                            </span>
                            <span id="display-class" class="badge">
                                <?= htmlspecialchars($bank_name) ?>
                            </span>
                        </div>
                        <div class="flex items-center gap-2 sm:gap-4">
                            <div class="timer bg-indigo-50 border border-indigo-100 text-indigo-700 px-3 py-1.5 rounded-md font-bold text-[14px] sm:text-[16px] flex items-center gap-2 shadow-sm" id="timer-display">
                                <i class="bi bi-clock text-[16px] sm:text-[18px]"></i>
                                <span id="time-remaining">Simulasi</span>
                            </div>
                            <div class="header-action-btns flex gap-1 sm:gap-2">
                                <button type="button" class="bg-gray-100 hover:bg-gray-200 text-gray-600 p-2 rounded-md transition-colors" id="btn-toggle-map" title="Daftar Soal" onclick="toggleMapModal()">
                                    <i class="bi bi-grid-3x3-gap-fill text-[16px] sm:text-[18px]"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modals: Question Map Grid -->
                <div id="question-map-modal" class="hidden">
                    <div class="map-overlay" onclick="toggleMapModal()"></div>
                    <div class="map-content">
                        <button type="button" id="btn-close-map" class="close-icon" onclick="toggleMapModal()">&times;</button>
                        <h3 style="margin-top:0;" class="flex items-center gap-2 font-bold text-gray-800">
                            <i class="bi bi-grid-3x3-gap-fill text-indigo-600"></i> Daftar Soal
                        </h3>
                        <p class="text-xs text-gray-500 mb-2">Klik nomor untuk langsung berpindah ke butir soal.</p>
                        <div id="question-map-grid" class="map-grid"></div>
                    </div>
                </div>

                <!-- Exam Card -->
                <div class="w-full max-w-[850px] bg-white rounded-none sm:rounded-b-md shadow-lg flex flex-col flex-grow exam-screen-container fade-in mt-0">
                    <form id="exam-form" class="flex-grow flex flex-col" onsubmit="event.preventDefault();">
                        <div id="single-question-container" class="p-4 sm:p-6 min-h-[400px] flex-grow">
                            <!-- Single Question injected by JS -->
                        </div>

                        <!-- Sticky Navigation Bar at Bottom -->
                        <div class="exam-navigation bg-[#F8FAFC] px-4 sm:px-6 py-4 border-t border-gray-200 sticky bottom-0 z-20">
                            <button type="button" id="btn-prev" class="btn-nav btn-nav-prev" title="Soal Sebelumnya" onclick="navigatePrev()">
                                <i class="bi bi-chevron-left"></i>
                                <span class="nav-text hidden sm:inline">Sebelumnya</span>
                            </button>

                            <button type="button" id="btn-toggle-map-bottom" class="btn-nav-refresh" title="Buka Daftar Soal" onclick="toggleMapModal()">
                                <i class="bi bi-grid-3x3-gap-fill text-indigo-600"></i>
                                <span class="hidden sm:inline font-bold">Daftar Soal</span>
                            </button>

                            <button type="button" id="btn-next" class="btn-nav btn-nav-next" title="Soal Selanjutnya" onclick="navigateNext()">
                                <span class="nav-text hidden sm:inline">Selanjutnya</span>
                                <i class="bi bi-chevron-right"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Injection -->
    <script>
        const rawQuestions = <?= json_encode($questions_raw, JSON_UNESCAPED_UNICODE) ?>;
        const examTitle = <?= json_encode($bank_name, JSON_UNESCAPED_UNICODE) ?>;
        
        let currentIndex = 0;
        let showKunci = false;
        let userAnswers = {};

        // Parse questions into unified format matching student script.js
        const questions = rawQuestions.map((q, idx) => {
            const qType = q.type || 'multiple_choice';
            let optionsWithIndex = [];
            if ((qType === 'multiple_choice' || qType === 'complex_mc') && q.options) {
                optionsWithIndex = q.options.map((opt, optIdx) => ({
                    text: opt,
                    value: optIdx
                }));
            }
            return {
                originalId: idx,
                type: qType,
                question: q.question,
                options: (qType === 'matching') ? (q.options || []) : optionsWithIndex,
                premises: q.premises || [],
                statements: q.statements || [],
                answer: q.answer !== undefined ? parseInt(q.answer) : null,
                answers: Array.isArray(q.answers) ? q.answers.map(a => parseInt(a)) : [],
                pairs: q.pairs || {},
                points: q.points !== undefined ? parseFloat(q.points) : 2
            };
        });

        function toggleKunciDisplay(isChecked) {
            showKunci = isChecked;
            renderQuestion(currentIndex);
        }

        function toggleMapModal() {
            const modal = document.getElementById('question-map-modal');
            if (modal) {
                modal.classList.toggle('hidden');
                if (!modal.classList.contains('hidden')) {
                    renderQuestionMap();
                }
            }
        }

        function isQuestionAnswered(idx) {
            const q = questions[idx];
            if (!q) return false;
            const ans = userAnswers[idx];
            if (ans === undefined || ans === null || ans === '') return false;
            if (Array.isArray(ans) && ans.length === 0) return false;
            if (typeof ans === 'object' && Object.keys(ans).length === 0) return false;
            return true;
        }

        function renderQuestionMap() {
            const grid = document.getElementById('question-map-grid');
            if (!grid) return;
            grid.innerHTML = '';
            
            questions.forEach((q, idx) => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'map-btn';
                btn.textContent = idx + 1;
                
                if (idx === currentIndex) {
                    btn.classList.add('active');
                }
                if (isQuestionAnswered(idx)) {
                    btn.classList.add('answered');
                }
                
                btn.onclick = () => {
                    currentIndex = idx;
                    renderQuestion(currentIndex);
                    toggleMapModal();
                };
                grid.appendChild(btn);
            });
        }

        function renderQuestion(index) {
            const container = document.getElementById('single-question-container');
            if (!container) return;
            container.innerHTML = '';

            if (questions.length === 0) {
                container.innerHTML = `
                    <div class="p-8 text-center text-gray-500">
                        <i class="bi bi-journal-x text-5xl text-gray-400 mb-3 block"></i>
                        <h3 class="text-lg font-bold text-gray-700">Bank Soal Masih Kosong</h3>
                        <p class="text-sm">Belum ada butir pertanyaan yang ditambahkan ke bank soal ini.</p>
                    </div>`;
                document.getElementById('btn-prev').disabled = true;
                document.getElementById('btn-next').disabled = true;
                return;
            }

            const q = questions[index];
            const card = document.createElement('div');
            card.className = 'question-card fade-in';

            let contentHtml = '';

            if (q.type === 'essay') {
                const savedVal = userAnswers[index] || '';
                contentHtml = `
                    <textarea class="form-control mt-3 essay-input w-full p-3 border rounded-md" rows="6" placeholder="Ketik jawaban uraian Anda di sini..." oninput="handleEssayInput(event, ${index})">${savedVal}</textarea>
                `;
            } else if (q.type === 'complex_mc') {
                let optsHtml = '';
                const selectedArr = Array.isArray(userAnswers[index]) ? userAnswers[index] : [];
                
                (q.options || []).forEach(opt => {
                    const isChecked = selectedArr.includes(opt.value) ? 'checked' : '';
                    const isKey = showKunci && q.answers.includes(opt.value);
                    const keyBadge = isKey ? `<span class="preview-kunci-badge"><i class="fas fa-check"></i> KUNCI</span>` : '';
                    const keyClass = isKey ? 'is-correct-key' : '';

                    optsHtml += `
                        <label class="option-label complex-option-label ${keyClass}">
                            <input type="checkbox" value="${opt.value}" class="option-input complex-input" ${isChecked} onchange="handleComplexChange(event, ${index})">
                            <div class="option-text flex-grow flex items-center justify-between">
                                <span>${opt.text}</span>
                                ${keyBadge}
                            </div>
                        </label>
                    `;
                });

                contentHtml = `
                    <div class="complex-badge-info">
                        <i class="bi bi-check-all"></i> Pilihan Ganda Kompleks: Anda dapat memilih lebih dari satu jawaban benar.
                    </div>
                    <div class="options-container">
                        ${optsHtml}
                    </div>
                `;
            } else if (q.type === 'true_false') {
                let rowsHtml = '';
                const selectedObj = userAnswers[index] || {};
                
                (q.statements || []).forEach((stmt, sIdx) => {
                    const isTrueChecked = selectedObj[sIdx] === true || selectedObj[sIdx] === 'true' ? 'checked' : '';
                    const isFalseChecked = selectedObj[sIdx] === false || selectedObj[sIdx] === 'false' ? 'checked' : '';
                    
                    let keyHint = '';
                    if (showKunci && stmt.answer !== undefined) {
                        const correctBool = (stmt.answer === true || stmt.answer === 'true');
                        keyHint = `<span class="preview-kunci-badge" style="background:${correctBool ? '#10B981':'#EF4444'}"><i class="fas fa-key"></i> ${correctBool ? 'BENAR':'SALAH'}</span>`;
                    }

                    rowsHtml += `
                        <tr>
                            <td class="text-center font-bold align-middle">${sIdx + 1}</td>
                            <td class="align-middle">
                                <span>${stmt.text}</span>
                                ${keyHint}
                            </td>
                            <td class="text-center align-middle" style="width: 85px;">
                                <label class="tf-radio-label">
                                    <input type="radio" name="tf_${index}_${sIdx}" value="true" class="tf-radio radio-true" ${isTrueChecked} onchange="handleTfChange(${index}, ${sIdx}, true)">
                                </label>
                            </td>
                            <td class="text-center align-middle" style="width: 85px;">
                                <label class="tf-radio-label">
                                    <input type="radio" name="tf_${index}_${sIdx}" value="false" class="tf-radio radio-false" ${isFalseChecked} onchange="handleTfChange(${index}, ${sIdx}, false)">
                                </label>
                            </td>
                        </tr>
                    `;
                });

                contentHtml = `
                    <div class="complex-badge-info" style="color: #047857; background: #ECFDF5; border-color: #A7F3D0;">
                        <i class="bi bi-list-check"></i> Tentukan Benar atau Salah untuk setiap pernyataan berikut:
                    </div>
                    <div class="table-responsive">
                        <table class="tf-statement-table">
                            <thead>
                                <tr>
                                    <th style="width: 45px;" class="text-center">No</th>
                                    <th>Pernyataan</th>
                                    <th style="width: 85px;" class="text-center text-success font-bold">Benar</th>
                                    <th style="width: 85px;" class="text-center text-danger font-bold">Salah</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${rowsHtml}
                            </tbody>
                        </table>
                    </div>
                `;
            } else if (q.type === 'matching') {
                const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
                const selectedObj = userAnswers[index] || {};
                let rowsHtml = '';

                (q.premises || []).forEach((premiseText, pIdx) => {
                    const userChoice = selectedObj[pIdx] !== undefined ? parseInt(selectedObj[pIdx]) : null;
                    const isAnsweredRow = userChoice !== null;
                    
                    let selectOptionsHtml = '<option value="">-- Pilih Pasangan Jawaban --</option>';
                    (q.options || []).forEach((opt, optIdx) => {
                        const letter = letters[optIdx] || (optIdx + 1);
                        const isSel = (userChoice !== null && userChoice === optIdx) ? 'selected' : '';
                        selectOptionsHtml += `<option value="${optIdx}" ${isSel}>${letter}. ${opt}</option>`;
                    });

                    let keyHint = '';
                    if (showKunci && q.pairs) {
                        const correctOptIdx = q.pairs[pIdx] !== undefined ? q.pairs[pIdx] : q.pairs[String(pIdx)];
                        if (correctOptIdx !== undefined && q.options[correctOptIdx]) {
                            const ltr = letters[correctOptIdx] || (correctOptIdx + 1);
                            keyHint = `<span class="preview-kunci-badge"><i class="fas fa-key"></i> Kunci: ${ltr}</span>`;
                        }
                    }

                    rowsHtml += `
                        <div class="match-item ${isAnsweredRow ? 'is-matched' : ''}">
                            <div class="match-left">
                                <span class="match-badge">${pIdx + 1}</span>
                                <div class="match-premise-text">${premiseText} ${keyHint}</div>
                            </div>
                            <div class="match-connector">
                                <i class="bi bi-arrow-right"></i>
                            </div>
                            <div class="match-right">
                                <select class="matching-select" onchange="handleMatchingChange(event, ${index}, ${pIdx})">
                                    ${selectOptionsHtml}
                                </select>
                            </div>
                        </div>
                    `;
                });

                contentHtml = `
                    <div class="match-clean-wrapper">
                        <div class="match-clean-hint">
                            <i class="bi bi-link-45deg text-primary mr-1"></i> Pasangkan setiap pernyataan dengan jawaban yang tepat:
                        </div>
                        <div class="match-items-list">
                            ${rowsHtml}
                        </div>
                    </div>
                `;
            } else {
                // Multiple Choice (Single Correct)
                let optsHtml = '';
                const selectedVal = userAnswers[index];

                (q.options || []).forEach(opt => {
                    const isChecked = selectedVal == opt.value ? 'checked' : '';
                    const isKey = showKunci && q.answer === opt.value;
                    const keyBadge = isKey ? `<span class="preview-kunci-badge"><i class="fas fa-check"></i> KUNCI</span>` : '';
                    const keyClass = isKey ? 'is-correct-key' : '';

                    optsHtml += `
                        <label class="option-label ${keyClass}">
                            <input type="radio" name="q_${index}" value="${opt.value}" class="option-input single-mc-input" ${isChecked} onchange="handleSingleMcChange(${index}, ${opt.value})">
                            <div class="option-text flex-grow flex items-center justify-between">
                                <span>${opt.text}</span>
                                ${keyBadge}
                            </div>
                        </label>
                    `;
                });

                contentHtml = `
                    <div class="options-container">
                        ${optsHtml}
                    </div>
                `;
            }

            const examBadgeHtml = examTitle ? `
                <span class="q-exam-badge" title="${examTitle.replace(/"/g, '&quot;')}">
                    <i class="bi bi-book"></i>
                    <span class="exam-title">${examTitle}</span>
                </span>
            ` : '';

            card.innerHTML = `
                <div class="q-header">
                    <span class="q-number">Soal ${index + 1} dari ${questions.length}</span>
                    ${examBadgeHtml}
                </div>
                <div class="q-text">${q.question}</div>
                ${contentHtml}
            `;

            container.appendChild(card);
            if (window.renderMath) {
                window.renderMath(container);
            }
            updateNavState();
        }

        function handleSingleMcChange(qIdx, val) {
            userAnswers[qIdx] = val;
            updateNavState();
        }

        function handleComplexChange(e, qIdx) {
            const container = document.getElementById('single-question-container');
            const checked = Array.from(container.querySelectorAll('.complex-input:checked')).map(el => parseInt(el.value));
            userAnswers[qIdx] = checked;
            updateNavState();
        }

        function handleTfChange(qIdx, sIdx, val) {
            if (!userAnswers[qIdx] || typeof userAnswers[qIdx] !== 'object') {
                userAnswers[qIdx] = {};
            }
            userAnswers[qIdx][sIdx] = val;
            updateNavState();
        }

        function handleMatchingChange(e, qIdx, pIdx) {
            const val = e.target.value !== '' ? parseInt(e.target.value) : null;
            if (!userAnswers[qIdx] || typeof userAnswers[qIdx] !== 'object') {
                userAnswers[qIdx] = {};
            }
            if (val !== null) {
                userAnswers[qIdx][pIdx] = val;
            } else {
                delete userAnswers[qIdx][pIdx];
            }
            updateNavState();
        }

        function handleEssayInput(e, qIdx) {
            userAnswers[qIdx] = e.target.value;
            updateNavState();
        }

        function updateNavState() {
            const btnPrev = document.getElementById('btn-prev');
            const btnNext = document.getElementById('btn-next');
            if (btnPrev) btnPrev.disabled = (currentIndex === 0);
            if (btnNext) btnNext.disabled = (currentIndex >= questions.length - 1);
        }

        function navigatePrev() {
            if (currentIndex > 0) {
                currentIndex--;
                renderQuestion(currentIndex);
            }
        }

        function navigateNext() {
            if (currentIndex < questions.length - 1) {
                currentIndex++;
                renderQuestion(currentIndex);
            }
        }

        // Keyboard navigation (ArrowLeft & ArrowRight)
        document.addEventListener('keydown', function(e) {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
                return;
            }
            if (e.key === 'ArrowLeft') {
                navigatePrev();
            } else if (e.key === 'ArrowRight') {
                navigateNext();
            }
        });

        // Initial render
        document.addEventListener('DOMContentLoaded', function() {
            renderQuestion(0);
        });
    </script>
</body>
</html>
