<?php
session_start();
require 'database.php';

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// Login Processing
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $input_user = trim($_POST['username'] ?? '');
    $input_pass = trim($_POST['password'] ?? '');
    
    $users = get_users();
    $found_user = null;
    $need_save = false;
    foreach ($users as &$u) {
        if (strcasecmp($u['username'], $input_user) === 0) {
            $is_valid = password_verify($input_pass, $u['password']) || ($u['password'] === $input_pass);
            if ($is_valid) {
                $found_user = $u;
                // Auto-upgrade password plain-text menjadi bcrypt hash
                if ($u['password'] === $input_pass && password_needs_rehash($u['password'], PASSWORD_BCRYPT)) {
                    $u['password'] = password_hash($input_pass, PASSWORD_BCRYPT);
                    $need_save = true;
                }
                break;
            }
        }
    }
    unset($u);
    if ($need_save) {
        save_users($users);
    }
    
    if ($found_user) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['user_role'] = $found_user['role'] ?? 'guru';
        $_SESSION['user_name'] = $found_user['name'] ?? ($found_user['role'] === 'admin' ? 'Administrator' : 'Guru');
        $_SESSION['user_id'] = (int)($found_user['id'] ?? 1);
        $_SESSION['username'] = $found_user['username'];
        $_SESSION['user_mapel'] = $found_user['mapel'] ?? '';
        $_SESSION['admin_role'] = $found_user['admin_role'] ?? ($found_user['role'] === 'admin' ? 'Super Admin' : 'Guru');
        $_SESSION['admin_permissions'] = $found_user['permissions'] ?? 'all';
        header("Location: admin.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}

// Check Login Status
$logged_in = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
$user_role = $_SESSION['user_role'] ?? 'admin';
$user_name = $_SESSION['user_name'] ?? ($user_role === 'admin' ? 'Administrator' : 'Guru');
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Role-based Route Guard for Guru
if ($logged_in && $user_role === 'guru') {
    $allowed_guru_pages = ['dashboard', 'soal', 'status', 'analisis', 'panduan'];
    if (!in_array($page, $allowed_guru_pages)) {
        header("Location: admin.php?page=soal");
        exit;
    }
}

// Role-based Route Guard for Admin
if ($logged_in && $user_role === 'admin') {
    $curId = (int)($_SESSION['user_id'] ?? 0);
    if ($curId > 0) {
        $allUsers = get_users();
        foreach ($allUsers as $u) {
            if ((int)$u['id'] === $curId) {
                $_SESSION['admin_role'] = $u['admin_role'] ?? 'Super Admin';
                $_SESSION['admin_permissions'] = $u['permissions'] ?? 'all';
                break;
            }
        }
    }
    
    // Validasi izin akses halaman yang diminta
    if (!admin_has_permission($page)) {
        $myPerms = parse_admin_permissions($_SESSION['admin_permissions'] ?? 'all');
        $targetPage = in_array('dashboard', $myPerms) ? 'dashboard' : (!empty($myPerms[0]) ? $myPerms[0] : 'dashboard');
        header("Location: admin.php?page=" . urlencode($targetPage) . "&denied=1");
        exit;
    }
}

if ($logged_in) {
    // Add Class
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_class'])) {
        $className = trim($_POST['class_name']);
        if (!empty($className)) {
            $classes = get_classes();
            $exists = false;
            foreach ($classes as $c) {
                if (strtolower($c['name']) === strtolower($className)) $exists = true;
            }
            if (!$exists) {
                $new_id = count($classes) > 0 ? max(array_column($classes, 'id')) + 1 : 1;
                $classes[] = ['id' => $new_id, 'name' => $className];
                save_classes($classes);
            }
        }
        header("Location: admin.php?page=kelas");
        exit;
    }

    // Edit Class
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_class'])) {
        $id = (int)$_POST['edit_class_id'];
        $className = trim($_POST['class_name']);
        if (!empty($className)) {
            $classes = get_classes();
            $exists = false;
            foreach ($classes as $c) {
                if (strtolower($c['name']) === strtolower($className) && $c['id'] != $id) $exists = true;
            }
            if (!$exists) {
                foreach ($classes as &$c) {
                    if ($c['id'] == $id) {
                        $c['name'] = $className;
                        break;
                    }
                }
                save_classes($classes);
            }
        }
        header("Location: admin.php?page=kelas");
        exit;
    }

    // Add Mata Pelajaran (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_mata_pelajaran'])) {
        $code = strtoupper(trim($_POST['mapel_code'] ?? ''));
        $name = trim($_POST['mapel_name'] ?? '');
        if (!empty($name)) {
            $pdo = get_db_connection();
            try {
                $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('mata_pelajaran_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
            } catch (Exception $e) {}
            $ins = $pdo->prepare("INSERT INTO mata_pelajaran (code, name) VALUES (?, ?)");
            $ins->execute([$code, $name]);
        }
        header("Location: admin.php?page=mata_pelajaran");
        exit;
    }

    // Edit Mata Pelajaran (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_mata_pelajaran'])) {
        $id = (int)($_POST['edit_mapel_id'] ?? 0);
        $code = strtoupper(trim($_POST['mapel_code'] ?? ''));
        $name = trim($_POST['mapel_name'] ?? '');
        if ($id > 0 && !empty($name)) {
            $pdo = get_db_connection();
            $upd = $pdo->prepare("UPDATE mata_pelajaran SET code = ?, name = ? WHERE id = ?");
            $upd->execute([$code, $name, $id]);
        }
        header("Location: admin.php?page=mata_pelajaran");
        exit;
    }

    // Add Jenis Ujian (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_jenis_ujian'])) {
        $code = strtoupper(trim($_POST['jenis_code'] ?? ''));
        $name = trim($_POST['jenis_name'] ?? '');
        if (!empty($name)) {
            $jenis_list = get_jenis_ujian_list();
            $new_id = count($jenis_list) > 0 ? max(array_column($jenis_list, 'id')) + 1 : 1;
            $jenis_list[] = [
                'id' => $new_id,
                'code' => $code,
                'name' => $name
            ];
            save_jenis_ujian_list($jenis_list);
        }
        header("Location: admin.php?page=jenis_ujian");
        exit;
    }

    // Edit Jenis Ujian (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_jenis_ujian'])) {
        $id = (int)($_POST['edit_jenis_id'] ?? 0);
        $code = strtoupper(trim($_POST['jenis_code'] ?? ''));
        $name = trim($_POST['jenis_name'] ?? '');
        if ($id > 0 && !empty($name)) {
            $jenis_list = get_jenis_ujian_list();
            foreach ($jenis_list as &$j) {
                if ($j['id'] === $id) {
                    $j['code'] = $code;
                    $j['name'] = $name;
                    break;
                }
            }
            unset($j);
            save_jenis_ujian_list($jenis_list);
        }
        header("Location: admin.php?page=jenis_ujian");
        exit;
    }

    // Add Guru (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_guru'])) {
        $name = trim($_POST['guru_name'] ?? '');
        $username = trim($_POST['guru_username'] ?? '');
        $password = trim($_POST['guru_password'] ?? '');
        $mapel = trim($_POST['guru_mapel'] ?? '');
        
        if (!empty($name) && !empty($username) && !empty($password)) {
            $users = get_users();
            $exists = false;
            foreach ($users as $u) {
                if (strtolower($u['username']) === strtolower($username)) {
                    $exists = true;
                    break;
                }
            }
            if (!$exists) {
                $new_id = count($users) > 0 ? max(array_column($users, 'id')) + 1 : 1;
                $users[] = [
                    'id' => $new_id,
                    'name' => $name,
                    'username' => $username,
                    'password' => $password,
                    'role' => 'guru',
                    'mapel' => $mapel,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                save_users($users);
            }
        }
        header("Location: admin.php?page=guru");
        exit;
    }

    // Edit Guru (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_guru'])) {
        $id = (int)$_POST['edit_guru_id'];
        $name = trim($_POST['guru_name'] ?? '');
        $username = trim($_POST['guru_username'] ?? '');
        $password = trim($_POST['guru_password'] ?? '');
        $mapel = trim($_POST['guru_mapel'] ?? '');
        
        if (!empty($name) && !empty($username) && !empty($password)) {
            $users = get_users();
            $exists = false;
            foreach ($users as $u) {
                if ($u['id'] != $id && strtolower($u['username']) === strtolower($username)) {
                    $exists = true;
                    break;
                }
            }
            if (!$exists) {
                foreach ($users as &$u) {
                    if ($u['id'] == $id) {
                        $u['name'] = $name;
                        $u['username'] = $username;
                        $u['password'] = $password;
                        $u['mapel'] = $mapel;
                        break;
                    }
                }
                save_users($users);
            }
        }
        header("Location: admin.php?page=guru");
        exit;
    }

    // Delete Guru (Admin only)
    if ($user_role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_guru'])) {
        $id = (int)$_POST['guru_id'];
        $users = get_users();
        $users = array_filter($users, function($u) use ($id) {
            return $u['id'] != $id;
        });
        save_users(array_values($users));
        header("Location: admin.php?page=guru");
        exit;
    }

    // Add Student
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {
        $classId = (int)$_POST['class_id'];
        $studentName = strtoupper(trim($_POST['student_name']));
        $studentPassword = trim($_POST['student_password'] ?? '');
        $studentUsername = trim($_POST['student_username'] ?? '');
        $studentRuang = trim($_POST['student_ruang'] ?? '');
        $studentNoPeserta = trim($_POST['student_no_peserta'] ?? '');
        if (!empty($studentName) && !empty($classId)) {
            $students = get_students();
            $new_id = count($students) > 0 ? max(array_column($students, 'id')) + 1 : 1;
            if (empty($studentUsername)) {
                $studentUsername = 'siswa' . $new_id;
            }
            $students[] = [
                'id' => $new_id,
                'username' => $studentUsername,
                'class_id' => $classId,
                'name' => $studentName,
                'password' => $studentPassword,
                'ruang' => $studentRuang,
                'no_peserta' => $studentNoPeserta
            ];
            save_students($students);
        }
        header("Location: admin.php?page=siswa");
        exit;
    }

    // Edit Student
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_student'])) {
        $id = (int)$_POST['edit_student_id'];
        $classId = (int)$_POST['class_id'];
        $studentName = strtoupper(trim($_POST['student_name']));
        $studentPassword = trim($_POST['student_password'] ?? '');
        $studentUsername = trim($_POST['student_username'] ?? '');
        $studentRuang = trim($_POST['student_ruang'] ?? '');
        $studentNoPeserta = trim($_POST['student_no_peserta'] ?? '');
        if (!empty($studentName) && !empty($classId)) {
            $students = get_students();
            foreach ($students as &$s) {
                if ($s['id'] == $id) {
                    $s['class_id'] = $classId;
                    $s['name'] = $studentName;
                    $s['password'] = $studentPassword;
                    $s['username'] = !empty($studentUsername) ? $studentUsername : ('siswa' . $id);
                    $s['ruang'] = $studentRuang;
                    $s['no_peserta'] = $studentNoPeserta;
                    break;
                }
            }
            save_students($students);
        }
        header("Location: admin.php?page=siswa");
        exit;
    }

    $classes = get_classes();
    usort($classes, function($a, $b) { return strcmp($a['name'], $b['name']); });
    
    $exams = get_exams();
    usort($exams, function($a, $b) { return strcmp($a['name'], $b['name']); });
    $qCounts = get_question_counts();
    foreach ($exams as &$e) {
        // Question count is now based on bank_soal_id if exists
        $bank_soal_id = isset($e['bank_soal_id']) ? (int)$e['bank_soal_id'] : (int)$e['id'];
        if (isset($qCounts[$bank_soal_id])) {
            $e['question_count'] = $qCounts[$bank_soal_id];
        } else {
            $e['question_count'] = count(get_questions_db($bank_soal_id));
        }
    }
    unset($e);
    
    $bank_soal = get_bank_soal();
    if ($user_role === 'guru') {
        $cur_user_id = $_SESSION['user_id'] ?? null;
        $cur_user_name = $_SESSION['user_name'] ?? '';
        $bank_soal = array_values(array_filter($bank_soal, function($b) use ($cur_user_id, $cur_user_name) {
            if (isset($b['author_id']) && $cur_user_id !== null && (int)$b['author_id'] === (int)$cur_user_id) {
                return true;
            }
            if (isset($b['created_by']) && !empty($cur_user_name) && strcasecmp(trim($b['created_by']), trim($cur_user_name)) === 0) {
                return true;
            }
            return false;
        }));
    }
    usort($bank_soal, function($a, $b) { return strcmp($a['name'], $b['name']); });
    foreach ($bank_soal as &$b) {
        $bId = (int)$b['id'];
        if (isset($qCounts[$bId])) {
            $b['question_count'] = $qCounts[$bId];
        } else {
            $b['question_count'] = count(get_questions_db($bId));
        }
    }
    unset($b);
    
    $all_students = get_students();
    usort($all_students, function($a, $b) { return strcmp($a['name'], $b['name']); });
    
    $studentsCount = count($all_students);
    $all_users = get_users();
    $teachersCount = count(array_filter($all_users, function($u) {
        return ($u['role'] ?? 'guru') === 'guru';
    }));
    $bankSoalCount = count($bank_soal);
    $activeExamsCount = count(array_filter($exams, function($e) {
        return ($e['status'] ?? 'aktif') === 'aktif';
    }));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $page_title = !empty($settings['school_name']) ? htmlspecialchars($settings['school_name']) . ' - Admin Panel' : 'Admin Panel - CBT';
    if (!empty($_GET['live_exam_name'])) {
        $page_title = htmlspecialchars($_GET['live_exam_name']);
    } elseif (!empty($_GET['live_exam_id'])) {
        $all_exs = get_exams();
        foreach ($all_exs as $ex_item) {
            if ($ex_item['id'] == (int)$_GET['live_exam_id']) {
                $page_title = htmlspecialchars($ex_item['name']);
                break;
            }
        }
    }
    ?>
    <title><?= $page_title ?></title>
    <?php
    $settings = get_settings();
    $admin_fav = !empty($settings['favicon']) ? $settings['favicon'] : (!empty($settings['school_logo']) ? $settings['school_logo'] : '');
    if(!empty($admin_fav)): 
        $favVersion = file_exists($admin_fav) ? filemtime($admin_fav) : '1.0';
    ?>
        <link rel="icon" href="<?= htmlspecialchars($admin_fav) ?>?v=<?= $favVersion ?>">
    <?php endif; ?>
    <!-- PWA App Icon & Manifest -->
    <?php
    $manifestVer = file_exists('manifest.json') ? filemtime('manifest.json') : '1.0';
    $pwa192Ver = file_exists('icon-192.png') ? filemtime('icon-192.png') : '1.0';
    $pwa512Ver = file_exists('icon-512.png') ? filemtime('icon-512.png') : '1.0';
    ?>
    <link rel="manifest" href="manifest.json?v=<?= $manifestVer ?>">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="apple-touch-icon" href="icon-192.png?v=<?= $pwa192Ver ?>">
    <link rel="apple-touch-icon" sizes="512x512" href="icon-512.png?v=<?= $pwa512Ver ?>">
    <!-- Google Fonts: Plus Jakarta Sans & Sora -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Sora:wght@500;600;700;800&display=swap" rel="stylesheet">
    <!-- FontAwesome & Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <!-- Summernote CSS -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- SheetJS with Style for Excel Import/Export -->
    <script src="https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js"></script>
    <!-- JSZip for Bulk Download Zip -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <!-- Mammoth.js for Word (.docx) Import -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js"></script>

    <!-- KaTeX & MathJax Support for Mathematics & LaTeX Formulas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js"></script>
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']],
                processEscapes: true
            },
            options: {
                skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code', 'annotation', 'annotation-xml'],
                ignoreHtmlClass: 'tex2jax_ignore|katex'
            }
        };
        function renderMath(target) {
            if (!target) target = document.body;
            var rendered = false;
            if (typeof renderMathInElement === 'function') {
                try {
                    renderMathInElement(target, {
                        delimiters: [
                            {left: '$$', right: '$$', display: true},
                            {left: '\\[', right: '\\]', display: true},
                            {left: '$', right: '$', display: false},
                            {left: '\\(', right: '\\)', display: false},
                            {left: '[math]', right: '[/math]', display: false}
                        ],
                        throwOnError: false,
                        ignoredTags: ["script", "noscript", "style", "textarea", "pre", "code", "option"]
                    });
                    rendered = true;
                } catch (e) {
                    console.warn('KaTeX render warning:', e);
                }
            }
            if (!rendered && (typeof renderMathInElement !== 'function')) {
                var retries = 0;
                var retryTimer = setInterval(function() {
                    retries++;
                    if (typeof renderMathInElement === 'function') {
                        clearInterval(retryTimer);
                        renderMath(target);
                    } else if (retries > 25) {
                        clearInterval(retryTimer);
                    }
                }, 100);
            }
            if (window.MathJax && window.MathJax.typesetPromise) {
                try {
                    window.MathJax.typesetPromise([target]).catch(function(err) {});
                } catch(e) {}
            }
        }
        window.renderMath = renderMath;
        window.triggerMathRender = function() {
            var targets = [
                document.getElementById('container-soal'),
                document.getElementById('modal-single-question-container'),
                document.getElementById('single-question-container')
            ];
            targets.forEach(function(el) {
                if (el && typeof renderMath === 'function') renderMath(el);
            });
        };
        window.addEventListener('load', function() {
            if (window.triggerMathRender) window.triggerMathRender();
        });
    </script>
    <script async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

    <style>
        .katex-display {
            overflow-x: auto;
            overflow-y: hidden;
            padding: 4px 0;
            margin: 0.5em 0;
        }
        .katex {
            font-size: 1.05em;
        }
        .btn-outline-small {
            padding: 0.2rem 0.5rem;
            font-size: 0.75rem;
            border: 1px solid #dc3545;
            color: #dc3545;
            background: transparent;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-outline-small:hover {
            background: #dc3545;
            color: #fff;
        }
        /* Global Admin Font: Plus Jakarta Sans */
        body {
            font-size: 0.92rem;
            letter-spacing: -0.01em;
        }
        /* Question Table & Editor Table Styling */
        .question-body, #modal-single-question-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .question-body table,
        #modal-single-question-container table,
        .note-editable table {
            display: table !important;
            border-collapse: collapse !important;
            border-spacing: 0 !important;
            margin: 10px 0 14px 0 !important;
            background-color: #ffffff !important;
            border: 1px solid #cbd5e1 !important;
            max-width: 100% !important;
        }
        .question-body table th,
        .question-body table td,
        #modal-single-question-container table th,
        #modal-single-question-container table td,
        .note-editable table th,
        .note-editable table td {
            border: 1px solid #cbd5e1 !important;
            padding: 8px 12px !important;
            vertical-align: middle !important;
            font-size: 0.95rem !important;
            line-height: 1.5 !important;
            color: #1e293b !important;
        }
        .question-body table th,
        #modal-single-question-container table th,
        .note-editable table th {
            background-color: #f1f5f9 !important;
            font-weight: 700 !important;
            color: #0f172a !important;
            text-align: center !important;
        }
        body, .main-header, .main-sidebar, .content-wrapper, .main-footer, .card, .card-title, .modal-title, .nav-link, .btn, .form-control, .table, .swal2-popup, .note-editor, .dropdown-menu {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        }
        /* Custom Sidebar Color #F2F2F2 */
        .main-sidebar,
        .main-sidebar .sidebar,
        .main-sidebar .brand-link {
            background-color: #F2F2F2 !important;
        }
        .main-sidebar {
            border-right: 1px solid #e0e0e0;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.03);
        }
        .main-sidebar .brand-link {
            border-bottom: 1px solid #e2e8f0 !important;
            color: #1e293b !important;
        }
        .main-sidebar .nav-header {
            color: #64748b !important;
            font-size: 0.74rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            padding: 0.75rem 1.25rem 0.35rem 1.25rem !important;
        }
        .main-sidebar .nav-link {
            font-size: 0.95rem;
            color: #334155 !important;
            border-radius: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            padding: 0.55rem 16px 0.55rem 22.5px !important;
            border-left: 3.5px solid transparent !important;
            border-top: 1px solid transparent !important;
            border-bottom: 1px solid transparent !important;
            border-right: 1px solid transparent !important;
            display: flex !important;
            align-items: center;
            box-sizing: border-box !important;
            transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, color 0.15s ease-in-out;
        }
        .main-sidebar .nav-link .nav-icon {
            color: #64748b !important;
            margin-right: 0.5rem;
        }
        .main-sidebar .nav-link:hover {
            background-color: #e5e7eb !important;
            color: #0f172a !important;
            border-left: 3.5px solid #DF2463 !important;
            border-top: 1px solid #e0e0e0 !important;
            border-bottom: 1px solid #e0e0e0 !important;
            border-right: 1px solid #e0e0e0 !important;
            border-radius: 0 !important;
        }
        .main-sidebar .nav-link:hover .nav-icon {
            color: #0f172a !important;
        }
        .main-sidebar .nav-link.active,
        .main-sidebar .nav-link:active {
            background-color: #FFFFFF !important;
            color: #DF2463 !important;
            font-weight: 600;
            border-radius: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            padding: 0.55rem 16px 0.55rem 22.5px !important;
            border-top: 1px solid #ebebeb !important;
            border-bottom: 1px solid #ebebeb !important;
            border-left: 3.5px solid #DF2463 !important;
            border-right: 1px solid #ebebeb !important;
            box-shadow: none !important;
            box-sizing: border-box !important;
        }
        .main-sidebar .nav-link.active .nav-icon,
        .main-sidebar .nav-link:active .nav-icon {
            color: #DF2463 !important;
        }
        .main-sidebar .nav-link.active:hover {
            background-color: #FFFFFF !important;
            color: #DF2463 !important;
            border-left: 3.5px solid #DF2463 !important;
            border-top: 1px solid #ebebeb !important;
            border-bottom: 1px solid #ebebeb !important;
            border-right: 1px solid #ebebeb !important;
        }
        .main-sidebar .nav-link.active:hover .nav-icon {
            color: #DF2463 !important;
        }
        /* Container sidebar tanpa padding horizontal agar garis aktif penuh & tidak terpotong */
        .main-sidebar .sidebar {
            padding-left: 0 !important;
            padding-right: 0 !important;
            padding-bottom: 80px !important;
        }
        .main-sidebar .nav-sidebar {
            padding-bottom: 50px !important;
        }
        .main-sidebar .nav-sidebar > .nav-item:last-child {
            margin-bottom: 40px !important;
        }
        .table {
            font-size: 0.885rem;
        }
        /* Header User Profile & Dropdown (Sesuai Referensi Gambar) */
        .user-dropdown-menu .nav-link {
            border-radius: 8px;
            padding: 4px 10px !important;
            transition: background-color 0.15s ease;
        }
        .user-dropdown-menu .nav-link:hover {
            background-color: #f1f5f9;
        }
        .header-user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: #e2e8f0;
            border: 2px solid #cbd5e1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            font-size: 1.15rem;
            flex-shrink: 0;
        }
        .header-user-greeting {
            font-size: 0.72rem;
            color: #64748b;
            font-weight: 500;
            line-height: 1.2;
        }
        .header-user-name {
            font-size: 0.88rem;
            font-weight: 700;
            color: #1e293b;
            line-height: 1.2;
            text-transform: uppercase;
        }
        .user-dropdown-menu .dropdown-menu {
            border: 1px solid #e2e8f0 !important;
            border-radius: 6px !important;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08) !important;
            margin-top: 10px;
            padding: 4px 0;
            background-color: #ffffff;
        }
        .user-dropdown-menu .dropdown-menu::before {
            content: '';
            position: absolute;
            top: -6px;
            right: 16px;
            width: 11px;
            height: 11px;
            background: #ffffff;
            transform: rotate(45deg);
            border-top: 1px solid #e2e8f0;
            border-left: 1px solid #e2e8f0;
            z-index: 1;
        }
        .user-dropdown-menu .dropdown-item {
            font-size: 0.92rem;
            color: #334155;
            padding: 10px 18px;
            transition: all 0.15s ease;
        }
        .user-dropdown-menu .dropdown-item i {
            color: #475569;
            transition: color 0.15s ease;
        }
        .user-dropdown-menu .dropdown-item:hover {
            background-color: #fef2f2;
            color: #dc2626;
        }
        .user-dropdown-menu .dropdown-item:hover i {
            color: #dc2626 !important;
        }
        /* Sticky Bottom Footer */
        .main-footer.sticky-bottom {
            position: sticky;
            bottom: 0;
            z-index: 1030;
            box-shadow: 0 -2px 6px rgba(0, 0, 0, 0.05);
            background-color: #ffffff;
        }
    </style>
</head>
<body class="hold-transition <?php echo $logged_in ? 'sidebar-mini layout-fixed layout-footer-fixed' : 'login-page'; ?>">
    
    <?php if (!$logged_in): ?>
    <style>
    /* ============================================================
       ROBOT LOGIN FORM (VOLT) STYLES
       ============================================================ */
    :root {
      --paper: #f4efe5;
      --ink: #23252d;
      --accent: #ff6b4b;
      --accent-deep: #e5532f;
      --teal: #2ec4b6;
      --yellow: #ffc53d;
      --shell: #fffdf8;
      --screen: #23252d;
      --eye: #fffdf8;
      --muted: #9a948a;
      --field: #faf7f0;
      --line: 2px solid var(--ink);
      --turn: .65s cubic-bezier(.5, -0.3, .25, 1.35);
    }
    body.login-page {
      font-family: 'Sora', 'Segoe UI', system-ui, sans-serif !important;
      color: var(--ink) !important;
      background:
        radial-gradient(rgba(35, 37, 45, .07) 1.2px, transparent 1.3px) 0 0 / 24px 24px,
        var(--paper) !important;
      min-height: 100vh !important;
      min-height: 100svh !important;
      display: grid !important;
      place-items: center !important;
      padding: 90px 24px 60px !important;
      overflow-x: hidden !important;
      position: relative !important;
      height: auto !important;
    }
    .scene {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
      width: 100%;
    }
    .stage {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
    }
    /* robot */
    .robot {
      position: relative;
      z-index: 1;
      margin-bottom: -16px;
      animation: float 4s ease-in-out infinite alternate;
      perspective: 800px;
    }
    @keyframes float {
      from { transform: translateY(0); }
      to { transform: translateY(-5px); }
    }
    /* antenna */
    .antenna {
      position: absolute;
      top: -32px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      flex-direction: column;
      align-items: center;
      z-index: 2;
    }
    .antenna-rod {
      width: 4px;
      height: 22px;
      background: var(--ink);
      border-radius: 2px;
    }
    .antenna-tip {
      width: 15px;
      height: 15px;
      border-radius: 50%;
      background: var(--accent);
      border: var(--line);
      order: -1;
      margin-bottom: -2px;
      position: relative;
      animation: bob 2.4s ease-in-out infinite;
    }
    .antenna-tip::after {
      content: '';
      position: absolute;
      top: 2px;
      left: 3px;
      width: 4px;
      height: 4px;
      border-radius: 50%;
      background: rgba(255, 255, 255, .85);
    }
    @keyframes bob {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-2.5px); }
    }
    .robot[data-mood="excited"] .antenna-tip {
      animation-duration: .4s;
      background: var(--yellow);
    }
    .robot[data-mood="success"] .antenna-tip {
      background: var(--teal);
    }
    /* head */
    .head3d {
      width: 152px;
      height: 140px;
      perspective: 700px;
      transform-style: preserve-3d;
      transform: translateY(var(--hy, 0px)) scale(var(--hsc, 1)) rotateX(var(--rx, 0deg)) rotateY(var(--ry, 0deg));
      transition: transform .25s ease-out;
      will-change: transform;
    }
    .is-hyped .head3d {
      --hy: 5px;
      --hsc: 1.04;
    }
    .is-pressed .head3d {
      --hy: 9px;
      --hsc: .94;
    }
    .head {
      position: relative;
      width: 100%;
      height: 100%;
      transform-style: preserve-3d;
      transition: transform var(--turn);
    }
    .is-turned .head {
      transform: rotateY(180deg);
    }
    .is-spinning .head {
      animation: victory .9s ease-in-out;
    }
    @keyframes victory {
      to { transform: rotateY(360deg); }
    }
    .ear {
      position: absolute;
      top: 48px;
      width: 16px;
      height: 40px;
      background: var(--shell);
      border: var(--line);
      border-radius: 8px;
      transform: translateZ(0);
    }
    .ear--l { left: -10px; }
    .ear--r { right: -10px; }
    .face {
      position: absolute;
      inset: 0;
      border-radius: 34px;
      backface-visibility: hidden;
      -webkit-backface-visibility: hidden;
      background: var(--shell);
      border: var(--line);
    }
    .face--front {
      box-shadow: 5px 6px 0 rgba(35, 37, 45, .16);
    }
    .face--back {
      box-shadow: 5px 6px 0 rgba(35, 37, 45, .16);
      transform: rotateY(180deg);
      display: grid;
      place-items: center;
    }
    .visor {
      position: absolute;
      inset: 22px 16px 20px;
      background: var(--screen);
      border-radius: 22px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 13px;
      overflow: hidden;
    }
    .eyes {
      display: flex;
      gap: 28px;
      transform: translate(var(--lx, 0px), var(--ly, 0px));
      transition: transform .18s ease-out;
    }
    .eyes.blink .eye {
      transform: scaleY(.08);
    }
    .eye {
      width: 19px;
      height: 25px;
      border-radius: 9px;
      background: var(--eye);
      transition: all .22s ease;
    }
    [data-mood="happy"] .eye,
    [data-mood="success"] .eye {
      width: 25px;
      height: 12px;
      background: transparent;
      border: 5px solid var(--eye);
      border-bottom: none;
      border-radius: 25px 25px 0 0;
    }
    [data-mood="excited"] .eye {
      transform: scale(1.2);
      border-radius: 50%;
      height: 21px;
    }
    [data-mood="pressed"] .eye {
      width: 24px;
      height: 12px;
      background: transparent;
      border: 5px solid var(--eye);
      border-top: none;
      border-radius: 0 0 24px 24px;
    }
    .cheek {
      position: absolute;
      top: 59%;
      width: 15px;
      height: 8px;
      border-radius: 50%;
      background: var(--accent);
      opacity: 0;
      transition: opacity .3s ease;
    }
    .cheek--l { left: 15px; }
    .cheek--r { right: 15px; }
    [data-mood="happy"] .cheek,
    [data-mood="excited"] .cheek,
    [data-mood="pressed"] .cheek,
    [data-mood="success"] .cheek {
      opacity: .9;
    }
    .mouth {
      width: 15px;
      height: 5px;
      border-radius: 4px;
      background: var(--eye);
      transition: all .25s ease;
    }
    [data-mood="watching"] .mouth {
      width: 9px;
      height: 9px;
      border-radius: 50%;
    }
    [data-mood="happy"] .mouth {
      width: 30px;
      height: 12px;
      border-radius: 0 0 16px 16px;
    }
    [data-mood="excited"] .mouth {
      width: 22px;
      height: 16px;
      border-radius: 0 0 13px 13px;
    }
    [data-mood="pressed"] .mouth {
      width: 27px;
      height: 15px;
      border-radius: 0 0 14px 14px;
    }
    [data-mood="success"] .mouth {
      width: 38px;
      height: 17px;
      border-radius: 0 0 20px 20px;
    }
    /* back panel + meter */
    .panel {
      width: 116px;
      padding: 12px 10px 10px;
      background: var(--screen);
      border-radius: 16px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
    }
    .panel-lights {
      display: flex;
      gap: 6px;
    }
    .panel-lights i {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--accent);
      animation: bob 1.8s ease-in-out infinite;
    }
    .panel-lights i:nth-child(2) {
      animation-delay: .3s;
      background: var(--yellow);
    }
    .panel-lights i:nth-child(3) {
      animation-delay: .6s;
      background: var(--teal);
    }
    .meter {
      display: flex;
      gap: 5px;
    }
    .meter i {
      width: 15px;
      height: 20px;
      border-radius: 4px;
      background: #3b3e49;
      transition: background .25s ease;
    }
    .meter[data-lvl="1"] i.on { background: #ff5c4d; }
    .meter[data-lvl="2"] i.on { background: #ff9f43; }
    .meter[data-lvl="3"] i.on { background: var(--yellow); }
    .meter[data-lvl="4"] i.on { background: var(--teal); }
    .panel-label {
      font-size: 9px;
      font-weight: 800;
      letter-spacing: 1.5px;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      color: var(--paper);
      white-space: nowrap;
    }
    /* speech bubble */
    .bubble {
      position: absolute;
      bottom: calc(100% + 16px);
      left: 50%;
      transform: translateX(-50%);
      background: var(--shell);
      border: var(--line);
      color: var(--ink);
      font-size: 13px;
      font-weight: 600;
      line-height: 1.35;
      padding: 9px 14px;
      border-radius: 12px;
      width: max-content;
      max-width: 260px;
      text-align: center;
      box-shadow: 3px 3px 0 rgba(35, 37, 45, .9);
      z-index: 3;
    }
    .bubble::after {
      content: '';
      position: absolute;
      top: calc(100% - 5px);
      left: 50%;
      width: 10px;
      height: 10px;
      background: var(--shell);
      border-right: var(--line);
      border-bottom: var(--line);
      transform: translateX(-50%) rotate(45deg);
    }
    .bubble.pop {
      animation: pop .3s cubic-bezier(.34, 1.56, .64, 1);
    }
    @keyframes pop {
      from { transform: translateX(-50%) scale(.8); }
      to { transform: translateX(-50%) scale(1); }
    }
    /* form card */
    .stage .card {
      position: relative !important;
      z-index: 2 !important;
      width: min(440px, calc(100vw - 48px)) !important;
      background: linear-gradient(165deg, #fffefb 0%, #fdfaf3 45%, #f7f1e4 100%) !important;
      border: var(--line) !important;
      border-radius: 20px !important;
      padding: 40px 36px 36px !important;
      box-shadow: 8px 9px 0 rgba(35, 37, 45, .9) !important;
      display: block !important;
      margin-bottom: 0 !important;
    }
    .hand {
      position: absolute;
      top: -16px;
      width: 44px;
      height: 32px;
      background:
        linear-gradient(90deg, transparent 31%, rgba(35, 37, 45, .9) 32%, rgba(35, 37, 45, .9) 36%, transparent 37%, transparent 63%, rgba(35, 37, 45, .9) 64%, rgba(35, 37, 45, .9) 68%, transparent 69%) 0 12px / 100% calc(100% - 12px) no-repeat,
        var(--shell);
      border: var(--line);
      border-radius: 9px 9px 14px 14px;
      z-index: 3;
      transition: transform .25s ease;
    }
    .hand--l { left: calc(50% - 134px); }
    .hand--r { right: calc(50% - 134px); }
    .is-hyped ~ .card .hand {
      transform: translateY(-3px) scaleY(1.08);
    }
    .foot {
      position: absolute;
      bottom: -26px;
      width: 54px;
      height: 34px;
      background: var(--shell);
      border: var(--line);
      border-radius: 9px 9px 14px 14px;
      box-shadow: inset 0 -9px 0 rgba(35, 37, 45, .12);
      z-index: -1;
    }
    .foot--l { left: calc(50% - 110px); }
    .foot--r { right: calc(50% - 110px); }
    .title {
      font-size: 19px;
      font-weight: 800;
      letter-spacing: -.2px;
      text-align: center;
      margin-bottom: 22px;
      color: var(--ink);
    }
    .field {
      display: flex !important;
      align-items: center;
      gap: 10px;
      height: 52px;
      padding: 0 14px;
      margin-bottom: 14px;
      background: var(--field);
      border: 2px solid rgba(35, 37, 45, .22);
      border-radius: 12px;
      transition: border-color .18s ease, box-shadow .18s ease, transform .18s ease;
      cursor: text;
    }
    .field:focus-within {
      border-color: var(--ink);
      box-shadow: 3px 3px 0 var(--accent);
      transform: translate(-1px, -1px);
    }
    .field-icon {
      width: 19px;
      height: 19px;
      fill: var(--muted);
      flex: none;
      transition: fill .18s ease;
    }
    .field:focus-within .field-icon {
      fill: var(--ink);
    }
    .field input {
      flex: 1;
      min-width: 0;
      border: none !important;
      outline: none !important;
      background: transparent !important;
      font: inherit;
      font-size: 14.5px;
      font-weight: 600;
      color: var(--ink) !important;
      box-shadow: none !important;
    }
    .field input::placeholder {
      color: var(--muted);
      font-weight: 500;
    }
    .peek {
      border: none;
      background: none;
      padding: 4px;
      cursor: pointer;
      border-radius: 8px;
      display: grid;
      place-items: center;
    }
    .peek svg {
      width: 20px;
      height: 20px;
      fill: var(--muted);
      transition: fill .18s ease;
    }
    .peek:hover svg,
    .peek[aria-pressed="true"] svg {
      fill: var(--ink);
    }
    .peek:focus-visible {
      outline: 2px solid var(--ink);
    }
    .stage .btn {
      position: relative;
      width: 100% !important;
      height: 54px !important;
      margin-top: 8px;
      border: var(--line) !important;
      border-radius: 12px !important;
      background: var(--accent) !important;
      color: #fff !important;
      font: inherit;
      font-size: 15px !important;
      font-weight: 800 !important;
      letter-spacing: 1px;
      cursor: pointer;
      display: flex !important;
      align-items: center;
      justify-content: center;
      gap: 8px;
      box-shadow: 4px 5px 0 rgba(35, 37, 45, .9) !important;
      transition: transform .18s cubic-bezier(.34, 1.56, .64, 1), box-shadow .18s ease, background .25s ease !important;
    }
    .stage .btn:hover,
    .stage .btn:focus-visible {
      transform: translate(-2px, -2px) !important;
      background: var(--accent-deep) !important;
      box-shadow: 7px 8px 0 rgba(35, 37, 45, .9) !important;
    }
    .stage .btn:active {
      transform: translate(3px, 4px) !important;
      box-shadow: 0 0 0 rgba(35, 37, 45, .9) !important;
    }
    .stage .btn:focus-visible {
      outline: 3px solid var(--ink) !important;
      outline-offset: 3px;
    }
    .btn-bolt {
      display: inline-block;
      opacity: 0;
      transform: translateX(-10px) scale(.4) rotate(-30deg);
      transition: all .3s cubic-bezier(.34, 1.56, .64, 1);
    }
    .stage .btn:hover .btn-bolt,
    .stage .btn:focus-visible .btn-bolt {
      opacity: 1;
      transform: none;
      animation: bolt-jitter .4s ease-in-out infinite;
    }
    @keyframes bolt-jitter {
      0%, 100% { transform: rotate(-7deg) scale(1); }
      50% { transform: rotate(7deg) scale(1.2); }
    }
    .stage .btn.is-success {
      background: var(--teal) !important;
    }
    .stage .card.shake {
      animation: shake .4s ease;
    }
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-7px); }
      50% { transform: translateX(6px); }
      75% { transform: translateX(-3px); }
    }
    .confetti {
      position: absolute;
      width: 10px;
      height: 10px;
      top: 0;
      left: 0;
      border-radius: 2px;
      pointer-events: none;
      z-index: 10;
    }
    @media (max-width: 560px) {
      body.login-page {
        padding-top: 80px !important;
      }
      .stage .card {
        width: min(344px, calc(100vw - 48px)) !important;
        padding: 36px 24px 36px !important;
      }
      .bubble {
        max-width: 210px;
        font-size: 12.5px;
      }
      .hand--l { left: 36px; }
      .hand--r { right: 36px; }
      .foot--l { left: 62px; }
      .foot--r { right: 62px; }
    }
    @media (prefers-reduced-motion: reduce) {
      .robot { animation: none; }
      .antenna-tip, .panel-lights i { animation: none; }
      .head { transition-duration: .01s; }
      .stage .btn:hover .btn-bolt { animation: none; }
      .is-spinning .head { animation: none; }
      .bubble.pop { animation: none; }
      .eyes { transition: none; }
    }
    </style>

    <div class="scene">
      <main class="stage" id="stage">
        <!-- ROBOT VOLT -->
        <div class="robot" id="robot" data-mood="idle">
          <div class="bubble" id="bubble" role="status" aria-live="polite">
            <span id="bubbleText">Hi. I'm Volt. I guard this form.</span>
          </div>
          <div class="antenna" aria-hidden="true">
            <span class="antenna-rod"></span>
            <span class="antenna-tip"></span>
          </div>
          <div class="head3d" aria-hidden="true">
            <div class="head" id="head">
              <span class="ear ear--l"></span>
              <span class="ear ear--r"></span>
              <div class="face face--front">
                <div class="visor">
                  <div class="eyes" id="eyes">
                    <span class="eye eye--l"></span>
                    <span class="eye eye--r"></span>
                  </div>
                  <span class="cheek cheek--l"></span>
                  <span class="cheek cheek--r"></span>
                  <span class="mouth"></span>
                </div>
              </div>
              <div class="face face--back">
                <div class="panel">
                  <span class="panel-lights"><i></i><i></i><i></i></span>
                  <div class="meter" id="meter">
                    <i></i><i></i><i></i><i></i>
                  </div>
                  <p class="panel-label" id="panelLabel">NOT LOOKING</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- LOGIN FORM CARD -->
        <form class="card" id="form" method="POST" novalidate>
          <input type="hidden" name="login" value="1">
          <span class="hand hand--l" aria-hidden="true"></span>
          <span class="hand hand--r" aria-hidden="true"></span>
          
          <h1 class="title">Beep boop. Who goes there?</h1>
          <?php if (!empty($settings['school_name'])): ?>
            <p class="text-center text-muted" style="font-size: 0.78rem; margin-top: -16px; margin-bottom: 18px; font-weight: 700; letter-spacing: 0.5px; text-transform: uppercase;">
              <?= htmlspecialchars($settings['school_name']) ?> &bull; PORTAL ADMIN
            </p>
          <?php endif; ?>

          <!-- Field Username -->
          <label class="field">
            <svg class="field-icon" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 12a4.5 4.5 0 1 0-4.5-4.5A4.5 4.5 0 0 0 12 12Zm0 2c-3.9 0-8 2-8 5v1.5h16V19c0-3-4.1-5-8-5Z" />
            </svg>
            <input id="name" name="username" type="text" placeholder="Username" autocomplete="username" aria-label="Username" required autofocus />
          </label>

          <!-- Field Password -->
          <label class="field">
            <svg class="field-icon" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 2a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5Zm-3 8V7a3 3 0 0 1 6 0v3H9Zm3 4a2 2 0 0 1 1 3.7V19h-2v-1.3a2 2 0 0 1 1-3.7Z" />
            </svg>
            <input id="password" name="password" type="password" placeholder="Password" autocomplete="current-password" aria-label="Password" required />
            <button class="peek" id="togglePass" type="button" aria-label="Show password" aria-pressed="false">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 5c-5 0-9.3 3.1-11 7.5C2.7 16.9 7 20 12 20s9.3-3.1 11-7.5C21.3 8.1 17 5 12 5Zm0 12.5a5 5 0 1 1 5-5 5 5 0 0 1-5 5Zm0-8a3 3 0 1 0 3 3 3 3 0 0 0-3-3Z" />
              </svg>
            </button>
          </label>

          <!-- Submit Button -->
          <button class="btn" id="loginBtn" type="submit">
            <span class="btn-bolt" aria-hidden="true">⚡</span>
            <span class="btn-label" id="btnLabel">LOG ME IN</span>
          </button>
          
          <span class="foot foot--l" aria-hidden="true"></span>
          <span class="foot foot--r" aria-hidden="true"></span>
        </form>

        <!-- Footer Branding -->
        <div class="text-center mt-4" style="font-size: 0.82rem; line-height: 1.6; color: var(--muted);">
            <div><a href="https://ryuexamcbt.web.id" target="_blank" rel="noopener noreferrer" class="font-weight-bold" style="text-decoration: none;" title="Kunjungi Website Resmi RyuExam CBT"><span style="color: #DF2463;">Ryu</span><span style="color: #269DD8;">Exam</span> <span style="color: #1F7FAB;">CBT</span></a> &bull; <span>Versi <span style="color: var(--accent); font-weight: bold;">1.6.8</span></span></div>
            <div style="font-size: 0.78rem;">Developed by <strong style="color: var(--ink);">Rudy Susanto</strong></div>
        </div>
      </main>
    </div>

    <!-- ROBOT SCRIPT -->
    <script>
      (function() {
        const $ = (s) => document.querySelector(s);
        const robot = $('#robot');
        const stage = $('#stage');
        const eyes = $('#eyes');
        const bubble = $('#bubble');
        const bubbleText = $('#bubbleText');
        const meter = $('#meter');
        const meterBars = meter ? [...meter.children] : [];
        const panelLabel = $('#panelLabel');
        const form = $('#form');
        const nameI = $('#name');
        const passI = $('#password');
        const peekBtn = $('#togglePass');
        const btn = $('#loginBtn');
        const btnLabel = $('#btnLabel');
        const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
        let done = false;
        let lastSaid = '';

        const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
        function setMood(mood) {
          if (!done && robot) robot.dataset.mood = mood;
        }
        function say(text) {
          if (text === lastSaid) return;
          lastSaid = text;
          if (!bubbleText || !bubble) return;
          bubbleText.textContent = text;
          bubble.classList.remove('pop');
          void bubble.offsetWidth;
          bubble.classList.add('pop');
        }
        function look(x, y) {
          if (!eyes) return;
          eyes.style.setProperty('--lx', `${x}px`);
          eyes.style.setProperty('--ly', `${y}px`);
        }
        const head3d = document.querySelector('.head3d');
        function tilt(ry, rx) {
          if (!head3d) return;
          head3d.style.setProperty('--ry', `${ry}deg`);
          head3d.style.setProperty('--rx', `${rx}deg`);
        }
        function followTyping(input) {
          const ratio = Math.min(input.value.length / 22, 1);
          look(-6 + 12 * ratio, 5);
          tilt(-5 + 10 * ratio, -8);
        }
        function turnAway(on) {
          if (robot) robot.classList.toggle('is-turned', on);
        }

        // username events
        if (nameI) {
          nameI.addEventListener('focus', () => {
            turnAway(false);
            setMood('watching');
            say(pick(["A visitor. State your name.", "Typing detected. Go on, I'm watching."]));
            followTyping(nameI);
          });
          nameI.addEventListener('input', () => {
            followTyping(nameI);
            const v = nameI.value.trim();
            if (v.length >= 2) say(`${v}. Solid name. Filed forever.`);
            else if (v.length === 0) say("Deleted. I've already forgotten it. Mostly.");
          });
        }

        // password events
        if (passI) {
          passI.addEventListener('focus', () => {
            setMood('shy');
            turnAway(true);
            look(0, 0);
            tilt(0, 0);
            say("A secret? Say no more. *turns around*");
            if (panelLabel) panelLabel.textContent = 'NOT LOOKING';
          });
          passI.addEventListener('blur', (e) => {
            if (e.relatedTarget === peekBtn) return;
            turnAway(false);
          });
          passI.addEventListener('input', () => {
            const v = passI.value;
            let score = 0;
            if (v.length >= 6) score++;
            if (/[a-z]/.test(v) && /[A-Z]/.test(v)) score++;
            if (/\d/.test(v)) score++;
            if (/[^a-zA-Z0-9]/.test(v)) score++;
            if (v.length > 0 && score === 0) score = 1;
            if (meter) {
              meter.dataset.lvl = score;
              meterBars.forEach((bar, i) => bar.classList.toggle('on', i < score));
            }
            if (panelLabel) {
              panelLabel.textContent = v.length === 0
                ? 'NOT LOOKING'
                : ['NOT LOOKING', 'TOO SHORT', 'GETTING THERE', 'STRONG', 'FORT KNOX'][score];
            }
          });
        }

        // peek toggle
        if (peekBtn && passI) {
          peekBtn.addEventListener('click', () => {
            const show = passI.type === 'password';
            passI.type = show ? 'text' : 'password';
            peekBtn.setAttribute('aria-pressed', String(show));
            peekBtn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            if (show) say('Revealing it? Good thing I\'m facing the wall.');
            passI.focus();
          });
        }

        // button hover/press
        function hype(on) {
          if (done || !robot) return;
          if (on && robot.classList.contains('is-pressed')) return;
          robot.classList.toggle('is-hyped', on);
          if (on) {
            turnAway(false);
            setMood('excited');
            say(pick(['Ooh. Do it. Press it.', 'This is my favorite part.']));
          } else {
            setMood('idle');
            say('The button misses you already.');
          }
        }
        if (btn) {
          btn.addEventListener('mouseenter', () => hype(true));
          btn.addEventListener('mouseleave', () => hype(false));
          btn.addEventListener('focus', () => hype(true));
          btn.addEventListener('blur', () => hype(false));

          let pressTimer;
          btn.addEventListener('pointerdown', () => {
            clearTimeout(pressTimer);
            if (robot) {
              robot.classList.add('is-pressed');
              robot.dataset.mood = 'pressed';
            }
            say(pick(['Ahh. That’s the stuff.', 'Mmm. Satisfying.', 'Beep. Do that again.']));
          });
          function releasePress() {
            clearTimeout(pressTimer);
            pressTimer = setTimeout(() => {
              if (robot) {
                robot.classList.remove('is-pressed');
                if (robot.dataset.mood === 'pressed') {
                  robot.dataset.mood = done ? 'success' : 'excited';
                }
              }
            }, 340);
          }
          btn.addEventListener('pointerup', releasePress);
          btn.addEventListener('pointercancel', releasePress);
          btn.addEventListener('pointerleave', () => {
            if (robot && robot.classList.contains('is-pressed')) releasePress();
          });
        }

        // submit form
        if (form) {
          form.addEventListener('submit', (e) => {
            if (done) return;
            if (!nameI.value.trim()) {
              e.preventDefault();
              say("Still don't know your name.");
              setMood('watching');
              form.classList.remove('shake');
              void form.offsetWidth;
              form.classList.add('shake');
              nameI.focus();
              return;
            }
            if (!passI.value) {
              e.preventDefault();
              say("A password would help.");
              setMood('watching');
              form.classList.remove('shake');
              void form.offsetWidth;
              form.classList.add('shake');
              passI.focus();
              return;
            }
            
            // Success animation then submit form
            e.preventDefault();
            done = true;
            turnAway(false);
            if (robot) {
              robot.classList.remove('is-hyped');
              robot.dataset.mood = 'success';
            }
            say(`Access granted. Welcome, ${nameI.value.trim()}.`);
            if (btn) btn.classList.add('is-success');
            if (btnLabel) btnLabel.textContent = 'ACCESS GRANTED ✓';
            look(0, 0);
            tilt(0, 0);
            if (!reduceMotion && robot) {
              robot.classList.add('is-spinning');
              confetti();
            }
            setTimeout(() => {
              form.submit();
            }, 550);
          });
        }

        // blinking loop
        (function blinkLoop() {
          setTimeout(() => {
            if (robot && robot.dataset.mood !== 'success' && !robot.classList.contains('is-turned') && eyes) {
              eyes.classList.add('blink');
              setTimeout(() => eyes.classList.remove('blink'), 150);
            }
            blinkLoop();
          }, 2600 + Math.random() * 2600);
        })();

        // mouse tracking
        let rafPending = false;
        document.addEventListener('mousemove', (e) => {
          const active = document.activeElement;
          if (done || (active && active.tagName === 'INPUT') || !robot) return;
          if (rafPending) return;
          rafPending = true;
          requestAnimationFrame(() => {
            rafPending = false;
            const rect = robot.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            const dx = Math.max(-1, Math.min(1, (e.clientX - cx) / 260));
            const dy = Math.max(-1, Math.min(1, (e.clientY - cy) / 260));
            look(dx * 7, dy * 6);
            if (!robot.classList.contains('is-turned')) tilt(dx * 12, -dy * 9);
          });
        });

        // confetti
        function confetti() {
          const colors = ['#ff6b4b', '#2ec4b6', '#ffc53d', '#23252d', '#fffdf8'];
          if (!btn) return;
          const origin = btn.getBoundingClientRect();
          const host = document.querySelector('.scene');
          if (!host) return;
          const hostRect = host.getBoundingClientRect();
          const ox = origin.left - hostRect.left + origin.width / 2;
          const oy = origin.top - hostRect.top;
          for (let i = 0; i < 70; i++) {
            const bit = document.createElement('span');
            bit.className = 'confetti';
            bit.style.background = pick(colors);
            if (Math.random() > .5) bit.style.borderRadius = '50%';
            host.appendChild(bit);
            const angle = -Math.PI / 2 + (Math.random() - .5) * 1.6;
            const speed = 240 + Math.random() * 380;
            const tx = Math.cos(angle) * speed;
            const ty = Math.sin(angle) * speed;
            bit.animate(
              [
                { transform: `translate(${ox}px, ${oy}px) rotate(0deg) scale(1)`, opacity: 1 },
                { transform: `translate(${ox + tx}px, ${oy + ty + 320}px) rotate(${540 * (Math.random() > .5 ? 1 : -1)}deg) scale(.6)`, opacity: 0 }
              ],
              { duration: 1100 + Math.random() * 700, easing: 'cubic-bezier(.15,.6,.35,1)' }
            ).onfinish = function () { bit.remove(); };
          }
        }

        // Show PHP Login Error if exists
        <?php if (!empty($error)): ?>
        window.addEventListener('load', () => {
          setTimeout(() => {
            say("<?= addslashes($error) ?>");
            setMood('watching');
            if (form) {
              form.classList.remove('shake');
              void form.offsetWidth;
              form.classList.add('shake');
            }
          }, 350);
        });
        <?php endif; ?>
      })();
    </script>
    <?php else: ?>
    
    <!-- Modals are now included inside their respective view files -->

    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav align-items-center">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <?php if (!empty($settings['school_name'])): ?>
                <li class="nav-item d-flex align-items-center ml-1">
                    <?php if (!empty($settings['school_logo']) && file_exists($settings['school_logo'])): 
                        $logoVersion = filemtime($settings['school_logo']);
                    ?>
                        <img src="<?= htmlspecialchars($settings['school_logo']) ?>?v=<?= $logoVersion ?>" alt="Logo Sekolah" class="img-circle elevation-1 mr-2" style="max-height: 28px; max-width: 28px; object-fit: contain; background: #fff; padding: 1px;">
                    <?php else: ?>
                        <i class="fas fa-school text-primary mr-2" style="font-size: 1.1rem;"></i>
                    <?php endif; ?>
                    <span class="font-weight-bold text-dark" style="font-size: 0.95rem;">
                        <?= htmlspecialchars($settings['school_name']) ?>
                    </span>
                </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ml-auto align-items-center">
                <!-- User Profile & Logout Dropdown (Sesuai Referensi Gambar) -->
                <li class="nav-item dropdown user-dropdown-menu">
                    <a class="nav-link d-flex align-items-center" data-toggle="dropdown" href="#" role="button" aria-expanded="false" style="cursor: pointer;">
                        <div class="header-user-avatar mr-2">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="d-flex flex-column text-left mr-2" style="line-height: 1.2;">
                            <span class="header-user-greeting">Selamat datang,</span>
                            <span class="header-user-name">
                                <?= htmlspecialchars($user_name) ?>
                            </span>
                        </div>
                        <i class="fas fa-caret-down text-muted ml-1" style="font-size: 0.85rem;"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow-sm border" style="min-width: 180px;">
                        <div class="px-3 py-2 border-bottom">
                            <div class="font-weight-bold text-dark text-truncate" style="font-size: 0.88rem;"><?= htmlspecialchars($user_name) ?></div>
                            <div class="text-muted text-truncate" style="font-size: 0.78rem; font-weight: 300; letter-spacing: 0.2px;"><?= htmlspecialchars($user_role === 'admin' ? ($_SESSION['admin_role'] ?? 'Super Admin') : 'Guru') ?></div>
                        </div>
                        <a href="?logout=1" class="dropdown-item d-flex align-items-center py-2 text-danger">
                            <i class="fas fa-power-off mr-2" style="font-size: 0.9rem; width: 18px;"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-light-primary elevation-1">
            <!-- Brand Logo -->
            <a href="admin.php" class="brand-link d-flex align-items-center px-3" style="gap: 10px; height: 57px; text-decoration: none;">
                <i class="fas fa-desktop brand-image text-info" style="font-size: 1.65rem; line-height: 1; margin: 0; float: none; display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; flex-shrink: 0;"></i>
                <span class="brand-text font-weight-bold" style="font-size: 1.15rem; line-height: 1; letter-spacing: 0.2px;">
                    <span style="color: #DF2463;">Ryu</span><span style="color: #38bdf8;">Exam CBT</span>
                </span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                        <?php if ($user_role === 'guru' || admin_has_permission('dashboard')): ?>
                        <li class="nav-item">
                            <a href="?page=dashboard" class="nav-link <?= $page == 'dashboard' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if ($user_role === 'admin'): ?>
                        <?php if (admin_has_permission('kelas') || admin_has_permission('siswa') || admin_has_permission('guru') || admin_has_permission('mata_pelajaran') || admin_has_permission('jenis_ujian')): ?>
                        <li class="nav-header mt-2">DATA MASTER</li>
                        <?php if (admin_has_permission('kelas')): ?>
                        <li class="nav-item">
                            <a href="?page=kelas" class="nav-link <?= $page == 'kelas' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-chalkboard"></i>
                                <p>Data Kelas</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('siswa')): ?>
                        <li class="nav-item">
                            <a href="?page=siswa" class="nav-link <?= $page == 'siswa' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-users"></i>
                                <p>Data Siswa</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('guru')): ?>
                        <li class="nav-item">
                            <a href="?page=guru" class="nav-link <?= $page == 'guru' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-chalkboard-teacher"></i>
                                <p>Data Guru</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('mata_pelajaran')): ?>
                        <li class="nav-item">
                            <a href="?page=mata_pelajaran" class="nav-link <?= $page == 'mata_pelajaran' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-book"></i>
                                <p>Mata Pelajaran</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('jenis_ujian')): ?>
                        <li class="nav-item">
                            <a href="?page=jenis_ujian" class="nav-link <?= $page == 'jenis_ujian' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-tags"></i>
                                <p>Jenis Ujian</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php endif; ?>

                        <?php if (admin_has_permission('soal') || admin_has_permission('mapel') || admin_has_permission('cetak_kartu')): ?>
                        <li class="nav-header mt-2">MANAJEMEN UJIAN</li>
                        <?php if (admin_has_permission('soal')): ?>
                        <li class="nav-item">
                            <a href="?page=soal" class="nav-link <?= $page == 'soal' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-file-alt"></i>
                                <p>Bank Soal</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('mapel')): ?>
                        <li class="nav-item">
                            <a href="?page=mapel" class="nav-link <?= $page == 'mapel' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-calendar-alt"></i>
                                <p>Jadwal Ujian & Token</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('cetak_kartu')): ?>
                        <li class="nav-item">
                            <a href="?page=cetak_kartu" class="nav-link <?= $page == 'cetak_kartu' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-id-card"></i>
                                <p>Cetak Kartu Peserta</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php endif; ?>

                        <?php if (admin_has_permission('status') || admin_has_permission('analisis')): ?>
                        <li class="nav-header mt-2">PELAKSANAAN</li>
                        <?php if (admin_has_permission('status')): ?>
                        <li class="nav-item">
                            <a href="?page=status" class="nav-link <?= $page == 'status' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-desktop"></i>
                                <p>Status Ujian</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('analisis')): ?>
                        <li class="nav-item">
                            <a href="?page=analisis" class="nav-link <?= $page == 'analisis' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <p>Analisis Soal</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php endif; ?>

                        <?php if (admin_has_permission('pengaturan') || admin_has_permission('log') || admin_has_permission('panduan')): ?>
                        <li class="nav-header mt-2">SISTEM</li>
                        <?php if (admin_has_permission('pengaturan')): ?>
                        <li class="nav-item">
                            <a href="?page=pengaturan" class="nav-link <?= $page == 'pengaturan' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-cogs"></i>
                                <p>Pengaturan</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('log')): ?>
                        <li class="nav-item">
                            <a href="?page=log" class="nav-link <?= $page == 'log' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-history"></i>
                                <p>Log Pembaruan</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (admin_has_permission('panduan')): ?>
                        <li class="nav-item">
                            <a href="?page=panduan" class="nav-link <?= $page == 'panduan' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-book-reader text-warning"></i>
                                <p>Petunjuk</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php else: ?>
                        <!-- MENU KHUSUS ROLE GURU -->
                        <li class="nav-header mt-2">MANAJEMEN SOAL</li>
                        <li class="nav-item">
                            <a href="?page=soal" class="nav-link <?= $page == 'soal' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-file-upload"></i>
                                <p>Bank Soal / Upload</p>
                            </a>
                        </li>

                        <li class="nav-header mt-2">HASIL & EVALUASI</li>
                        <li class="nav-item">
                            <a href="?page=status" class="nav-link <?= $page == 'status' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-desktop"></i>
                                <p>Status Ujian & Nilai</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?page=analisis" class="nav-link <?= $page == 'analisis' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <p>Analisis Butir Soal</p>
                            </a>
                        </li>

                        <li class="nav-header mt-2">PANDUAN & BANTUAN</li>
                        <li class="nav-item">
                            <a href="?page=panduan" class="nav-link <?= $page == 'panduan' ? 'active' : '' ?>">
                                <i class="nav-icon fas fa-book-reader text-warning"></i>
                                <p>Petunjuk</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

            <!-- Main content -->
            <section class="content pt-4 px-3">
                
                <!-- INCLUDED SECTIONS -->
                <?php 
                if ($page == 'dashboard' && ($user_role === 'guru' || admin_has_permission('dashboard'))) {
                    include 'views/admin_dashboard.php';
                } elseif ($page == 'kelas' && $user_role === 'admin' && admin_has_permission('kelas')) {
                    include 'views/admin_kelas.php';
                } elseif ($page == 'siswa' && $user_role === 'admin' && admin_has_permission('siswa')) {
                    include 'views/admin_siswa.php';
                } elseif ($page == 'guru' && $user_role === 'admin' && admin_has_permission('guru')) {
                    include 'views/admin_guru.php';
                } elseif ($page == 'mata_pelajaran' && $user_role === 'admin' && admin_has_permission('mata_pelajaran')) {
                    include 'views/admin_mata_pelajaran.php';
                } elseif ($page == 'jenis_ujian' && $user_role === 'admin' && admin_has_permission('jenis_ujian')) {
                    include 'views/admin_jenis_ujian.php';
                } elseif ($page == 'mapel' && $user_role === 'admin' && admin_has_permission('mapel')) {
                    include 'views/admin_mapel.php';
                } elseif ($page == 'cetak_kartu' && $user_role === 'admin' && admin_has_permission('cetak_kartu')) {
                    include 'views/admin_cetak_kartu.php';
                } elseif ($page == 'soal' && ($user_role === 'guru' || admin_has_permission('soal'))) {
                    include 'views/admin_soal.php';
                } elseif ($page == 'panduan' && ($user_role === 'guru' || admin_has_permission('panduan'))) {
                    include 'views/admin_panduan.php';
                } elseif ($page == 'status' && ($user_role === 'guru' || admin_has_permission('status'))) {
                    include 'views/admin_status.php';
                } elseif ($page == 'analisis' && ($user_role === 'guru' || admin_has_permission('analisis'))) {
                    include 'views/admin_analisis.php';
                } elseif ($page == 'pengaturan' && $user_role === 'admin' && admin_has_permission('pengaturan')) {
                    include 'views/admin_pengaturan.php';
                } elseif ($page == 'log' && $user_role === 'admin' && admin_has_permission('log')) {
                    include 'views/admin_log.php';
                } else {
                    include 'views/admin_dashboard.php';
                }
                ?>
            </section>
        </div>
        
        <footer class="main-footer sticky-bottom">
            <strong><a href="https://ryuexamcbt.web.id" target="_blank" rel="noopener noreferrer" style="text-decoration: none;" title="Kunjungi Website Resmi RyuExam CBT"><?= !empty($settings['app_name']) ? htmlspecialchars($settings['app_name']) : '<span style="color: #DF2463;">Ryu</span><span style="color: #269DD8;">Exam</span> <span style="color: #1F7FAB;">CBT</span>' ?></a> &copy; <?= date('Y') ?>.</strong>
            Developed by <b class="text-primary">Rudy Susanto</b>
            <div class="float-right d-none d-sm-inline">
                <b>Versi</b> <span class="text-primary font-weight-bold">1.6.8</span>
            </div>
        </footer>
    </div>
    <?php endif; ?>
    
    <script>
    <?php if ($logged_in): ?>
        window.currentUserRole = <?= json_encode($user_role) ?>;
        // Routing replaces Tab Switching Logic

        // Sorting state
        let currentSortCol = 'class_name';
        let currentSortDir = 'asc';
        let currentLiveExamId = null;
        
        function setSort(col) {
            if (currentSortCol === col) {
                currentSortDir = currentSortDir === 'asc' ? 'desc' : 'asc';
            } else {
                currentSortCol = col;
                currentSortDir = 'asc';
            }
            liveCurrentPage = 1;
            if (currentLiveExamId !== null) {
                fetchLiveStatus();
            }
        }
        
        function filterExamList() {
            const query = document.getElementById('exam-list-search').value.toLowerCase();
            const rows = document.querySelectorAll('#status-exam-list tbody tr');
            
            rows.forEach(row => {
                const nameCell = row.querySelector('.exam-name-cell') || row.querySelector('td:nth-child(3)');
                if (nameCell) {
                    const name = nameCell.textContent.toLowerCase();
                    if (name.includes(query)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            });
            updateStatusExamBulkUI();
        }
        
        let examListSortCol = null;
        let examListSortDir = 'asc';
        
        function sortExamList(colIndex) {
            const tbody = document.querySelector('#status-exam-list tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            if (rows.length === 0 || rows[0].querySelector('td[colspan]')) return;
            
            if (examListSortCol === colIndex) {
                examListSortDir = examListSortDir === 'asc' ? 'desc' : 'asc';
            } else {
                examListSortCol = colIndex;
                examListSortDir = 'asc';
            }
            
            rows.sort((a, b) => {
                let valA = a.children[colIndex].textContent.trim();
                let valB = b.children[colIndex].textContent.trim();
                
                if (colIndex === 5 || colIndex === 6) {
                    valA = parseInt(valA) || 0;
                    valB = parseInt(valB) || 0;
                } else {
                    valA = valA.toLowerCase();
                    valB = valB.toLowerCase();
                }
                
                if (valA < valB) return examListSortDir === 'asc' ? -1 : 1;
                if (valA > valB) return examListSortDir === 'asc' ? 1 : -1;
                return 0;
            });
            
            rows.forEach(row => tbody.appendChild(row));
            
            let i = 1;
            rows.forEach(row => {
                row.children[1].textContent = i++;
            });
        }

        function updateStatusExamBulkUI() {
            const allCbs = document.querySelectorAll('.cb-status-exam');
            const checkedBoxes = document.querySelectorAll('.cb-status-exam:checked');
            const size = checkedBoxes.length;
            const btn = document.getElementById('btn-bulk-download-status');
            const countEl = document.getElementById('selected-status-count');
            if (countEl) countEl.innerText = size;
            if (btn) {
                btn.style.display = size > 0 ? 'inline-block' : 'none';
            }
            const masterCb = document.getElementById('cb-all-status-exam');
            if (masterCb && allCbs.length > 0) {
                const visibleCbs = Array.from(allCbs).filter(cb => {
                    const row = cb.closest('tr');
                    return !row || row.style.display !== 'none';
                });
                if (visibleCbs.length > 0) {
                    masterCb.checked = visibleCbs.every(cb => cb.checked);
                } else {
                    masterCb.checked = false;
                }
            }
        }

        function toggleAllStatusExam(masterCb) {
            const checked = masterCb.checked;
            const cbs = document.querySelectorAll('.cb-status-exam');
            cbs.forEach(cb => {
                const row = cb.closest('tr');
                if (!row || row.style.display !== 'none') {
                    cb.checked = checked;
                }
            });
            updateStatusExamBulkUI();
        }

        function toggleStatusExamSelection(cb) {
            updateStatusExamBulkUI();
        }
        
        let liveTokenCountdownTimer = null;
        let liveTokenRemainingSeconds = 0;
        let liveStatusPollingTimer = null;

        function openLiveStatus(examId, examName, token) {
            currentLiveExamId = examId;
            if (examName) {
                document.title = examName;
            }
            clearInterval(liveTokenCountdownTimer);
            if (liveStatusPollingTimer) clearInterval(liveStatusPollingTimer);
            document.getElementById('live-exam-title').innerText = examName;
            document.getElementById('live-exam-token').innerText = token || '-';
            const dynInfo = document.getElementById('token-dynamic-info');
            if (dynInfo) dynInfo.style.display = 'none';
            document.getElementById('status-exam-list').style.display = 'none';
            document.getElementById('status-live-view').style.display = 'block';
            document.getElementById('live-status-tbody').innerHTML = '<tr><td colspan="8" class="text-center">Memuat data...</td></tr>';
            fetchLiveStatus();
            // Auto refresh live status setiap 10 detik (optimal & hemat koneksi server)
            liveStatusPollingTimer = setInterval(fetchLiveStatus, 10000);
        }
        
        function closeLiveStatus() {
            currentLiveExamId = null;
            document.title = "<?= !empty($settings['school_name']) ? htmlspecialchars(addslashes($settings['school_name'])) . ' - Admin Panel' : 'Admin Panel - CBT' ?>";
            clearInterval(liveTokenCountdownTimer);
            if (liveStatusPollingTimer) {
                clearInterval(liveStatusPollingTimer);
                liveStatusPollingTimer = null;
            }
            document.getElementById('status-live-view').style.display = 'none';
            document.getElementById('status-exam-list').style.display = 'block';
        }

        let liveCurrentPage = 1;
        let liveItemsPerPage = 10;
        let liveStatusData = [];
        let currentFilteredData = [];
        let selectedStatusIds = new Set();
        
        function toggleStatusSelection(id, checked) {
            if (checked) {
                selectedStatusIds.add(id);
            } else {
                selectedStatusIds.delete(id);
            }
            updateSelectAllCheckbox();
        }
        
        function toggleAllStatus() {
            const cbAll = document.getElementById('cb-all-status');
            const isChecked = cbAll.checked;
            
            const paginatedData = liveItemsPerPage > 0 
                ? currentFilteredData.slice((liveCurrentPage - 1) * liveItemsPerPage, Math.min(liveCurrentPage * liveItemsPerPage, currentFilteredData.length))
                : currentFilteredData;
            
            paginatedData.forEach(s => {
                if (isChecked) {
                    selectedStatusIds.add(s.id);
                } else {
                    selectedStatusIds.delete(s.id);
                }
            });
            renderLiveStatusTable();
        }
        
        function updateSelectAllCheckbox() {
            const cbAll = document.getElementById('cb-all-status');
            if (!cbAll) return;
            
            if (currentFilteredData.length === 0) {
                cbAll.checked = false;
                return;
            }
            
            const paginatedData = liveItemsPerPage > 0 
                ? currentFilteredData.slice((liveCurrentPage - 1) * liveItemsPerPage, Math.min(liveCurrentPage * liveItemsPerPage, currentFilteredData.length))
                : currentFilteredData;
            
            let allSelected = true;
            if (paginatedData.length === 0) allSelected = false;
            paginatedData.forEach(s => {
                if (!selectedStatusIds.has(s.id)) allSelected = false;
            });
            cbAll.checked = allSelected;
        }

        async function bulkReset() {
            if (selectedStatusIds.size === 0) {
                Swal.fire('Oops', 'Pilih minimal satu siswa untuk dikeluarkan.', 'warning');
                return;
            }
            
            const result = await Swal.fire({
                title: 'Keluarkan Siswa Terpilih?',
                html: `Keluarkan <strong>${selectedStatusIds.size} siswa terpilih</strong> dari sesi ujian saat ini?<br><strong class="text-success"><i class="fas fa-check-circle mr-1"></i>Seluruh jawaban siswa tetap aman dan TIDAK akan hilang.</strong><br><small class="text-muted">Siswa dapat login kembali untuk melanjutkan ujian.</small>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ffc107',
                confirmButtonText: '<i class="fas fa-sign-out-alt mr-1"></i> Ya, Keluarkan Siswa',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const ids = Array.from(selectedStatusIds);
                Swal.fire({ title: 'Memproses...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
                
                try {
                    for (let id of ids) {
                        const fd = new FormData();
                        fd.append('student_id', id);
                        if (currentLiveExamId) {
                            fd.append('exam_id', currentLiveExamId);
                        }
                        await fetch('api.php?action=reset_student', { method: 'POST', body: fd });
                    }
                    selectedStatusIds.clear();
                    Swal.fire('Berhasil!', 'Semua siswa terpilih berhasil dikeluarkan. Jawaban tetap aman tersimpan.', 'success').then(() => fetchLiveStatus());
                } catch(e) {
                    Swal.fire('Error', 'Gagal memproses pengeluaran siswa.', 'error');
                }
            }
        }

        async function resetAllExamStatus() {
            if (!currentLiveExamId) return;
            const examName = document.getElementById('live-exam-title')?.innerText || 'Ujian';
            const result = await Swal.fire({
                title: 'Reset Seluruh Status Ujian Ini?',
                html: `Apakah Anda yakin ingin <strong>mereset seluruh riwayat pengerjaan & nilai</strong> siswa untuk jadwal <strong>${examName}</strong>?<br><small class="text-danger">Seluruh siswa yang ada pada jadwal ini akan berstatus "Belum Mulai" kembali.</small>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-undo mr-1"></i> Ya, Reset Semua',
                cancelButtonText: 'Batal'
            });
            if (!result.isConfirmed) return;

            Swal.fire({ title: 'Memproses reset...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            const fd = new FormData();
            fd.append('action', 'reset_all_exam_status');
            fd.append('exam_id', currentLiveExamId);

            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    selectedStatusIds.clear();
                    Swal.fire('Berhasil!', json.message, 'success').then(() => fetchLiveStatus());
                } else {
                    Swal.fire('Gagal', json.message || 'Terjadi kesalahan.', 'error');
                }
            } catch(e) {
                Swal.fire('Error', 'Gagal memproses reset: ' + e.message, 'error');
            }
        }
        
        async function recalculateLiveExamScores() {
            if (!currentLiveExamId) return;
            const examName = document.getElementById('live-exam-title')?.innerText || 'Ujian';
            const result = await Swal.fire({
                title: 'Hitung Ulang Nilai Siswa?',
                html: `Sistem akan mencocokkan kembali jawaban seluruh siswa pada jadwal <strong>${examName}</strong> dengan <strong>kunci jawaban terbaru di Bank Soal</strong>.<br><br><small class="text-muted">Nilai siswa yang sudah selesai akan langsung terupdate otomatis.</small>`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#007bff',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-calculator mr-1"></i> Ya, Hitung Ulang!',
                cancelButtonText: 'Batal'
            });
            if (!result.isConfirmed) return;

            Swal.fire({ title: 'Memproses rekalkulasi nilai...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            const fd = new FormData();
            fd.append('action', 'recalculate_scores');
            fd.append('exam_id', currentLiveExamId);

            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    Swal.fire('Berhasil!', json.message, 'success').then(() => fetchLiveStatus());
                } else {
                    Swal.fire('Gagal', json.message || 'Terjadi kesalahan.', 'error');
                }
            } catch(e) {
                Swal.fire('Error', 'Gagal memproses rekalkulasi: ' + e.message, 'error');
            }
        }
        
        async function bulkForceSubmit() {
            if (selectedStatusIds.size === 0) {
                Swal.fire('Oops', 'Pilih minimal satu siswa.', 'warning');
                return;
            }
            
            const result = await Swal.fire({
                title: 'Bulk Selesai?',
                text: `Yakin ingin menyelesaikan ujian paksa untuk ${selectedStatusIds.size} siswa terpilih? (Status selain "Sedang Mengerjakan" mungkin akan error/diabaikan)`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Selesai',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const ids = Array.from(selectedStatusIds);
                Swal.fire({ title: 'Memproses...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
                
                try {
                    for (let id of ids) {
                        const fd = new FormData();
                        fd.append('student_id', id);
                        await fetch('api.php?action=force_submit', { method: 'POST', body: fd });
                    }
                    selectedStatusIds.clear();
                    Swal.fire('Berhasil!', 'Proses selesai paksa berhasil dilakukan.', 'success').then(() => fetchLiveStatus());
                } catch(e) {
                    Swal.fire('Error', 'Gagal memproses bulk selesai.', 'error');
                }
            }
        }
        async function downloadAllAnswersExcel() {
            if (!currentLiveExamId) {
                Swal.fire('Error', 'Mata pelajaran belum dipilih', 'error');
                return;
            }
            
            try {
                Swal.fire({
                    title: 'Memproses Excel...',
                    text: 'Sedang menyiapkan data jawaban seluruh siswa...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });
                
                const response = await fetch(`api.php?action=get_all_answers_data&exam_id=${currentLiveExamId}`);
                const res = await response.json();
                
                if (res.status !== 'success') {
                    Swal.fire('Gagal', res.message || 'Gagal memuat data jawaban', 'error');
                    return;
                }
                
                const questions = res.questions || [];
                const students = res.students || [];
                const examName = res.exam_name || 'Ujian';
                
                if (students.length === 0) {
                    Swal.fire('Informasi', 'Tidak ada siswa yang terdaftar pada mata pelajaran ini.', 'info');
                    return;
                }
                
                // Build 2D array for SheetJS
                const sheetData = [];
                
                // Table Headers (Row index 0)
                const headerRow = ['No', 'Nama Siswa', 'Kelas', 'Status Ujian', 'Total Skor', 'B/S'];
                questions.forEach((q, i) => {
                    const qTypeName = q.type === 'essay' ? 'Esai' : (q.type === 'complex_mc' ? 'PGK' : (q.type === 'true_false' ? 'B-S' : 'PG'));
                    headerRow.push(`Soal ${i + 1} (${qTypeName})`);
                });
                sheetData.push(headerRow);
                
                // Key Row (Row index 1)
                const keyRow = ['', '', '', '', '', ''];
                questions.forEach((q) => {
                    keyRow.push(q.key || '-');
                });
                sheetData.push(keyRow);
                
                // Student Data Rows (Row index 2 onwards)
                students.forEach((s, idx) => {
                    let bsText = '-';
                    if (s.bs !== undefined && s.bs !== null && s.bs !== '') {
                        bsText = s.bs;
                    } else if (s.correct_count !== undefined && s.wrong_count !== undefined) {
                        bsText = `${s.correct_count}/${s.wrong_count}`;
                    }
                    const row = [
                        idx + 1,
                        s.name,
                        s.class_name,
                        s.status,
                        s.score,
                        bsText
                    ];
                    questions.forEach((q) => {
                        const ans = s.answers && s.answers[q.index] !== undefined ? s.answers[q.index] : '-';
                        row.push(ans);
                    });
                    sheetData.push(row);
                });
                
                // Worksheet creation
                const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
                
                // Column Widths
                const colWidths = [
                    { wch: 6 },  // No
                    { wch: 35 }, // Nama Siswa
                    { wch: 15 }, // Kelas
                    { wch: 20 }, // Status Ujian
                    { wch: 14 }, // Total Skor
                    { wch: 12 }  // B/S
                ];
                questions.forEach((q, i) => {
                    const qTypeName = q.type === 'essay' ? 'Esai' : (q.type === 'complex_mc' ? 'PGK' : (q.type === 'true_false' ? 'B-S' : 'PG'));
                    const label = `Soal ${i + 1} (${qTypeName})`;
                    colWidths.push({ wch: Math.max(label.length + 4, 15) });
                });
                worksheet['!cols'] = colWidths;
                
                // Merged cells: Vertikal merge kolom A sampai F pada baris 1 dan 2 (A1:A2, B1:B2, C1:C2, D1:D2, E1:E2, F1:F2)
                worksheet['!merges'] = [
                    { s: { r: 0, c: 0 }, e: { r: 1, c: 0 } }, // A1:A2 (No)
                    { s: { r: 0, c: 1 }, e: { r: 1, c: 1 } }, // B1:B2 (Nama Siswa)
                    { s: { r: 0, c: 2 }, e: { r: 1, c: 2 } }, // C1:C2 (Kelas)
                    { s: { r: 0, c: 3 }, e: { r: 1, c: 3 } }, // D1:D2 (Status Ujian)
                    { s: { r: 0, c: 4 }, e: { r: 1, c: 4 } }, // E1:E2 (Total Skor)
                    { s: { r: 0, c: 5 }, e: { r: 1, c: 5 } }  // F1:F2 (B/S)
                ];
                
                // Styles definition
                const borderThin = {
                    top: { style: 'thin', color: { rgb: '000000' } },
                    bottom: { style: 'thin', color: { rgb: '000000' } },
                    left: { style: 'thin', color: { rgb: '000000' } },
                    right: { style: 'thin', color: { rgb: '000000' } }
                };
                
                // Header (Yellow Background, bold, center)
                const headerStyle = {
                    fill: { fgColor: { rgb: 'FFFF00' } },
                    font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderThin
                };
                
                // Key Row Style (Soft Yellow Background, bold, center)
                const keyRowStyle = {
                    fill: { fgColor: { rgb: 'FFF9C4' } },
                    font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderThin
                };
                
                // Data Row Styles
                const cellStyleCenter = {
                    font: { name: 'Calibri', sz: 11, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderThin
                };
                
                const cellStyleLeft = {
                    font: { name: 'Calibri', sz: 11, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left', wrapText: true },
                    border: borderThin
                };
                
                const cellStyleScore = {
                    font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center' },
                    border: borderThin
                };
                
                const totalCols = headerRow.length;
                const totalRows = sheetData.length;
                
                // Row heights
                const rowHeights = [];
                for (let r = 0; r < totalRows; r++) {
                    if (r === 0) rowHeights.push({ hpt: 26 }); // Header baris 1
                    else if (r === 1) rowHeights.push({ hpt: 22 }); // Header baris 2 (Kunci)
                    else rowHeights.push({ hpt: 20 }); // Data
                }
                worksheet['!rows'] = rowHeights;
                
                // Apply styles to all cells
                for (let R = 0; R < totalRows; R++) {
                    for (let C = 0; C < totalCols; C++) {
                        const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!worksheet[cellAddress]) {
                            worksheet[cellAddress] = { t: 's', v: '' };
                        }
                        
                        if (R === 0) {
                            // Table Header Row: Yellow, center, bold, border
                            worksheet[cellAddress].s = headerStyle;
                        } else if (R === 1) {
                            // Baris 2: Kolom A-F merupakan bagian merge vertikal (kuning header), G2 dst kunci jawaban (kuning lembut)
                            worksheet[cellAddress].s = (C < 6) ? headerStyle : keyRowStyle;
                        } else {
                            // Data Rows
                            if (C === 0) {
                                worksheet[cellAddress].s = cellStyleCenter; // No
                            } else if (C === 1) {
                                worksheet[cellAddress].s = cellStyleLeft;   // Nama Siswa
                            } else if (C === 2) {
                                worksheet[cellAddress].s = cellStyleCenter; // Kelas
                            } else if (C === 3) {
                                worksheet[cellAddress].s = cellStyleCenter; // Status Ujian
                            } else if (C === 4) {
                                worksheet[cellAddress].s = cellStyleScore;  // Total Skor
                            } else if (C === 5) {
                                worksheet[cellAddress].s = cellStyleScore;  // B/S
                            } else {
                                worksheet[cellAddress].s = cellStyleCenter; // Jawaban
                            }
                        }
                    }
                }
                
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, "Jawaban Siswa");
                
                const dateStr = new Date().toISOString().split('T')[0];
                const safeName = examName.replace(/[^a-zA-Z0-9]/g, '_');
                const fileName = `Analisis_Jawaban_${safeName}_${dateStr}.xlsx`;
                
                XLSX.writeFile(workbook, fileName, { compression: true });
                Swal.close();
            } catch (err) {
                console.error(err);
                Swal.fire('Error', 'Gagal membuat file Excel: ' + err.message, 'error');
            }
        }

        async function downloadStudentAnswerExcel(studentId, examId) {
            try {
                Swal.fire({
                    title: 'Memproses Excel...',
                    text: 'Sedang menyiapkan lembar jawaban siswa...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });
                
                const response = await fetch(`api.php?action=get_student_answers_data&student_id=${studentId}&exam_id=${examId}`);
                const res = await response.json();
                
                if (res.status !== 'success') {
                    Swal.fire('Gagal', res.message || 'Gagal memuat data jawaban', 'error');
                    return;
                }
                
                const sheetData = [];
                sheetData.push(['LEMBAR JAWABAN SISWA']);
                sheetData.push(['Nama Siswa', res.student_name]);
                sheetData.push(['Kelas', res.class_name]);
                sheetData.push(['Mata Pelajaran', res.exam_name]);
                sheetData.push(['Status Ujian', res.student_status || res.status || 'Selesai']);
                sheetData.push(['Total Skor', res.score]);
                if (res.bs) {
                    sheetData.push(['Jumlah Benar/Salah (B/S)', res.bs]);
                }
                sheetData.push([]);
                
                sheetData.push(['No', 'Pertanyaan / Stimulus', 'Tipe Soal', 'Jawaban Siswa']);
                (res.answers || []).forEach(a => {
                    sheetData.push([a.no, a.question, a.type, a.answer]);
                });
                
                const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
                worksheet['!cols'] = [
                    { wch: 6 },
                    { wch: 50 },
                    { wch: 18 },
                    { wch: 35 }
                ];
                
                const borderThin = {
                    top: { style: 'thin', color: { rgb: '000000' } },
                    bottom: { style: 'thin', color: { rgb: '000000' } },
                    left: { style: 'thin', color: { rgb: '000000' } },
                    right: { style: 'thin', color: { rgb: '000000' } }
                };
                
                const titleStyle = {
                    font: { name: 'Calibri', sz: 14, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left' }
                };
                
                const headerStyle = {
                    fill: { fgColor: { rgb: 'FFFF00' } },
                    font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderThin
                };
                
                const infoLabelStyle = {
                    font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left' }
                };
                
                const infoValStyle = {
                    font: { name: 'Calibri', sz: 11, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left' }
                };
                
                const cellCenter = {
                    font: { name: 'Calibri', sz: 11, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderThin
                };
                
                const cellLeft = {
                    font: { name: 'Calibri', sz: 11, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left', wrapText: true },
                    border: borderThin
                };
                
                const totalRows = sheetData.length;
                const totalCols = 4;
                
                for (let R = 0; R < totalRows; R++) {
                    for (let C = 0; C < totalCols; C++) {
                        const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!worksheet[cellAddress]) {
                            worksheet[cellAddress] = { t: 's', v: '' };
                        }
                        
                        if (R === 0) {
                            if (C === 0) worksheet[cellAddress].s = titleStyle;
                        } else if (R >= 1 && R <= 5) {
                            if (C === 0) worksheet[cellAddress].s = infoLabelStyle;
                            else if (C === 1) worksheet[cellAddress].s = infoValStyle;
                        } else if (R === 6) {
                            // Blank separator
                        } else if (R === 7) {
                            // Table Header (Yellow)
                            worksheet[cellAddress].s = headerStyle;
                        } else {
                            // Data Rows
                            if (C === 0) worksheet[cellAddress].s = cellCenter; // No
                            else if (C === 1) worksheet[cellAddress].s = cellLeft; // Pertanyaan
                            else if (C === 2) worksheet[cellAddress].s = cellCenter; // Tipe
                            else if (C === 3) worksheet[cellAddress].s = cellLeft; // Jawaban
                        }
                    }
                }
                
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, "Jawaban");
                
                const safeStudent = res.student_name.replace(/[^a-zA-Z0-9]/g, '_');
                const safeClass = res.class_name.replace(/[^a-zA-Z0-9]/g, '_');
                const fileName = `Jawaban_${safeStudent}_${safeClass}.xlsx`;
                
                XLSX.writeFile(workbook, fileName, { compression: true });
                Swal.close();
            } catch (err) {
                console.error(err);
                Swal.fire('Error', 'Gagal mengunduh Excel: ' + err.message, 'error');
            }
        }

        async function koreksiEsai(studentId, examId, studentName, currentScore) {
            document.getElementById('koreksi_student_id').value = studentId;
            document.getElementById('koreksi_exam_id').value = examId;
            document.getElementById('koreksi_student_name').textContent = studentName;
            document.getElementById('koreksi_current_score').textContent = currentScore;
            
            const container = document.getElementById('koreksi_list_container');
            const noEssayAlert = document.getElementById('koreksi_no_essay');
            container.innerHTML = '<div class="text-center">Memuat jawaban esai...</div>';
            noEssayAlert.style.display = 'none';
            
            $('#modalKoreksiEsai').modal('show');
            
            try {
                const res = await fetch(`api.php?action=get_student_essay_answers&student_id=${studentId}&exam_id=${examId}`);
                const json = await res.json();
                
                if (json.status === 'success') {
                    const essays = json.data;
                    if (essays.length === 0) {
                        container.innerHTML = '';
                        noEssayAlert.style.display = 'block';
                        return;
                    }
                    
                    let html = '';
                    essays.forEach((essay, idx) => {
                        // essay.question, essay.selected (the typed answer), essay.points (max points), essay.awarded_points
                        const awarded = essay.awarded_points !== undefined ? essay.awarded_points : 0;
                        html += `
                            <div class="card mb-3">
                                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0 font-weight-bold">Soal ${idx + 1}</h6>
                                    <div>Maks Poin: <span class="badge badge-secondary">${essay.points}</span></div>
                                </div>
                                <div class="card-body py-2">
                                    <div class="mb-3 text-muted text-sm border-bottom pb-2">${essay.question}</div>
                                    <div class="mb-3">
                                        <strong>Jawaban Siswa:</strong>
                                        <div class="p-2 bg-light border rounded mt-1" style="min-height: 60px; white-space: pre-wrap;">${essay.selected ? String(essay.selected).replace(/</g, '&lt;').replace(/>/g, '&gt;') : '<i class="text-muted">Tidak ada jawaban</i>'}</div>
                                    </div>
                                    <div class="form-group row mb-0 align-items-center">
                                        <label class="col-sm-3 col-form-label text-right">Beri Nilai (Poin):</label>
                                        <div class="col-sm-3">
                                            <input type="number" step="0.1" max="${essay.points}" min="0" class="form-control koreksi-input-point" data-orig-id="${essay.originalId}" value="${awarded}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    container.innerHTML = html;
                } else {
                    container.innerHTML = `<div class="text-danger text-center">Gagal memuat: ${json.message}</div>`;
                }
            } catch (err) {
                container.innerHTML = '<div class="text-danger text-center">Terjadi kesalahan saat memuat data.</div>';
            }
        }
        
        async function submitKoreksiEsai() {
            const studentId = document.getElementById('koreksi_student_id').value;
            const examId = document.getElementById('koreksi_exam_id').value;
            const inputs = document.querySelectorAll('.koreksi-input-point');
            
            const pointsData = [];
            inputs.forEach(inp => {
                pointsData.push({
                    originalId: parseInt(inp.getAttribute('data-orig-id')),
                    points: parseFloat(inp.value) || 0
                });
            });
            
            const fd = new FormData();
            fd.append('action', 'save_essay_points');
            fd.append('student_id', studentId);
            fd.append('exam_id', examId);
            fd.append('points_data', JSON.stringify(pointsData));
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    Swal.fire('Tersimpan', 'Nilai esai berhasil disimpan dan total skor telah diupdate.', 'success');
                    $('#modalKoreksiEsai').modal('hide');
                    fetchLiveStatus(); // Refresh skor di tabel
                } else {
                    Swal.fire('Gagal', json.message, 'error');
                }
            } catch (err) {
                Swal.fire('Error', 'Terjadi kesalahan jaringan.', 'error');
            }
        }

        function changePerPage() {
            liveItemsPerPage = parseInt(document.getElementById('live-status-per-page').value);
            liveCurrentPage = 1;
            renderLiveStatusTable();
        }

        function changePage(page) {
            liveCurrentPage = page;
            renderLiveStatusTable();
        }

        function refreshStatusManual() {
            const btn = document.getElementById('btn-refresh-status');
            const icon = btn ? btn.querySelector('i') : null;
            if (icon) icon.classList.add('fa-spin');
            fetchLiveStatus().finally(() => {
                setTimeout(() => {
                    if (icon) icon.classList.remove('fa-spin');
                }, 400);
            });
        }

        // Realtime Polling
        async function fetchLiveStatus() {
            if (currentLiveExamId === null) return;
            
            try {
                const response = await fetch(`api.php?action=get_live_status&exam_id=${currentLiveExamId}`);
                const res = await response.json();
                
                if (res.status === 'success') {
                    liveStatusData = res.data;
                    renderLiveStatusTable();

                    const timeEl = document.getElementById('last-updated-time');
                    if (timeEl) {
                        const now = new Date();
                        const timeStr = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0') + ':' + String(now.getSeconds()).padStart(2, '0');
                        timeEl.textContent = 'update: ' + timeStr;
                    }

                    if (res.exam_token) {
                        const tokenEl = document.getElementById('live-exam-token');
                        if (tokenEl) tokenEl.innerText = res.exam_token;
                    }
                    
                    const dynInfo = document.getElementById('token-dynamic-info');
                    if (res.is_dynamic && dynInfo) {
                        dynInfo.style.display = 'block';
                        // Only start if not already counting down or if remaining diff is large
                        if (!liveTokenCountdownTimer || Math.abs(liveTokenRemainingSeconds - (res.token_remaining_seconds || 0)) > 5) {
                            startTokenCountdown(res.token_remaining_seconds || 0);
                        }
                    } else if (dynInfo) {
                        dynInfo.style.display = 'none';
                        clearInterval(liveTokenCountdownTimer);
                    }
                }
            } catch(e) {
                console.error('Failed to fetch live status');
            }
        }

        function startTokenCountdown(seconds) {
            clearInterval(liveTokenCountdownTimer);
            liveTokenRemainingSeconds = Math.max(0, seconds);
            updateTokenCountdownDisplay();
            
            liveTokenCountdownTimer = setInterval(() => {
                liveTokenRemainingSeconds--;
                if (liveTokenRemainingSeconds <= 0) {
                    clearInterval(liveTokenCountdownTimer);
                    liveTokenRemainingSeconds = 0;
                    updateTokenCountdownDisplay();
                    fetchLiveStatus();
                } else {
                    updateTokenCountdownDisplay();
                }
            }, 1000);
        }

        function updateTokenCountdownDisplay() {
            const el = document.getElementById('token-countdown-display');
            if (!el) return;
            const m = Math.floor(Math.max(0, liveTokenRemainingSeconds) / 60);
            const s = Math.max(0, liveTokenRemainingSeconds) % 60;
            el.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        }

        async function refreshExamTokenNow() {
            if (!currentLiveExamId) return;
            const confirm = await Swal.fire({
                title: 'Acak Token Sekarang?',
                text: 'Token ujian akan langsung diperbarui secara acak dengan kode baru.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, Acak Baru',
                cancelButtonText: 'Batal'
            });
            if (!confirm.isConfirmed) return;
            
            try {
                const fd = new FormData();
                fd.append('action', 'refresh_exam_token');
                fd.append('exam_id', currentLiveExamId);
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    const tokenEl = document.getElementById('live-exam-token');
                    if (tokenEl) tokenEl.innerText = json.token;
                    if (json.remaining_seconds !== undefined) {
                        startTokenCountdown(json.remaining_seconds);
                    }
                    Swal.fire({
                        icon: 'success',
                        title: 'Token Baru Berhasil Dirilis!',
                        html: `Token saat ini: <strong style="font-size:1.5em; letter-spacing:2px; color:#e67e22;">${json.token}</strong>`,
                        timer: 2500,
                        showConfirmButton: false
                    });
                } else {
                    Swal.fire('Gagal', json.message || 'Gagal merilis token baru', 'error');
                }
            } catch(e) {
                Swal.fire('Error', 'Terjadi kesalahan koneksi', 'error');
            }
        }

        let currentStatusFilter = 'Semua';
        let liveSearchQuery = '';
        
        function filterLiveSearch() {
            liveSearchQuery = document.getElementById('live-search-input').value.toLowerCase();
            liveCurrentPage = 1;
            renderLiveStatusTable();
        }
        
        function filterStatusTab(status, e, element) {
            e.preventDefault();
            currentStatusFilter = status;
            
            document.querySelectorAll('#status-tabs .nav-link').forEach(el => el.classList.remove('active'));
            element.classList.add('active');
            
            liveCurrentPage = 1;
            renderLiveStatusTable();
        }

        function renderLiveStatusTable() {
            // Calculate tab counts
            let countBelum = 0;
            let countMengerjakan = 0;
            let countTerkunci = 0;
            let countDiblokir = 0;
            let countSelesai = 0;
            liveStatusData.forEach(s => {
                if (s.is_blocked) countDiblokir++;
                if (s.is_locked) countTerkunci++;
                if (s.status === 'Belum Mengerjakan') countBelum++;
                else if (s.status === 'Sedang Mengerjakan') {
                    if (!s.is_locked) countMengerjakan++;
                }
                else if (s.status === 'Selesai') countSelesai++;
            });
            document.getElementById('tab-count-semua').textContent = liveStatusData.length;
            document.getElementById('tab-count-belum').textContent = countBelum;
            document.getElementById('tab-count-mengerjakan').textContent = countMengerjakan;
            const tabTerkunciEl = document.getElementById('tab-count-terkunci');
            if (tabTerkunciEl) tabTerkunciEl.textContent = countTerkunci;
            const tabDiblokirEl = document.getElementById('tab-count-diblokir');
            if (tabDiblokirEl) tabDiblokirEl.textContent = countDiblokir;
            document.getElementById('tab-count-selesai').textContent = countSelesai;
            
            // Filter Data first
            currentFilteredData = liveStatusData;
            if (currentStatusFilter !== 'Semua') {
                if (currentStatusFilter === 'Diblokir') {
                    currentFilteredData = currentFilteredData.filter(s => !!s.is_blocked);
                } else if (currentStatusFilter === 'Terkunci') {
                    currentFilteredData = currentFilteredData.filter(s => !!s.is_locked);
                } else if (currentStatusFilter === 'Sedang Mengerjakan') {
                    currentFilteredData = currentFilteredData.filter(s => s.status === 'Sedang Mengerjakan' && !s.is_locked);
                } else {
                    currentFilteredData = currentFilteredData.filter(s => s.status === currentStatusFilter);
                }
            }
            if (liveSearchQuery.trim() !== '') {
                currentFilteredData = currentFilteredData.filter(s => (s.name || '').toLowerCase().includes(liveSearchQuery));
            }
            
            // Sort Data
            currentFilteredData.sort((a, b) => {
                let valA = a[currentSortCol];
                let valB = b[currentSortCol];
                
                if (['score', 'answered_count', 'start_time_ts', 'end_time_ts', 'duration_seconds'].includes(currentSortCol)) {
                    valA = Number(valA) || 0;
                    valB = Number(valB) || 0;
                } else {
                    valA = String(valA || '').toLowerCase();
                    valB = String(valB || '').toLowerCase();
                }
                
                if (valA < valB) return currentSortDir === 'asc' ? -1 : 1;
                if (valA > valB) return currentSortDir === 'asc' ? 1 : -1;
                return 0;
            });

            const totalItems = currentFilteredData.length;
            let totalPages = 1;
            let startIndex = 0;
            let endIndex = totalItems;
            let paginatedData = currentFilteredData;

            if (liveItemsPerPage > 0) {
                totalPages = Math.ceil(totalItems / liveItemsPerPage);
                if (liveCurrentPage > totalPages && totalPages > 0) liveCurrentPage = totalPages;
                startIndex = (liveCurrentPage - 1) * liveItemsPerPage;
                endIndex = Math.min(startIndex + liveItemsPerPage, totalItems);
                paginatedData = currentFilteredData.slice(startIndex, endIndex);
            } else {
                liveCurrentPage = 1;
                totalPages = 1;
                startIndex = 0;
                endIndex = totalItems;
                paginatedData = currentFilteredData;
            }

            const tbody = document.getElementById('live-status-tbody');
            let html = '';
            const isGuru = (window.currentUserRole === 'guru');

            paginatedData.forEach((s, index) => {
                let badgeClass = '';
                let actionHtml = '';
                let violationBadge = '';
                let resetBadge = s.is_reset ? `<span class="badge badge-info ml-1" title="Siswa telah dikeluarkan oleh admin dan sesi direset. Seluruh jawaban aman tersimpan."><i class="fas fa-undo mr-1"></i>Sesi Direset</span>` : '';
                let blockBadge = s.is_blocked ? `<span class="badge badge-danger ml-1" title="Siswa Diblokir oleh Admin"><i class="fas fa-ban mr-1"></i>Diblokir</span>` : '';
                let blockBtn = s.is_blocked
                    ? `<button onclick="toggleBlockStudent(${s.id}, 0, '${(s.name || '').replace(/'/g, "\\'")}')" class="btn btn-secondary btn-sm mr-1" title="Buka Blokir Siswa"><i class="fas fa-user-check"></i></button>`
                    : `<button onclick="toggleBlockStudent(${s.id}, 1, '${(s.name || '').replace(/'/g, "\\'")}')" class="btn btn-outline-danger btn-sm mr-1" title="Blokir Siswa (Keluarkan & Larang Ujian)"><i class="fas fa-ban"></i></button>`;
                
                if (s.is_locked) {
                    badgeClass = 'badge badge-danger';
                    violationBadge = `<span class="badge badge-danger ml-1" title="Ujian Terkunci karena Melanggar"><i class="fas fa-lock mr-1"></i>Terkunci (${s.violations || 0}x)</span>`;
                } else if (s.status === 'Selesai') {
                    badgeClass = 'badge badge-success';
                    if (s.violations > 0) {
                        violationBadge = `<span class="badge badge-danger ml-1" title="Pelanggaran selama ujian"><i class="fas fa-exclamation-triangle mr-1"></i>${s.violations}x</span>`;
                    }
                } else if (s.status === 'Sedang Mengerjakan') {
                    badgeClass = 'badge badge-warning';
                    if (s.violations > 0) {
                        violationBadge = `<span class="badge badge-danger ml-1" title="Pelanggaran terdeteksi"><i class="fas fa-exclamation-triangle mr-1"></i>${s.violations}x</span>`;
                    }
                } else {
                    badgeClass = 'badge badge-secondary';
                }

                if (isGuru) {
                    // Akun Guru: Hanya diperbolehkan untuk Koreksi Essay dan Unduh Jawaban saja
                    if (s.status === 'Selesai') {
                        actionHtml = `
                            <button onclick="koreksiEsai(${s.id}, ${currentLiveExamId}, '${(s.name || '').replace(/'/g, "\\'")}', ${s.score})" class="btn btn-primary btn-sm mr-1" title="Koreksi Esai"><i class="fas fa-edit"></i></button>
                            <button onclick="downloadStudentAnswerExcel(${s.id}, ${currentLiveExamId})" class="btn btn-success btn-sm" title="Unduh Jawaban Siswa (.xlsx)"><i class="fas fa-file-excel"></i></button>
                        `;
                    } else if (s.status === 'Sedang Mengerjakan' || s.is_locked) {
                        if ((s.answered_count || 0) > 0) {
                            actionHtml = `<button onclick="downloadStudentAnswerExcel(${s.id}, ${currentLiveExamId})" class="btn btn-success btn-sm" title="Unduh Jawaban Siswa (.xlsx)"><i class="fas fa-file-excel"></i></button>`;
                        } else {
                            actionHtml = `<span class="text-muted small">-</span>`;
                        }
                    } else {
                        actionHtml = `<span class="text-muted small">-</span>`;
                    }
                } else {
                    // Akun Admin: Kontrol penuh (Blokir, Buka Kunci, Reset/Keluarkan, Paksa Selesai, Koreksi, Unduh)
                    if (s.is_locked) {
                        actionHtml = `${blockBtn}
                                      <button onclick="unlockStudent(${s.id}, '${(s.name || '').replace(/'/g, "\\'")}')" class="btn btn-success btn-sm mr-1" title="Buka Kunci"><i class="fas fa-unlock-alt"></i></button>
                                      <button onclick="resetStudent(${s.id})" class="btn btn-warning btn-sm mr-1 text-white" title="Keluarkan Siswa (Jawaban Tetap Aman)"><i class="fas fa-undo"></i></button>
                                      <button onclick="forceSubmitStudent(${s.id})" class="btn btn-info btn-sm" title="Paksa Selesai"><i class="fas fa-check-double"></i></button>`;
                    } else if (s.status === 'Selesai') {
                        actionHtml = `${blockBtn}
                                      <button onclick="resetStudent(${s.id})" class="btn btn-warning btn-sm mr-1 text-white" title="Buka Kembali / Keluarkan Siswa (Jawaban Tetap Aman)"><i class="fas fa-undo"></i></button>
                                      <button onclick="koreksiEsai(${s.id}, ${currentLiveExamId}, '${(s.name || '').replace(/'/g, "\\'")}', ${s.score})" class="btn btn-primary btn-sm mr-1" title="Koreksi Esai"><i class="fas fa-edit"></i></button>
                                      <button onclick="downloadStudentAnswerExcel(${s.id}, ${currentLiveExamId})" class="btn btn-success btn-sm" title="Unduh Jawaban Siswa (.xlsx)"><i class="fas fa-file-excel"></i></button>`;
                    } else if (s.status === 'Sedang Mengerjakan') {
                        actionHtml = `${blockBtn}
                                      <button onclick="resetStudent(${s.id})" class="btn btn-warning btn-sm mr-1 text-white" title="Keluarkan Siswa (Jawaban Tetap Aman)"><i class="fas fa-undo"></i></button><button onclick="forceSubmitStudent(${s.id})" class="btn btn-info btn-sm" title="Paksa Selesai"><i class="fas fa-check-double"></i></button>`;
                    } else if (s.is_reset) {
                        actionHtml = `${blockBtn}
                                      <button onclick="resetStudent(${s.id})" class="btn btn-warning btn-sm mr-1 text-white" title="Keluarkan Siswa / Reset Ulang (Jawaban Tetap Aman)"><i class="fas fa-undo"></i></button><button onclick="forceSubmitStudent(${s.id})" class="btn btn-info btn-sm" title="Paksa Selesai"><i class="fas fa-check-double"></i></button>`;
                    } else {
                        actionHtml = `${blockBtn}`;
                    }
                }
                
                const isChecked = selectedStatusIds.has(s.id) ? 'checked' : '';
                const progressBadge = `<span class="badge badge-light border font-weight-bold" style="font-size:0.85rem; padding: 4px 8px;" title="Terjawab: ${s.answered_count || 0} dari ${s.total_questions || 0} soal">${s.progress || '0/0'}</span>`;
                
                const startDisplay = s.start_time || '-';
                const endDisplay = s.end_time || '-';
                let durationBadge = '<span class="text-muted">-</span>';
                if (s.duration && s.duration !== '-') {
                    if (s.status === 'Sedang Mengerjakan' || s.is_locked) {
                        durationBadge = `<span class="badge badge-light border text-primary" title="Sedang berjalan"><i class="fas fa-clock mr-1 text-warning"></i>${s.duration}</span>`;
                    } else {
                        durationBadge = `<span class="badge badge-light border font-weight-normal text-dark">${s.duration}</span>`;
                    }
                }

                const cbCol = isGuru ? '' : `<td class="text-center align-middle"><input type="checkbox" class="cb-status-row" value="${s.id}" onchange="toggleStatusSelection(${s.id}, this.checked)" ${isChecked}></td>`;

                html += `
                    <tr>
                        ${cbCol}
                        <td class="text-center align-middle">${startIndex + index + 1}</td>
                        <td class="align-middle"><div class="font-weight-bold text-dark">${s.name}</div><small class="text-muted">${s.username || '-'} | ${s.password || '-'}</small></td>
                        <td class="text-center align-middle">${s.class_name}</td>
                        <td class="text-center align-middle">${progressBadge}</td>
                        <td class="text-center align-middle"><span class="${badgeClass}">${s.status}</span> ${resetBadge} ${violationBadge} ${blockBadge}</td>
                        <td class="text-center align-middle text-nowrap"><small class="text-muted font-weight-bold">${startDisplay}</small></td>
                        <td class="text-center align-middle text-nowrap"><small class="text-muted font-weight-bold">${endDisplay}</small></td>
                        <td class="text-center align-middle text-nowrap">${durationBadge}</td>
                        <td class="text-center align-middle font-weight-bold">${s.score}</td>
                        <td class="text-center align-middle text-nowrap">${actionHtml}</td>
                    </tr>
                `;
            });
            const emptyColspan = isGuru ? 10 : 11;
            if (totalItems === 0) html = `<tr><td colspan="${emptyColspan}" class="text-center">Tidak ada data siswa</td></tr>`;
            tbody.innerHTML = html;
            
            updateSelectAllCheckbox();

            renderPagination(totalItems, totalPages, startIndex, endIndex);
        }

        function renderPagination(totalItems, totalPages, startIndex, endIndex) {
            const pagination = document.getElementById('live-status-pagination');
            const info = document.getElementById('live-status-info');
            
            if (totalItems === 0) {
                if (pagination) pagination.innerHTML = '';
                if (info) info.innerHTML = 'Menampilkan 0 dari 0 data';
                return;
            }
            
            if (liveItemsPerPage <= 0) {
                if (info) info.innerHTML = `Menampilkan semua (${totalItems} data)`;
                if (pagination) pagination.innerHTML = '';
                return;
            }

            if (info) info.innerHTML = `Menampilkan ${startIndex + 1} sampai ${endIndex} dari ${totalItems} data`;
            
            if (!pagination) return;
            
            let html = '';
            
            // Prev Button
            html += `<li class="page-item ${liveCurrentPage === 1 ? 'disabled' : ''}">
                        <a class="page-link" href="javascript:void(0)" onclick="changePage(${liveCurrentPage - 1})">«</a>
                     </li>`;
                     
            // Page Numbers
            let startPage = Math.max(1, liveCurrentPage - 2);
            let endPage = Math.min(totalPages, startPage + 4);
            
            if (endPage - startPage < 4) {
                startPage = Math.max(1, endPage - 4);
            }
            
            for (let i = startPage; i <= endPage; i++) {
                html += `<li class="page-item ${i === liveCurrentPage ? 'active' : ''}">
                            <a class="page-link" href="javascript:void(0)" onclick="changePage(${i})">${i}</a>
                         </li>`;
            }
            
            // Next Button
            html += `<li class="page-item ${liveCurrentPage === totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="javascript:void(0)" onclick="changePage(${liveCurrentPage + 1})">»</a>
                     </li>`;
                     
            pagination.innerHTML = html;
        }
        
       let currentQuestions = [];
        
        let selectedQIndices = new Set();
        
        function toggleAllQ() {
            const masterCb = document.getElementById('cb-all-q');
            const checked = masterCb ? masterCb.checked : false;
            const cbs = document.querySelectorAll('.cb-q-row');
            cbs.forEach(cb => {
                cb.checked = checked;
                const idx = parseInt(cb.value);
                if (checked) selectedQIndices.add(idx);
                else selectedQIndices.delete(idx);
            });
            updateQBulkUI();
        }
        
        function toggleQSelection(index, checked) {
            if (checked) selectedQIndices.add(index);
            else selectedQIndices.delete(index);
            
            const masterCb = document.getElementById('cb-all-q');
            const cbs = document.querySelectorAll('.cb-q-row');
            if (masterCb && cbs.length > 0) {
                masterCb.checked = Array.from(cbs).every(cb => cb.checked);
            }
            updateQBulkUI();
        }

        function updateQBulkUI() {
            const btnDelete = document.getElementById('btn-bulk-delete-q');
            const countBadge = document.getElementById('selected-q-count');
            const size = selectedQIndices.size;
            if (countBadge) countBadge.textContent = size;
            if (btnDelete) btnDelete.style.display = size > 0 ? 'inline-block' : 'none';
        }
        
        async function deleteBulkQuestions() {
            if (selectedQIndices.size === 0) return;
            const result = await Swal.fire({
                title: 'Hapus Soal Terpilih?',
                text: `Yakin ingin menghapus ${selectedQIndices.size} soal terpilih secara permanen?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            });
            
            if (result.isConfirmed) {
                const examId = document.getElementById('preview_exam_id').value;
                const fd = new FormData();
                fd.append('action', 'delete_bulk_soal');
                fd.append('exam_id', examId);
                fd.append('indices', JSON.stringify(Array.from(selectedQIndices)));
                
                try {
                    const res = await fetch('api.php', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Terhapus!',
                            text: 'Soal terpilih berhasil dihapus.',
                            icon: 'success',
                            timer: 1000,
                            showConfirmButton: false
                        }).then(() => loadQuestions());
                    } else {
                        Swal.fire('Gagal', json.message, 'error');
                    }
                } catch(e) { Swal.fire('Error', 'Terjadi kesalahan.', 'error'); }
            }
        }
        
        // Load Questions for Preview
        async function loadQuestions() {
            try {
                const examId = document.getElementById('preview_exam_id').value;
                if (!examId) return;
                
                selectedQIndices.clear();
                const cbAll = document.getElementById('cb-all-q');
                if(cbAll) cbAll.checked = false;
                updateQBulkUI();
                
                const response = await fetch(`api.php?action=get_questions&bank_soal_id=${examId}&exam_id=${examId}`);
                const res = await response.json();
                
                const container = document.getElementById('container-soal') || document.getElementById('tbody-soal');
                const badge = document.getElementById('badge-total-soal');
                
                if (res.status === 'success') {
                    currentQuestions = res.data || [];
                    badge.innerText = `${currentQuestions.length} Soal`;
                    document.getElementById('btn-add-soal').style.display = 'inline-block';
                    const btnAi = document.getElementById('btn-ai-soal');
                    if (btnAi) btnAi.style.display = 'inline-block';
                    const btnPrevSiswa = document.getElementById('btn-preview-siswa');
                    if (btnPrevSiswa) btnPrevSiswa.style.display = 'inline-block';
                    const btnAutoPoin = document.getElementById('btn-auto-poin');
                    if (btnAutoPoin) btnAutoPoin.style.display = 'inline-block';
                    const btnRecalc = document.getElementById('btn-recalc-bank');
                    if (btnRecalc) btnRecalc.style.display = 'inline-block';
                    const btnKunciExcel = document.getElementById('btn-kunci-excel');
                    if (btnKunciExcel) btnKunciExcel.style.display = 'inline-block';
                    const btnOptWebp = document.getElementById('btn-opt-webp');
                    if (btnOptWebp) btnOptWebp.style.display = 'inline-block';
                    document.getElementById('btn-download-word').style.display = 'inline-block';
                    const btnPlain = document.getElementById('btn-download-word-plain');
                    if (btnPlain) btnPlain.style.display = 'inline-block';
                    
                    // Hitung total akumulasi poin nilai seluruh soal
                    let totalPoints = currentQuestions.reduce((sum, q) => {
                        let pts = q.points !== undefined ? parseFloat(q.points) : 2;
                        return sum + (isNaN(pts) ? 0 : pts);
                    }, 0);
                    totalPoints = Math.round(totalPoints * 100) / 100;

                    const badgeTotalPoin = document.getElementById('badge-total-poin');
                    const valTotalPoin = document.getElementById('val-total-poin');
                    if (valTotalPoin) valTotalPoin.innerText = totalPoints;
                    if (badgeTotalPoin) {
                        badgeTotalPoin.style.display = currentQuestions.length > 0 ? 'inline-flex' : 'none';
                        badgeTotalPoin.className = 'align-items-center ml-2';
                        badgeTotalPoin.innerHTML = `Total: <span id="val-total-poin" style="font-weight: 300; color: #000; margin: 0 3px;">${totalPoints}</span> Poin`;
                    }
                    
                    if (currentQuestions.length === 0) {
                        container.innerHTML = `
                            <div class="card p-5 text-center shadow-sm border-0 my-3 bg-white rounded">
                                <i class="fas fa-file-word fa-4x text-muted mb-3" style="opacity: 0.35;"></i>
                                <h5 class="text-secondary font-weight-bold">Bank Soal Masih Kosong</h5>
                                <p class="text-muted">Belum ada soal pada bank soal ini. Silakan klik tombol <strong>Impor Soal</strong> dari file Word / JSON, atau klik <strong>Tambah Soal</strong>.</p>
                                <div class="mt-2">
                                    <button class="btn btn-primary btn-sm mr-2 shadow-sm" data-toggle="modal" data-target="#modalImportSoal"><i class="fas fa-upload mr-1"></i> Impor Soal Word</button>
                                    <button class="btn btn-success btn-sm mr-2 shadow-sm" onclick="openAddQModal()"><i class="fas fa-plus mr-1"></i> Tambah Soal Manual</button>
                                    <a href="https://share.gemini.google/ReefFdC6lnEu" target="_blank" rel="noopener noreferrer" onclick="return openGeminiAiPopup(event)" class="btn btn-sm shadow-sm font-weight-bold text-white" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);"><i class="fas fa-robot mr-1"></i> Buat via AI</a>
                                </div>
                            </div>`;
                        document.getElementById('btn-download-word').style.display = 'none';
                        if (btnPrevSiswa) btnPrevSiswa.style.display = 'none';
                        if (btnPlain) btnPlain.style.display = 'none';
                        if (btnRecalc) btnRecalc.style.display = 'none';
                        if (btnKunciExcel) btnKunciExcel.style.display = 'none';
                        if (btnOptWebp) btnOptWebp.style.display = 'none';
                        if (btnAutoPoin) btnAutoPoin.style.display = 'none';
                        if (badgeTotalPoin) badgeTotalPoin.style.display = 'none';
                        return;
                    }
                    
                    const labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
                    const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
                    let html = '';

                    currentQuestions.forEach((q, i) => {
                        let typeBadge = '<span class="badge badge-primary px-2 py-1"><i class="fas fa-dot-circle mr-1"></i> Pilihan Ganda</span>';
                        let points = q.points !== undefined ? q.points : 2;
                        let contentHtml = '';

                        if (q.type === 'complex_mc') {
                            typeBadge = '<span class="badge badge-info px-2 py-1"><i class="fas fa-check-square mr-1"></i> PG Kompleks</span>';
                            const correctArr = Array.isArray(q.answers) ? q.answers.map(a => parseInt(a)) : [];
                            
                            contentHtml = '<div class="options-preview pl-1 mb-2">';
                            if (q.options && Array.isArray(q.options)) {
                                q.options.forEach((opt, optIdx) => {
                                    const isCorrect = correctArr.includes(optIdx);
                                    if (isCorrect) {
                                        contentHtml += `
                                        <div class="d-flex align-items-start p-2 mb-2 rounded" style="background-color: #e0f2fe; border: 1px solid #bae6fd;">
                                            <span class="badge badge-info mr-2 font-weight-bold" style="font-size: 0.85rem; min-width: 26px; text-align: center;">${labels[optIdx] || optIdx + 1}</span>
                                            <div class="flex-grow-1 font-weight-bold text-primary" style="font-size: 0.95rem;">${opt}</div>
                                            <span class="badge badge-info ml-2 px-2 py-1"><i class="fas fa-check-double mr-1"></i> Kunci</span>
                                        </div>`;
                                    } else {
                                        contentHtml += `
                                        <div class="d-flex align-items-start p-2 mb-2 rounded" style="background-color: #ffffff; border: 1px solid #e2e8f0;">
                                            <span class="badge badge-light border mr-2 font-weight-bold text-secondary" style="font-size: 0.85rem; min-width: 26px; text-align: center;">${labels[optIdx] || optIdx + 1}</span>
                                            <div class="flex-grow-1 text-dark" style="font-size: 0.95rem;">${opt}</div>
                                        </div>`;
                                    }
                                });
                            }
                            contentHtml += '</div>';

                        } else if (q.type === 'true_false') {
                            typeBadge = '<span class="badge badge-warning text-dark px-2 py-1"><i class="fas fa-check-circle mr-1"></i> Benar / Salah</span>';
                            contentHtml = `
                            <div class="table-responsive mt-2 mb-2">
                                <table class="table table-bordered table-sm mb-1 bg-white" style="border: 1px solid #dee2e6;">
                                    <thead class="thead-light">
                                        <tr>
                                            <th style="width: 45px;" class="text-center">No</th>
                                            <th>Pernyataan</th>
                                            <th style="width: 140px;" class="text-center">Kunci Nilai</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;
                            if (q.statements && Array.isArray(q.statements)) {
                                q.statements.forEach((st, stIdx) => {
                                    const isBenar = (st.answer === true || st.answer === 'true');
                                    contentHtml += `
                                    <tr>
                                        <td class="text-center align-middle font-weight-bold">${stIdx + 1}</td>
                                        <td class="align-middle">${st.text}</td>
                                        <td class="text-center align-middle">
                                            <span class="badge ${isBenar ? 'badge-success' : 'badge-danger'} px-2 py-1" style="font-size: 0.85rem;">
                                                <i class="fas ${isBenar ? 'fa-check' : 'fa-times'} mr-1"></i> ${isBenar ? 'BENAR' : 'SALAH'}
                                            </span>
                                        </td>
                                    </tr>`;
                                });
                            }
                            contentHtml += `</tbody></table></div>`;

                        } else if (q.type === 'matching') {
                            typeBadge = '<span class="badge badge-success px-2 py-1"><i class="fas fa-exchange-alt mr-1"></i> Menjodohkan</span>';
                            contentHtml = `
                            <div class="table-responsive mt-2 mb-2">
                                <table class="table table-bordered table-sm mb-1 bg-white" style="border: 1px solid #dee2e6;">
                                    <thead class="thead-light">
                                        <tr>
                                            <th style="width: 45px;" class="text-center">No</th>
                                            <th style="width: 50%;">Premis (Kiri)</th>
                                            <th style="width: 50%;">Kunci Pasangan Pilihan (Kanan)</th>
                                        </tr>
                                    </thead>
                                    <tbody>`;
                            if (q.premises && Array.isArray(q.premises)) {
                                q.premises.forEach((p, pIdx) => {
                                    const optIdx = q.pairs ? (q.pairs[pIdx] !== undefined ? q.pairs[pIdx] : q.pairs[String(pIdx)]) : undefined;
                                    const letter = (optIdx !== undefined && letters[optIdx]) ? letters[optIdx] : '?';
                                    const optText = (optIdx !== undefined && q.options && q.options[optIdx]) ? q.options[optIdx] : '';
                                    contentHtml += `
                                    <tr>
                                        <td class="text-center align-middle font-weight-bold">${pIdx + 1}</td>
                                        <td class="align-middle">${p}</td>
                                        <td class="align-middle bg-light">
                                            <span class="badge badge-warning text-dark mr-1 font-weight-bold px-2 py-1">
                                                <i class="fas fa-arrow-right mr-1"></i> Opsi ${letter}
                                            </span>
                                            <span class="font-weight-bold text-dark">${optText}</span>
                                        </td>
                                    </tr>`;
                                });
                            }
                            contentHtml += `</tbody></table></div>`;

                        } else if (q.type === 'essay') {
                            typeBadge = '<span class="badge badge-secondary px-2 py-1"><i class="fas fa-paragraph mr-1"></i> Esai</span>';
                            contentHtml = `
                            <div class="p-3 my-2 bg-light rounded text-muted" style="border: 1px dashed #cbd5e1; font-style: italic;">
                                <i class="fas fa-pen-alt mr-1"></i> Lembar jawaban uraian siswa...
                            </div>`;

                        } else {
                            // PG Biasa
                            typeBadge = '<span class="badge badge-primary px-2 py-1"><i class="fas fa-dot-circle mr-1"></i> Pilihan Ganda</span>';
                            contentHtml = '<div class="options-preview pl-1 mb-2">';
                            if (q.options && Array.isArray(q.options)) {
                                q.options.forEach((opt, optIdx) => {
                                    const isCorrect = (parseInt(q.answer) === optIdx);
                                    if (isCorrect) {
                                        contentHtml += `
                                        <div class="d-flex align-items-start p-2 mb-2 rounded" style="background-color: #e8f5e9; border: 1px solid #c8e6c9;">
                                            <span class="badge badge-success mr-2 font-weight-bold" style="font-size: 0.85rem; min-width: 26px; text-align: center;">${labels[optIdx] || optIdx + 1}</span>
                                            <div class="flex-grow-1 font-weight-bold text-success" style="font-size: 0.95rem;">${opt}</div>
                                            <span class="badge badge-success ml-2 px-2 py-1"><i class="fas fa-check mr-1"></i> Kunci</span>
                                        </div>`;
                                    } else {
                                        contentHtml += `
                                        <div class="d-flex align-items-start p-2 mb-2 rounded" style="background-color: #ffffff; border: 1px solid #e2e8f0;">
                                            <span class="badge badge-light border mr-2 font-weight-bold text-secondary" style="font-size: 0.85rem; min-width: 26px; text-align: center;">${labels[optIdx] || optIdx + 1}</span>
                                            <div class="flex-grow-1 text-dark" style="font-size: 0.95rem;">${opt}</div>
                                        </div>`;
                                    }
                                });
                            }
                            contentHtml += '</div>';
                        }

                        html += `
                        <div class="card mb-3 shadow-sm rounded word-doc-question-item" id="q-card-${i}" style="background-color: #ffffff; border: 1px solid #e2e8f0;">
                            <div class="card-body p-3">
                                <div class="d-flex justify-content-between align-items-start">
                                    
                                    <!-- Nomor & Checkbox -->
                                    <div class="mr-3 pt-1 text-center" style="min-width: 48px;">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input cb-q-row" id="cb_q_${i}" value="${i}" onchange="toggleQSelection(${i}, this.checked)">
                                            <label class="custom-control-label text-dark" for="cb_q_${i}" style="font-size: 1.05rem; cursor: pointer; font-weight: 600;">${i + 1}.</label>
                                        </div>
                                    </div>

                                    <!-- Isi Soal Tampilan Dokumen Word -->
                                    <div class="flex-grow-1 pr-3" style="min-width: 0;">
                                        <div class="d-flex align-items-center flex-wrap mb-2">
                                            ${typeBadge}
                                            <span class="badge badge-light border text-muted ml-2 font-weight-normal px-2 py-1">
                                                <i class="fas fa-award text-warning mr-1"></i>${points} Poin
                                            </span>
                                        </div>
                                        
                                        <!-- Teks Pertanyaan -->
                                        <div class="question-body text-dark mb-3" style="font-size: 1.05rem; line-height: 1.6; word-break: break-word;">
                                            ${q.question}
                                        </div>

                                        <!-- Opsi / Tabel Pilihan -->
                                        ${contentHtml}
                                    </div>

                                    <!-- Tombol Aksi di Samping Kanan (Hanya Ikon) -->
                                    <div class="d-flex flex-column pl-3 border-left ml-2 action-buttons-col align-items-center justify-content-start" style="min-width: 48px;">
                                        <button onclick="editQuestion(${i})" class="btn btn-warning btn-sm mb-2 shadow-sm d-flex align-items-center justify-content-center" style="width: 34px; height: 34px; padding: 0; border-radius: 6px;" title="Edit Soal #${i + 1}">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="deleteQuestion(${i})" class="btn btn-outline-danger btn-sm shadow-sm d-flex align-items-center justify-content-center" style="width: 34px; height: 34px; padding: 0; border-radius: 6px;" title="Hapus Soal #${i + 1}">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        `;
                    });
                    container.innerHTML = html;
                    if (window.renderMath) {
                        window.renderMath(container);
                    }
                } else {
                    container.innerHTML = '<div class="alert alert-danger text-center my-3"><i class="fas fa-exclamation-triangle mr-1"></i> Gagal memuat daftar soal</div>';
                }
            } catch(e) {
                console.error(e);
            }
        }

        function addStatementRow(mode, text = '', isTrue = true) {
            const tbody = document.getElementById(mode === 'edit' ? 'edit_q_tf_tbody' : 'add_q_tf_tbody');
            if (!tbody) return;
            const rowCount = tbody.querySelectorAll('tr').length + 1;
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="text-center align-middle statement-no">${rowCount}</td>
                <td><input type="text" class="form-control form-control-sm statement-text" placeholder="Ketik pernyataan..." value="${text.replace(/"/g, '&quot;')}"></td>
                <td>
                    <select class="form-control form-control-sm statement-ans">
                        <option value="true" ${isTrue ? 'selected' : ''}>Benar</option>
                        <option value="false" ${!isTrue ? 'selected' : ''}>Salah</option>
                    </select>
                </td>
                <td class="text-center align-middle">
                    <button type="button" class="btn btn-danger btn-xs" onclick="removeStatementRow(this)"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
            reindexStatements(tbody);
        }

        function removeStatementRow(btn) {
            const tr = btn.closest('tr');
            const tbody = tr.closest('tbody');
            tr.remove();
            reindexStatements(tbody);
        }

        function reindexStatements(tbody) {
            if (!tbody) return;
            const rows = tbody.querySelectorAll('tr');
            rows.forEach((r, idx) => {
                const noEl = r.querySelector('.statement-no');
                if (noEl) noEl.textContent = idx + 1;
            });
        }

        const matchingLetters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];

        function addMatchingOptionRow(mode, text = '') {
            const container = document.getElementById(mode === 'edit' ? 'edit_q_matching_options_list' : 'add_q_matching_options_list');
            if (!container) return;
            const currentCount = container.querySelectorAll('.matching-opt-row').length;
            if (currentCount >= 10) {
                Swal.fire('Info', 'Maksimal 10 pilihan jawaban target', 'info');
                return;
            }
            const div = document.createElement('div');
            div.className = 'input-group input-group-sm mb-2 matching-opt-row';
            div.innerHTML = `
                <div class="input-group-prepend">
                    <span class="input-group-text font-weight-bold opt-label">Opsi ?</span>
                </div>
                <input type="text" class="form-control matching-opt-text" placeholder="Teks pilihan jawaban..." value="${text.replace(/"/g, '&quot;')}" oninput="refreshMatchingPremiseDropdowns('${mode}')">
                <div class="input-group-append">
                    <button type="button" class="btn btn-outline-danger" onclick="removeMatchingOptionRow(this, '${mode}')"><i class="fas fa-times"></i></button>
                </div>
            `;
            container.appendChild(div);
            reindexMatchingOptions(mode);
        }

        function removeMatchingOptionRow(btn, mode) {
            const container = document.getElementById(mode === 'edit' ? 'edit_q_matching_options_list' : 'add_q_matching_options_list');
            const rows = container.querySelectorAll('.matching-opt-row');
            if (rows.length <= 2) {
                Swal.fire('Peringatan', 'Minimal harus ada 2 pilihan jawaban', 'warning');
                return;
            }
            btn.closest('.matching-opt-row').remove();
            reindexMatchingOptions(mode);
        }

        function reindexMatchingOptions(mode) {
            const container = document.getElementById(mode === 'edit' ? 'edit_q_matching_options_list' : 'add_q_matching_options_list');
            if (!container) return;
            const rows = container.querySelectorAll('.matching-opt-row');
            rows.forEach((row, idx) => {
                const label = row.querySelector('.opt-label');
                if (label) label.textContent = 'Opsi ' + (matchingLetters[idx] || (idx + 1));
            });
            refreshMatchingPremiseDropdowns(mode);
        }

        function getMatchingOptions(mode) {
            const container = document.getElementById(mode === 'edit' ? 'edit_q_matching_options_list' : 'add_q_matching_options_list');
            if (!container) return [];
            const inputs = container.querySelectorAll('.matching-opt-text');
            const opts = [];
            inputs.forEach(inp => opts.push(inp.value.trim()));
            return opts;
        }

        function addMatchingPremiseRow(mode, text = '', selectedOptIdx = 0) {
            const tbody = document.getElementById(mode === 'edit' ? 'edit_q_matching_tbody' : 'add_q_matching_tbody');
            if (!tbody) return;
            const rowCount = tbody.querySelectorAll('tr').length + 1;
            const tr = document.createElement('tr');
            tr.className = 'matching-premise-row';
            tr.innerHTML = `
                <td class="text-center align-middle font-weight-bold premise-no">${rowCount}</td>
                <td><input type="text" class="form-control form-control-sm premise-text" placeholder="Ketik pernyataan baris ${rowCount}..." value="${text.replace(/"/g, '&quot;')}"></td>
                <td>
                    <select class="form-control form-control-sm premise-target" data-saved-idx="${selectedOptIdx}">
                        <!-- populated by refreshMatchingPremiseDropdowns -->
                    </select>
                </td>
                <td class="text-center align-middle">
                    <button type="button" class="btn btn-danger btn-xs" onclick="removeMatchingPremiseRow(this, '${mode}')"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tbody.appendChild(tr);
            reindexMatchingPremises(mode);
            refreshMatchingPremiseDropdowns(mode);
        }

        function removeMatchingPremiseRow(btn, mode) {
            const tbody = document.getElementById(mode === 'edit' ? 'edit_q_matching_tbody' : 'add_q_matching_tbody');
            const rows = tbody.querySelectorAll('tr');
            if (rows.length <= 1) {
                Swal.fire('Peringatan', 'Minimal harus ada 1 baris pernyataan', 'warning');
                return;
            }
            btn.closest('tr').remove();
            reindexMatchingPremises(mode);
        }

        function reindexMatchingPremises(mode) {
            const tbody = document.getElementById(mode === 'edit' ? 'edit_q_matching_tbody' : 'add_q_matching_tbody');
            if (!tbody) return;
            const rows = tbody.querySelectorAll('tr');
            rows.forEach((r, idx) => {
                const noEl = r.querySelector('.premise-no');
                if (noEl) noEl.textContent = idx + 1;
            });
        }

        function refreshMatchingPremiseDropdowns(mode) {
            const opts = getMatchingOptions(mode);
            const tbody = document.getElementById(mode === 'edit' ? 'edit_q_matching_tbody' : 'add_q_matching_tbody');
            if (!tbody) return;
            const selects = tbody.querySelectorAll('.premise-target');
            selects.forEach((sel) => {
                const currentVal = sel.value !== '' ? parseInt(sel.value) : (parseInt(sel.dataset.savedIdx) || 0);
                let optHtml = '';
                opts.forEach((o, i) => {
                    const char = matchingLetters[i] || (i + 1);
                    const label = o ? `${char}. ${o.length > 30 ? o.substring(0, 30) + '...' : o}` : `Opsi ${char}`;
                    optHtml += `<option value="${i}" ${currentVal === i ? 'selected' : ''}>${label}</option>`;
                });
                sel.innerHTML = optHtml;
                if (sel.value !== '') sel.dataset.savedIdx = sel.value;
            });
        }
        
        function editQuestion(index) {
            const q = currentQuestions[index];
            const examId = document.getElementById('preview_exam_id').value;
            
            document.getElementById('edit_q_exam_id').value = examId;
            document.getElementById('edit_q_index').value = index;
            document.getElementById('edit_q_text').value = q.question;
            document.getElementById('edit_q_points').value = q.points !== undefined ? q.points : 2;
            if ($('#edit_q_text').data('summernote')) {
                $('#edit_q_text').summernote('code', q.question);
            }
            
            const qType = q.type || 'multiple_choice';
            document.getElementById('edit_q_type').value = qType;
            toggleEditQType(qType);
            
            let optsHtml = '';
            let ansHtml = '';
            let complexCbHtml = '';
            
            if (qType === 'multiple_choice' || qType === 'complex_mc') {
                let optionsList = q.options && q.options.length > 0 ? [...q.options] : ['', '', '', ''];
                // Bersihkan opsi kosong di akhir jika ada
                while (optionsList.length > 2) {
                    const last = optionsList[optionsList.length - 1];
                    const clean = (typeof last === 'string') ? last.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, '').trim() : '';
                    if (clean === '' && (!last || (!last.includes('<img') && !last.includes('<audio') && !last.includes('<video')))) {
                        optionsList.pop();
                    } else {
                        break;
                    }
                }
                const optCount = (optionsList.length >= 5) ? 5 : 4;
                while (optionsList.length < 5) optionsList.push('');

                optionsList.forEach((opt, i) => {
                    const char = String.fromCharCode(65 + i);
                    const wrapAttr = (i === 4) ? 'id="edit_opt_wrapper_4"' : '';
                    const ansAttr = (i === 4) ? 'id="edit_ans_opt_4"' : '';
                    const chkWrapAttr = (i === 4) ? 'id="edit_chk_wrapper_4"' : '';

                    optsHtml += `
                        <div class="mb-3" ${wrapAttr}>
                            <label>Opsi ${char}</label>
                            <textarea name="option_${i}" class="form-control summernote-option-edit">${(opt || '').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
                        </div>
                    `;
                    ansHtml += `<option value="${i}" ${ansAttr} ${q.answer == i ? 'selected' : ''}>Pilihan ${char}</option>`;
                    
                    const isChecked = (q.answers && Array.isArray(q.answers) && q.answers.includes(i)) ? 'checked' : '';
                    complexCbHtml += `
                        <div class="form-check mr-3" ${chkWrapAttr}>
                            <input class="form-check-input edit-complex-ans" type="checkbox" value="${i}" id="edit_chk_${i}" ${isChecked}>
                            <label class="form-check-label font-weight-bold" for="edit_chk_${i}">Opsi ${char}</label>
                        </div>
                    `;
                });
                document.getElementById('edit_q_options_container').innerHTML = optsHtml;
                document.getElementById('edit_q_answer').innerHTML = ansHtml;
                document.getElementById('edit_q_complex_checkboxes').innerHTML = complexCbHtml;
                
                setOptionCount('edit', optCount);
                
                setTimeout(() => {
                    $('.summernote-option-edit').summernote(typeof window.getSummernoteConfig === 'function' ? window.getSummernoteConfig(100) : {
                        height: 100,
                        toolbar: [
                            ['style', ['style']],
                            ['font', ['bold', 'italic', 'underline', 'clear']],
                            ['para', ['ul', 'ol', 'paragraph']],
                            ['table', ['table']],
                            ['insert', ['picture', 'link', 'hr']],
                            ['view', ['fullscreen', 'codeview']]
                        ]
                    });
                }, 100);
            } else if (qType === 'true_false') {
                const tbody = document.getElementById('edit_q_tf_tbody');
                tbody.innerHTML = '';
                if (q.statements && Array.isArray(q.statements)) {
                    q.statements.forEach((s) => {
                        addStatementRow('edit', s.text, s.answer === true || s.answer === 'true');
                    });
                } else {
                    addStatementRow('edit', '', true);
                    addStatementRow('edit', '', false);
                }
            } else if (qType === 'matching') {
                const optList = document.getElementById('edit_q_matching_options_list');
                const tbody = document.getElementById('edit_q_matching_tbody');
                if (optList) optList.innerHTML = '';
                if (tbody) tbody.innerHTML = '';
                
                const options = q.options && q.options.length > 0 ? q.options : ['Pilihan A', 'Pilihan B'];
                options.forEach(opt => {
                    addMatchingOptionRow('edit', opt);
                });
                
                const premises = q.premises && q.premises.length > 0 ? q.premises : ['Pernyataan 1'];
                premises.forEach((p, pIdx) => {
                    let targetIdx = 0;
                    if (q.pairs) {
                        targetIdx = q.pairs[pIdx] !== undefined ? q.pairs[pIdx] : (q.pairs[String(pIdx)] !== undefined ? q.pairs[String(pIdx)] : 0);
                    }
                    addMatchingPremiseRow('edit', p, targetIdx);
                });
            }
            
            $('#modalEditSoal').modal('show');
        }
        
        async function submitEditQuestion(e) {
            e.preventDefault();
            const form = e.target;
            const fd = new FormData(form);
            const type = document.getElementById('edit_q_type').value;
            const examId = document.getElementById('edit_q_exam_id').value || document.getElementById('preview_exam_id').value;
            const index = document.getElementById('edit_q_index').value;

            if (!examId) {
                Swal.fire('Oops', 'ID Bank Soal tidak valid', 'error');
                return;
            }

            const qText = $('#edit_q_text').data('summernote') ? $('#edit_q_text').summernote('code') : document.getElementById('edit_q_text').value;
            const cleanQText = qText.replace(/<[^>]*>/g, '').trim();
            if (!cleanQText && !qText.includes('<img')) {
                Swal.fire('Oops', 'Pertanyaan / stimulus tidak boleh kosong', 'warning');
                return;
            }

            fd.append('action', 'edit_question_item');
            fd.append('exam_id', examId);
            fd.append('index', index);
            fd.append('type', type);
            fd.append('question', qText);
            fd.append('points', document.getElementById('edit_q_points').value || 2);
            
            if (type === 'multiple_choice' || type === 'complex_mc') {
                const is4Opt = document.getElementById('btn_edit_opt_4') && document.getElementById('btn_edit_opt_4').classList.contains('active');
                $('.summernote-option-edit').each(function(i, el) {
                    const name = $(el).attr('name');
                    if (is4Opt && name === 'option_4') return;
                    const code = $(el).data('summernote') ? $(el).summernote('code') : $(el).val();
                    fd.set(name, code);
                });

                if (type === 'multiple_choice') {
                    fd.append('answer', document.getElementById('edit_q_answer').value);
                } else if (type === 'complex_mc') {
                    const checked = [];
                    document.querySelectorAll('.edit-complex-ans:checked').forEach(cb => checked.push(parseInt(cb.value)));
                    if (checked.length === 0) {
                        Swal.fire('Oops', 'Pilih minimal 1 kunci jawaban benar untuk Pilihan Ganda Kompleks', 'warning');
                        return;
                    }
                    fd.append('answers', JSON.stringify(checked));
                }
            } else if (type === 'true_false') {
                const stmts = [];
                const rows = document.querySelectorAll('#edit_q_tf_tbody tr');
                rows.forEach(r => {
                    const text = r.querySelector('.statement-text').value.trim();
                    const ans = r.querySelector('.statement-ans').value === 'true';
                    if (text) stmts.push({ text: text, answer: ans });
                });
                if (stmts.length === 0) {
                    Swal.fire('Oops', 'Minimal harus ada 1 pernyataan untuk soal Benar-Salah', 'warning');
                    return;
                }
                fd.append('statements', JSON.stringify(stmts));
            } else if (type === 'matching') {
                const opts = getMatchingOptions('edit');
                const validOpts = opts.filter(o => o.trim() !== '');
                if (validOpts.length < 2) {
                    Swal.fire('Oops', 'Minimal harus ada 2 pilihan jawaban pada kolom kanan', 'warning');
                    return;
                }
                
                const premises = [];
                const pairs = {};
                const rows = document.querySelectorAll('#edit_q_matching_tbody tr');
                rows.forEach((r, idx) => {
                    const text = r.querySelector('.premise-text').value.trim();
                    const targetIdx = parseInt(r.querySelector('.premise-target').value);
                    if (text) {
                        premises.push(text);
                        pairs[premises.length - 1] = isNaN(targetIdx) ? 0 : targetIdx;
                    }
                });
                if (premises.length === 0) {
                    Swal.fire('Oops', 'Minimal harus ada 1 baris pernyataan pada kolom kiri', 'warning');
                    return;
                }
                fd.append('options', JSON.stringify(opts));
                fd.append('premises', JSON.stringify(premises));
                fd.append('pairs', JSON.stringify(pairs));
            }
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    $('#modalEditSoal').modal('hide');
                    $('body').removeClass('modal-open');
                    $('.modal-backdrop').remove();
                    await loadQuestions();
                    Swal.fire({
                        title: 'Sukses',
                        text: json.message,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: true
                    });
                } else {
                    Swal.fire('Gagal', json.message, 'error');
                }
            } catch(err) { Swal.fire('Error', 'Gagal menyimpan soal: ' + err.message, 'error'); }
        }
        
        async function autoSetPoints() {
            const examId = document.getElementById('preview_exam_id').value;
            if (!examId) return;
            
            const confirmResult = await Swal.fire({
                title: 'Set Poin Otomatis?',
                html: 'Poin seluruh butir soal pada bank soal ini akan diratakan secara otomatis agar <b>total akumulasi skor tepat bernilai 100</b>.<br><br>Lanjutkan?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#ffc107',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<span class="text-dark font-weight-bold"><i class="fas fa-magic mr-1"></i> Ya, Set Poin!</span>',
                cancelButtonText: 'Batal'
            });

            if (!confirmResult.isConfirmed) return;
            
            const fd = new FormData();
            fd.append('action', 'auto_set_points');
            fd.append('exam_id', examId);
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    Swal.fire('Sukses', json.message, 'success');
                    loadQuestions();
                } else {
                    Swal.fire('Gagal', json.message, 'error');
                }
            } catch(err) { Swal.fire('Error', 'Gagal mengatur poin otomatis', 'error'); }
        }

        async function recalculateBankScores(bankId) {
            const bId = bankId || document.getElementById('preview_exam_id').value;
            if (!bId) {
                Swal.fire('Oops', 'ID Bank Soal tidak ditemukan', 'warning');
                return;
            }

            const confirmResult = await Swal.fire({
                title: 'Hitung Ulang Nilai Siswa?',
                html: 'Sistem akan mengevaluasi kembali jawaban seluruh siswa yang telah menyelesaikan ujian dari Bank Soal ini berdasarkan <b>kunci jawaban terbaru saat ini</b>.<br><br><small class="text-muted">Gunakan fitur ini jika kunci jawaban baru saja diubah, diedit, atau diperbaiki.</small>',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#007bff',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-calculator mr-1"></i> Ya, Hitung Ulang!',
                cancelButtonText: 'Batal'
            });

            if (!confirmResult.isConfirmed) return;

            try {
                Swal.fire({
                    title: 'Memproses...',
                    text: 'Sedang menghitung ulang nilai seluruh siswa...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });

                const fd = new FormData();
                fd.append('action', 'recalculate_scores');
                fd.append('bank_id', bId);

                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();

                if (json.status === 'success') {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: json.message,
                        icon: 'success'
                    });
                } else {
                    Swal.fire('Gagal', json.message || 'Gagal menghitung ulang nilai', 'error');
                }
            } catch (err) {
                Swal.fire('Error', 'Terjadi kesalahan sistem: ' + err.message, 'error');
            }
        }

        async function optimizeBankImagesWebp() {
            const examId = document.getElementById('preview_exam_id') ? document.getElementById('preview_exam_id').value : '';
            if (!examId) return;

            const confirm = await Swal.fire({
                title: 'Optimasi Gambar ke WebP?',
                text: 'Sistem akan memindai seluruh gambar di bank soal ini dan mengonversinya menjadi format .webp berkualitas tinggi agar sangat ringan dan cepat dimuat oleh siswa.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#17a2b8',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-bolt mr-1"></i> Mulai Optimasi',
                cancelButtonText: 'Batal'
            });

            if (!confirm.isConfirmed) return;

            Swal.fire({
                title: 'Mengoptimasi Gambar...',
                text: 'Mohon tunggu, proses konversi ke format WebP sedang berjalan...',
                allowOutsideClick: false,
                didOpen: () => Swal.showLoading()
            });

            try {
                const fd = new FormData();
                fd.append('bank_id', examId);
                const res = await fetch('api.php?action=optimize_bank_images_webp', { method: 'POST', body: fd });
                const json = await res.json();

                if (json.status === 'success') {
                    Swal.fire({
                        title: 'Berhasil!',
                        text: json.message,
                        icon: 'success'
                    });
                    loadQuestions();
                } else {
                    Swal.fire('Gagal', json.message || 'Gagal mengoptimasi gambar', 'error');
                }
            } catch (err) {
                Swal.fire('Error', 'Terjadi kesalahan sistem: ' + err.message, 'error');
            }
        }

        function openModalKunciExcel() {
            const countEl = document.getElementById('tpl-current-q-count');
            const totalQ = currentQuestions ? currentQuestions.length : 0;
            if (countEl) countEl.innerText = totalQ;

            // Set radio default
            if (totalQ > 0) {
                const curRadio = document.getElementById('template_source_current');
                if (curRadio) curRadio.checked = true;
                toggleTemplateSource('current');
            } else {
                const cusRadio = document.getElementById('template_source_custom');
                if (cusRadio) cusRadio.checked = true;
                toggleTemplateSource('custom');
            }

            // Set default custom count
            const customCountInp = document.getElementById('tpl_custom_count');
            if (customCountInp && totalQ > 0) {
                customCountInp.value = totalQ;
            }

            // Reset form import
            const formImport = document.getElementById('form-import-kunci-excel');
            if (formImport) formImport.reset();

            // Set tab active to tab 1
            $('#tabKunciExcel a[href="#tab-unduh-kunci"]').tab('show');
            $('#modalKunciExcel').modal('show');
        }

        function toggleTemplateSource(val) {
            const container = document.getElementById('container-kustom-template');
            if (container) {
                container.style.display = (val === 'custom') ? 'block' : 'none';
            }
        }

        function downloadTemplateKunciExcel() {
            const source = document.querySelector('input[name="template_source"]:checked')?.value || 'current';
            const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
            
            const rows = [];
            // Header baris tabel
            rows.push(['No Soal', 'Tipe Soal', 'Kunci Jawaban', 'Bobot Poin', 'Ringkasan Soal']);

            if (source === 'current' && currentQuestions && currentQuestions.length > 0) {
                currentQuestions.forEach((q, idx) => {
                    const no = idx + 1;
                    const type = q.type || 'multiple_choice';
                    let typeLabel = 'Pilihan Ganda';
                    let keyDisplay = '';

                    if (type === 'multiple_choice') {
                        typeLabel = 'Pilihan Ganda';
                        const ansIdx = (q.answer !== undefined && q.answer !== null) ? parseInt(q.answer) : null;
                        keyDisplay = (ansIdx !== null && letters[ansIdx]) ? letters[ansIdx] : '';
                    } else if (type === 'complex_mc') {
                        typeLabel = 'PG Kompleks';
                        const ansArr = Array.isArray(q.answers) ? q.answers : (q.answer !== undefined ? [q.answer] : []);
                        const letterArr = ansArr.map(a => letters[parseInt(a)] || a);
                        keyDisplay = letterArr.join(', ');
                    } else if (type === 'true_false') {
                        typeLabel = 'Benar - Salah';
                        const stmts = q.statements || [];
                        const tfArr = stmts.map(s => (s.answer === true || s.answer === 'true' || s.answer === 1 || s.answer === '1' || String(s.answer).toLowerCase() === 'b') ? 'B' : 'S');
                        keyDisplay = tfArr.join(', ');
                    } else if (type === 'matching') {
                        typeLabel = 'Menjodohkan';
                        const pairs = q.pairs || {};
                        const pairArr = [];
                        (q.premises || []).forEach((p, pIdx) => {
                            const optIdx = pairs[pIdx] !== undefined ? pairs[pIdx] : (pairs[String(pIdx)] !== undefined ? pairs[String(pIdx)] : null);
                            const optLetter = optIdx !== null && letters[parseInt(optIdx)] ? letters[parseInt(optIdx)] : '-';
                            pairArr.push(optLetter);
                        });
                        keyDisplay = pairArr.join(', ');
                    } else if (type === 'essay') {
                        typeLabel = 'Esai';
                        keyDisplay = 'Koreksi Manual';
                    }

                    const points = q.points !== undefined ? q.points : 2;
                    const cleanQ = (q.question || '').replace(/<[^>]*>?/gm, '').trim().substring(0, 80);

                    rows.push([no, typeLabel, keyDisplay, points, cleanQ]);
                });
            } else {
                // Kustom Manual
                const customType = document.getElementById('tpl_custom_type')?.value || 'multiple_choice';
                const count = Math.min(250, Math.max(1, parseInt(document.getElementById('tpl_custom_count')?.value || '40')));
                const defaultPoints = parseFloat(document.getElementById('tpl_custom_points')?.value || '2.5');

                let typeLabel = 'Pilihan Ganda';
                let exampleKey = 'A';
                if (customType === 'complex_mc') {
                    typeLabel = 'PG Kompleks';
                    exampleKey = 'A, C';
                } else if (customType === 'true_false') {
                    typeLabel = 'Benar - Salah';
                    exampleKey = 'B, S, B';
                } else if (customType === 'matching') {
                    typeLabel = 'Menjodohkan';
                    exampleKey = 'A, C, B';
                }

                for (let i = 1; i <= count; i++) {
                    const kVal = (i === 1) ? exampleKey : '';
                    rows.push([i, typeLabel, kVal, defaultPoints, '']);
                }
            }

            const worksheet = XLSX.utils.aoa_to_sheet(rows);
            worksheet['!cols'] = [
                { wch: 10 }, // No Soal
                { wch: 18 }, // Tipe Soal
                { wch: 18 }, // Kunci Jawaban
                { wch: 12 }, // Bobot Poin
                { wch: 45 }  // Ringkasan Soal
            ];

            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Kunci Jawaban");

            const examName = document.getElementById('detail-soal-title')?.innerText?.replace('Kelola Soal: ', '') || 'Bank_Soal';
            const safeName = examName.replace(/[^a-zA-Z0-9]/g, '_');
            XLSX.writeFile(workbook, `Template_Kunci_${safeName}.xlsx`, { compression: true });
        }

        async function submitImportKunciExcel(e) {
            e.preventDefault();
            const fileInput = document.getElementById('file_kunci_excel');
            const file = fileInput.files[0];
            if (!file) {
                Swal.fire('Oops', 'Pilih file Excel terlebih dahulu', 'warning');
                return;
            }

            const examId = document.getElementById('preview_exam_id')?.value;
            if (!examId) {
                Swal.fire('Error', 'ID Bank Soal tidak ditemukan', 'error');
                return;
            }

            const autoRecalc = document.getElementById('cb_auto_recalc_excel')?.checked ? 1 : 0;

            try {
                Swal.fire({
                    title: 'Membaca File Excel...',
                    text: 'Sedang mengekstrak data kunci jawaban...',
                    allowOutsideClick: false,
                    didOpen: () => Swal.showLoading()
                });

                const data = await file.arrayBuffer();
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[firstSheetName];
                const rawJson = XLSX.utils.sheet_to_json(worksheet);

                if (!rawJson || rawJson.length === 0) {
                    Swal.fire('Gagal', 'File Excel kosong atau tidak memiliki baris data', 'error');
                    return;
                }

                // Normalisasi nama kolom objek
                const keysData = [];
                rawJson.forEach(row => {
                    let no = null;
                    let kunci = null;
                    let points = null;

                    for (const prop in row) {
                        const cleanProp = prop.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
                        if (cleanProp === 'nosoal' || cleanProp === 'no' || cleanProp === 'nomor') {
                            no = parseInt(row[prop]);
                        } else if (cleanProp === 'kuncijawaban' || cleanProp === 'kunci' || cleanProp === 'jawaban') {
                            kunci = String(row[prop]).trim();
                        } else if (cleanProp === 'bobotpoin' || cleanProp === 'poin' || cleanProp === 'points' || cleanProp === 'bobot') {
                            const p = parseFloat(row[prop]);
                            if (!isNaN(p)) points = p;
                        }
                    }

                    if (no !== null && !isNaN(no)) {
                        keysData.push({
                            no_soal: no,
                            kunci: kunci !== null ? kunci : '',
                            points: points
                        });
                    }
                });

                if (keysData.length === 0) {
                    Swal.fire('Gagal', 'Tidak ada data kolom "No Soal" atau nomor soal yang valid pada file Excel', 'error');
                    return;
                }

                Swal.fire({
                    title: 'Menyimpan Kunci...',
                    text: `Menerapkan kunci jawaban untuk ${keysData.length} butir soal...`,
                    allowOutsideClick: false,
                    didOpen: () => Swal.showLoading()
                });

                const fd = new FormData();
                fd.append('action', 'import_kunci_jawaban');
                fd.append('exam_id', examId);
                fd.append('keys_data', JSON.stringify(keysData));
                fd.append('auto_recalculate', autoRecalc);

                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();

                if (json.status === 'success') {
                    $('#modalKunciExcel').modal('hide');
                    $('body').removeClass('modal-open');
                    $('.modal-backdrop').remove();

                    await loadQuestions();

                    Swal.fire({
                        title: 'Berhasil!',
                        text: json.message,
                        icon: 'success'
                    });
                } else {
                    Swal.fire('Gagal', json.message || 'Gagal menyimpan kunci jawaban', 'error');
                }
            } catch (err) {
                console.error(err);
                Swal.fire('Error', 'Gagal memproses file Excel: ' + err.message, 'error');
            }
        }
        
        async function deleteQuestion(index) {
            const result = await Swal.fire({
                title: 'Konfirmasi',
                text: 'Yakin ingin menghapus soal ini?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const examId = document.getElementById('preview_exam_id').value;
                const fd = new FormData();
                fd.append('action', 'delete_question_item');
                fd.append('exam_id', examId);
                fd.append('index', index);
                
                try {
                    const res = await fetch('api.php', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Berhasil!',
                            text: 'Soal berhasil dihapus.',
                            icon: 'success',
                            timer: 1000,
                            showConfirmButton: false
                        }).then(() => {
                            loadQuestions();
                        });
                    } else {
                        Swal.fire('Gagal', json.message, 'error');
                    }
                } catch(err) { Swal.fire('Gagal', 'Gagal menghapus soal', 'error'); }
            }
        }
        
        function toggleAddQType(val) {
            const mcFields = document.getElementById('add_q_mc_fields');
            const singleAns = document.getElementById('add_q_single_answer_container');
            const complexAns = document.getElementById('add_q_complex_answer_container');
            const tfFields = document.getElementById('add_q_tf_fields');
            const matchFields = document.getElementById('add_q_matching_fields');
            
            if (val === 'multiple_choice') {
                if (mcFields) mcFields.style.display = 'block';
                if (singleAns) singleAns.style.display = 'block';
                if (complexAns) complexAns.style.display = 'none';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'none';
            } else if (val === 'complex_mc') {
                if (mcFields) mcFields.style.display = 'block';
                if (singleAns) singleAns.style.display = 'none';
                if (complexAns) complexAns.style.display = 'block';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'none';
            } else if (val === 'true_false') {
                if (mcFields) mcFields.style.display = 'none';
                if (tfFields) tfFields.style.display = 'block';
                if (matchFields) matchFields.style.display = 'none';
            } else if (val === 'matching') {
                if (mcFields) mcFields.style.display = 'none';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'block';
            } else if (val === 'essay') {
                if (mcFields) mcFields.style.display = 'none';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'none';
            }
        }

        function setOptionCount(mode, count) {
            if (mode === 'add') {
                const btn4 = document.getElementById('btn_add_opt_4');
                const btn5 = document.getElementById('btn_add_opt_5');
                const wrap4 = document.getElementById('add_opt_wrapper_4');
                const ansOpt4 = document.getElementById('add_ans_opt_4');
                const chkWrap4 = document.getElementById('add_chk_wrapper_4');
                const ansSelect = document.getElementById('add_q_answer');

                if (count === 4) {
                    if (btn4) { btn4.classList.add('active', 'btn-primary'); btn4.classList.remove('btn-outline-primary'); }
                    if (btn5) { btn5.classList.remove('active', 'btn-primary'); btn5.classList.add('btn-outline-primary'); }
                    if (wrap4) wrap4.style.display = 'none';
                    if (ansOpt4) ansOpt4.style.display = 'none';
                    if (chkWrap4) {
                        chkWrap4.style.display = 'none';
                        const chk = document.getElementById('add_chk_4');
                        if (chk) chk.checked = false;
                    }
                    if (ansSelect && ansSelect.value === '4') ansSelect.value = '0';
                } else {
                    if (btn5) { btn5.classList.add('active', 'btn-primary'); btn5.classList.remove('btn-outline-primary'); }
                    if (btn4) { btn4.classList.remove('active', 'btn-primary'); btn4.classList.add('btn-outline-primary'); }
                    if (wrap4) wrap4.style.display = 'block';
                    if (ansOpt4) ansOpt4.style.display = 'block';
                    if (chkWrap4) chkWrap4.style.display = 'block';
                }
            } else if (mode === 'edit') {
                const btn4 = document.getElementById('btn_edit_opt_4');
                const btn5 = document.getElementById('btn_edit_opt_5');
                const wrap4 = document.getElementById('edit_opt_wrapper_4');
                const ansOpt4 = document.getElementById('edit_ans_opt_4');
                const chkWrap4 = document.getElementById('edit_chk_wrapper_4');
                const ansSelect = document.getElementById('edit_q_answer');

                if (count === 4) {
                    if (btn4) { btn4.classList.add('active', 'btn-primary'); btn4.classList.remove('btn-outline-primary'); }
                    if (btn5) { btn5.classList.remove('active', 'btn-primary'); btn5.classList.add('btn-outline-primary'); }
                    if (wrap4) wrap4.style.display = 'none';
                    if (ansOpt4) ansOpt4.style.display = 'none';
                    if (chkWrap4) {
                        chkWrap4.style.display = 'none';
                        const chk = document.getElementById('edit_chk_4');
                        if (chk) chk.checked = false;
                    }
                    if (ansSelect && ansSelect.value === '4') ansSelect.value = '0';
                } else {
                    if (btn5) { btn5.classList.add('active', 'btn-primary'); btn5.classList.remove('btn-outline-primary'); }
                    if (btn4) { btn4.classList.remove('active', 'btn-primary'); btn4.classList.add('btn-outline-primary'); }
                    if (wrap4) wrap4.style.display = 'block';
                    if (ansOpt4) ansOpt4.style.display = 'block';
                    if (chkWrap4) chkWrap4.style.display = 'block';
                }
            }
        }

        function toggleEditQType(val) {
            const mcFields = document.getElementById('edit_q_mc_fields');
            const singleAns = document.getElementById('edit_q_single_answer_container');
            const complexAns = document.getElementById('edit_q_complex_answer_container');
            const tfFields = document.getElementById('edit_q_tf_fields');
            const matchFields = document.getElementById('edit_q_matching_fields');
            
            if (val === 'multiple_choice') {
                if (mcFields) mcFields.style.display = 'block';
                if (singleAns) singleAns.style.display = 'block';
                if (complexAns) complexAns.style.display = 'none';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'none';
            } else if (val === 'complex_mc') {
                if (mcFields) mcFields.style.display = 'block';
                if (singleAns) singleAns.style.display = 'none';
                if (complexAns) complexAns.style.display = 'block';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'none';
            } else if (val === 'true_false') {
                if (mcFields) mcFields.style.display = 'none';
                if (tfFields) tfFields.style.display = 'block';
                if (matchFields) matchFields.style.display = 'none';
            } else if (val === 'matching') {
                if (mcFields) mcFields.style.display = 'none';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'block';
            } else if (val === 'essay') {
                if (mcFields) mcFields.style.display = 'none';
                if (tfFields) tfFields.style.display = 'none';
                if (matchFields) matchFields.style.display = 'none';
            }
        }

        function openAddQModal() {
            const examId = document.getElementById('preview_exam_id').value;
            if (!examId) return;
            
            // 1. Reset form controls first
            document.getElementById('form-add-soal').reset();
            
            // 2. Set the target exam ID
            document.getElementById('add_q_exam_id').value = examId;
            
            // 3. Clear summernote question text
            document.getElementById('add_q_text').value = '';
            if ($('#add_q_text').data('summernote')) {
                $('#add_q_text').summernote('code', '');
            }
            
            // 4. Default type to multiple choice
            document.getElementById('add_q_type').value = 'multiple_choice';
            toggleAddQType('multiple_choice');
            
            // 5. Clear summernote options
            $('.summernote-option-add').each(function() {
                if ($(this).data('summernote')) {
                    $(this).summernote('code', '');
                } else {
                    $(this).val('');
                }
            });
            
            const is4 = document.getElementById('btn_add_opt_4') && document.getElementById('btn_add_opt_4').classList.contains('active');
            setOptionCount('add', is4 ? 4 : 5);
            
            // 6. Reset Benar-Salah statement rows
            const tfTbody = document.getElementById('add_q_tf_tbody');
            if (tfTbody) {
                tfTbody.innerHTML = '';
                addStatementRow('add', '', true);
                addStatementRow('add', '', false);
            }

            // 7. Reset Matching rows
            const addOptList = document.getElementById('add_q_matching_options_list');
            const addPremiseTbody = document.getElementById('add_q_matching_tbody');
            if (addOptList) {
                addOptList.innerHTML = '';
                addMatchingOptionRow('add', '');
                addMatchingOptionRow('add', '');
                addMatchingOptionRow('add', '');
            }
            if (addPremiseTbody) {
                addPremiseTbody.innerHTML = '';
                addMatchingPremiseRow('add', '', 0);
                addMatchingPremiseRow('add', '', 1);
            }
            
            $('#modalAddSoal').modal('show');
        }
        
        async function submitAddQuestion(e) {
            e.preventDefault();
            const form = e.target;
            const fd = new FormData(form);
            const type = document.getElementById('add_q_type').value;
            const examId = document.getElementById('add_q_exam_id').value || document.getElementById('preview_exam_id').value;
            
            if (!examId) {
                Swal.fire('Oops', 'ID Bank Soal tidak valid', 'error');
                return;
            }

            const qText = $('#add_q_text').data('summernote') ? $('#add_q_text').summernote('code') : document.getElementById('add_q_text').value;
            const cleanQText = qText.replace(/<[^>]*>/g, '').trim();
            if (!cleanQText && !qText.includes('<img')) {
                Swal.fire('Oops', 'Pertanyaan / stimulus tidak boleh kosong', 'warning');
                return;
            }

            fd.append('action', 'add_question_item');
            fd.append('exam_id', examId);
            fd.append('type', type);
            fd.append('question', qText);
            fd.append('points', document.getElementById('add_q_points').value || 2);

            if (type === 'multiple_choice' || type === 'complex_mc') {
                const is4Opt = document.getElementById('btn_add_opt_4') && document.getElementById('btn_add_opt_4').classList.contains('active');
                $('.summernote-option-add').each(function(i, el) {
                    const name = $(el).attr('name');
                    if (is4Opt && name === 'option_4') return;
                    const code = $(el).data('summernote') ? $(el).summernote('code') : $(el).val();
                    fd.set(name, code);
                });

                if (type === 'multiple_choice') {
                    fd.append('answer', document.getElementById('add_q_answer').value);
                } else if (type === 'complex_mc') {
                    const checked = [];
                    document.querySelectorAll('input[name="add_complex_ans[]"]:checked').forEach(cb => checked.push(parseInt(cb.value)));
                    if (checked.length === 0) {
                        Swal.fire('Oops', 'Pilih minimal 1 kunci jawaban benar untuk Pilihan Ganda Kompleks', 'warning');
                        return;
                    }
                    fd.append('answers', JSON.stringify(checked));
                }
            } else if (type === 'true_false') {
                const stmts = [];
                const rows = document.querySelectorAll('#add_q_tf_tbody tr');
                rows.forEach(r => {
                    const text = r.querySelector('.statement-text').value.trim();
                    const ans = r.querySelector('.statement-ans').value === 'true';
                    if (text) stmts.push({ text: text, answer: ans });
                });
                if (stmts.length === 0) {
                    Swal.fire('Oops', 'Minimal harus ada 1 pernyataan untuk soal Benar-Salah', 'warning');
                    return;
                }
                fd.append('statements', JSON.stringify(stmts));
            } else if (type === 'matching') {
                const opts = getMatchingOptions('add');
                const validOpts = opts.filter(o => o.trim() !== '');
                if (validOpts.length < 2) {
                    Swal.fire('Oops', 'Minimal harus ada 2 pilihan jawaban pada kolom kanan', 'warning');
                    return;
                }
                
                const premises = [];
                const pairs = {};
                const rows = document.querySelectorAll('#add_q_matching_tbody tr');
                rows.forEach((r, idx) => {
                    const text = r.querySelector('.premise-text').value.trim();
                    const targetIdx = parseInt(r.querySelector('.premise-target').value);
                    if (text) {
                        premises.push(text);
                        pairs[premises.length - 1] = isNaN(targetIdx) ? 0 : targetIdx;
                    }
                });
                if (premises.length === 0) {
                    Swal.fire('Oops', 'Minimal harus ada 1 baris pernyataan pada kolom kiri', 'warning');
                    return;
                }
                fd.append('options', JSON.stringify(opts));
                fd.append('premises', JSON.stringify(premises));
                fd.append('pairs', JSON.stringify(pairs));
            }
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') {
                    $('#modalAddSoal').modal('hide');
                    $('body').removeClass('modal-open');
                    $('.modal-backdrop').remove();
                    await loadQuestions();
                    Swal.fire({
                        title: 'Sukses',
                        text: json.message,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: true
                    });
                } else {
                    Swal.fire('Gagal', json.message, 'error');
                }
            } catch(err) { Swal.fire('Error', 'Gagal menambah soal: ' + err.message, 'error'); }
        }

        const formatJsonSampleText = `[
    {
        "type": "multiple_choice",
        "question": "<p>Hitunglah akar persamaan kuadrat $$x^2 - 5x + 6 = 0$$:</p>",
        "options": ["$x = 2$ atau $x = 3$", "$x = -2$ atau $x = -3$", "$x = 1$ atau $x = 6$", "$x = -1$ atau $x = 6$"],
        "answer": 0,
        "points": 2.5
    },
    {
        "type": "multiple_choice",
        "question": "<p>Tentukan hasil dari integral $$\\int_{0}^{2} 3x^2 \\, dx$$:</p>",
        "options": ["8", "12", "6", "16"],
        "answer": 0,
        "points": 2.5
    },
    {
        "type": "complex_mc",
        "question": "<p>Manakah identitas trigonometri yang bernilai <strong>benar</strong>? (Pilih lebih dari 1)</p>",
        "options": ["$$\\\\sin^2 \\\\theta + \\\\cos^2 \\\\theta = 1$$", "$$\\\\tan \\\\theta = \\\\frac{\\\\sin \\\\theta}{\\\\cos \\\\theta}$$", "$$\\\\sin(2\\\\theta) = \\\\cos^2 \\\\theta$$", "$$\\\\sec^2 \\\\theta - \\\\tan^2 \\\\theta = 1$$"],
        "answers": [0, 1, 3],
        "points": 3.0
    },
    {
        "type": "true_false",
        "question": "<p>Tentukan Benar atau Salah untuk pernyataan matematika berikut:</p>",
        "statements": [
            { "text": "Nilai dari $\\\\sqrt{144}$ adalah $12$", "answer": true },
            { "text": "Jika $f(x) = 2x + 1$, maka turunan pertamanya $f'(x) = 1$", "answer": false }
        ],
        "points": 2.0
    },
    {
        "type": "matching",
        "question": "<p>Jodohkan bangun ruang dengan rumus volumenya yang sesuai:</p>",
        "premises": ["Kubus sisi $s$", "Tabung jari-jari $r$, tinggi $t$", "Bola jari-jari $r$"],
        "options": ["$V = s^3$", "$V = \\\\pi r^2 t$", "$V = \\\\frac{4}{3} \\\\pi r^3$", "$V = \\\\frac{1}{3} \\\\pi r^2 t$"],
        "pairs": { "0": 0, "1": 1, "2": 2 },
        "points": 3.0
    },
    {
        "type": "essay",
        "question": "<p>Tuliskan langkah-langkah menentukan nilai limit $\\\\lim_{x \\\\to 0} \\\\frac{\\\\sin x}{x}$!</p>",
        "points": 5.0
    }
]`;

        function copyFormatJsonSample() {
            const btn = document.getElementById('btn-copy-sample-json');
            const onCopied = () => {
                if (btn) {
                    btn.className = 'btn btn-success btn-sm';
                    btn.style.fontWeight = '400';
                    btn.innerHTML = '<i class="fas fa-check mr-1"></i> Berhasil Disalin!';
                    setTimeout(() => {
                        if (btn) {
                            btn.className = 'btn btn-outline-primary btn-sm';
                            btn.style.fontWeight = '400';
                            btn.innerHTML = '<i class="fas fa-copy mr-1"></i> Salin Format JSON';
                        }
                    }, 2500);
                }
            };

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(formatJsonSampleText).then(onCopied).catch(() => {
                    fallbackCopyJson(formatJsonSampleText, onCopied);
                });
            } else {
                fallbackCopyJson(formatJsonSampleText, onCopied);
            }
        }

        function fallbackCopyJson(text, cb) {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.top = '-9999px';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            try {
                document.execCommand('copy');
                if (cb) cb();
            } catch(e) {
                console.error('Copy fallback error:', e);
            }
            document.body.removeChild(ta);
        }

        function showFormatSoal() {
            Swal.fire({
                title: 'Contoh Format JSON (Dukungan MathJax / KaTeX)',
                html: `
                <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                    <span class="text-muted small"><i class="fas fa-code mr-1"></i> Format JSON Valid (Mendukung Rumus Matematika)</span>
                    <button type="button" class="btn btn-outline-primary btn-sm" id="btn-copy-sample-json" onclick="copyFormatJsonSample()" style="font-size: 12px; padding: 3px 12px; font-weight: 400;">
                        <i class="fas fa-copy mr-1"></i> Salin Format JSON
                    </button>
                </div>
                <pre style="text-align: left; background: #282c34; color: #abb2bf; padding: 12px 14px; border-radius: 6px; font-size: 12.5px; max-height: 280px; overflow: auto; line-height: 1.45; font-family: Consolas, Monaco, 'Courier New', monospace;"><code>${formatJsonSampleText.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</code></pre>
                <div class="text-sm text-left mt-2" style="font-size: 13px;">
                    <div class="alert alert-info py-2 px-3 mb-2" style="font-size: 12px;">
                        <i class="fas fa-square-root-alt text-primary mr-1"></i> <strong>Dukungan Rumus Matematika (KaTeX / MathJax):</strong><br>
                        Gunakan delimiter <code>$...$</code> untuk rumus sejajar teks (inline), atau <code>$$...$$</code> untuk rumus blok/terpusat. Contoh: <code>$x^2 + y^2 = r^2$</code> atau <code>$$\\\\frac{a}{b}$$</code>.
                    </div>
                    <b>Keterangan Tipe Soal:</b>
                    <ul class="pl-3 mt-1 mb-0">
                        <li><code>multiple_choice</code>: PG biasa, gunakan <code>answer</code> (angka indeks opsi benar: 0, 1, dst).</li>
                        <li><code>complex_mc</code>: PG Kompleks, gunakan <code>answers</code> (array angka opsi benar: misal <code>[0, 2]</code>).</li>
                        <li><code>true_false</code>: Benar/Salah, gunakan <code>statements</code> (array objek dengan <code>text</code> & <code>answer: true/false</code>).</li>
                        <li><code>matching</code>: Menjodohkan, gunakan <code>premises</code> (array baris kiri), <code>options</code> (array opsi kanan), dan <code>pairs</code> (pemetaan indeks baris kiri -> indeks opsi kanan).</li>
                        <li><code>essay</code>: Uraian/Esai siswa dikoreksi manual oleh pengawas/guru.</li>
                    </ul>
                </div>`,
                icon: 'info',
                confirmButtonText: 'Tutup',
                width: '720px'
            });
        }

        async function promptTemplatePGBiasa() {
            const { value: formValues } = await Swal.fire({
                title: '<i class="fas fa-dot-circle text-primary mr-2"></i>Template PG Biasa',
                html: `
                <div class="text-left" style="font-size: 0.95rem;">
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Jumlah Soal:</label>
                        <input id="swal-pg-count" type="number" class="form-control" value="10" min="1" max="100">
                    </div>
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Pilihan Opsi:</label>
                        <select id="swal-pg-opsi" class="form-control">
                            <option value="4">4 Opsi (A - D)</option>
                            <option value="5" selected>5 Opsi (A - E)</option>
                        </select>
                    </div>
                    <small class="text-muted d-block">Format Word pilihan ganda standar dengan 1 kunci jawaban benar.</small>
                </div>`,
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-download mr-1"></i> Unduh Template Word',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#007bff',
                width: '420px',
                preConfirm: () => {
                    const count = parseInt(document.getElementById('swal-pg-count').value) || 0;
                    const opsi = parseInt(document.getElementById('swal-pg-opsi').value) || 5;
                    if (count <= 0) {
                        Swal.showValidationMessage('Jumlah soal harus minimal 1');
                        return false;
                    }
                    return { count, opsi };
                }
            });

            if (formValues) {
                downloadSingleTemplate('pg', formValues.count, formValues.opsi);
            }
        }

        async function promptTemplatePGKompleks() {
            const { value: formValues } = await Swal.fire({
                title: '<i class="fas fa-check-square text-success mr-2"></i>Template PG Kompleks',
                html: `
                <div class="text-left" style="font-size: 0.95rem;">
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Jumlah Soal:</label>
                        <input id="swal-pgk-count" type="number" class="form-control" value="5" min="1" max="100">
                    </div>
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Pilihan Opsi:</label>
                        <select id="swal-pgk-opsi" class="form-control">
                            <option value="4">4 Opsi (A - D)</option>
                            <option value="5" selected>5 Opsi (A - E)</option>
                        </select>
                    </div>
                    <small class="text-muted d-block">Format Word PG Kompleks dengan centang banyak (lebih dari 1 jawaban benar, contoh: A, C).</small>
                </div>`,
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-download mr-1"></i> Unduh Template Word',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#28a745',
                width: '420px',
                preConfirm: () => {
                    const count = parseInt(document.getElementById('swal-pgk-count').value) || 0;
                    const opsi = parseInt(document.getElementById('swal-pgk-opsi').value) || 5;
                    if (count <= 0) {
                        Swal.showValidationMessage('Jumlah soal harus minimal 1');
                        return false;
                    }
                    return { count, opsi };
                }
            });

            if (formValues) {
                downloadSingleTemplate('pgk', formValues.count, formValues.opsi);
            }
        }

        async function promptTemplateBenarSalah() {
            const { value: formValues } = await Swal.fire({
                title: '<i class="fas fa-check-circle text-warning mr-2"></i>Template Soal Benar / Salah',
                html: `
                <div class="text-left" style="font-size: 0.95rem;">
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Jumlah Soal:</label>
                        <input id="swal-bs-count" type="number" class="form-control" value="5" min="1" max="100">
                    </div>
                    <small class="text-muted d-block">Format Word soal Benar / Salah berupa tabel stimulus, pernyataan, dan kunci BENAR/SALAH.</small>
                </div>`,
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-download mr-1"></i> Unduh Template Word',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#e0a800',
                width: '420px',
                preConfirm: () => {
                    const count = parseInt(document.getElementById('swal-bs-count').value) || 0;
                    if (count <= 0) {
                        Swal.showValidationMessage('Jumlah soal harus minimal 1');
                        return false;
                    }
                    return { count };
                }
            });

            if (formValues) {
                downloadSingleTemplate('bs', formValues.count);
            }
        }

        async function promptTemplateMenjodohkan() {
            const { value: formValues } = await Swal.fire({
                title: '<i class="fas fa-exchange-alt text-info mr-2"></i>Template Soal Menjodohkan',
                html: `
                <div class="text-left" style="font-size: 0.95rem;">
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Jumlah Soal:</label>
                        <input id="swal-jodoh-count" type="number" class="form-control" value="5" min="1" max="100">
                    </div>
                    <small class="text-muted d-block">Format Word soal Menjodohkan mencocokkan premis sebelah kiri dengan pilihan jawaban sebelah kanan (kunci contoh: 1-A, 2-C, 3-B).</small>
                </div>`,
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-download mr-1"></i> Unduh Template Word',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#17a2b8',
                width: '420px',
                preConfirm: () => {
                    const count = parseInt(document.getElementById('swal-jodoh-count').value) || 0;
                    if (count <= 0) {
                        Swal.showValidationMessage('Jumlah soal harus minimal 1');
                        return false;
                    }
                    return { count };
                }
            });

            if (formValues) {
                downloadSingleTemplate('jodoh', formValues.count);
            }
        }

        function downloadSingleTemplate(type, count, jmlOpsi = 5) {
            if (type === 'pg') {
                downloadTemplate({ pg: count, pgk: 0, jodoh: 0, bs: 0, jmlOpsi: jmlOpsi }, `Template_Soal_PG_Biasa_${count}_Butir.doc`, 'Template Soal PG Biasa');
            } else if (type === 'pgk') {
                downloadTemplate({ pg: 0, pgk: count, jodoh: 0, bs: 0, jmlOpsi: jmlOpsi }, `Template_Soal_PG_Kompleks_${count}_Butir.doc`, 'Template Soal PG Kompleks');
            } else if (type === 'bs') {
                downloadTemplate({ pg: 0, pgk: 0, jodoh: 0, bs: count, jmlOpsi: 5 }, `Template_Soal_Benar_Salah_${count}_Butir.doc`, 'Template Soal Benar / Salah');
            } else if (type === 'jodoh') {
                downloadTemplate({ pg: 0, pgk: 0, jodoh: count, bs: 0, jmlOpsi: 5 }, `Template_Soal_Menjodohkan_${count}_Butir.doc`, 'Template Soal Menjodohkan');
            }
        }

        async function promptDownloadTemplate() {
            showFormatWord();
        }

        function downloadTemplate(vals, customFileName, customTitle) {
            let tablesHtml = '';
            const labels = ['A', 'B', 'C', 'D', 'E'];
            let num = 1;
            const titleText = customTitle || 'Template Soal CBT Dinamis';

            // 1. PG Biasa
            const pgCount = vals.pg || 0;
            for (let i = 0; i < pgCount; i++) {
                let optionsHtml = '';
                const optCount = vals.jmlOpsi || 5;
                for (let j = 0; j < optCount; j++) {
                    optionsHtml += `
                    <tr>
                        <td></td>
                        <td width="10%">${labels[j]}</td>
                        <td>Opsi ${labels[j]}</td>
                    </tr>`;
                }
                
                tablesHtml += `
                <table>
                    <tr>
                        <td width="5%">${num}.</td>
                        <td colspan="2">Tulis teks soal Pilihan Ganda nomor ${num} di sini...</td>
                    </tr>
                    ${optionsHtml}
                    <tr>
                        <td></td>
                        <td>Jawaban</td>
                        <td>A</td>
                    </tr>
                </table>
                <br>
                `;
                num++;
            }

            // 2. PG Kompleks
            const pgkCount = vals.pgk || 0;
            for (let i = 0; i < pgkCount; i++) {
                let optionsHtml = '';
                const optCount = vals.jmlOpsi || 5;
                for (let j = 0; j < optCount; j++) {
                    optionsHtml += `
                    <tr>
                        <td></td>
                        <td width="10%">${labels[j]}</td>
                        <td>Opsi ${labels[j]}</td>
                    </tr>`;
                }
                
                tablesHtml += `
                <table>
                    <tr>
                        <td width="5%">${num}.</td>
                        <td colspan="2">Tulis teks soal PG Kompleks nomor ${num} di sini... (Centang Banyak)</td>
                    </tr>
                    ${optionsHtml}
                    <tr>
                        <td></td>
                        <td>Jawaban</td>
                        <td>A, C</td>
                    </tr>
                </table>
                <br>
                `;
                num++;
            }

            // 3. Menjodohkan
            const jodohCount = vals.jodoh || 0;
            for (let i = 0; i < jodohCount; i++) {
                tablesHtml += `
                <table>
                    <tr>
                        <td width="5%">${num}.</td>
                        <td colspan="2">Tulis teks soal / instruksi Menjodohkan nomor ${num} di sini...</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td width="45%">Premis 1</td>
                        <td>Opsi A</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Premis 2</td>
                        <td>Opsi B</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Premis 3</td>
                        <td>Opsi C</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Jawaban</td>
                        <td>1-A, 2-C, 3-B</td>
                    </tr>
                </table>
                <br>
                `;
                num++;
            }

            // 4. Benar / Salah
            const bsCount = vals.bs || 0;
            for (let i = 0; i < bsCount; i++) {
                tablesHtml += `
                <table>
                    <tr>
                        <td width="5%">${num}.</td>
                        <td colspan="2">Tulis teks soal / stimulus Benar/Salah nomor ${num} di sini...</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td width="70%">Pernyataan 1</td>
                        <td>BENAR</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Pernyataan 2</td>
                        <td>SALAH</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>Pernyataan 3</td>
                        <td>BENAR</td>
                    </tr>
                </table>
                <br>
                `;
                num++;
            }

            const totalSoal = (vals.pg || 0) + (vals.pgk || 0) + (vals.jodoh || 0) + (vals.bs || 0);

            if (totalSoal === 0) {
                Swal.fire('Info', 'Anda harus mengisi minimal 1 soal.', 'info');
                return;
            }

            const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
            <head><meta charset='utf-8'><title>${titleText}</title>
            <style>
                table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
                td { border: 1px solid black; padding: 8px; vertical-align: top; }
            </style>
            </head>
            <body>
                <h2>${titleText}</h2>
                <p>Silakan isi soal-soal Anda menggunakan format tabel di bawah ini. Jangan mengubah struktur baris Kunci Jawaban. Anda dapat menyisipkan gambar langsung ke dalam sel tabel.</p>
                ${tablesHtml}
            </body>
            </html>`;
            
            const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = customFileName || `Template_Soal_${totalSoal}_Butir.doc`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        function convertLatexToWordMathML(text) {
            if (!text || typeof text !== 'string') return text || '';

            function cleanTeX(t) {
                if (!t) return '';
                return t
                    .replace(/&amp;/g, '&')
                    .replace(/&lt;/g, '<')
                    .replace(/&gt;/g, '>')
                    .replace(/&nbsp;/g, ' ')
                    .replace(/\\\\([a-zA-Z])/g, '\\$1')
                    .trim();
            }

            function buildMathImg(tex, isBlock) {
                const cleaned = cleanTeX(tex);
                if (!cleaned) return '';
                const dpi = isBlock ? '140' : '125';
                const url = 'https://latex.codecogs.com/png.image?\\dpi{' + dpi + '}\\bg{white}' + encodeURIComponent(cleaned);
                const safeAlt = cleaned.replace(/"/g, '&quot;');
                if (isBlock) {
                    return '<div style="text-align: center; margin: 8px 0;"><img class="math-tex" src="' + url + '" alt="' + safeAlt + '" style="vertical-align: middle;" /></div>';
                }
                return '<img class="math-tex" src="' + url + '" alt="' + safeAlt + '" style="vertical-align: middle; margin: 0 2px;" />';
            }

            let result = text;

            // 1. Display Math: $$ ... $$
            result = result.replace(/\$\$([\s\S]*?)\$\$/g, function(m, tex) {
                return buildMathImg(tex, true);
            });

            // 2. Display Math: \[ ... \]
            result = result.replace(/\\\[([\s\S]*?)\\\]/g, function(m, tex) {
                return buildMathImg(tex, true);
            });

            // 3. Inline Math: \( ... \)
            result = result.replace(/\\\(([\s\S]*?)\\\)/g, function(m, tex) {
                return buildMathImg(tex, false);
            });

            // 4. Custom tag: [math] ... [/math]
            result = result.replace(/\[math\]([\s\S]*?)\[\/math\]/gi, function(m, tex) {
                return buildMathImg(tex, false);
            });

            // 5. Inline Math: $ ... $ (abaikan mata uang seperti $100 atau string kosong)
            result = result.replace(/(^|[^\$])\$([^\$\r\n]+?)\$(?!\$)/g, function(m, prefix, tex) {
                if (/^\s*\d+([.,]\d+)?\s*$/.test(tex) || /^\s*$/.test(tex)) {
                    return m;
                }
                return prefix + buildMathImg(tex, false);
            });

            return result;
        }

        function downloadWordSoal() {
            if (!currentQuestions || currentQuestions.length === 0) {
                Swal.fire('Oops', 'Belum ada soal untuk didownload.', 'warning');
                return;
            }
            
            const previewInput = document.getElementById('preview_exam_id');
            let examName = previewInput ? (previewInput.dataset.name || '') : '';
            if (!examName) {
                const titleEl = document.getElementById('detail-soal-title');
                if (titleEl) {
                    examName = titleEl.innerText.replace(/^Kelola Soal:\s*/i, '').trim();
                }
            }
            if (!examName) examName = 'Bank_Soal';
            
            let tablesHtml = '';
            const labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
            
            currentQuestions.forEach((q, index) => {
                const qType = q.type || 'multiple_choice';
                const qText = convertLatexToWordMathML(q.question || q.text || '');

                if (qType === 'essay') {
                    tablesHtml += `
                    <table>
                        <tr>
                            <td width="5%">${index + 1}.</td>
                            <td colspan="2">${qText}</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td width="15%">Tipe Soal</td>
                            <td>Esai (Uraian)</td>
                        </tr>
                    </table>
                    <br>
                    `;
                } else if (qType === 'complex_mc') {
                    let optionsHtml = '';
                    const qOptions = q.options || [];
                    for (let j = 0; j < qOptions.length; j++) {
                        optionsHtml += `
                        <tr>
                            <td></td>
                            <td width="10%">${labels[j] || ''}</td>
                            <td>${convertLatexToWordMathML(qOptions[j] || '')}</td>
                        </tr>`;
                    }
                    let answerLabel = '-';
                    const correctAnswers = Array.isArray(q.answers) ? q.answers : (Array.isArray(q.answer) ? q.answer : []);
                    if (correctAnswers.length > 0) {
                        answerLabel = correctAnswers.map(a => {
                            const num = parseInt(a);
                            return !isNaN(num) && labels[num] ? labels[num] : a;
                        }).join(', ');
                    } else if (q.answer !== undefined && q.answer !== null && q.answer !== '') {
                        answerLabel = q.answer;
                    }
                    tablesHtml += `
                    <table>
                        <tr>
                            <td width="5%">${index + 1}.</td>
                            <td colspan="2">${qText}</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td width="15%">Tipe Soal</td>
                            <td>Pilihan Ganda Kompleks</td>
                        </tr>
                        ${optionsHtml}
                        <tr>
                            <td></td>
                            <td>Kunci Jawaban</td>
                            <td>${answerLabel}</td>
                        </tr>
                    </table>
                    <br>`;
                } else if (qType === 'true_false') {
                    let stmtsHtml = '';
                    const stmts = q.statements || [];
                    stmts.forEach((stmt, sIdx) => {
                        const sText = convertLatexToWordMathML(stmt.text || stmt.statement || stmt || '');
                        const isCorrect = (stmt.answer === true || stmt.answer === 'true');
                        stmtsHtml += `
                        <tr>
                            <td></td>
                            <td width="10%">${sIdx + 1}</td>
                            <td>${sText} <strong>[Kunci: ${isCorrect ? 'BENAR' : 'SALAH'}]</strong></td>
                        </tr>`;
                    });
                    tablesHtml += `
                    <table>
                        <tr>
                            <td width="5%">${index + 1}.</td>
                            <td colspan="2">${qText}</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td width="15%">Tipe Soal</td>
                            <td>Benar / Salah</td>
                        </tr>
                        ${stmtsHtml}
                    </table>
                    <br>`;
                } else if (qType === 'matching') {
                    let pairsHtml = '';
                    const premises = q.premises || [];
                    const responses = q.options || q.responses || [];
                    premises.forEach((prem, pIdx) => {
                        const pText = convertLatexToWordMathML(prem.text || prem || '');
                        let rText = '-';
                        if (q.answer && q.answer[pIdx] !== undefined) {
                            const rIdx = parseInt(q.answer[pIdx]);
                            rText = responses[rIdx] ? convertLatexToWordMathML(responses[rIdx].text || responses[rIdx] || '') : q.answer[pIdx];
                        }
                        pairsHtml += `
                        <tr>
                            <td></td>
                            <td width="10%">${pIdx + 1}</td>
                            <td>Premis: ${pText} &nbsp;➔&nbsp; Pasangan: ${rText}</td>
                        </tr>`;
                    });
                    tablesHtml += `
                    <table>
                        <tr>
                            <td width="5%">${index + 1}.</td>
                            <td colspan="2">${qText}</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td width="15%">Tipe Soal</td>
                            <td>Menjodohkan</td>
                        </tr>
                        ${pairsHtml}
                    </table>
                    <br>`;
                } else {
                    let optionsHtml = '';
                    const qOptions = q.options || [];
                    
                    for (let j = 0; j < qOptions.length; j++) {
                        optionsHtml += `
                        <tr>
                            <td></td>
                            <td width="10%">${labels[j] || ''}</td>
                            <td>${convertLatexToWordMathML(qOptions[j] || '')}</td>
                        </tr>`;
                    }
                    
                    let answerLabel = '-';
                    if (typeof q.answer !== 'undefined' && q.answer !== null && q.answer !== '') {
                        if (typeof q.answer === 'number' || (!isNaN(q.answer) && !isNaN(parseInt(q.answer)))) {
                            answerLabel = labels[parseInt(q.answer)] || q.answer;
                        } else {
                            answerLabel = q.answer;
                        }
                    }
                    
                    tablesHtml += `
                    <table>
                        <tr>
                            <td width="5%">${index + 1}.</td>
                            <td colspan="2">${qText}</td>
                        </tr>
                        ${optionsHtml}
                        <tr>
                            <td></td>
                            <td>Jawaban</td>
                            <td>${answerLabel}</td>
                        </tr>
                    </table>
                    <br>
                    `;
                }
            });

            const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns:m='http://schemas.microsoft.com/office/2004/12/omml' xmlns='http://www.w3.org/TR/REC-html40'>
            <head><meta charset='utf-8'><title>Soal ${examName}</title>
            <style>
                body { font-family: 'Times New Roman', serif; font-size: 11pt; line-height: 1.25; }
                table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
                td { border: 1px solid black; padding: 8px; vertical-align: top; }
                math { font-family: 'Cambria Math', 'Times New Roman', serif; }
                .math-tex { vertical-align: middle; margin: 0 2px; }
                img { max-width: 100%; height: auto; }
            </style>
            </head>
            <body>
                <h2>Soal Mata Pelajaran: ${examName}</h2>
                <p>Total Soal: ${currentQuestions.length}</p>
                ${tablesHtml}
            </body>
            </html>`;
            
            const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const safeFileName = examName.replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_+/g, '_');
            a.download = `Soal_${safeFileName}.doc`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        function downloadWordSoalPlain() {
            if (!currentQuestions || currentQuestions.length === 0) {
                Swal.fire('Oops', 'Belum ada soal untuk didownload.', 'warning');
                return;
            }
            
            const previewInput = document.getElementById('preview_exam_id');
            let examName = previewInput ? (previewInput.dataset.name || '') : '';
            if (!examName) {
                const titleEl = document.getElementById('detail-soal-title');
                if (titleEl) {
                    examName = titleEl.innerText.replace(/^Kelola Soal:\s*/i, '').trim();
                }
            }
            if (!examName) examName = 'Bank_Soal';
            
            const labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
            let questionsHtml = '';
            
            currentQuestions.forEach((q, index) => {
                const qType = q.type || 'multiple_choice';
                let qText = convertLatexToWordMathML((q.question || q.text || '').trim());
                
                // Normalisasi tag paragraph agar nomor dan pertanyaan sejajar rapi
                if (qText.startsWith('<p>') && qText.endsWith('</p>') && qText.indexOf('<p>', 3) === -1) {
                    qText = qText.substring(3, qText.length - 4).trim();
                }
                
                if (qType === 'essay') {
                    questionsHtml += `
                    <div class="soal-item">
                        <div class="soal-pertanyaan">
                            <span class="soal-nomor">${index + 1}.</span>
                            <span class="soal-isi">${qText}</span>
                        </div>
                    </div>`;
                } else if (qType === 'complex_mc') {
                    let optionsHtml = '';
                    const qOptions = q.options || [];
                    for (let j = 0; j < qOptions.length; j++) {
                        let optText = convertLatexToWordMathML((qOptions[j] || '').trim());
                        if (optText.startsWith('<p>') && optText.endsWith('</p>') && optText.indexOf('<p>', 3) === -1) {
                            optText = optText.substring(3, optText.length - 4).trim();
                        }
                        optionsHtml += `
                        <div class="soal-opsi">
                            <span class="opsi-huruf">[ ]</span>
                            <span class="opsi-isi">${optText}</span>
                        </div>`;
                    }
                    questionsHtml += `
                    <div class="soal-item">
                        <div class="soal-pertanyaan">
                            <span class="soal-nomor">${index + 1}.</span>
                            <span class="soal-isi">${qText} <em>(Pilihan Ganda Kompleks)</em></span>
                        </div>
                        <div class="soal-opsi-list">
                            ${optionsHtml}
                        </div>
                    </div>`;
                } else if (qType === 'true_false') {
                    let stmtsHtml = '';
                    const stmts = q.statements || [];
                    stmts.forEach((stmt, sIdx) => {
                        let sText = convertLatexToWordMathML((stmt.text || stmt.statement || stmt || '').trim());
                        stmtsHtml += `
                        <div class="soal-opsi">
                            <span class="opsi-huruf">${sIdx + 1}.</span>
                            <span class="opsi-isi">[ Benar / Salah ] &nbsp; ${sText}</span>
                        </div>`;
                    });
                    questionsHtml += `
                    <div class="soal-item">
                        <div class="soal-pertanyaan">
                            <span class="soal-nomor">${index + 1}.</span>
                            <span class="soal-isi">${qText} <em>(Benar / Salah)</em></span>
                        </div>
                        <div class="soal-opsi-list">
                            ${stmtsHtml}
                        </div>
                    </div>`;
                } else if (qType === 'matching') {
                    let pairsHtml = '';
                    const premises = q.premises || [];
                    const responses = q.options || q.responses || [];
                    premises.forEach((prem, pIdx) => {
                        const pText = convertLatexToWordMathML(prem.text || prem || '');
                        const rText = responses[pIdx] ? convertLatexToWordMathML(responses[pIdx].text || responses[pIdx] || '') : '';
                        pairsHtml += `
                        <div class="soal-opsi">
                            <span class="opsi-huruf">${pIdx + 1}.</span>
                            <span class="opsi-isi">${pText} &nbsp;&nbsp; ➔ &nbsp;&nbsp; ${rText}</span>
                        </div>`;
                    });
                    questionsHtml += `
                    <div class="soal-item">
                        <div class="soal-pertanyaan">
                            <span class="soal-nomor">${index + 1}.</span>
                            <span class="soal-isi">${qText} <em>(Menjodohkan)</em></span>
                        </div>
                        <div class="soal-opsi-list">
                            ${pairsHtml}
                        </div>
                    </div>`;
                } else {
                    let optionsHtml = '';
                    const qOptions = q.options || [];
                    for (let j = 0; j < qOptions.length; j++) {
                        let optText = convertLatexToWordMathML((qOptions[j] || '').trim());
                        if (optText.startsWith('<p>') && optText.endsWith('</p>') && optText.indexOf('<p>', 3) === -1) {
                            optText = optText.substring(3, optText.length - 4).trim();
                        }
                        optionsHtml += `
                        <div class="soal-opsi">
                            <span class="opsi-huruf">${labels[j] || ''}.</span>
                            <span class="opsi-isi">${optText}</span>
                        </div>`;
                    }
                    
                    questionsHtml += `
                    <div class="soal-item">
                        <div class="soal-pertanyaan">
                            <span class="soal-nomor">${index + 1}.</span>
                            <span class="soal-isi">${qText}</span>
                        </div>
                        <div class="soal-opsi-list">
                            ${optionsHtml}
                        </div>
                    </div>`;
                }
            });

            const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns:m='http://schemas.microsoft.com/office/2004/12/omml' xmlns='http://www.w3.org/TR/REC-html40'>
            <head>
                <meta charset='utf-8'>
                <title>Naskah Soal - ${examName}</title>
                <!--[if gte mso 9]>
                <xml>
                <w:WordDocument>
                    <w:View>Print</w:View>
                    <w:Zoom>100</w:Zoom>
                    <w:DoNotOptimizeForBrowser/>
                </w:WordDocument>
                </xml>
                <![endif]-->
                <style>
                    @page {
                        size: A4;
                        margin: 1.5cm 2cm 2cm 2cm;
                        mso-page-orientation: portrait;
                    }
                    body {
                        font-family: 'Times New Roman', serif;
                        font-size: 11pt;
                        line-height: 1.15;
                        color: #000000;
                        margin: 0;
                        padding: 0;
                    }
                    p {
                        margin: 0;
                        padding: 0;
                        display: inline;
                    }
                    math {
                        font-family: 'Cambria Math', 'Times New Roman', serif;
                    }
                    .kop-header {
                        text-align: center;
                        border-bottom: 2px solid #000000;
                        padding-bottom: 5px;
                        margin-bottom: 12px;
                    }
                    .kop-header h2 {
                        font-size: 14pt;
                        margin: 0 0 3px 0;
                        font-weight: bold;
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    }
                    .kop-header p {
                        display: block;
                        font-size: 11pt;
                        margin: 0 0 2px 0;
                    }
                    .kop-header .sub-info {
                        font-size: 9.5pt;
                        color: #333333;
                    }
                    .soal-item {
                        margin-bottom: 8px;
                        page-break-inside: avoid;
                    }
                    .soal-pertanyaan {
                        margin-left: 22px;
                        text-indent: -22px;
                        margin-bottom: 2px;
                        line-height: 1.15;
                        text-align: justify;
                    }
                    .soal-nomor {
                        font-weight: bold;
                        display: inline-block;
                        width: 22px;
                    }
                    .soal-isi {
                        display: inline;
                    }
                    .soal-opsi-list {
                        margin-left: 22px;
                        margin-top: 2px;
                        line-height: 1.15;
                    }
                    .soal-opsi {
                        margin-bottom: 1.5px;
                        line-height: 1.15;
                        font-weight: normal;
                    }
                    .opsi-huruf {
                        font-weight: normal;
                        display: inline-block;
                        width: 18px;
                    }
                    .opsi-isi {
                        display: inline;
                        font-weight: normal;
                    }
                    .math-tex {
                        vertical-align: middle;
                        margin: 0 2px;
                    }
                    img {
                        max-width: 100%;
                        height: auto;
                        margin: 3px 0;
                    }
                </style>
            </head>
            <body>
                <div class="kop-header">
                    <h2>NASKAH SOAL UJIAN</h2>
                    <p><strong>Mata Pelajaran:</strong> ${examName}</p>
                    <p class="sub-info">Jumlah Soal: ${currentQuestions.length} Butir</p>
                </div>
                ${questionsHtml}
            </body>
            </html>`;
            
            const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const safeFileName = examName.replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_+/g, '_');
            a.download = `Naskah_Soal_${safeFileName}.doc`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }

        function showFormatWord() {
            Swal.fire({
                title: 'Template & Petunjuk Word',
                html: `
                <div class="text-sm text-left mt-2">
                    <p class="mb-2">Silakan pilih template Word sesuai jenis soal yang ingin Anda buat:</p>
                    <div class="list-group mb-3">
                        <button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2" onclick="Swal.close(); promptTemplatePGBiasa();">
                            <div>
                                <i class="fas fa-dot-circle text-primary mr-2"></i>
                                <strong>1. Template PG Biasa</strong>
                                <small class="d-block text-muted">1 jawaban benar (A-D / A-E)</small>
                            </div>
                            <span class="btn btn-xs btn-primary"><i class="fas fa-download mr-1"></i> Unduh</span>
                        </button>
                        <button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2" onclick="Swal.close(); promptTemplatePGKompleks();">
                            <div>
                                <i class="fas fa-check-square text-success mr-2"></i>
                                <strong>2. Template PG Kompleks</strong>
                                <small class="d-block text-muted">Centang banyak / lebih dari 1 jawaban</small>
                            </div>
                            <span class="btn btn-xs btn-success"><i class="fas fa-download mr-1"></i> Unduh</span>
                        </button>
                        <button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2" onclick="Swal.close(); promptTemplateBenarSalah();">
                            <div>
                                <i class="fas fa-check-circle text-warning mr-2"></i>
                                <strong>3. Template Benar / Salah</strong>
                                <small class="d-block text-muted">Tabel kolom pernyataan dan BENAR / SALAH</small>
                            </div>
                            <span class="btn btn-xs btn-warning"><i class="fas fa-download mr-1"></i> Unduh</span>
                        </button>
                        <button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2" onclick="Swal.close(); promptTemplateMenjodohkan();">
                            <div>
                                <i class="fas fa-exchange-alt text-info mr-2"></i>
                                <strong>4. Template Menjodohkan</strong>
                                <small class="d-block text-muted">Pasangan premis kiri dengan opsi kanan</small>
                            </div>
                            <span class="btn btn-xs btn-info"><i class="fas fa-download mr-1"></i> Unduh</span>
                        </button>
                    </div>
                    <b>Aturan Pengetikan Word:</b>
                    <ul class="pl-3 mt-1 mb-0 text-muted">
                        <li>Satu soal terdiri dari satu blok tabel.</li>
                        <li><b>Baris pertama:</b> Nomor Soal (misal "1.") dan Teks Pertanyaan / Stimulus.</li>
                        <li><b>Baris opsi / premis:</b> Opsi jawaban atau pernyataan.</li>
                        <li><b>Baris terakhir:</b> Label "Jawaban" dan Kunci Jawaban.</li>
                        <li>Gambar dapat disisipkan langsung ke dalam sel tabel.</li>
                    </ul>
                </div>`,
                icon: 'info',
                confirmButtonText: 'Tutup',
                width: '580px'
            });
        }

        function parseHtmlQuestions(html) {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const questions = [];
            const tables = doc.querySelectorAll('table');

            if (tables.length > 0) {
                tables.forEach(table => {
                    const rows = table.querySelectorAll('tr');
                    let currentQuestion = null;

                    for (let i = 0; i < rows.length; i++) {
                        const cells = rows[i].querySelectorAll('td, th');
                        if (cells.length === 0) continue;
                        
                        let col0Text = cells[0].textContent.trim();
                        
                        // Deteksi pertanyaan baru berdasarkan nomor (misal "1." atau "1")
                        if (/^\d+[\.\)]?$/.test(col0Text) || /^\d+$/.test(col0Text)) {
                            if (currentQuestion && currentQuestion.options.length > 0) {
                                if (currentQuestion.answer === null) currentQuestion.answer = 0;
                                questions.push(currentQuestion);
                            }
                            
                            let qHtml = cells.length > 1 ? cells[1].innerHTML.trim() : cells[0].innerHTML.trim();
                            currentQuestion = {
                                type: 'multiple_choice',
                                question: qHtml,
                                options: [],
                                answer: null,
                                points: 2
                            };
                        } else if (currentQuestion) {
                            let labelCol = "";
                            let valColHtml = "";
                            let valColText = "";
                            
                            if (cells.length >= 3) {
                                labelCol = cells[1].textContent.trim().toUpperCase();
                                valColHtml = cells[2].innerHTML.trim();
                                valColText = cells[2].textContent.trim();
                            } else if (cells.length === 2) {
                                labelCol = cells[0].textContent.trim().toUpperCase();
                                valColHtml = cells[1].innerHTML.trim();
                                valColText = cells[1].textContent.trim();
                            }
                            
                            if (valColHtml === '<p></p>') valColHtml = '';

                            if (['A', 'B', 'C', 'D', 'E'].includes(labelCol)) {
                                if (valColHtml) {
                                    currentQuestion.options.push(valColHtml);
                                }
                            } else if (labelCol.includes('JAWAB') || labelCol.includes('KUNCI')) {
                                let match = valColText.toUpperCase().match(/[A-E]/);
                                if (match) {
                                    currentQuestion.answer = match[0].charCodeAt(0) - 65;
                                }
                            }
                        }
                    }
                    if (currentQuestion && currentQuestion.options.length > 0) {
                        if (currentQuestion.answer === null) currentQuestion.answer = 0;
                        questions.push(currentQuestion);
                    }
                });
            }

            // Fallback parsing teks paragraf biasa jika tidak menggunakan tabel
            if (questions.length === 0) {
                const ps = doc.querySelectorAll('p, div, li');
                let currentQuestion = null;
                ps.forEach(p => {
                    const txt = p.textContent.trim();
                    const html = p.innerHTML.trim();
                    if (!txt) return;

                    const qMatch = txt.match(/^(\d+)[\.\)]\s*(.*)/s);
                    if (qMatch) {
                        if (currentQuestion && currentQuestion.options.length > 0) {
                            if (currentQuestion.answer === null) currentQuestion.answer = 0;
                            questions.push(currentQuestion);
                        }
                        currentQuestion = {
                            type: 'multiple_choice',
                            question: html.replace(/^(\d+)[\.\)]\s*/, ''),
                            options: [],
                            answer: null,
                            points: 2
                        };
                        return;
                    }

                    if (currentQuestion) {
                        const optMatch = txt.match(/^([A-E])[\.\)]\s*(.*)/s);
                        if (optMatch) {
                            currentQuestion.options.push(html.replace(/^([A-E])[\.\)]\s*/, ''));
                            return;
                        }

                        const keyMatch = txt.match(/(?:kunci|jawaban)\s*[:=]\s*([A-E])/i);
                        if (keyMatch) {
                            currentQuestion.answer = keyMatch[1].toUpperCase().charCodeAt(0) - 65;
                        }
                    }
                });
                if (currentQuestion && currentQuestion.options.length > 0) {
                    if (currentQuestion.answer === null) currentQuestion.answer = 0;
                    questions.push(currentQuestion);
                }
            }

            return questions;
        }

        async function uploadSoal(e) {
            e.preventDefault();
            const btn = document.getElementById('btn-upload-soal');
            const fileInput = document.getElementById('file-soal');
            const previewEl = document.getElementById('preview_exam_id');
            let examId = document.getElementById('upload_exam_id') ? document.getElementById('upload_exam_id').value : '';
            if (!examId && previewEl && previewEl.value) {
                examId = previewEl.value;
            }
            
            if (!fileInput.files.length || !examId) {
                Swal.fire('Oops', 'Pilih bank soal tujuan dan file terlebih dahulu', 'warning');
                return;
            }
            
            const file = fileInput.files[0];
            const fileName = file.name.toLowerCase();
            const isDocx = fileName.endsWith('.docx');
            const isDoc = fileName.endsWith('.doc');
            const isZip = fileName.endsWith('.zip');
            
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Mengolah...';
            btn.disabled = true;
            
            try {
                // Seluruh berkas (.docx, .doc, .zip, .json) dikirim langsung ke parser server berpresisi tinggi.
                // Parser PHP server mengekstrak seluruh rumus Word Equation (OMML -> LaTeX / KaTeX),
                // gambar tersemat (WebP), tabel multi-tipe (PG, PGK, B/S, Jodohkan, Esai), dan penomoran paragraf.
                let fileToSend = file;
                let sendAsName = file.name;

                btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Mengunggah...';
                
                const formData = new FormData();
                formData.append('action', 'upload_questions');
                formData.append('exam_id', examId);
                formData.append('file', fileToSend, sendAsName);
                formData.append('uploader_name', <?= json_encode($user_name) ?>);
                
                const response = await fetch('api.php', { method: 'POST', body: formData });
                const res = await response.json();
                
                if (res.status === 'success') {
                    Swal.fire('Sukses', res.message, 'success');
                    document.getElementById('form-upload-soal').reset();
                    $('#modalImportSoal').modal('hide');
                    loadQuestions();
                } else {
                    Swal.fire('Gagal', res.message, 'error');
                }
            } catch (e) {
                Swal.fire('Gagal Memproses File', e.message || 'Gagal mengunggah file', 'error');
            } finally {
                btn.innerHTML = '<i class="fas fa-upload mr-2"></i> Unggah Soal';
                btn.disabled = false;
            }
        }

        async function submitAddBankSoal(e) {
            e.preventDefault();
            const name = document.getElementById('add_bank_soal_name').value;
            const checkedClasses = Array.from(document.querySelectorAll('.add-bank-class-cb:checked')).map(cb => cb.value.trim()).filter(Boolean);
            const fd = new FormData();
            fd.append('action', 'add_bank_soal');
            fd.append('name', name);
            fd.append('classes', JSON.stringify(checkedClasses));
            fd.append('created_by', <?= json_encode($user_name) ?>);
            fd.append('author_id', <?= json_encode($_SESSION['user_id'] ?? 0) ?>);
            fd.append('author_role', <?= json_encode($user_role) ?>);
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') location.reload();
                else Swal.fire('Gagal', json.message, 'error');
            } catch(e) { Swal.fire('Error', 'Gagal membuat Bank Soal', 'error'); }
        }

        function backupBankSoalZip(id, name) {
            if (!id) return;
            const link = document.createElement('a');
            link.href = `api.php?action=backup_soal_zip&bank_id=${id}`;
            link.setAttribute('download', '');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function backupCurrentBankSoalZip() {
            const previewEl = document.getElementById('preview_exam_id');
            const id = previewEl ? previewEl.value : null;
            const name = previewEl ? (previewEl.dataset.name || '') : '';
            if (!id) {
                Swal.fire('Perhatian', 'Pilih bank soal terlebih dahulu', 'warning');
                return;
            }
            backupBankSoalZip(id, name);
        }

        function toggleZipTargetType(val) {
            const newContainer = document.getElementById('container-zip-new-bank');
            const existingContainer = document.getElementById('container-zip-existing-bank');
            const existingSelect = document.getElementById('zip_existing_bank_id');
            if (val === 'existing') {
                if (newContainer) newContainer.style.display = 'none';
                if (existingContainer) existingContainer.style.display = 'block';
                if (existingSelect) existingSelect.required = true;
            } else {
                if (newContainer) newContainer.style.display = 'block';
                if (existingContainer) existingContainer.style.display = 'none';
                if (existingSelect) existingSelect.required = false;
            }
        }

        async function submitImportBankSoalZip(e) {
            e.preventDefault();
            const fileInput = document.getElementById('zip_file_input');
            if (!fileInput || !fileInput.files.length) {
                Swal.fire('Oops', 'Pilih setidaknya satu file backup ZIP terlebih dahulu', 'warning');
                return;
            }

            const targetType = document.querySelector('input[name="zip_target_type"]:checked')?.value || 'new';
            const customName = document.getElementById('zip_custom_bank_name')?.value || '';
            const existingBankId = document.getElementById('zip_existing_bank_id')?.value || '';
            const importMode = document.getElementById('zip_import_mode')?.value || 'append';

            if (targetType === 'existing' && !existingBankId) {
                Swal.fire('Oops', 'Silakan pilih Bank Soal tujuan terlebih dahulu', 'warning');
                return;
            }

            const btn = document.getElementById('btn-submit-import-zip');
            const origHtml = btn.innerHTML;
            const fileCount = fileInput.files.length;
            btn.innerHTML = `<i class="fas fa-spinner fa-spin mr-2"></i> Mengimpor ${fileCount > 1 ? fileCount + ' Berkas ZIP' : 'ZIP'} & Memproses Gambar...`;
            btn.disabled = true;

            const fd = new FormData();
            fd.append('action', 'import_bank_soal_zip');
            for (let i = 0; i < fileInput.files.length; i++) {
                fd.append('files_zip[]', fileInput.files[i]);
            }
            fd.append('target_type', targetType);
            fd.append('bank_name', customName);
            fd.append('existing_bank_id', existingBankId);
            fd.append('import_mode', importMode);

            try {
                const response = await fetch('api.php', { method: 'POST', body: fd });
                const res = await response.json();

                if (res.status === 'success') {
                    let detailHtml = `<p>${res.message}</p>`;
                    if (res.imported_names && res.imported_names.length > 1) {
                        detailHtml += `<div class="text-left mt-2 p-2 bg-light border rounded" style="max-height: 180px; overflow-y: auto;"><small class="font-weight-bold d-block mb-1">Daftar Bank Soal Terimpor (${res.imported_names.length}):</small><ul class="mb-0 pl-3">` +
                            res.imported_names.map(n => `<li><small>${n}</small></li>`).join('') +
                            `</ul></div>`;
                    }
                    await Swal.fire({
                        title: 'Berhasil!',
                        html: detailHtml,
                        icon: 'success',
                        confirmButtonText: res.total_banks > 1 ? 'Selesai' : 'Buka Bank Soal'
                    });
                    $('#modalImportBankSoalZip').modal('hide');
                    document.getElementById('form-import-bank-soal-zip').reset();
                    if (res.total_banks === 1 && res.bank_id) {
                        window.location.href = `admin.php?page=soal&open_bank_id=${res.bank_id}&open_bank_name=${encodeURIComponent(res.bank_name || '')}`;
                    } else {
                        location.reload();
                    }
                } else {
                    Swal.fire('Gagal Impor', res.message || 'Terjadi kesalahan saat mengimpor ZIP', 'error');
                }
            } catch (err) {
                Swal.fire('Error', err.message || 'Gagal terhubung ke server', 'error');
            } finally {
                btn.innerHTML = origHtml;
                btn.disabled = false;
            }
        }

        function bulkBackupSelectedBankSoal() {
            if (selectedBankIds.size === 0) {
                Swal.fire('Perhatian', 'Pilih setidaknya satu bank soal yang ingin dibackup dengan mencentang kotak pada tabel.', 'warning');
                return;
            }
            const ids = Array.from(selectedBankIds).join(',');
            window.location.href = `api.php?action=bulk_backup_soal_zip&bank_ids=${ids}`;
        }

        async function backupAllBankSoal() {
            const result = await Swal.fire({
                title: 'Backup Semua Bank Soal?',
                text: 'Seluruh bank soal beserta seluruh butir soal dan aset gambarnya akan dikemas ke dalam satu file ZIP paket massal.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, Download Backup Massal!',
                cancelButtonText: 'Batal'
            });
            if (result.isConfirmed) {
                window.location.href = 'api.php?action=bulk_backup_soal_zip&all=1';
            }
        }

        function openDetailSoal(id, name) {
            document.getElementById('section-list-bank-soal').style.display = 'none';
            document.getElementById('section-detail-soal').style.display = 'block';
            document.getElementById('detail-soal-title').innerText = 'Kelola Soal: ' + name;
            const previewEl = document.getElementById('preview_exam_id');
            if (previewEl) {
                previewEl.value = id;
                previewEl.dataset.name = name;
            }
            const uploadEl = document.getElementById('upload_exam_id');
            if (uploadEl) {
                uploadEl.value = id;
            }
            const addBtn = document.getElementById('btn-add-soal');
            if (addBtn) addBtn.style.display = 'inline-block';
            const aiBtn = document.getElementById('btn-ai-soal');
            if (aiBtn) aiBtn.style.display = 'inline-block';
            
            const container = document.getElementById('container-soal') || document.getElementById('tbody-soal');
            if (container) {
                container.innerHTML = '<div class="card p-5 text-center shadow-sm border-0 my-3 bg-white rounded text-muted"><i class="fas fa-spinner fa-spin fa-2x mb-3 text-primary d-block"></i><span class="font-weight-bold">Memuat pratinjau dokumen soal...</span></div>';
            }
            loadQuestions();
        }

        function backToBankSoal() {
            window.location.href = 'admin.php?page=soal';
        }

        function openGeminiAiPopup(e) {
            if (e && e.preventDefault) e.preventDefault();
            const url = 'https://share.gemini.google/ReefFdC6lnEu';
            // Hitung ukuran pop-up mengambang di sisi kanan (Side-by-Side dengan CBT)
            const width = Math.min(Math.max(Math.round(window.screen.availWidth * 0.46), 540), 850);
            const height = Math.max(window.screen.availHeight - 60, 600);
            const left = Math.max(window.screen.availWidth - width - 10, 0);
            const top = 30;
            const windowFeatures = `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=no,toolbar=no,menubar=no,location=yes`;
            
            const popup = window.open(url, 'GeminiSoalPopup', windowFeatures);
            if (popup && !popup.closed) {
                popup.focus();
            } else {
                window.open(url, '_blank', 'noopener,noreferrer');
            }
            return false;
        }

        async function editBankSoalName(id, currentName, currentClasses = '') {
            if (typeof openEditBankSoalModal === 'function') {
                openEditBankSoalModal(id, currentName, currentClasses);
                return;
            }
            const { value: name } = await Swal.fire({
                title: 'Edit Nama Bank Soal',
                input: 'text',
                inputValue: currentName,
                showCancelButton: true,
                confirmButtonText: 'Simpan',
                cancelButtonText: 'Batal',
                inputValidator: (value) => {
                    if (!value) return 'Nama tidak boleh kosong'
                }
            });
            if (name) {
                const fd = new FormData();
                fd.append('action', 'edit_bank_soal_name');
                fd.append('id', id);
                fd.append('name', name);
                try {
                    await fetch('api.php', { method: 'POST', body: fd });
                    location.reload();
                } catch(e) { Swal.fire('Gagal', 'Terjadi kesalahan.', 'error'); }
            }
        }

        async function deleteBankSoal(id, name) {
            if(!id) return;
            const result = await Swal.fire({
                title: 'Hapus Bank Soal?',
                text: `Yakin ingin menghapus seluruh bank soal "${name}"? Data pertanyaan di dalamnya juga akan terhapus secara permanen.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const fd = new FormData();
                fd.append('action', 'delete_bank_soal');
                fd.append('id', id);
                try {
                    await fetch('api.php', { method: 'POST', body: fd });
                    Swal.fire({
                        title: 'Terhapus!',
                        text: 'Bank Soal berhasil dihapus.',
                        icon: 'success',
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => location.reload());
                } catch(e) { Swal.fire('Gagal', 'Terjadi kesalahan.', 'error'); }
            }
        }

        let selectedBankIds = new Set();

        function toggleAllBank(masterCb) {
            const checked = masterCb.checked;
            const cbs = document.querySelectorAll('.cb-bank');
            cbs.forEach(cb => {
                const row = cb.closest('tr');
                if (!row || row.style.display !== 'none') {
                    cb.checked = checked;
                    const id = parseInt(cb.value);
                    if (checked) selectedBankIds.add(id);
                    else selectedBankIds.delete(id);
                }
            });
            updateBankBulkUI();
        }

        function toggleBankSelection(cb) {
            const id = parseInt(cb.value);
            if (cb.checked) {
                selectedBankIds.add(id);
            } else {
                selectedBankIds.delete(id);
                const masterCb = document.getElementById('cb-all-bank');
                if (masterCb) masterCb.checked = false;
            }
            updateBankBulkUI();
        }

        function updateBankBulkUI() {
            const btn = document.getElementById('btn-bulk-delete-bank');
            const countEl = document.getElementById('selected-bank-count');
            const btnBackup = document.getElementById('btn-bulk-backup-bank');
            const countBackupEl = document.getElementById('selected-bank-count-backup');
            const size = selectedBankIds.size;
            if (countEl) countEl.innerText = size;
            if (countBackupEl) countBackupEl.innerText = size;
            if (btn) {
                btn.style.display = size > 0 ? 'inline-block' : 'none';
            }
            if (btnBackup) {
                btnBackup.style.display = size > 0 ? 'inline-block' : 'none';
            }
            const allCbs = document.querySelectorAll('.cb-bank');
            const masterCb = document.getElementById('cb-all-bank');
            if (masterCb && allCbs.length > 0) {
                const visibleCbs = Array.from(allCbs).filter(cb => {
                    const row = cb.closest('tr');
                    return !row || row.style.display !== 'none';
                });
                if (visibleCbs.length > 0) {
                    masterCb.checked = visibleCbs.every(cb => cb.checked);
                }
            }
        }

        function filterBankSoalTable() {
            const query = (document.getElementById('search-bank-soal')?.value || '').toLowerCase().trim();
            const rows = document.querySelectorAll('.bank-soal-row');
            let visibleCount = 0;

            rows.forEach(row => {
                const name = row.getAttribute('data-bank-name') || '';
                const match = !query || name.includes(query);
                row.style.display = match ? '' : 'none';
                if (match) {
                    visibleCount++;
                    const numCell = row.querySelector('.bank-soal-num');
                    if (numCell) numCell.innerText = visibleCount;
                }
            });

            const emptyRow = document.getElementById('row-empty-bank');
            if (emptyRow) {
                emptyRow.style.display = (visibleCount === 0 && rows.length > 0) ? '' : 'none';
                if (visibleCount === 0 && rows.length > 0) {
                    emptyRow.querySelector('td').innerText = 'Tidak ada bank soal yang cocok dengan pencarian.';
                }
            }
            updateBankBulkUI();
        }

        async function bulkDeleteBankSoal() {
            if (selectedBankIds.size === 0) return;
            const count = selectedBankIds.size;
            const result = await Swal.fire({
                title: 'Hapus Bank Soal Terpilih?',
                text: `Yakin ingin menghapus ${count} bank soal terpilih? Seluruh butir soal di dalam bank soal yang dipilih juga akan terhapus secara permanen.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: `<i class="fas fa-trash mr-1"></i> Ya, Hapus ${count} Bank Soal!`,
                cancelButtonText: 'Batal'
            });

            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Menghapus...',
                    text: 'Sedang memproses penghapusan data...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });

                const fd = new FormData();
                fd.append('action', 'bulk_delete_bank_soal');
                fd.append('ids', JSON.stringify(Array.from(selectedBankIds)));

                try {
                    const res = await fetch('api.php', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Berhasil!',
                            text: json.message || 'Bank soal terpilih berhasil dihapus.',
                            icon: 'success',
                            timer: 1200,
                            showConfirmButton: false
                        }).then(() => location.reload());
                    } else {
                        Swal.fire('Gagal', json.message || 'Gagal menghapus bank soal.', 'error');
                    }
                } catch (e) {
                    Swal.fire('Error', 'Terjadi kesalahan sistem saat menghapus.', 'error');
                }
            }
        }

        async function resetStudent(studentId) {
            const result = await Swal.fire({
                title: 'Keluarkan Siswa?',
                html: 'Siswa akan dikeluarkan dari sesi ujian saat ini.<br><strong class="text-success"><i class="fas fa-check-circle mr-1"></i>Seluruh jawaban siswa tetap aman dan TIDAK akan hilang.</strong><br><small class="text-muted">Siswa dapat login kembali untuk melanjutkan ujian.</small>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ffc107',
                confirmButtonText: '<i class="fas fa-sign-out-alt mr-1"></i> Ya, Keluarkan Siswa',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const fd = new FormData();
                fd.append('student_id', studentId);
                if (currentLiveExamId) {
                    fd.append('exam_id', currentLiveExamId);
                }
                try {
                    const res = await fetch('api.php?action=reset_student', { method: 'POST', body: fd });
                    const json = await res.json();
                    Swal.fire({
                        title: 'Berhasil!',
                        text: json.message || 'Siswa berhasil dikeluarkan. Jawaban tetap tersimpan aman.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        fetchLiveStatus(); // Refresh tabel
                    });
                } catch(e) {
                    Swal.fire('Gagal', 'Gagal mereset/mengeluarkan siswa.', 'error');
                }
            }
        }

        async function unlockStudent(studentId, studentName) {
            const result = await Swal.fire({
                title: 'Buka Kunci Ujian?',
                text: `Buka kunci ujian untuk siswa "${studentName || 'ini'}"? Jumlah pelanggaran akan direset dan siswa dapat melanjutkan ujian tanpa kehilangan jawaban.`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, Buka Kunci!',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#28a745'
            });

            if (result.isConfirmed) {
                const fd = new FormData();
                fd.append('student_id', studentId);
                try {
                    const res = await fetch('api.php?action=unlock_student', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Berhasil!',
                            text: json.message || 'Ujian siswa berhasil dibuka kembali.',
                            icon: 'success',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => {
                            fetchLiveStatus();
                        });
                    } else {
                        Swal.fire('Gagal', json.message || 'Gagal membuka kunci siswa.', 'error');
                    }
                } catch(e) {
                    Swal.fire('Error', 'Terjadi kesalahan pada server.', 'error');
                }
            }
        }

        async function bulkUnlock() {
            if (selectedStatusIds.size === 0) {
                Swal.fire('Peringatan', 'Pilih minimal satu siswa terlebih dahulu dengan mencentang kotak di tabel.', 'warning');
                return;
            }
            
            const result = await Swal.fire({
                title: 'Buka Kunci Terpilih?',
                text: `Buka kunci ujian untuk ${selectedStatusIds.size} siswa terpilih? Jumlah pelanggaran akan direset dan siswa dapat melanjutkan ujian.`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, Buka Kunci!',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#28a745'
            });
            
            if (result.isConfirmed) {
                const ids = Array.from(selectedStatusIds);
                let successCount = 0;
                for (const id of ids) {
                    const fd = new FormData();
                    fd.append('student_id', id);
                    try {
                        const res = await fetch('api.php?action=unlock_student', { method: 'POST', body: fd });
                        const json = await res.json();
                        if (json.status === 'success') successCount++;
                    } catch(e) {}
                }
                Swal.fire({
                    title: 'Berhasil!',
                    text: `${successCount} siswa berhasil dibuka kuncinya.`,
                    icon: 'success',
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => {
                    selectedStatusIds.clear();
                    fetchLiveStatus();
                });
            }
        }

        async function toggleBlockStudent(studentId, block, studentName) {
            const actionText = block ? 'Blokir' : 'Buka Blokir';
            const actionMsg = block 
                ? `Apakah Anda yakin ingin <strong>memblokir</strong> siswa <strong>"${studentName || 'ini'}"</strong>?<br><small class="text-danger">Siswa tidak dapat mengerjakan ujian. Jika siswa sedang membuka ujian, sesi ujian akan langsung terputus dan logout seketika.</small>`
                : `Apakah Anda yakin ingin <strong>membuka blokir</strong> untuk siswa <strong>"${studentName || 'ini'}"</strong>?<br><small class="text-success">Siswa akan dapat login dan melanjutkan ujian kembali.</small>`;
            
            const result = await Swal.fire({
                title: `${actionText} Siswa?`,
                html: actionMsg,
                icon: block ? 'warning' : 'question',
                showCancelButton: true,
                confirmButtonColor: block ? '#d33' : '#28a745',
                confirmButtonText: block ? '<i class="fas fa-ban mr-1"></i> Ya, Blokir!' : '<i class="fas fa-check mr-1"></i> Ya, Buka Blokir',
                cancelButtonText: 'Batal'
            });

            if (result.isConfirmed) {
                const fd = new FormData();
                fd.append('student_id', studentId);
                fd.append('block', block ? 1 : 0);
                try {
                    const res = await fetch('api.php?action=block_student', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Berhasil!',
                            text: json.message || `Siswa berhasil di${actionText.toLowerCase()}.`,
                            icon: 'success',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => {
                            fetchLiveStatus();
                        });
                    } else {
                        Swal.fire('Gagal', json.message || 'Gagal memproses.', 'error');
                    }
                } catch(e) {
                    Swal.fire('Error', 'Terjadi kesalahan koneksi server.', 'error');
                }
            }
        }

        async function bulkBlock(block) {
            if (selectedStatusIds.size === 0) {
                Swal.fire('Oops', 'Pilih minimal satu siswa dengan mencentang kotak di tabel.', 'warning');
                return;
            }

            const actionText = block ? 'Blokir' : 'Buka Blokir';
            const actionMsg = block
                ? `Apakah Anda yakin ingin <strong>memblokir ${selectedStatusIds.size} siswa terpilih</strong>?<br><small class="text-danger">Siswa tidak dapat mengerjakan ujian. Jika ada siswa yang sedang mengerjakan, sesi akan langsung terputus dan logout seketika.</small>`
                : `Apakah Anda yakin ingin <strong>membuka blokir ${selectedStatusIds.size} siswa terpilih</strong>?<br><small class="text-success">Siswa akan dapat login dan mengerjakan ujian kembali.</small>`;

            const result = await Swal.fire({
                title: `${actionText} Siswa Terpilih?`,
                html: actionMsg,
                icon: block ? 'warning' : 'question',
                showCancelButton: true,
                confirmButtonColor: block ? '#d33' : '#28a745',
                confirmButtonText: block ? '<i class="fas fa-ban mr-1"></i> Ya, Blokir Semua' : '<i class="fas fa-check mr-1"></i> Ya, Buka Blokir Semua',
                cancelButtonText: 'Batal'
            });

            if (result.isConfirmed) {
                const fd = new FormData();
                fd.append('student_ids', JSON.stringify(Array.from(selectedStatusIds)));
                fd.append('block', block ? 1 : 0);
                Swal.fire({ title: 'Memproses...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
                try {
                    const res = await fetch('api.php?action=bulk_block_students', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        selectedStatusIds.clear();
                        Swal.fire('Berhasil!', json.message || 'Aksi massal berhasil diproses.', 'success').then(() => fetchLiveStatus());
                    } else {
                        Swal.fire('Gagal', json.message || 'Gagal memproses bulk blokir.', 'error');
                    }
                } catch(e) {
                    Swal.fire('Error', 'Gagal memproses bulk blokir.', 'error');
                }
            }
        }
        
        async function forceSubmitStudent(studentId) {
            const result = await Swal.fire({
                title: 'Paksa Selesai?',
                text: 'Yakin ingin menyelesaikan ujian siswa ini secara paksa? Sisa jawaban mereka akan disubmit secara otomatis sesuai apa adanya.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Selesai!',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const fd = new FormData();
                fd.append('student_id', studentId);
                try {
                    await fetch('api.php?action=force_submit', { method: 'POST', body: fd });
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Ujian siswa diselesaikan.',
                        icon: 'success',
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => {
                        fetchLiveStatus();
                    });
                } catch(e) {
                    Swal.fire('Gagal', 'Gagal memproses.', 'error');
                }
            }
        }
        
        function parseBankSoalData(bankName, storedClassesStr) {
            let examName = '';
            let targetClassList = [];
            
            if (storedClassesStr) {
                try {
                    const parsed = JSON.parse(storedClassesStr);
                    if (Array.isArray(parsed)) {
                        targetClassList = parsed.map(s => String(s).trim()).filter(Boolean);
                    }
                } catch(e) {
                    if (typeof storedClassesStr === 'string' && storedClassesStr.trim()) {
                        targetClassList = storedClassesStr.split(',').map(s => s.trim()).filter(Boolean);
                    }
                }
            }

            if (!bankName) return { examName, targetClassList };

            const trimmed = bankName.trim();
            if (trimmed.includes('-')) {
                let parts = trimmed.split('-').map(p => p.trim());
                // Hapus kode acak di akhir jika berupa karakter alfanumerik 3-6 digit (misal: 8X2K)
                if (parts.length >= 4 && /^[A-Za-z0-9]{3,6}$/.test(parts[parts.length - 1])) {
                    parts.pop();
                }

                if (parts.length >= 3) {
                    const jenis = parts[0];
                    const kelasPart = parts[1];
                    const mapel = parts.slice(2).join('-');
                    examName = (jenis + ' ' + mapel).toUpperCase().trim();

                    if (targetClassList.length === 0 && kelasPart) {
                        targetClassList = kelasPart.split(',').map(s => s.trim()).filter(Boolean);
                    }
                } else if (parts.length === 2) {
                    examName = (parts[0] + ' ' + parts[1]).toUpperCase().trim();
                } else {
                    examName = trimmed.toUpperCase();
                }
            } else {
                examName = trimmed.toUpperCase();
            }

            return { examName, targetClassList };
        }

        function onSelectBankSoalChange(prefix = 'add', autoFill = true) {
            const selectEl = document.getElementById(prefix + '_bank_soal_id');
            if (!selectEl) return;
            
            const selectedOption = selectEl.options[selectEl.selectedIndex];
            if (!selectedOption || !selectedOption.value) return;

            const bankName = selectedOption.getAttribute('data-name') || selectedOption.text || '';
            const bankCount = parseInt(selectedOption.getAttribute('data-count') || '0');
            const storedClasses = selectedOption.getAttribute('data-classes') || '';

            const { examName, targetClassList } = parseBankSoalData(bankName, storedClasses);

            // 1. Auto isi Nama Ujian
            const nameInput = document.getElementById(prefix + '_exam_name');
            if (nameInput && autoFill) {
                nameInput.value = examName;
            }

            // 2. Auto isi dan badge Jumlah Soal
            const maxQInput = document.getElementById(prefix + '_exam_max_questions');
            const badgeEl = document.getElementById(prefix + '_exam_total_badge');
            if (badgeEl) {
                badgeEl.textContent = `dari ${bankCount} soal di bank`;
            }
            if (maxQInput) {
                maxQInput.max = bankCount > 0 ? bankCount : '';
                if (autoFill) {
                    maxQInput.value = bankCount > 0 ? bankCount : '';
                }
            }

            // 3. Auto ceklis kelas yang sesuai
            if (autoFill && targetClassList.length > 0) {
                const cbSelector = '.' + prefix + '-exam-class-cb';
                document.querySelectorAll(cbSelector).forEach(cb => cb.checked = false);
                
                document.querySelectorAll(cbSelector).forEach(cb => {
                    const cName = (cb.getAttribute('data-name') || cb.nextElementSibling?.textContent || '').trim();
                    const cNameLower = cName.toLowerCase();
                    let matched = false;

                    for (const t of targetClassList) {
                        const tTrim = t.trim();
                        const tLower = tTrim.toLowerCase();
                        if (cNameLower === tLower) {
                            matched = true;
                            break;
                        }
                        if (/^(XII|XI|IX|VIII|VII|VI|IV|V|X|\d+)$/i.test(tTrim)) {
                            const regex = new RegExp('^' + tTrim + '([.\\-\\s_A-Za-z0-9]|$)', 'i');
                            if (regex.test(cName)) {
                                matched = true;
                                break;
                            }
                        }
                    }
                    if (matched) {
                        cb.checked = true;
                    }
                });
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            if (window.jQuery) {
                $('#modalAddExam').on('show.bs.modal', function () {
                    const bankSelect = document.getElementById('add_bank_soal_id');
                    if (bankSelect) bankSelect.selectedIndex = 0;
                    const nameInput = document.getElementById('add_exam_name');
                    if (nameInput) nameInput.value = '';
                    const maxQ = document.getElementById('add_exam_max_questions');
                    if (maxQ) maxQ.value = '';
                    const badge = document.getElementById('add_exam_total_badge');
                    if (badge) badge.textContent = 'dari 0 soal di bank';
                    $('.add-exam-class-cb').prop('checked', false);
                    
                    const tokenInput = document.getElementById('add_exam_token');
                    if (tokenInput && !tokenInput.value) {
                        tokenInput.value = Math.random().toString(36).substring(2, 8).toUpperCase();
                    }
                    
                    const now = new Date();
                    const pad = n => n < 10 ? '0' + n : n;
                    const toLocalISO = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
                    
                    const startInput = document.getElementById('add_exam_start');
                    if (startInput && !startInput.value) {
                        startInput.value = toLocalISO(now);
                    }
                    const endInput = document.getElementById('add_exam_end');
                    if (endInput && !endInput.value) {
                        const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
                        endInput.value = toLocalISO(tomorrow);
                    }
                });
            }
        });
        
        async function addExam(e) {
            e.preventDefault();
            const name = document.getElementById('add_exam_name').value;
            const bank_soal_id = document.getElementById('add_bank_soal_id').value;
            const max_questions = document.getElementById('add_exam_max_questions') ? document.getElementById('add_exam_max_questions').value : 0;
            const token = document.getElementById('add_exam_token').value;
            const class_cbs = document.querySelectorAll('.add-exam-class-cb:checked');
            const class_ids = Array.from(class_cbs).map(cb => parseInt(cb.value));
            const start = document.getElementById('add_exam_start').value;
            const end = document.getElementById('add_exam_end').value;
            const duration = document.getElementById('add_exam_duration').value;
            const shuffle_q = document.getElementById('add_exam_shuffle_q').checked ? 1 : 0;
            const shuffle_o = document.getElementById('add_exam_shuffle_o').checked ? 1 : 0;
            const status = document.getElementById('add_exam_status').value;
            
            const fd = new FormData();
            fd.append('action', 'add_exam');
            fd.append('exam_name', name);
            fd.append('bank_soal_id', bank_soal_id);
            fd.append('max_questions', max_questions || 0);
            fd.append('token', token);
            fd.append('class_ids', JSON.stringify(class_ids));
            fd.append('start_time', start);
            fd.append('end_time', end);
            fd.append('duration', duration);
            fd.append('shuffle_questions', shuffle_q);
            fd.append('shuffle_options', shuffle_o);
            fd.append('status', status);
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') location.reload();
                else alert(json.message);
            } catch(e) { alert('Gagal menambah mata pelajaran'); }
        }
        
        function openEditExamModal(exam) {
            document.getElementById('edit_exam_id').value = exam.id;
            document.getElementById('edit_bank_soal_id').value = exam.bank_soal_id || exam.id;
            document.getElementById('edit_exam_name').value = exam.name || '';
            document.getElementById('edit_exam_token').value = exam.token || '';
            
            const maxQInput = document.getElementById('edit_exam_max_questions');
            if (maxQInput) {
                maxQInput.value = exam.max_questions > 0 ? exam.max_questions : '';
            }
            onSelectBankSoalChange('edit', false);
            
            document.querySelectorAll('.edit-exam-class-cb').forEach(cb => cb.checked = false);
            let ids = exam.class_ids !== undefined ? exam.class_ids : exam.classes;
            if (ids === undefined && exam.class_id !== undefined) {
                ids = exam.class_id == 0 ? [] : [exam.class_id];
            }
            if (typeof ids === 'string') {
                try { ids = JSON.parse(ids); } catch(e) { ids = []; }
            }
            if (Array.isArray(ids)) {
                ids.forEach(id => {
                    const cb = document.getElementById('edit_class_' + id);
                    if (cb) cb.checked = true;
                });
            }

            const formatDt = (dtStr) => {
                if (!dtStr) return '';
                return dtStr.replace(' ', 'T').substring(0, 16);
            };

            document.getElementById('edit_exam_start').value = formatDt(exam.start_time);
            document.getElementById('edit_exam_end').value = formatDt(exam.end_time);
            document.getElementById('edit_exam_duration').value = exam.duration || 90;
            
            const isShuffleQ = (exam.shuffle_questions === undefined || exam.shuffle_questions === null) 
                ? true 
                : (exam.shuffle_questions == 1 || exam.shuffle_questions === true || exam.shuffle_questions === 'true');
            document.getElementById('edit_exam_shuffle_q').checked = isShuffleQ;

            const isShuffleO = (exam.shuffle_options === undefined || exam.shuffle_options === null) 
                ? true 
                : (exam.shuffle_options == 1 || exam.shuffle_options === true || exam.shuffle_options === 'true');
            document.getElementById('edit_exam_shuffle_o').checked = isShuffleO;
            
            document.getElementById('edit_exam_status').value = exam.status || 'aktif';
            
            $('#modalEditExam').modal('show');
        }
        
        async function submitEditExam(e) {
            e.preventDefault();
            const id = document.getElementById('edit_exam_id').value;
            const name = document.getElementById('edit_exam_name').value;
            const bank_soal_id = document.getElementById('edit_bank_soal_id').value;
            const max_questions = document.getElementById('edit_exam_max_questions') ? document.getElementById('edit_exam_max_questions').value : 0;
            const token = document.getElementById('edit_exam_token').value;
            const class_cbs = document.querySelectorAll('.edit-exam-class-cb:checked');
            const class_ids = Array.from(class_cbs).map(cb => parseInt(cb.value));
            const start = document.getElementById('edit_exam_start').value;
            const end = document.getElementById('edit_exam_end').value;
            const duration = document.getElementById('edit_exam_duration').value;
            const shuffle_q = document.getElementById('edit_exam_shuffle_q').checked ? 1 : 0;
            const shuffle_o = document.getElementById('edit_exam_shuffle_o').checked ? 1 : 0;
            const status = document.getElementById('edit_exam_status').value;
            
            const fd = new FormData();
            fd.append('action', 'edit_exam');
            fd.append('exam_id', id);
            fd.append('exam_name', name);
            fd.append('bank_soal_id', bank_soal_id);
            fd.append('max_questions', max_questions || 0);
            fd.append('token', token);
            fd.append('class_ids', JSON.stringify(class_ids));
            fd.append('start_time', start);
            fd.append('end_time', end);
            fd.append('duration', duration);
            fd.append('shuffle_questions', shuffle_q);
            fd.append('shuffle_options', shuffle_o);
            fd.append('status', status);
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();
                if (json.status === 'success') location.reload();
                else alert(json.message);
            } catch(e) { alert('Gagal menyimpan perubahan jadwal'); }
        }
        
        async function deleteExam(examId) {
            const result = await Swal.fire({
                title: 'Konfirmasi',
                text: 'Yakin ingin menghapus mata pelajaran ini? (Bank soal tetap tersimpan aman)',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            });

            if(result.isConfirmed) {
                const fd = new FormData();
                fd.append('action', 'delete_exam');
                fd.append('exam_id', examId);
                try {
                    await fetch('api.php', { method: 'POST', body: fd });
                    Swal.fire({
                        title: 'Berhasil!',
                        text: 'Mata pelajaran dihapus.',
                        icon: 'success',
                        timer: 1000,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                } catch(e) { Swal.fire('Gagal', 'Gagal menghapus mata pelajaran', 'error'); }
            }
        }

        let selectedExamIds = new Set();

        function toggleAllExam(masterCb) {
            const checked = masterCb.checked;
            const cbs = document.querySelectorAll('.cb-exam');
            cbs.forEach(cb => {
                const row = cb.closest('tr');
                if (!row || row.style.display !== 'none') {
                    cb.checked = checked;
                    const id = parseInt(cb.value);
                    if (checked) selectedExamIds.add(id);
                    else selectedExamIds.delete(id);
                }
            });
            updateExamBulkUI();
        }

        function toggleExamSelection(cb) {
            const id = parseInt(cb.value);
            if (cb.checked) {
                selectedExamIds.add(id);
            } else {
                selectedExamIds.delete(id);
                const masterCb = document.getElementById('cb-all-exam');
                if (masterCb) masterCb.checked = false;
            }
            updateExamBulkUI();
        }

        function updateExamBulkUI() {
            const bulkContainer = document.getElementById('bulk-exam-actions');
            const countEls = document.querySelectorAll('.selected-exam-count');
            const size = selectedExamIds.size;
            countEls.forEach(el => el.innerText = size);
            if (bulkContainer) {
                if (size > 0) {
                    bulkContainer.style.setProperty('display', 'inline-flex', 'important');
                } else {
                    bulkContainer.style.setProperty('display', 'none', 'important');
                }
            }
            const allCbs = document.querySelectorAll('.cb-exam');
            const masterCb = document.getElementById('cb-all-exam');
            if (masterCb && allCbs.length > 0) {
                const visibleCbs = Array.from(allCbs).filter(cb => {
                    const row = cb.closest('tr');
                    return !row || row.style.display !== 'none';
                });
                if (visibleCbs.length > 0) {
                    masterCb.checked = visibleCbs.every(cb => cb.checked);
                }
            }
        }

        function filterExamTable() {
            const query = (document.getElementById('search-exam')?.value || '').toLowerCase().trim();
            const rows = document.querySelectorAll('.exam-row');
            let visibleCount = 0;

            rows.forEach(row => {
                const text = row.innerText.toLowerCase();
                const matchQuery = !query || text.includes(query);

                const rowStatus = (row.getAttribute('data-exam-status') || 'aktif').toLowerCase();
                let matchStatus = true;
                if (typeof currentExamStatusTab !== 'undefined' && currentExamStatusTab !== 'all') {
                    if (currentExamStatusTab === 'draft' || currentExamStatusTab === 'draf') {
                        matchStatus = (rowStatus === 'draft' || rowStatus === 'draf');
                    } else {
                        matchStatus = (rowStatus === currentExamStatusTab);
                    }
                }

                const match = matchQuery && matchStatus;
                row.style.display = match ? '' : 'none';
                if (match) {
                    visibleCount++;
                    const noCol = row.querySelector('.exam-no-col');
                    if (noCol) {
                        noCol.textContent = visibleCount;
                        noCol.setAttribute('data-val', visibleCount);
                    }
                }
            });

            const emptyRow = document.getElementById('row-empty-exam');
            if (emptyRow) {
                emptyRow.style.display = (visibleCount === 0 && rows.length > 0) ? '' : 'none';
                if (visibleCount === 0 && rows.length > 0) {
                    emptyRow.querySelector('td').innerText = 'Tidak ada mata pelajaran yang cocok dengan filter / pencarian.';
                }
            }
            updateExamBulkUI();
        }

        async function bulkDeleteExam() {
            if (selectedExamIds.size === 0) return;
            const count = selectedExamIds.size;
            const result = await Swal.fire({
                title: 'Hapus Mata Pelajaran Terpilih?',
                text: `Yakin ingin menghapus ${count} mata pelajaran terpilih? (Bank soal asli tetap aman tersimpan).`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: `<i class="fas fa-trash mr-1"></i> Ya, Hapus ${count} Mapel!`,
                cancelButtonText: 'Batal'
            });

            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Menghapus...',
                    text: 'Sedang menghapus mata pelajaran terpilih...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });

                const fd = new FormData();
                fd.append('action', 'bulk_delete_exam');
                fd.append('ids', JSON.stringify(Array.from(selectedExamIds)));

                try {
                    const res = await fetch('api.php', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Berhasil!',
                            text: json.message || 'Mata pelajaran terpilih berhasil dihapus.',
                            icon: 'success',
                            timer: 1200,
                            showConfirmButton: false
                        }).then(() => location.reload());
                    } else {
                        Swal.fire('Gagal', json.message || 'Gagal menghapus mata pelajaran.', 'error');
                    }
                } catch (e) {
                    Swal.fire('Error', 'Terjadi kesalahan sistem saat menghapus.', 'error');
                }
            }
        }

        async function bulkUpdateExamStatus(newStatus) {
            if (selectedExamIds.size === 0) return;
            const count = selectedExamIds.size;
            const statusLabels = {
                'aktif': { name: 'Aktif', color: '#28a745', icon: 'fas fa-check-circle' },
                'draft': { name: 'Draft', color: '#6c757d', icon: 'fas fa-file-alt' },
                'selesai': { name: 'Selesai', color: '#17a2b8', icon: 'fas fa-flag-checkered' }
            };
            const label = statusLabels[newStatus] || { name: newStatus, color: '#007bff', icon: 'fas fa-info-circle' };

            const result = await Swal.fire({
                title: `Ubah Status ke ${label.name}?`,
                text: `Yakin ingin mengubah status ${count} jadwal mata pelajaran terpilih menjadi "${label.name}"?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: label.color,
                cancelButtonColor: '#6c757d',
                confirmButtonText: `<i class="${label.icon} mr-1"></i> Ya, Ubah ke ${label.name}!`,
                cancelButtonText: 'Batal'
            });

            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Memperbarui Status...',
                    text: 'Sedang memproses perubahan status...',
                    allowOutsideClick: false,
                    didOpen: () => { Swal.showLoading(); }
                });

                const fd = new FormData();
                fd.append('action', 'bulk_update_exam_status');
                fd.append('ids', JSON.stringify(Array.from(selectedExamIds)));
                fd.append('status', newStatus);

                try {
                    const res = await fetch('api.php', { method: 'POST', body: fd });
                    const json = await res.json();
                    if (json.status === 'success') {
                        Swal.fire({
                            title: 'Berhasil!',
                            text: json.message || 'Status mata pelajaran berhasil diperbarui.',
                            icon: 'success',
                            timer: 1200,
                            showConfirmButton: false
                        }).then(() => location.reload());
                    } else {
                        Swal.fire('Gagal', json.message || 'Gagal memperbarui status.', 'error');
                    }
                } catch (e) {
                    Swal.fire('Error', 'Terjadi kesalahan sistem.', 'error');
                }
            }
        }
        
        async function importExcelSiswa(e) {
            e.preventDefault();
            const fileInput = document.getElementById('file_siswa');
            
            if (!fileInput.files.length) return;
            
            const btn = document.getElementById('btn-import-siswa');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Memproses...';
            btn.disabled = true;
            
            const file = fileInput.files[0];
            const reader = new FileReader();
            
            reader.onload = async function(e) {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, {type: 'array'});
                    
                    const firstSheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[firstSheetName];
                    
                    // Convert sheet to json
                    const json = XLSX.utils.sheet_to_json(worksheet);
                    
                    let studentsData = [];
                    json.forEach(row => {
                        let username = row['Username'] || row['User'] || row['NIS'] || row['NISN'] || '';
                        let name = row['Nama'] || row['Nama Siswa'] || row['Name'] || Object.values(row)[0];
                        let className = row['Kelas'] || row['Class'] || Object.values(row)[1];
                        let password = row['Password'] || row['Sandi'] || '';
                        let ruang = row['Ruang'] || row['Ruangan'] || row['Room'] || '';
                        let noPeserta = row['No Peserta'] || row['Nomor Peserta'] || row['No_Peserta'] || row['NoPeserta'] || row['Nopes'] || '';
                        
                        if (name && typeof name === 'string' && className && typeof className === 'string') {
                            studentsData.push({
                                username: (username + '').trim(),
                                name: name.trim(),
                                class_name: className.trim(),
                                password: (password + '').trim(),
                                ruang: (ruang + '').trim(),
                                no_peserta: (noPeserta + '').trim()
                            });
                        }
                    });
                    
                    if (studentsData.length === 0) {
                        alert('Tidak ada data siswa ditemukan. Pastikan format kolom "Nama" dan "Kelas" benar.');
                        resetBtn();
                        return;
                    }
                    
                    const formData = new FormData();
                    formData.append('action', 'import_students_batch');
                    formData.append('students', JSON.stringify(studentsData));
                    
                    const response = await fetch('api.php', { method: 'POST', body: formData });
                    const res = await response.json();
                    
                    alert(res.message);
                    if (res.status === 'success') {
                        location.reload(); // Refresh to see changes
                    }
                } catch (error) {
                    console.error(error);
                    alert('Gagal memproses file Excel.');
                }
                resetBtn();
            };
            
            reader.readAsArrayBuffer(file);
            
            function resetBtn() {
                btn.innerHTML = '<i class="fas fa-file-excel mr-2"></i> Impor Siswa';
                btn.disabled = false;
            }
        }

        function downloadTemplateSiswa() {
            const worksheet = XLSX.utils.json_to_sheet([
                { "No Peserta": "01-001-001-8", Username: "siswa101", Nama: "Andi Susanto", Kelas: "IX.1", Ruang: "Ruang 1", Password: "123" },
                { "No Peserta": "01-001-002-7", Username: "siswa102", Nama: "Budi Santoso", Kelas: "IX.2", Ruang: "Ruang 2", Password: "" }
            ]);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Template Siswa");
            XLSX.writeFile(workbook, "Template_Import_Siswa.xlsx", { compression: true });
        }
        
        async function refreshStatusManual() {
            const btn = document.getElementById('btn-refresh-status');
            const icon = btn ? btn.querySelector('i') : null;
            if (icon) icon.classList.add('fa-spin');
            if (btn) btn.disabled = true;
            try {
                await fetchLiveStatus();
            } finally {
                setTimeout(() => {
                    if (icon) icon.classList.remove('fa-spin');
                    if (btn) btn.disabled = false;
                }, 300);
            }
        }

        fetchLiveStatus();
        loadQuestions();
        // Background polling dihapus agar server dan browser lebih ringan
        
        // Excel Styling & Workbook Builder Helper
        function buildNilaiWorkbook(data, examName = null) {
            // Format data array: No, Nama Siswa, Kelas, Nilai
            const sheetData = [
                ['No', 'Nama Siswa', 'Kelas', 'Nilai']
            ];
            
            data.forEach((row, idx) => {
                sheetData.push([
                    row['No'] !== undefined ? row['No'] : (idx + 1),
                    row['Nama Siswa'] || '',
                    row['Kelas'] || '',
                    row['Nilai'] !== undefined ? Number(row['Nilai']) : 0
                ]);
            });
            
            // Create worksheet from AOA
            const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
            
            // Column widths
            worksheet['!cols'] = [
                { wch: 6 },  // No
                { wch: 35 }, // Nama Siswa
                { wch: 15 }, // Kelas
                { wch: 12 }  // Nilai
            ];

            // Style: Border tabel & Header warna kuning
            const borderThin = {
                top: { style: 'thin', color: { rgb: '000000' } },
                bottom: { style: 'thin', color: { rgb: '000000' } },
                left: { style: 'thin', color: { rgb: '000000' } },
                right: { style: 'thin', color: { rgb: '000000' } }
            };

            const headerStyle = {
                fill: {
                    fgColor: { rgb: 'FFFF00' } // Warna kuning
                },
                font: {
                    name: 'Calibri',
                    sz: 11,
                    bold: true,
                    color: { rgb: '000000' }
                },
                alignment: {
                    vertical: 'center',
                    horizontal: 'center'
                },
                border: borderThin
            };

            const bodyStyleCenter = {
                font: { name: 'Calibri', sz: 11 },
                alignment: { vertical: 'center', horizontal: 'center' },
                border: borderThin
            };

            const bodyStyleLeft = {
                font: { name: 'Calibri', sz: 11 },
                alignment: { vertical: 'center', horizontal: 'left' },
                border: borderThin
            };

            const range = XLSX.utils.decode_range(worksheet['!ref']);
            for (let R = range.s.r; R <= range.e.r; ++R) {
                for (let C = range.s.c; C <= range.e.c; ++C) {
                    const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
                    if (!worksheet[cell_address]) {
                        worksheet[cell_address] = { t: 's', v: '' };
                    }
                    if (R === 0) {
                        worksheet[cell_address].s = headerStyle;
                    } else {
                        worksheet[cell_address].s = (C === 1) ? bodyStyleLeft : bodyStyleCenter;
                    }
                }
            }
            
            // Create workbook and append sheet
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Nilai");
            
            // Determine class name(s) from data for file naming
            const uniqueClasses = [...new Set(data.map(r => r.Kelas).filter(k => k && k !== '-'))];
            let classPart = '';
            if (uniqueClasses.length > 0) {
                classPart = uniqueClasses.join('_').trim().replace(/[\s\/\\]+/g, '_').replace(/[^a-zA-Z0-9_.-]/g, '');
            }

            const dateStr = new Date().toISOString().split('T')[0];
            let fileName = '';
            if (examName) {
                const cleanExam = examName.trim().replace(/[\s\/\\]+/g, '_').replace(/[^a-zA-Z0-9_.-]/g, '');
                fileName = classPart 
                    ? `Nilai_${cleanExam}_${classPart}_${dateStr}.xlsx` 
                    : `Nilai_${cleanExam}_${dateStr}.xlsx`;
            } else {
                fileName = classPart 
                    ? `Rekap_Nilai_${classPart}_${dateStr}.xlsx` 
                    : `Rekap_Nilai_${dateStr}.xlsx`;
            }

            return { workbook, fileName };
        }

        // Excel Download Logic (Single Exam)
        async function downloadExcel(examId = null, examName = null) {
            try {
                let url = 'api.php?action=get_all_results';
                if (examId !== null) {
                    url += `&exam_id=${examId}`;
                }
                
                const response = await fetch(url);
                const res = await response.json();
                
                if (res.status === 'success') {
                    if (!res.data || res.data.length === 0) {
                        Swal.fire('Informasi', 'Belum ada data siswa untuk ' + (examName ? examName : 'semua mapel') + '.', 'info');
                        return;
                    }
                    
                    const { workbook, fileName } = buildNilaiWorkbook(res.data, examName);
                    XLSX.writeFile(workbook, fileName, { compression: true });
                } else {
                    Swal.fire('Error', res.message || 'Gagal mengambil data ujian', 'error');
                }
            } catch(e) {
                console.error(e);
                Swal.fire('Error', 'Gagal mengunduh Excel: ' + e.message, 'error');
            }
        }

        // Bulk Excel Download Logic (ZIP if multiple, direct XLSX if single)
        async function bulkDownloadStatusExcel() {
            let selected = Array.from(document.querySelectorAll('.cb-status-exam:checked'));
            if (selected.length === 0) {
                selected = Array.from(document.querySelectorAll('.cb-exam-row:checked'));
            }
            if (selected.length === 0) {
                Swal.fire('Peringatan', 'Silakan centang minimal satu mata pelajaran terlebih dahulu.', 'warning');
                return;
            }

            // Jika hanya 1 yang dipilih, unduh langsung sebagai file .xlsx tunggal
            if (selected.length === 1) {
                const examId = selected[0].value;
                const examName = selected[0].dataset.name || '';
                await downloadExcel(examId, examName);
                return;
            }

            // Jika lebih dari 1 yang dipilih, kemas ke dalam berkas ZIP
            if (typeof JSZip === 'undefined') {
                Swal.fire('Error', 'Pustaka kompresi ZIP (JSZip) belum siap atau gagal dimuat. Periksa koneksi internet Anda.', 'error');
                return;
            }

            Swal.fire({
                title: 'Menyiapkan Berkas...',
                html: `Memproses data ujian (0/${selected.length})...`,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            try {
                const zip = new JSZip();
                let processedCount = 0;
                let emptyCount = 0;
                const usedFileNames = {};

                for (let i = 0; i < selected.length; i++) {
                    const examId = selected[i].value;
                    const examName = selected[i].dataset.name || `Ujian_${examId}`;
                    
                    if (Swal.getHtmlContainer()) {
                        Swal.getHtmlContainer().textContent = `Mengunduh nilai: ${examName} (${i + 1}/${selected.length})...`;
                    }

                    try {
                        const response = await fetch(`api.php?action=get_all_results&exam_id=${examId}`);
                        const res = await response.json();

                        if (res.status === 'success' && res.data && res.data.length > 0) {
                            const { workbook, fileName } = buildNilaiWorkbook(res.data, examName);
                            // Tulis workbook sebagai buffer byte array untuk JSZip
                            const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });

                            // Cegah tabrakan nama file identik di dalam arsip zip
                            let finalFileName = fileName;
                            if (usedFileNames[finalFileName]) {
                                usedFileNames[finalFileName]++;
                                const dotIdx = finalFileName.lastIndexOf('.');
                                finalFileName = finalFileName.substring(0, dotIdx) + `_(${usedFileNames[finalFileName]})` + finalFileName.substring(dotIdx);
                            } else {
                                usedFileNames[finalFileName] = 1;
                            }

                            zip.file(finalFileName, excelBuffer);
                            processedCount++;
                        } else {
                            emptyCount++;
                        }
                    } catch (err) {
                        console.error(`Gagal memproses mata pelajaran ${examName}:`, err);
                    }
                }

                if (processedCount === 0) {
                    Swal.fire('Informasi', 'Tidak ada data nilai siswa pada mata pelajaran yang dipilih.', 'info');
                    return;
                }

                if (Swal.getHtmlContainer()) {
                    Swal.getHtmlContainer().textContent = 'Mengompres ke dalam berkas ZIP...';
                }

                const zipBlob = await zip.generateAsync({ type: 'blob' });
                const dateStr = new Date().toISOString().split('T')[0];
                const zipFileName = `Rekap_Nilai_Ujian_${dateStr}.zip`;

                // Picu unduhan berkas ZIP pada browser
                const link = document.createElement('a');
                link.href = URL.createObjectURL(zipBlob);
                link.download = zipFileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                setTimeout(() => URL.revokeObjectURL(link.href), 10000);

                let infoMsg = `Berhasil mengunduh <b>${processedCount}</b> file nilai ujian dalam format ZIP.`;
                if (emptyCount > 0) {
                    infoMsg += `<br><small class="text-muted">(${emptyCount} mata pelajaran dilewati karena belum ada data nilai siswa)</small>`;
                }
                Swal.fire({
                    icon: 'success',
                    title: 'Unduh Selesai!',
                    html: infoMsg
                });
            } catch (err) {
                console.error(err);
                Swal.fire('Error', 'Terjadi kesalahan saat membuat file ZIP: ' + err.message, 'error');
            }
        }
        window.bulkDownloadExcel = bulkDownloadStatusExcel;
    <?php endif; ?>
    </script>
    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.1/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Summernote -->
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script>
    // Custom Summernote Button untuk Equation / Rumus LaTeX
    var LatexMathButton = function (context) {
        var ui = $.summernote.ui;
        var button = ui.button({
            contents: '<i class="fas fa-square-root-alt text-primary mr-1"></i><span style="font-weight:600; font-size:11px;">Rumus</span>',
            tooltip: 'Sisipkan Rumus Matematika / Equation LaTeX',
            click: function () {
                if (typeof window.openLatexEquationModal === 'function') {
                    window.openLatexEquationModal(context);
                } else {
                    Swal.fire('Fitur Rumus', 'Editor Rumus LaTeX sedang disiapkan...', 'info');
                }
            }
        });
        return button.render();
    };

    window.getSummernoteConfig = function(height) {
        return {
            height: height || 120,
            buttons: {
                latexMath: LatexMathButton
            },
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'italic', 'underline', 'clear']],
                ['math', ['latexMath']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['table', ['table']],
                ['insert', ['picture', 'link', 'hr']],
                ['view', ['fullscreen', 'codeview']]
            ],
            popover: {
                image: [],
                link: [
                    ['link', ['linkDialogShow', 'unlink']]
                ],
                table: [
                    ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
                    ['delete', ['deleteRow', 'deleteCol', 'deleteTable']]
                ]
            },
            callbacks: {
                onImageUpload: function(files) {
                    var $editor = $(this);
                    for (var i = 0; i < files.length; i++) {
                        var file = files[i];
                        if (!file.type || !file.type.match(/^image\//i)) continue;

                        (function(imgFile) {
                            var reader = new FileReader();
                            reader.onload = function(e) {
                                var tempImg = new Image();
                                tempImg.onload = function() {
                                    var maxDim = 1400;
                                    var w = tempImg.width;
                                    var h = tempImg.height;
                                    if (w > maxDim || h > maxDim) {
                                        if (w > h) {
                                            h = Math.round((h * maxDim) / w);
                                            w = maxDim;
                                        } else {
                                            w = Math.round((w * maxDim) / h);
                                            h = maxDim;
                                        }
                                    }
                                    var canvas = document.createElement('canvas');
                                    canvas.width = w;
                                    canvas.height = h;
                                    var ctx = canvas.getContext('2d');
                                    ctx.drawImage(tempImg, 0, 0, w, h);

                                    var dataUrl = '';
                                    try {
                                        dataUrl = canvas.toDataURL('image/webp', 0.85);
                                        if (!dataUrl || !dataUrl.startsWith('data:image/webp')) {
                                            dataUrl = canvas.toDataURL(imgFile.type || 'image/jpeg', 0.85);
                                        }
                                    } catch (err) {
                                        dataUrl = canvas.toDataURL(imgFile.type || 'image/jpeg', 0.85);
                                    }
                                    $editor.summernote('insertImage', dataUrl || e.target.result);
                                };
                                tempImg.onerror = function() {
                                    $editor.summernote('insertImage', e.target.result);
                                };
                                tempImg.src = e.target.result;
                            };
                            reader.readAsDataURL(imgFile);
                        })(file);
                    }
                }
            }
        };
    };

    $(document).ready(function() {
        $('#add_q_text, #edit_q_text').summernote(window.getSummernoteConfig(150));
        $('.summernote-option-add').summernote(window.getSummernoteConfig(100));

        $('#modalImportSoal').on('show.bs.modal', function() {
            const previewEl = document.getElementById('preview_exam_id');
            const uploadEl = document.getElementById('upload_exam_id');
            if (previewEl && previewEl.value && uploadEl) {
                uploadEl.value = previewEl.value;
            }
        });

        // Interactive Drag-to-Resize Table Columns (Kiri-Kanan) & Rows (Atas-Bawah)
        initSummernoteTableResizer();

        // Interactive Drag-Corner Image Resizer for Summernote Editor
        initSummernoteImageResizer();

        // Fix for Bootstrap modal scrolling issue when Summernote dialog closes
        $(document).on('hidden.bs.modal', function () {
            if ($('.modal:visible').length) {
                $('body').addClass('modal-open');
            }
        });
    });

    /**
     * Interactive Table Column & Row Resizer for Summernote Editor
     * Memungkinkan guru menggeser batas kolom (kanan-kiri) dan batas baris (atas-bawah) dengan mouse
     */
    function initSummernoteTableResizer() {
        let isResizing = false;
        let resizeMode = null; // 'col' atau 'row'
        let currentCell = null;
        let currentRow = null;
        let currentTable = null;
        let colIndex = -1;
        let startX = 0, startY = 0;
        let startCellWidth = 0, startRowHeight = 0;

        let guideLine = document.getElementById('sn-table-resize-guide');
        if (!guideLine) {
            guideLine = document.createElement('div');
            guideLine.id = 'sn-table-resize-guide';
            guideLine.style.position = 'fixed';
            guideLine.style.zIndex = '999999';
            guideLine.style.pointerEvents = 'none';
            guideLine.style.display = 'none';
            guideLine.style.backgroundColor = '#0284c7';
            guideLine.style.boxShadow = '0 0 5px rgba(2, 132, 199, 0.6)';
            document.body.appendChild(guideLine);
        }

        $(document).on('mousemove', function(e) {
            if (isResizing && currentTable) {
                const tableRect = currentTable.getBoundingClientRect();

                if (resizeMode === 'col') {
                    const deltaX = e.clientX - startX;
                    const newWidth = Math.max(25, Math.round(startCellWidth + deltaX));

                    // Atur lebar untuk seluruh baris pada kolom yang digeser
                    const rows = currentTable.rows;
                    for (let r = 0; r < rows.length; r++) {
                        if (rows[r].cells[colIndex]) {
                            rows[r].cells[colIndex].style.width = newWidth + 'px';
                            rows[r].cells[colIndex].style.minWidth = newWidth + 'px';
                        }
                    }

                    // Tampilkan garis bantu vertikal
                    guideLine.style.display = 'block';
                    guideLine.style.top = tableRect.top + 'px';
                    guideLine.style.left = e.clientX + 'px';
                    guideLine.style.width = '2px';
                    guideLine.style.height = tableRect.height + 'px';
                    document.body.style.cursor = 'col-resize';
                } else if (resizeMode === 'row') {
                    const deltaY = e.clientY - startY;
                    const newHeight = Math.max(20, Math.round(startRowHeight + deltaY));

                    currentRow.style.height = newHeight + 'px';
                    for (let c = 0; c < currentRow.cells.length; c++) {
                        currentRow.cells[c].style.height = newHeight + 'px';
                    }

                    // Tampilkan garis bantu horizontal
                    guideLine.style.display = 'block';
                    guideLine.style.top = e.clientY + 'px';
                    guideLine.style.left = tableRect.left + 'px';
                    guideLine.style.width = tableRect.width + 'px';
                    guideLine.style.height = '2px';
                    document.body.style.cursor = 'row-resize';
                }
                e.preventDefault();
                return;
            }

            // Deteksi posisi mouse di dekat batas sel tabel editor Summernote
            const cell = e.target.closest('.note-editable td, .note-editable th');
            if (!cell) return;

            const rect = cell.getBoundingClientRect();
            const tolerance = 6;
            const isNearRight = (rect.right - e.clientX) >= 0 && (rect.right - e.clientX) <= tolerance;
            const isNearBottom = (rect.bottom - e.clientY) >= 0 && (rect.bottom - e.clientY) <= tolerance;

            if (isNearRight) {
                cell.style.cursor = 'col-resize';
            } else if (isNearBottom) {
                cell.style.cursor = 'row-resize';
            } else {
                cell.style.cursor = '';
            }
        });

        $(document).on('mousedown', '.note-editable td, .note-editable th', function(e) {
            const cell = this;
            const rect = cell.getBoundingClientRect();
            const tolerance = 6;
            const isNearRight = (rect.right - e.clientX) >= 0 && (rect.right - e.clientX) <= tolerance;
            const isNearBottom = (rect.bottom - e.clientY) >= 0 && (rect.bottom - e.clientY) <= tolerance;

            if (isNearRight || isNearBottom) {
                isResizing = true;
                currentCell = cell;
                currentRow = cell.parentElement;
                currentTable = cell.closest('table');
                colIndex = cell.cellIndex;
                startX = e.clientX;
                startY = e.clientY;
                startCellWidth = cell.getBoundingClientRect().width;
                startRowHeight = currentRow.getBoundingClientRect().height;

                if (currentTable) {
                    currentTable.style.tableLayout = 'fixed';
                    currentTable.style.width = 'auto';
                    currentTable.style.maxWidth = '100%';
                }

                if (isNearRight) {
                    resizeMode = 'col';
                    document.body.style.cursor = 'col-resize';
                } else {
                    resizeMode = 'row';
                    document.body.style.cursor = 'row-resize';
                }

                e.preventDefault();
                e.stopPropagation();
            }
        });

        $(document).on('mouseup', function(e) {
            if (isResizing) {
                isResizing = false;
                guideLine.style.display = 'none';
                document.body.style.cursor = '';

                if (currentTable) {
                    const $editor = $(currentTable).closest('.note-editable');
                    if ($editor.length) {
                        $editor.trigger('input').trigger('change');
                    }
                }
                currentCell = null;
                currentRow = null;
                currentTable = null;
            }
        });
    }

    /**
     * Interactive Corner-Drag Image Resizer for Summernote Editor
     * Memungkinkan guru mengatur ukuran gambar (memperbesar / memperkecil)
     * dengan menarik salah satu dari 4 sisi pojok gambar secara proporsional dan halus.
     */
    function initSummernoteImageResizer() {
        let activeImg = null;
        let isDragging = false;
        let dragHandle = null;
        let startX = 0, startY = 0;
        let startWidth = 0, startHeight = 0;
        let aspectRatio = 1;

        let overlay = document.getElementById('sn-img-resizer-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'sn-img-resizer-overlay';
            overlay.style.cssText = [
                'position: fixed',
                'display: none',
                'z-index: 1065',
                'border: 2px dashed #0284c7',
                'box-sizing: border-box',
                'pointer-events: none',
                'background: rgba(2, 132, 199, 0.05)',
                'border-radius: 4px'
            ].join(';');

            overlay.innerHTML = `
                <div class="sn-img-handle sn-handle-nw" data-handle="nw" title="Tarik pojok kiri-atas untuk ubah ukuran"></div>
                <div class="sn-img-handle sn-handle-ne" data-handle="ne" title="Tarik pojok kanan-atas untuk ubah ukuran"></div>
                <div class="sn-img-handle sn-handle-sw" data-handle="sw" title="Tarik pojok kiri-bawah untuk ubah ukuran"></div>
                <div class="sn-img-handle sn-handle-se" data-handle="se" title="Tarik pojok kanan-bawah untuk ubah ukuran"></div>

                <div id="sn-img-toolbar" class="sn-img-toolbar shadow-sm">
                    <span id="sn-img-size-badge" class="sn-img-badge">0 × 0 px</span>
                    <span class="sn-img-sep"></span>
                    <button type="button" class="sn-img-btn" data-preset="0.25" title="Kecil (25%)">25%</button>
                    <button type="button" class="sn-img-btn" data-preset="0.50" title="Sedang (50%)">50%</button>
                    <button type="button" class="sn-img-btn" data-preset="0.75" title="Besar (75%)">75%</button>
                    <button type="button" class="sn-img-btn" data-preset="1.00" title="Penuh (100%)">100%</button>
                    <span class="sn-img-sep"></span>
                    <button type="button" class="sn-img-btn" data-align="left" title="Rata Kiri"><i class="fas fa-align-left"></i></button>
                    <button type="button" class="sn-img-btn" data-align="center" title="Rata Tengah"><i class="fas fa-align-center"></i></button>
                    <button type="button" class="sn-img-btn" data-align="right" title="Rata Kanan"><i class="fas fa-align-right"></i></button>
                    <button type="button" class="sn-img-btn" data-align="inline" title="Sejajar Teks"><i class="fas fa-bars"></i></button>
                    <span class="sn-img-sep"></span>
                    <button type="button" class="sn-img-btn text-danger" data-action="delete" title="Hapus Gambar"><i class="fas fa-trash"></i></button>
                </div>
            `;
            document.body.appendChild(overlay);

            const style = document.createElement('style');
            style.id = 'sn-img-resizer-style';
            style.textContent = `
                .note-control-selection {
                    display: none !important;
                }
                .sn-img-handle {
                    position: absolute;
                    width: 14px;
                    height: 14px;
                    background-color: #ffffff;
                    border: 3px solid #0284c7;
                    border-radius: 4px;
                    box-shadow: 0 1px 5px rgba(0, 0, 0, 0.35);
                    pointer-events: auto;
                    cursor: pointer;
                    transition: transform 0.12s ease, background-color 0.12s ease;
                    z-index: 10;
                }
                .sn-img-handle:hover {
                    transform: scale(1.3);
                    background-color: #0284c7;
                }
                .sn-handle-nw { top: -7px; left: -7px; cursor: nwse-resize; }
                .sn-handle-ne { top: -7px; right: -7px; cursor: nesw-resize; }
                .sn-handle-sw { bottom: -7px; left: -7px; cursor: nesw-resize; }
                .sn-handle-se { bottom: -7px; right: -7px; cursor: nwse-resize; }

                .sn-img-toolbar {
                    position: absolute;
                    left: 50%;
                    transform: translateX(-50%);
                    display: flex;
                    align-items: center;
                    gap: 3px;
                    background: #1e293b;
                    color: #ffffff;
                    padding: 4px 8px;
                    border-radius: 6px;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    font-size: 11px;
                    white-space: nowrap;
                    pointer-events: auto;
                    z-index: 11;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
                }
                .sn-img-toolbar.pos-bottom {
                    bottom: -40px;
                }
                .sn-img-toolbar.pos-top {
                    top: -40px;
                }
                .sn-img-badge {
                    font-weight: 600;
                    color: #38bdf8;
                    padding: 0 4px;
                }
                .sn-img-sep {
                    width: 1px;
                    height: 14px;
                    background: #475569;
                    margin: 0 2px;
                }
                .sn-img-btn {
                    background: transparent;
                    border: none;
                    color: #e2e8f0;
                    font-size: 11px;
                    font-weight: 500;
                    padding: 2px 6px;
                    border-radius: 3px;
                    cursor: pointer;
                    transition: background 0.15s ease, color 0.15s ease;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    line-height: 1.2;
                }
                .sn-img-btn:hover {
                    background: #334155;
                    color: #ffffff;
                }
                .sn-img-btn.text-danger:hover {
                    background: #dc2626;
                    color: #ffffff !important;
                }
            `;
            document.head.appendChild(style);
        }

        function updateOverlayPosition() {
            if (!activeImg || !document.body.contains(activeImg)) {
                hideOverlay();
                return;
            }

            const rect = activeImg.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0 || rect.bottom < 0 || rect.top > window.innerHeight) {
                hideOverlay();
                return;
            }

            overlay.style.display = 'block';
            overlay.style.top = rect.top + 'px';
            overlay.style.left = rect.left + 'px';
            overlay.style.width = rect.width + 'px';
            overlay.style.height = rect.height + 'px';

            const badge = document.getElementById('sn-img-size-badge');
            if (badge) {
                badge.textContent = Math.round(rect.width) + ' × ' + Math.round(rect.height) + ' px';
            }

            const toolbar = document.getElementById('sn-img-toolbar');
            if (toolbar) {
                if (rect.bottom + 45 > window.innerHeight && rect.top > 45) {
                    toolbar.classList.remove('pos-bottom');
                    toolbar.classList.add('pos-top');
                } else {
                    toolbar.classList.remove('pos-top');
                    toolbar.classList.add('pos-bottom');
                }
            }
        }

        function hideOverlay() {
            if (overlay) overlay.style.display = 'none';
            activeImg = null;
            isDragging = false;
        }

        // Klik gambar dalam editor Summernote
        $(document).on('click', '.note-editable img', function(e) {
            e.stopPropagation();
            activeImg = this;
            updateOverlayPosition();
        });

        // Drag handle mousedown
        $(document).on('mousedown', '.sn-img-handle', function(e) {
            if (!activeImg) return;
            isDragging = true;
            dragHandle = this.dataset.handle;
            startX = e.clientX;
            startY = e.clientY;

            const rect = activeImg.getBoundingClientRect();
            startWidth = rect.width;
            startHeight = rect.height;
            aspectRatio = (startHeight > 0) ? (startWidth / startHeight) : 1;

            if (dragHandle === 'nw' || dragHandle === 'se') {
                document.body.style.cursor = 'nwse-resize';
            } else {
                document.body.style.cursor = 'nesw-resize';
            }

            e.preventDefault();
            e.stopPropagation();
        });

        // Mousemove saat drag
        $(document).on('mousemove', function(e) {
            if (!isDragging || !activeImg) return;

            const deltaX = e.clientX - startX;
            let newWidth = startWidth;

            if (dragHandle === 'se' || dragHandle === 'ne') {
                newWidth = startWidth + deltaX;
            } else if (dragHandle === 'sw' || dragHandle === 'nw') {
                newWidth = startWidth - deltaX;
            }

            const $editable = $(activeImg).closest('.note-editable');
            const maxAllowedWidth = $editable.length ? Math.max(250, $editable.width()) : 1400;
            newWidth = Math.max(35, Math.min(maxAllowedWidth, newWidth));

            activeImg.style.width = Math.round(newWidth) + 'px';
            activeImg.style.height = 'auto';
            activeImg.removeAttribute('width');
            activeImg.removeAttribute('height');

            updateOverlayPosition();
            e.preventDefault();
        });

        // Mouseup
        $(document).on('mouseup', function() {
            if (isDragging) {
                isDragging = false;
                document.body.style.cursor = '';

                if (activeImg) {
                    const $editable = $(activeImg).closest('.note-editable');
                    if ($editable.length) {
                        $editable.trigger('input').trigger('change');
                    }
                    updateOverlayPosition();
                }
            }
        });

        // Deselect saat klik luar
        $(document).on('mousedown', function(e) {
            if (isDragging) return;
            if ($(e.target).closest('#sn-img-resizer-overlay').length || $(e.target).is('.note-editable img')) {
                return;
            }
            hideOverlay();
        });

        // Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') hideOverlay();
        });

        // Modal closed
        $('.modal').on('hidden.bs.modal', function() {
            hideOverlay();
        });

        // Window scroll & resize
        window.addEventListener('scroll', function() {
            if (activeImg) updateOverlayPosition();
        }, true);
        window.addEventListener('resize', function() {
            if (activeImg) updateOverlayPosition();
        });

        // Preset Ukuran
        $(document).on('click', '.sn-img-btn[data-preset]', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (!activeImg) return;

            const factor = parseFloat(this.dataset.preset);
            const $editable = $(activeImg).closest('.note-editable');
            const containerWidth = $editable.length ? $editable.width() : 800;
            const newWidth = Math.round(containerWidth * factor);

            activeImg.style.width = newWidth + 'px';
            activeImg.style.height = 'auto';
            activeImg.removeAttribute('width');
            activeImg.removeAttribute('height');

            if ($editable.length) {
                $editable.trigger('input').trigger('change');
            }
            updateOverlayPosition();
        });

        // Alignment
        $(document).on('click', '.sn-img-btn[data-align]', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (!activeImg) return;

            const align = this.dataset.align;
            if (align === 'left') {
                activeImg.style.float = 'left';
                activeImg.style.display = 'inline-block';
                activeImg.style.margin = '0 16px 12px 0';
            } else if (align === 'right') {
                activeImg.style.float = 'right';
                activeImg.style.display = 'inline-block';
                activeImg.style.margin = '0 0 12px 16px';
            } else if (align === 'center') {
                activeImg.style.float = 'none';
                activeImg.style.display = 'block';
                activeImg.style.margin = '14px auto';
            } else if (align === 'inline') {
                activeImg.style.float = 'none';
                activeImg.style.display = 'inline-block';
                activeImg.style.margin = '6px 0';
            }

            const $editable = $(activeImg).closest('.note-editable');
            if ($editable.length) {
                $editable.trigger('input').trigger('change');
            }
            updateOverlayPosition();
        });

        // Delete Image
        $(document).on('click', '.sn-img-btn[data-action="delete"]', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (!activeImg) return;

            const $editable = $(activeImg).closest('.note-editable');
            activeImg.remove();
            hideOverlay();
            if ($editable.length) {
                $editable.trigger('input').trigger('change');
            }
        });
    }
    </script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                let submitBtn = e.submitter;
                if (submitBtn && submitBtn.textContent.toLowerCase().includes('simpan')) {
                    // Abaikan form yang sudah memiliki handler AJAX sendiri (onsubmit)
                    if (form.hasAttribute('onsubmit')) return;
                    
                    e.preventDefault();
                    
                    let hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = submitBtn.name;
                    hiddenInput.value = submitBtn.value || '1';
                    form.appendChild(hiddenInput);

                    Swal.fire({
                        title: 'Menyimpan...',
                        text: 'Data sedang disimpan',
                        icon: 'success',
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 1000,
                        timerProgressBar: true
                    }).then(() => {
                        form.submit();
                    });
                }
            });
        });


    });
    </script>
    <?php if (!empty($_GET['denied'])): ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'warning',
                title: 'Akses Dibatasi',
                text: 'Akun Anda tidak memiliki hak akses/tugas untuk membuka halaman tersebut.',
                confirmButtonColor: '#3085d6'
            });
        }
    });
    </script>
    <?php endif; ?>
</body>
</html>
