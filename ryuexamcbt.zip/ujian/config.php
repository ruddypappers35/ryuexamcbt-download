<?php
/**
 * ==============================================================================
 * KONFIGURASI APLIKASI CBT UJIAN
 * ==============================================================================
 * File ini mengatur koneksi database untuk lingkungan Lokal (Laragon/XAMPP) 
 * maupun Server Hosting (cPanel / DirectAdmin / VPS / Cloud).
 */

// Mode Lingkungan:
// 'auto'    : Otomatis mendeteksi (Lokal pakai $db_local, Hosting pakai $db_hosting)
// 'hosting' : Memaksa selalu menggunakan konfigurasi hosting
// 'local'   : Memaksa selalu menggunakan konfigurasi lokal
$environment_mode = 'auto';

// ==============================================================================
// 1. PENGATURAN DATABASE SERVER HOSTING (cPanel / DirectAdmin / VPS)
//    --> Sesuaikan bagian ini saat website di-online-kan di hosting!
// ==============================================================================
$db_hosting = [
    'host' => 'localhost',              // Di cPanel biasanya tetap 'localhost'
    'port' => '3306',
    'name' => 'nama_database_hosting',  // Contoh cPanel: u123456_cbtujian
    'user' => 'user_database_hosting',  // Contoh cPanel: u123456_admin
    'pass' => 'password_db_hosting',    // Password user database hosting Anda
];

// ==============================================================================
// 2. PENGATURAN DATABASE KOMPUTER LOKAL (Laragon / XAMPP)
//    --> Pengaturan standar di komputer pengembangan Anda
// ==============================================================================
$db_local = [
    'host' => 'localhost',
    'port' => '3306',
    'name' => 'cbt_ujian',
    'user' => 'root',
    'pass' => '',
];

// ==============================================================================
// DETEKSI OTOMATIS LINGKUNGAN (Lokal vs Hosting)
// ==============================================================================
$is_cli = (php_sapi_name() === 'cli');
$server_host = strtolower($_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? ''));

// Bersihkan port dari HTTP_HOST jika ada (misal localhost:8080)
$clean_host = explode(':', $server_host)[0];

$is_localhost = false;
if ($is_cli) {
    // Pada CLI lokal, default ke lokal kecuali ada flag hosting
    $is_localhost = true;
} elseif (
    in_array($clean_host, ['localhost', '127.0.0.1', '::1'], true) ||
    substr($clean_host, -5) === '.test' ||
    substr($clean_host, -6) === '.local' ||
    substr($clean_host, -10) === '.localhost'
) {
    $is_localhost = true;
}

// Tentukan konfigurasi yang aktif
if ($environment_mode === 'hosting') {
    $active_db = $db_hosting;
} elseif ($environment_mode === 'local') {
    $active_db = $db_local;
} else {
    $active_db = $is_localhost ? $db_local : $db_hosting;
}

// Definisikan konstanta koneksi (Mendukung override via Environment Variable)
if (!defined('DB_HOST')) define('DB_HOST', getenv('DB_HOST') ?: $active_db['host']);
if (!defined('DB_PORT')) define('DB_PORT', getenv('DB_PORT') ?: $active_db['port']);
if (!defined('DB_USER')) define('DB_USER', getenv('DB_USER') ?: $active_db['user']);
if (!defined('DB_PASS')) define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : $active_db['pass']);
if (!defined('DB_NAME')) define('DB_NAME', getenv('DB_NAME') ?: $active_db['name']);
if (!defined('IS_LOCALHOST')) define('IS_LOCALHOST', $is_localhost);

/**
 * Mendapatkan koneksi singleton PDO dengan penanganan error ramah hosting
 */
function get_db_connection() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Pada localhost, coba auto-create database jika belum ada (kode 1049)
            if ($e->getCode() == 1049 && IS_LOCALHOST) {
                try {
                    $rootDsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4";
                    $tempPdo = new PDO($rootDsn, DB_USER, DB_PASS, $options);
                    $tempPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                    return $pdo;
                } catch (Throwable $ignored) {
                    // Lanjut ke error handler jika gagal
                }
            }
            
            // Tampilkan halaman diagnostik informatif alih-alih layar blank / Error 500
            render_db_error_page($e);
        }
    }
    return $pdo;
}

/**
 * Menampilkan pesan/halaman diagnostik yang jelas jika koneksi database gagal
 */
function render_db_error_page(PDOException $e) {
    $is_api = (
        (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) ||
        (isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'api.php') !== false) ||
        (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
    );

    if ($is_api) {
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode([
            'status' => 'error',
            'error_code' => 'DB_CONNECTION_ERROR',
            'message' => 'Koneksi database MySQL gagal. Periksa konfigurasi di config.php.',
            'detail' => $e->getMessage()
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!headers_sent()) {
        http_response_code(500);
    }
    
    $is_local_detected = defined('IS_LOCALHOST') && IS_LOCALHOST;
    $db_name = defined('DB_NAME') ? DB_NAME : '-';
    $db_user = defined('DB_USER') ? DB_USER : '-';
    $db_host = defined('DB_HOST') ? DB_HOST : '-';
    $db_port = defined('DB_PORT') ? DB_PORT : '3306';
    $err_msg = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Database Connection Error - CBT Ujian</title>
        <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                background-color: #0f172a;
                color: #e2e8f0;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                padding: 20px;
            }
            .card {
                background: #1e293b;
                border-radius: 16px;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
                max-width: 650px;
                width: 100%;
                border: 1px solid #334155;
                overflow: hidden;
            }
            .card-header {
                background: #dc2626;
                padding: 20px 24px;
                display: flex;
                align-items: center;
                gap: 14px;
            }
            .card-header svg {
                width: 32px;
                height: 32px;
                flex-shrink: 0;
            }
            .card-header h1 {
                font-size: 1.25rem;
                font-weight: 700;
                color: #fff;
            }
            .card-body {
                padding: 24px;
            }
            .status-badge {
                display: inline-block;
                padding: 4px 10px;
                border-radius: 9999px;
                font-size: 0.75rem;
                font-weight: 600;
                margin-bottom: 16px;
                background: <?= $is_local_detected ? '#0284c7' : '#d97706' ?>;
                color: #fff;
            }
            .error-box {
                background: #0f172a;
                border-left: 4px solid #ef4444;
                padding: 12px 16px;
                border-radius: 6px;
                font-family: Consolas, Monaco, "Courier New", monospace;
                font-size: 0.85rem;
                color: #fca5a5;
                margin-bottom: 20px;
                word-break: break-all;
            }
            .param-table {
                width: 100%;
                margin-bottom: 20px;
                border-collapse: collapse;
                font-size: 0.9rem;
            }
            .param-table td {
                padding: 6px 10px;
                border-bottom: 1px solid #334155;
            }
            .param-table td:first-child {
                color: #94a3b8;
                width: 35%;
            }
            .param-table code {
                background: #0f172a;
                padding: 2px 6px;
                border-radius: 4px;
                color: #38bdf8;
            }
            .checklist {
                background: #0f172a;
                border-radius: 8px;
                padding: 16px;
                margin-bottom: 20px;
                border: 1px solid #334155;
            }
            .checklist h3 {
                font-size: 0.95rem;
                color: #38bdf8;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .checklist ol {
                padding-left: 20px;
                font-size: 0.85rem;
                line-height: 1.6;
                color: #cbd5e1;
            }
            .checklist ol li {
                margin-bottom: 6px;
            }
            .btn-refresh {
                display: block;
                width: 100%;
                text-align: center;
                background: #2563eb;
                color: #fff;
                font-weight: 600;
                padding: 12px;
                border-radius: 8px;
                text-decoration: none;
                cursor: pointer;
                border: none;
                font-size: 0.95rem;
                transition: background 0.2s;
            }
            .btn-refresh:hover {
                background: #1d4ed8;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="card-header">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                </svg>
                <div>
                    <h1>Gagal Terhubung ke Database MySQL</h1>
                </div>
            </div>
            <div class="card-body">
                <div class="status-badge">
                    Lingkungan: <?= $is_local_detected ? 'Lokal (Localhost)' : 'Server Hosting / Production' ?>
                </div>

                <div class="error-box">
                    <?= $err_msg ?>
                </div>

                <table class="param-table">
                    <tr>
                        <td>Host / Port</td>
                        <td><code><?= htmlspecialchars($db_host) ?>:<?= htmlspecialchars($db_port) ?></code></td>
                    </tr>
                    <tr>
                        <td>Nama Database</td>
                        <td><code><?= htmlspecialchars($db_name) ?></code></td>
                    </tr>
                    <tr>
                        <td>Username Database</td>
                        <td><code><?= htmlspecialchars($db_user) ?></code></td>
                    </tr>
                </table>

                <div class="checklist">
                    <h3>💡 Cara Mengatasi di Hosting (cPanel):</h3>
                    <ol>
                        <li>Buka cPanel > <strong>MySQL Databases</strong>. Pastikan Database dan User sudah dibuat.</li>
                        <li>Pastikan User sudah dihubungkan ke Database dengan centang <strong>ALL PRIVILEGES</strong>.</li>
                        <li>Buka file <strong>config.php</strong> di hosting, lalu sesuaikan bagian <code>$db_hosting</code> dengan database cPanel Anda.</li>
                        <li>Pastikan data tabel database sudah di-import melalui <strong>phpMyAdmin</strong> di cPanel.</li>
                    </ol>
                </div>

                <button class="btn-refresh" onclick="location.reload();">🔄 Muat Ulang Halaman (Coba Lagi)</button>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

