<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Buku Panduan Lengkap CBT Ujian Sekolah - Instalasi & Operasional</title>
<style>
/* ========================================================
   GLOBAL PRINT & SCREEN STYLES
   ======================================================== */
@page {
    size: A4 portrait;
    margin: 20mm 15mm 20mm 15mm;
}

@page:first {
    margin: 0;
}

* {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #1e293b;
    background: #ffffff;
    font-size: 10pt;
    line-height: 1.55;
    margin: 0;
    padding: 0;
}

/* Page Break Controls */
.page-break {
    page-break-before: always;
    break-before: page;
}

.no-break {
    page-break-inside: avoid;
    break-inside: avoid;
}

/* Screen Only Toolbar */
@media screen {
    body {
        background: #f1f5f9;
        padding-bottom: 60px;
    }
    .page-container {
        max-width: 210mm;
        margin: 24px auto;
        background: #ffffff;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #e2e8f0;
    }
    .page-content-wrapper {
        padding: 40px 48px;
    }
    .screen-toolbar {
        position: sticky;
        top: 0;
        z-index: 1000;
        background: #0f172a;
        color: #ffffff;
        padding: 12px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .screen-toolbar a, .screen-toolbar button {
        background: #2563eb;
        color: #ffffff;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .screen-toolbar a:hover, .screen-toolbar button:hover {
        background: #1d4ed8;
    }
}

@media print {
    body {
        background: #ffffff;
    }
    .screen-toolbar {
        display: none !important;
    }
    .page-container {
        max-width: 100%;
        margin: 0;
        box-shadow: none;
        border: none;
    }
    .page-content-wrapper {
        padding: 0;
    }
}

/* ========================================================
   COVER PAGE DESIGN
   ======================================================== */
.cover-page {
    height: 100vh;
    min-height: 297mm;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 60%, #172554 100%);
    color: #ffffff;
    padding: 60px 50px 45px 50px;
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
}

.cover-decor-1 {
    position: absolute;
    top: -120px;
    right: -120px;
    width: 380px;
    height: 380px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(59, 130, 246, 0.25) 0%, rgba(59, 130, 246, 0) 70%);
}

.cover-decor-2 {
    position: absolute;
    bottom: -80px;
    left: -80px;
    width: 320px;
    height: 320px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(14, 165, 233, 0.2) 0%, rgba(14, 165, 233, 0) 70%);
}

.cover-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255,255,255,0.15);
    padding-bottom: 24px;
    position: relative;
    z-index: 2;
}

.cover-logo-area {
    display: flex;
    align-items: center;
    gap: 16px;
}

.cover-logo-img {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #ffffff;
    padding: 3px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.cover-app-title {
    font-size: 18pt;
    font-weight: 800;
    letter-spacing: -0.5px;
    color: #ffffff;
    margin: 0;
}

.cover-app-subtitle {
    font-size: 9pt;
    color: #93c5fd;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    font-weight: 600;
    margin: 0;
}

.cover-badge {
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.25);
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 8.5pt;
    font-weight: 600;
    color: #e2e8f0;
    letter-spacing: 0.5px;
}

.cover-body {
    margin-top: 40px;
    margin-bottom: 40px;
    position: relative;
    z-index: 2;
}

.cover-category-tag {
    display: inline-block;
    background: #3b82f6;
    color: #ffffff;
    font-size: 9.5pt;
    font-weight: 700;
    padding: 5px 14px;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    margin-bottom: 20px;
}

.cover-main-title {
    font-size: 28pt;
    font-weight: 900;
    line-height: 1.2;
    color: #ffffff;
    margin: 0 0 16px 0;
    letter-spacing: -0.5px;
}

.cover-main-desc {
    font-size: 11pt;
    line-height: 1.6;
    color: #cbd5e1;
    max-width: 620px;
    margin-bottom: 28px;
}

.cover-feature-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    max-width: 580px;
    margin-top: 24px;
}

.cover-feature-item {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 9pt;
    color: #e2e8f0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.cover-feature-bullet {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #38bdf8;
    flex-shrink: 0;
}

.cover-footer {
    border-top: 1px solid rgba(255,255,255,0.15);
    padding-top: 20px;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    font-size: 8.5pt;
    color: #94a3b8;
    position: relative;
    z-index: 2;
}

.cover-meta-group h5 {
    color: #ffffff;
    font-size: 9.5pt;
    margin: 0 0 4px 0;
    font-weight: 700;
}

.cover-meta-group p {
    margin: 0;
}

/* ========================================================
   TYPOGRAPHY & HEADINGS
   ======================================================== */
h1.section-title {
    font-size: 18pt;
    font-weight: 800;
    color: #0f172a;
    border-bottom: 2px solid #2563eb;
    padding-bottom: 8px;
    margin-top: 0;
    margin-bottom: 18px;
    letter-spacing: -0.3px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

h1.section-title .section-tag {
    font-size: 8.5pt;
    font-weight: 700;
    color: #2563eb;
    background: #eff6ff;
    padding: 4px 10px;
    border-radius: 6px;
    border: 1px solid #bfdbfe;
    text-transform: uppercase;
}

h2.chapter-title {
    font-size: 13pt;
    font-weight: 700;
    color: #1e3a8a;
    margin-top: 24px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
    page-break-after: avoid;
}

h2.chapter-title .num-badge {
    background: #2563eb;
    color: #ffffff;
    width: 24px;
    height: 24px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 9pt;
    font-weight: 800;
    flex-shrink: 0;
}

h3.sub-title {
    font-size: 10.5pt;
    font-weight: 700;
    color: #334155;
    margin-top: 16px;
    margin-bottom: 6px;
    page-break-after: avoid;
}

p {
    margin-top: 0;
    margin-bottom: 10px;
    color: #334155;
    text-align: justify;
}

/* ========================================================
   TABLE OF CONTENTS (DAFTAR ISI)
   ======================================================== */
.toc-container {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 22px 26px;
    margin-bottom: 26px;
}

.toc-part-title {
    font-size: 10.5pt;
    font-weight: 800;
    color: #1e3a8a;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 14px;
    margin-bottom: 8px;
    padding-bottom: 4px;
    border-bottom: 1px dashed #cbd5e1;
}

.toc-part-title:first-child {
    margin-top: 0;
}

.toc-item {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    font-size: 9pt;
    margin-bottom: 6px;
    color: #1e293b;
    text-decoration: none;
}

.toc-title {
    font-weight: 600;
}

.toc-leader {
    flex-grow: 1;
    border-bottom: 1px dotted #94a3b8;
    margin: 0 8px;
    position: relative;
    bottom: 3px;
}

.toc-page {
    font-weight: 700;
    color: #2563eb;
    min-width: 24px;
    text-align: right;
}

.toc-sub-item {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    font-size: 8.5pt;
    margin-left: 18px;
    margin-bottom: 4px;
    color: #475569;
}

/* ========================================================
   CALLOUT BOXES & CARDS
   ======================================================== */
.callout {
    border-radius: 8px;
    padding: 12px 16px;
    margin: 14px 0;
    font-size: 9pt;
    line-height: 1.55;
    page-break-inside: avoid;
}

.callout-info {
    background: #eff6ff;
    border-left: 4px solid #2563eb;
    color: #1e40af;
}

.callout-warning {
    background: #fffbeb;
    border-left: 4px solid #f59e0b;
    color: #92400e;
}

.callout-success {
    background: #f0fdf4;
    border-left: 4px solid #16a34a;
    color: #166534;
}

.callout-danger {
    background: #fef2f2;
    border-left: 4px solid #dc2626;
    color: #991b1b;
}

.callout-title {
    font-weight: 700;
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    gap: 6px;
}

/* Step Numbered Cards */
.step-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin: 14px 0;
}

.step-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 12px 16px;
    display: flex;
    gap: 14px;
    align-items: flex-start;
    page-break-inside: avoid;
}

.step-num {
    background: #2563eb;
    color: #ffffff;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 9pt;
    font-weight: 700;
    flex-shrink: 0;
    margin-top: 2px;
}

.step-num.green { background: #16a34a; }
.step-num.purple { background: #7c3aed; }
.step-num.orange { background: #ea580c; }

.step-content {
    flex-grow: 1;
}

.step-content h4 {
    font-size: 9.5pt;
    font-weight: 700;
    color: #0f172a;
    margin: 0 0 4px 0;
}

.step-content p {
    font-size: 8.8pt;
    color: #475569;
    margin: 0;
}

/* ========================================================
   TABLES
   ======================================================== */
table.custom-table {
    width: 100%;
    border-collapse: collapse;
    margin: 14px 0;
    font-size: 8.5pt;
    page-break-inside: avoid;
}

table.custom-table th {
    background: #1e3a8a;
    color: #ffffff;
    font-weight: 700;
    padding: 8px 10px;
    text-align: left;
    border: 1px solid #1e3a8a;
}

table.custom-table td {
    padding: 7px 10px;
    border: 1px solid #e2e8f0;
    vertical-align: top;
}

table.custom-table tr:nth-child(even) td {
    background: #f8fafc;
}

/* Code Snippets */
pre.code-box {
    background: #0f172a;
    color: #e2e8f0;
    padding: 10px 14px;
    border-radius: 6px;
    font-family: Consolas, "Courier New", monospace;
    font-size: 8.2pt;
    line-height: 1.5;
    overflow-x: auto;
    margin: 10px 0;
    border: 1px solid #334155;
    page-break-inside: avoid;
}

code.inline-code {
    background: #f1f5f9;
    color: #0f172a;
    padding: 2px 5px;
    border-radius: 4px;
    font-family: Consolas, monospace;
    font-size: 8.5pt;
    border: 1px solid #cbd5e1;
}

/* Checklists */
ul.checklist {
    list-style: none;
    padding-left: 0;
    margin: 8px 0;
}

ul.checklist li {
    position: relative;
    padding-left: 22px;
    margin-bottom: 6px;
    font-size: 8.8pt;
    color: #334155;
}

ul.checklist li::before {
    content: "✔";
    position: absolute;
    left: 0;
    top: 0;
    color: #16a34a;
    font-weight: 800;
}

/* Badge System */
.badge-tech {
    display: inline-block;
    padding: 2px 7px;
    border-radius: 4px;
    font-size: 7.5pt;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.badge-blue { background: #dbeafe; color: #1e40af; }
.badge-green { background: #dcfce7; color: #166534; }
.badge-yellow { background: #fef3c7; color: #92400e; }
.badge-red { background: #fee2e2; color: #991b1b; }
.badge-purple { background: #f3e8ff; color: #6b21a8; }
</style>
</head>
<body>

<!-- TOOLBAR KHUSUS MODE LAYAR BROWSER -->
<div class="screen-toolbar">
    <div>
        <strong>📖 RyuExam CBT - Dokumentasi & Buku Panduan Resmi</strong>
        <span style="opacity: 0.7; font-size: 11px; margin-left: 10px;">Format Siap Cetak (A4 Clean &amp; Modern)</span>
    </div>
    <div style="display: flex; gap: 8px;">
        <a href="admin.php" style="background: #334155;">⬅ Kembali ke Admin</a>
        <button onclick="window.print()">🖨 Cetak / Simpan PDF</button>
        <a href="Buku_Panduan_CBT_Ujian.pdf" download style="background: #16a34a;">📥 Download PDF Resmi</a>
    </div>
</div>

<div class="page-container">
<div class="page-content-wrapper">

<!-- ========================================================
     HALAMAN 1: COVER ELEGAN
     ======================================================== -->
<div class="cover-page">
    <div class="cover-decor-1"></div>
    <div class="cover-decor-2"></div>
    
    <div class="cover-header">
        <div class="cover-logo-area">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAYAAAB1PADUAAAQAElEQVR4Aex9B4BlRZX2Vze+3K9zzj2pJydmhjhkETFjRFHMa8SMccwZFGUVEyiICgqKCJJhGJicZ3pmOucc3uuX303/V2/Adf8VRUXX3fVyz711K5w6dVKdqno9KPjX9S8OPIsc+JdCPYvM/Bcq4F8K9S8teFY58C+FelbZ+S9k/1Kof+nAs8qBfynUs8rOfyH7l0L9Swf+OAf+ytx/KdTTMK6pabNvM6G9vb1k09ozl69ZtmHF4sXLl8tv/Ot6Wg78n1SoV7/xjXWvetVrLnzVa17zrpe+6qU/OvP8M/bVNdd2cc3rklOugOIO9W9Lb+t/PN3Z0TW9e+/2Q4eO7DvYc/z4oc6OzmkVmvsUaEy31LYcO3XdqQ9s3rj5q2duPPPV55527hkXnHpBBf4PXv/rFerNb36z/rWvfW31+6+66ufnX/Cc3uUrV4/u2rqt/5ZbfvK7W2666Ru/+OkvXrvzscdWD/ePtMGDkP95cIVmqsKGRXAkwOF/LsFjmQCEAiFUKARVDI4MLt6zZ8+523Y8/r59+w/c/MjjW7d29J3oWbtqQ++Zp5+9Z9OmM96zdu3aAP4PXMr/xjFu2bIl8u4r3/e5y1/3+u2/+vVv0h/80FX7vvrFL7zsgfvvbT7ecaS6u+uEqlIrNA4+4AFqFggJwGDaVJnJdM7KQfGTPQqdFsETLhwJ4Jtgw4EFGzn5VDzkNQ+2cJDMp+HoKoYnx0J7D+5t3vr4Y2t37t1zzd69+5O6rk9t2rDhB8+76KJXb968Ocqe/tfd5Nj/jjG9//3vD37sqk+85fTTNvfffPMtE//+rW995Ec3/mjj7MyU5tp5CCqLTkXxLAu650H1XBgQ/A+Ft+0CkhmOffKtUtvcHDNV8odpSGCaLgmgYoFKJUHVWIfKBccq5OsBVnKyAPKAT4MeMOFSOdlGOI5Ttmvnzit+d889Nw92Hh/dtHbtkde86jWvuPTSS9mITf4X3JKH/6OH8ZKXvGLdi1740h9869rrZj77hc9+Z/euHY293T0+x7KhUuieLd+AyVGqrkflAXSm5bfCOU5VTS8J4dmAZ/h8ieJo+GBTY81vFja3fKe1ofo7bbXV1yysq726rbH26tbGmq811dVcV0eoqa66vbysaG9EQ8LnwvN58KhbnpvKMcUOpJ7lsrAyqcKHYZrwXBcqvxTCyOi4/+C+/UtvvuWmn9522232ZZdddvPb3va2jSz6H33Lsf2PHACt+vw1a9YcvP3223b/9u67rrBdR+oI8laeauLQ27jQhICpAAHObxoVRoIOjFcHggfbyivvP2XRoo+vWbjwgovWrg7ZdEzz2WxkKpZY1ds/+vxjJ3rf1tM/9rbu/rH3dvaOvK+7e+R9PT2j7+8bGH3H0NDoO0bGxl8yOR1fN5dFhP5IObOyMrypqerstXVVH64LaHfVF4d3h1VlIKRrnkoVs7I5+A2TKn6S3Qp9o00vKb84FeLmm29+9be//e3tq1at6nnHO97xBpn/7MA/Fovyj+3ub+/tRS960ZtWr159iFZ93759+1Z4nL7y+TxseiIUxOXCp2sUl0el8qRT8Hyqur25puqqTe3tLztrw4ZV3enUqv1TExc8dOLEZx85dviB3+zdm/5Dym5tbzcIVbe3tlbc2djYXIDKyuY7JfBb5l+/dq1+KwoOp9D0vomJ1GP944/uGh7/8nDKvmRoNnFKe2PLirbyqnOaysvfYwBbhUcXydoOQfX55EQJheG9xWmYWQgEAjhw4EDLt771re+3trb2v/rVr/6SzP+fBP9jFOolL3zJy+rq6k7c8etffXf/gf3LqTGQoKhyEgEU+iUNgE/AUyx7qtTvv3NZY/0VS9euNSfz9qmHR8e/dF9Hxy/u3LlzgtWwhUrz3dNPX3jX2Wdfcf+Zp317x7ln7t996imJHQvbZjaZemZ9JjPYNjE5sWh6urd9ZqZ38Xyqd8F8sndJPNl7Ss4afsHcbGbtgtbx3ctXzOzYdHrHg+vX//y369e/++alq9ZvaWryyT52dnfPHxgefqRnauraHHBWo2X5FhYXv6bMMG7LZzNjCmmlkhW8qBxFJp2GqgrZFIO9fY23/uSWD9ZVVI1d8ZrXvaeQ+T/g8U+vUM973vPWnLJq3RO/+tUvfz4yPLywwFP1KbIVnLR5MC7yvBDQvaSu5g1rWxafO57JvGB3/9CNe/fuZbQM/IiB0OPLFl12aMXSa0Y3rd9/7thIbs2xoyeWHj/6g9q9O98a3fv4qqJDu0INIwMlxrFjijk0rDcbKqoo9WA+i5BrI+oBgWQGyvi4bowNqYGBnrLagYGSkoP7lrT1db6suePQ10/p7d31osmZTPfSBd0HVy380cOLmt56Q135Akl3B5DvmJu7eSKff9mihqKldeUVlxcJ7DMYg2msYPDhcEDsEgqnQ4NGkpqcqrrlphuvWb3ulIMvu+K157HaP/Wt/LNSt3nz5uiKNet/es9dd+/dd2DfJkkn5QlwioPjQhqywrTPNKYqIqE7Vzc2Lo0BC/YNjd6wtff4YVn/++s2rb7vzNO/vm3lkvnFsdRwzfjYTaGjR99jHNi3alk6i7Z4AhXjk1jkAc2Wg3rORSVZCxWKgmrDgDMbQ8BzYHA6DTOvmHkBBtblpg8RCruUnZRl02h2HJTNxrHQdtBqZ9HuOijp72st6ux8bcPY+LfXWk7n7lXLvK1nbLrxOy3167YAxuHB+Fzf5ORNMx7WtpeURCt8+o80G10y3jLk4Ihbo5nk2Y8mTOzfs2fFrT/+yf3LN5zy4POvuCLM4n/K+59SoU499dSLdx0+cOTQ4b2vkNOa4CzgcFKTaUVVyWbApFU3lxR/ra21Yvnk/PwLdgwMHJMcvqm5ZtH21uaPDi9f07ehs3tf/d5D724dnghXzc8jms2i1jRRRMXx5S0UaToMRSVmDYWVPvNdAOlMDul0DiHDj3l6JE0BfFQSJzGPSNDHeC2PZM6B7lMpbgcqXYpJIhUP3JWy6DVz0LI2KlwdJRkXNbEsaruGUL794OWbx+O737R4Yfr+msiWGxuq17I77JydnR/KWq9bEG06pcwX+rhte57NgjijrJSiISm9ldChUWGP7Nl1zn0/+9HAC5/znNexyj/dTVb9U9EkFi5ofWDvzh13peditSAjJdBqocGFRoHpijveWFVxdRpQemZn33/kSN+EHMEtq5acv23F4kMrcvbxqqmJz4a7TjQ1zs+imUv3UCyGqAs4uTzmclQWTcDRANtzYDvUImqqxkA+QfxOXc34QCRwwVhZ9JxOn75ptsRYOmKgpiuXW+tyTnLpoVzua4XDOuZTDixuYOW5aTVNr9VLQmaKIhjm7uhcwI+04YPhaSiFikr220r1W+QqCHf1qwtm5j/Znpzb8+DKU8ZuXHPmq6+sq/MfiPXHJrLJz9kcW43P97GwqXeDNIKKBS9HLOyA5Fppp/ixRx64oaWqYscll1zyT7UD/0+jUO3rVy7VivzHO7t6zlU4vegULqcAKhLokVxUw/QqVfX2FW2Nq7vHJt9H1hbuPSsXv3NgSWPHit7B++oGR5eXxhLQklQ3LwXNdGAENQhDpUg8ZP0GAqvbekdK9BfPRrSPTVExBJUkns4gQw8zF/SjIxqcaI+n7m+bnn64fX5+x4LZfEd7GmPtwL4pKkqWXiKgGXBzFujskBfADJWpo6T4pydamy/YEw4u3hsJb9gZDX3sgKlgjuV524KtOtzkVJHMJhEyAqg0A2jK2Wg4tqdq89jxm98V9Q8/0FL93uvlcDmyoWz2c8vKzQ1VnvOjCH0eAI4BMOmxVJan6AFHxic3PHD/3d3nXnDu85j1T3Er/wxUrFix7KMd+w8esVOZhaoquOlsQ04fIaqSCXilwnhiUWnJ0hHHecnujv5xSfPPuKLavWihF+04fm3k2MCSBTz2iMgpybFQ5DPgBU1MesCElcU8YyDD74PDsuH43E/bhzN3zDiB6/TWJichAF/AB4WCclQNk4rXKPFL+MHFZ371zjNWX7t30/JrRtYv+Y3DHfJcLgOoUqQKEnnWqq7d3plKNp8zPPqqi4913f+CvtETLxue2fWyoanPnTcVF1MB/SNjioU518J8jsoUjSCdScBLWQhmbLTxWKdiYhKRnq6S2omxry2I+vOPrF7x+a+sqAxuH56f5WBft6yiaEHIh7s5HO6D2AjqJv01IEiG56H6wfse/M2adat/jH+C679doRYtbP5+54mOz4LckvxwHAGFfikIk2/LW1hS+d5+L3/aAzNjhRjptuXtl+5atPjQKcNTXy87MYAK10C0KIw0g2zTD7a0MZ3OY9rU3zITDrXHI1UfShth5FJp+CwPQcd7LXitjsViw+GK4zG6mTwjFi+VQdgTICKHxYVb7D32vtrDQ+9sOD7ynvyeY88roVcK6TpyjL+SWReioqJnv+O+8uxstl822NVU8/KepqpPHK0pueKpParV8fgXTpRqH0yFBRSfgmRyFhqnXFMG+CZnK/ZmaoBfMVHimmhzNZR29191STo68IvqujeB1xOT8Z7ZLC5uqom+W6OBZawcYzUFOUeHzVgupBo4tGf/a049ZcO9rK4Q/tvu/7bO29vbQ5zZevt6+t6Qy7tkE3lA5vpUnYpkeya8u9sbGkr3zE58nSX48cY1Sx5a3b5/0dTcrSU9fcuLx0bQ5DMhFS8RT0L3C1hEI003FDQwarm/WTuTPLZ4fPTLfSUlz5kLhmDrChLjs/W7mpqqJM5jycRPsxronRRavQHBFZ6bzsnFmyxGaUn1RTaUValUvt3z0OQQP3USOS7t8/SCY7n0B88dGxu4ta7Ov7+++kTRzPTPwpOTn4rOzv5gZVnIfrQs+CqJyBjPXePzBWdTKRcGz/cU3UWOns5ifBSHQEY3EEvlOKkLRDml1vNAMdTbU7rCyn132+qVY19f2rJe4ukZjX1zfXl5JGoYP1eheArNh9TDoudVyLXdu/ZdoDJ037BhQwT/TZfy39Hv5s2by44fP94hhGiWukSeFhRKkz7cyXk14aIvjSF/8bbBwTlJ3/3t7e9oO97V0dQzuKouE0eJmoc/CKTyCeqPBs2IIMe2WQE49DI2V0Ruadmlsq2E84f67+2trDgvES6G6RiIquI1Mn82kL05baURMHQ4FCJcAdUy8NT1go5Dv9sQmzzYlE8eawEGZn1+JBwPOSp92tQxHU7eLeuGFPsDofj8wvIUpyN6rhJ62eK5JBbOZ34yGQm9Y31ZxTYqVUlE80FIrfRcQHURd3NIl1buTpbXDM6rgMXpD/kMQq6DMs75NdkEqroOV22antp1R3Ptp2Vfj0xNJcfz+Ve0lFR8SodUb8AmA1XiBpXKhSoO7jvWv2HDGQz7ZIt/LPzDFWr9+vWnPvroo1NUpno5VIOrK1o/WQLortO7trHx3O5E/CpZdt2yBUt2b1w9FR0f+mZTNo2SRBK+HBVApVDpTeRRBYQLx3GoU3gXYwAAEABJREFUkCqKokUQnJKy2QwqAsEXSRxPwQWdvQ8ma4uiRl1jxiku+5TMf8f+voGKmpqxmVgKKmO3gCJQanuyqABfPXPzx24748wbj1104Y+6li75lYyNA6EIXE2BHQxMn92PLHg5eetTOrcHiv3FSFMp0wqVMuQHOK0peeebmen4Bp/wU4c05KlwuqkVAuwsz/a2lZScXtXf3zhcWnr+fFXFY6isxAzP/RQqVYDnknV0uw30wO2p3Mfvqqj0vrF4cWGroXN29FNrmurW+BV3WNGALPe/LGKV1Gctq3j/vgNHN60//Tkk7x96K//I3jZu3Hjawf0HHhcctUslcGntVt6Gym/C1LrVbRsfHxh4WNJ076L2l77IiHT4O4+XVXkZ+H0OFIYcXKWDK3dEwgHkGTeBwW6AAlLzHlKxLCwhUBTQoXYd27xvUVmNxPX9M0/97K2XQl23tzd+KBppGG1sSGw5//xCme35bjD8Gjx6hAgFUpuMy3BOyHaRicHP1Bzrvdx8eOdrQ529L6hjx4qVgdBU5Dzn97zLcyxmsAjT9FBu1YKrB/3VxQNVtS/c5VOv7o0GMV0URFYzkCeNQa4InaxLZ6hg3uf/1Ms6OvKyr/MmZx5o7R0+c+d86oVOcemI7QvAZRcqY8RiBBCdmcdKxobnzyX3bF269IOyzRP9/QfWLi5fonvusPy9FoRN2hQWuchbNnbs3n3PGadufgUz/mG37P0f0tm6detO27t7zzbLtuiNPBiqBp2biiYDqbpo0a9soOKx/d1TW7ZsUfaedvovW2bit3mHjqLBAd2/AjsF8PQDflNw7cdvbjzCdaCIPISXhZ8KYVC5bIJgTNHCWKXGQcGa9VTqQd/j5faule1LL9m7d/rcX/6ycsv994/Kgc/Y3j0x4slwGspmsigV/8GS4qIAQgygDZb5uPWQ44pRMJ1JxGHk3ZItQKFyuLLqhpFcCjGdGEPhe1fH+mPrT3T/+gXTqfedMj4tUkFf0DO1GZXe1LVs5FnNKinpyTS2fo5JfHPT2hd+/8xNq2X6/ETi1yfmZpoS3MrwSEvecRktuSg3DZSkU6ibm0a0+/iXdmxY+NiPTllc+kjHVDLtoL4x6vseWQPPzhGNC42GpTC1/YltPz3nrLNeyeQ/5JZ9/t072khlOnrw0DaXcYrsUJEqRUa5dFGhgPj+QCxemJ7u2Lw5+qpf/WZ7eUfni8u5tI7SbXnxDKc5HRFFRxAGbO4+anw79G4mg2/ptawcZx6uvAKKi2hQh+4JZOZsrqjct4PX5XsPPhzKpFCWmNv+cHvTKmb9/p7S8n3JUABxDfCC9BqsdxTUWdbo91kt/UWoHS4L108WRctninxTGa4Iy+g9aizgVeXVp7MaRuzsp8OrmjATTMHwZ395on3pr25rWfQeWSZh0HFC8cxMqT+oshMbcbg4jPzX1+3da/2uva6kubfrjiUHDu47FgrcPhwOl/LA8sood+mhCDg8EsjpOWTcNHTDhU5jWRYKo+5Y7+kb59O7bz9lJasDA3PZN9f6lB8YgvGZIHHsQ6Gv1aBg66OP3nL++ef8Q5RKkQP+e8IFp55asWff/m15xgMC8j9wmB6H63pNZWWfmU46haXx3Wec0d4+F+sL9fed4pubpMrkkXXzcIuj6KdXm/aHMSlM2Iqfu9uAykA6S5xWzgZDkQJw4YQMPZcQAoKezcuKC7eAHOUAl1TXbgvEZsPaUP/+e1a0vYFZhfuSzuGRvK4/wTi68K2phVfh8YGtJ/pecGJodOPIyPCi0dFpX8BMqJoHj/Gclk6jAt4XH25q8r3+eH//ou2HBeqrPj2rWONKKLCpuLw8XUDCR5VpftmgMsh9qAQVd5px3ubx+etYhOd0DM+W+M2LltbWzZQI9UV6Njcd0fUvFzwNB+FpVBDdQ4LTJKgsMrZKz8RQ7agonphtLu0ZOvHIWaedL3H1pt03tpRH3+c3Nc/z8uSzCzkcKeQHH3zolk3nbDpV1vt7guzr74b/jDPOKH90566jqhAcmAKNUxxOXl5jTcNXuqenPyk/Hzhl9aZlU9NHwz09USU1CyOkYoZeZ5bnZseLjC2djdUtJ5oqnzfT1ngwU1yCvKYjyRWSx2nNEQFkLR8ynEcUxsEqg3yJU/Ch5R0sblu7iklkkvM/VnlGt8AG6vp6v7999cr3ynwJlZHKB4OuCpWBdYB7RUsXNH9zomXBl/obF17XX1p13UR19U8S9aU/wWisRR4UB3w6bLnLHpvbtCKV/4XEIWHj4eFPth7sXLBg1+7K83Zu+67M2xcqfVvZ4NDlJfRO2TAwEy7CTFH1a0mfJ8slnNo/9bvosc6yAxoumfeZcDUNmq7Cc22wG6iagsqqwKAr3HnD74dhGJhhsG7nXDQnHYQOdN334KZNBS9/fDJ2dW1p0Rd8Ot07zdZBnu5WIy5g+yPbty1ZtWqB7PPvBcrfCzHxKtsee+yE7bpltmNzaC4NzJHuwmugZ+oZHfwQ6+C+lcsuKO3pf0Lt6UExN+zKGLdMcy8m1dL0xLFAceOm/slPXXhioO+cA8d+u+LIkVVzrtNtqySbll74UR13Y3RuEHoKmca4LJ2XfXnwUTAG44m6XPJi2Q/m4/cxnkalJlBFxSnq6/3axOrVR3pbWied2djHDQqI+gliwWxP35t9fSMfLBma+LeyWPLf/JNzr3Kn4q8qUQX8QuMYBAwqrp/mH5iPXdytqN6htpYrH2yrb31gWXPl7a2VFfc2NKzdW1N/e3Uu+e+1rGel8ohzKp6tqNyzeWTwJknTTzdsvOnuVSt237u4teA58v7wQwr1yKMBCrrKtAXkDGBWM3cdddJLxyqijYOG2jXCeFEEAyALCj+vqUomYHR23v7AmadcLvF2j8x8tCxsvJ96KLkDi9zXDQNC1cSxQwdOsI5C+LvcfzfEixYt+I1qqMUOB+PRHHWS78HzomH1e71Peqb7Vm64oKK3596GTAzFhlIY+Hwig3RJxY8Wd/af9vzR0cEnNnHTcEXN++/ftHY5UUAP+d+Qcy2YqgbdBq3Pgpc/ObvYjKtUns25ikDeyyGk5LHMnTnLA7SwlrWq20rTs2kPBgVczpgr13FkaWBquDySi0F1vcLqUWMgLP/YJchpxudlEVQsBvyA6QUA20dPa8LhUlMz6UmER+WyUEnaS/r6rl48Ode9MS32np5R97fNxPZUz8++SKMnBadJhkGw3CCOGu5X5DgeaKhoWd174rIlQ73r2vp7Hp+Ihr92Wjp+dySREKbiIuM6sIIm5v2BsT6/eemyKSSb+2Oxw/UlG9ILGnfEnXn4RAa2O4+omsdCycOjB2984PQV75L4B2ZTVxeXRK6xGNKTW7AslQE7SzyIRYtbH1u7dq0UCTOe3Vt5dtGdxMYd7m+MjYw/17Y8gALyGDvJjhqLAjdMJpy3gNcv21ZsjPT331vH5a0v48HlCsujZzLoaSxHfIdVCrfj+J+Yjs99JaOApxlgkJo5JhSH1ulA8UDMeT6YFoLCVakYCsCNLRo3PMuBmJw+F5XBESWFkYn+mYA/YEAXOgL0SOVcYYao8LlsDoyjMEXvw3kFYzzb69cdjAYFegwP4xEeGts5jIfCGOaG5jC93xEGbANc8U0zSM5ZFqqCQRRls8j09ta6o6M1DaQnmEmDjoQ9gHTRM5ZUHHrdwe7COHyhiF941l5NbmRyCNFk8r3+WOosrguQY2yYpG+Z84UwUFx+2hm9c4PgdcPGjU3POzw4t/Rw9ybNF5xwuA2h6yr89LqcBlA1n4P/WNc37j1zbcFTjU3H3lcbjPzIZFuPiwlISgTQ1dNzqpXN3MbsZ/0m959dnCvb2i7oHRx8VyKZAYQcCg3B0xAWovtEPP0G8PrN2uWLT4G1tZVTnMqzq0BxOXQlCNVRoHNPR5uZ2P7LJUuqwWvO0y/r9xXhaCZzCT+R99TlOQbe6XmPKyqyiNbvqA4ELVpQgXQyWXNUqJoJlYKXPmR2IlUR9gxEFR2KJeBYHny6j4ITSDs6rGAU8UgZ7IXLEF+2Cr1tLb39q9se29FU/P0djeWfu7/E/4GuFc3v31Hl/+yuysh3u9oaHx5sX7jX27ghoy9oR8ofwaSmYEZx4NC9hcN+7mg4MDT2p2qQe6UKvVkoZy3aWtd8ihzH6R3dRxdNJ9d1lpS+2Gmo7Uk6GhQan8apKU3Bp0w/hnzRF8vpXtZ/cNmynStSmZ5bFi4sk9+5rPlZOlWkedRgk782x1Wq+tGUBur6Z2787fpNz5H1+lNTrw8iczioWVBMF3SxcHXg0PGOF2w6a9MrZZ1nE5RnE1lbW1tkaHD0h7ri4wpDPYmaHsevip71C6oLv7r89WmLwq3z8wecgU5dS8fIRAczs1PQVR0B1YTL6aSeAlnopO8Er+fv7jj6phPj4qp9Hd38RMATP5ZbA0VhQMZEDjMZrEJQCDo9U2FRRMUUrhyaBlUxUVJchlTWQ1b3Y1zTMES3cYKBdWJBy1B8wYLrDvnNVz6czq74wZED+qpde8T5+zpaz9vWceYrjoy96bKOkY9d0TX61ZfvP/61y04MfPwlXYNvOf9AxznPO3h83eJHHg/ccazDeDSfXX5fcv6lQ7XVX51pbDx+SAAddg6TVNrRhA1V16XTRHZq3CyZntx5oL39se+0VK8j6Th3YPKOsbHpt4PeUVEDmOLqYpZecDAUeN25wz13yDoSEl6+YnJ+Tsn4w4vltxEwUzqNRoYTLlwYgQiQzSOSd1A0N4/y4fF7Hjv9wpWy7ms3bdrgd3DIywPCAGARKJ59e/d+/9RTT13Gr2ftllx/1pBl4ol7U/l0bZKrE8gIl+dVcPPeytamV/2mc3T6Zh5atse9B8pm58zSiAERAFcsNkrCTDNesZ0MdL+C9FwGRePD6w4trLv2KeJuvfRSdW/7kn32WKwWWRWwNSofXzZrSMMTCnR6A53TmEpvhXwOTob46JWG5mZgFUUxQI+VWLMSh9rqvvJASXFF/bGOhgUHD77jotGJn70+NXd4C9HhyWstENhYFlhzWlg746zi4jNOC1cTak4/Naiv2gz4nqyGt1A8r83nj7wuj1+e3jP6gaXH+5bcGS4p21dbe+VIY9NRtaKVh7cBxkRAiPyoQwqhzo7Tz43N7+6tqLi5KxRa2uqLvsVPT52kMWWDQcSrK79x9sjIj57qQ75feLSz+VhNqPQNB/duk9+K4b7dcXIwTA+eyCOXmodJRVQZ+ynZOZTNTKI+PvHY3eec2nrN9u2ZM1YsvtTnUq/TbG3rQF5BLpkP8Ez1duY8a/ezplALWhe8ZWJqYqNhBsHQBuD+EGzHayoNX7m9s3OXpHi5kvml19d3io9nbTnuBOdoyWNJF3NwkKJCKX7AUwSK/WR+0oExPv7O3yxperls+7LbbnN0RZ3R6GFAxcnRyjR6GTpAQAEc4cGmIjkET1DhuDHohMIYNRWMF0fQW1709R2avWL51tGNEEQAABAASURBVCfEK/Z1fPBd3d1TEu/mpqbomubKS5ZWl13ZUlZ2d0BoUwbgdkNPdk2n9/Qk7EePzs09eiIx9Wh3YmbrsZS1bx+Q9sNwfUogtrC+9r7lTVVfWlgRee2qupN/jPCFkZGZN/T3f/3Uo4eW3Tczu/KIZn5qoqgYI7qCJJlTwfGVzqZQOT376lrLPSLiMy+iD+M4FDh64EennRh+j6TtcxesO/99F234/SHve7d3zMr82xbXvFN1rLWGoSDL/SlNU6HoKs/zLDjkX8Q0UaVYUPqPhWvjM/u3EPMdB493rm1t/oCPZ0yqpyCkhaFCw9xsbMFFF130VYn32QDl2UDS2tpa0dXT9R2byBIMVlW64LBnYaFp/rB/avYbzMa+pa2vDR7qOK/C0JBn8G1lVQSiTbcZLQsfGNFpwWEVca7SBDWEjgp+VaAsL9A0PPmzne0Lz5A4Vhw5cr5XVjQes5JwaMl5qVxkoJzdcooH5iJDgWVUFUmfH5NUpAPlgS/dXR03N3Z3X/mWibnDEs/amprFS5parikuih7YPzExfLRv4s6esbmrR6ZnL8p7bpkifCILQ6S4STAPiCQhp9gihpzIM+0KU1jQRd4VRZ2jI+cfHh//YOfU/I2Hh6d2VJfVdDYGK752bllLYQf7Tfm5Q2clJ7dsjc8ZB+pqPpNcUIWYT4FiAKprI5dLc7q2aSN5aIqLA7NTbwCvHTXh01v7xu772j07O/iJRxYtvXuipeXWzqrSfSvHZq/1ZuaQtlz4OU6b8VeGWzMpxp/prBSpBg15ROnBIgPd4ZectvLrEse2nr6vNQeKbwiCa29ucKlUKZW9/+6ee95HpVot6/ytoPytCGR7x879VH0KEy0FVCgdrteZTb1Rlv9wSfWawPDwj8rSNhROQ6ASVDS3Hg2N9L+yrqfz/JHauouHqip2jRVr6EnlIDg9Kb4I9DxQzTYlk/Ff3L1iRZ3ENZVInVXUWJ+bTsZhcZVFJ0g/Dnj0WnmfDxPhIDoDPuwz1Gv2m075i7tGP7ylg9xl46aq8OUNRZH9Jyamjx3rH3pPPGutjGfzwTw9GnuFNAiPtNteHh4ZDeiFtyuADefW0nsAtgpk2a+QQpFoNRY6RG5AOAIlY9NzC0ZTqffun+49vswf2b+mtvx17e0w3gJYzz828Inbp8crjoUjW3oMEzHGioLeypM4nTwsO40zg8XtR4GSmvnUY6uDkW48eRWPz1wU6O29tGk2sbqGh8QhFzB9QUxnLMSpVCOR4A8GDWOpXhQdtXJUTs5qOuv44w6crq533rnh1BdIVMfSM2/wQWXoZVGdPKgMFWT+4YOHbpHvvxWUvxXBwrrGi8YHhs8RLlBQKtsCGetV11dc9BTu5a6+NyI8UM7QyHyHwfOIm3UFwC/gosPH7l7TMbahY8GSdRO11XdPcYUzkfXgcQ4Mc9MyEotVrJyZ+qkHqBumpzszofDNNGkojoWAqRZiKYublXEtgKGWup0PVRYtvGhi4r2vYty2uanJtyAS+UxYV+eGxxM3TsfnV7kUnsGu3VwKRAKPq0RPseFoLiRRKj2FysjVQ5IK5UEhl7Z85vl4CSdf7gZwWJLsLGQdlV6UTSF1S7AeBPHwIw2Ivsz8qgNjUz/s6cDIKeHKqy9Cm/mRcUxd2Bv71Nay6uYTFTW3zwVCsNhOhE0IDQjm0ofaSkv7hBDgYeS3wesXje2ri7iv5tMNuK4LUzNQpAcRm08jEQzjWCDw9vZY6o1r8vmOmXzigzpNg4tdcOtJsgllVJ9o3/Fffb+9vYToEGkofYELm1LI89MGu8fY6Mjil7/k0s8y42+6Ja6/CYHnOdf8HoEL6CpQXxr+9dGhSflzVGxfs+ojvsEpmFkHgnO3T9Pg03TEZiaW39NU+zr8wfWybYf3njkwdvGQP7hmqqLsxgFq4Gg+D11TEZyeOB0L638w3b7wpuG+3jdEQyakoONUvDnOH6OhCHqKAh88e9/RjR881tsl0VZEI6/ZOzieHpnPfSxtiahD1kkWOixU4MLgWxCgkWgKk8WQwNiY6pSjj+KAWP6mNy1GY0Meb7jiXFA2rOKCyl0Yq0ZvpfEjxGmMSda2oBmC2IEcvzgdi5yCsuOJuSufwEBmcW3t5czGlf39/Wf19LzkeDj83i7GQlNUz6QNqLYNkUxHTFWDE4//RtZtsBLnIhOj4rtQVB0zmRzGBTBfVoIen7nhnKHRf5f1bqoq21wc9F8LToUurVoRCgL02m4shepUCudWlnxL1useHP1NWMFNHDW9uwdVUQuwc+eOD3/oQx8qknX+WlD+2oay3YplK941MDK6CODgyWaZx91rrzGgXCHTPz1z06lq/+TnWowSRBGCnXUB1YTFaa0JKhYnEzc8zuMKPHndePaZb5bJswa6968d6X39kcqi1rnGuh9NcOQ6z/fmh4cu9wY6L2ujL7eTKWRprdO2AWPFKdn7/Gi6qG/4K7L90tLS9SFVm5mOZ3+cJmfzFK/UF5VqwMUhcvKDFU0JjD9UGXdY/HAAqRSBiJ/+C3AUgLqKS56/nh+zWLG0Bi9/ZRVUH+sJcM0BjkIlKMjSQxKDzECeXlrhR4ig2YCmCczThccBcXxk7EYqsntKfX1h2+Ci/rFrHvL7aqzmhTl/cSUVWYFC7+RQaUo18a2hujp/hWevDvo85OkKXQrfDpeir7Skd3dIb75kfLyw4NlWUfWBc1PiYWVyriSgGVDp9ozCYF2U+UMIMXRI7D74yoc3rnk1eK1taXuzyWGoTLuuA4/+anR0VB0fHbuLWX/1rfy1LTdv3qz19PV9FppJ5iswFI1qBdREA1u2DcbnJN6aueQdpVztWbSOOM0+EYygi9NNjLvV2VQaoUQaC+D+3AOdAQDNdtfdd+bpc79Zv+ZN/MSru7p61/R0vq6kNPLpDGMFjUKPUEAKY4QcuTEdCSO9sP3Rm3qOV7x/LDYg2zT6zav7Z2Z3pRyUUH1JG6hOoNAFFLAn3uD1VJnOkoCiM4f9y5cCpFMZqBrAIeHss4BVS4OoLlYRUFK4/LJNEkuh3JD12YPCHqRgRAELHxQOyUSGSYNews6zU+JFkJrIb081xKGhod2rGxt+wSr46HR67Ncz08UDxWW3zxSVYIrEeaRWSWQvqDK0fY1+7VInC6SIo980MFVe9pPTBgZaX98/3i/b/2ZRyw/qEukvRxJTiNKDCVWFYQZgcV9KobfKzSdRpvtQynNO7Vj3zT9esSJ4T3d3rjoUeqfJeEol+z1akpxO77jjjtOvvfrqwiIIf8VFEv+KVmwSi8U+l0qlwnnGMRYZ6nHFUh2KdHTH0p9mMR6n96roG6koZlwSFxlMFJkYqyu9tHdhzfviy1oPqc3Ndt4xMN09ufbYomUFl33ZY9veXDxw7MSy/mPf7WqoiXfVlL99qiywtsJJf9BOg0LUoNgqMraByVA59vuj16/u2Lf5Q9PTiQ0lVe3NgXDXbNa+0tI0PPULRmopXNVCjrYvSJhJL2RQ2jRg8DiHuTnk3DRk/CJ3tKsrgdM2ARddCLz2FcAXP30GyiKjsGYGoGRGsaLdxpup7q94GbB2NdDSBHD7B5QJ5KVqZClvm0aT46Ehjw5ZpNHYdGpEFgEjAOG4siq6BwZfUl1kHF/XXLPovcPDmbW9R19ysLrs6pHSUuREEIJeJd7bvzgzNKT7SXOcuA/WVL1hde/xyySCB4p8LT0NzTuXDM5cEbDn4Y+YyGtZZJ0MkqkEAqEQVCpwQNchtxYiioZqoaI2k7lKtj+aTF5nw3ncgwe/6efTQyKZwL4DB78sy/8a4ND/8mbyYHFsbOzdCl25YLwAxYEOFSGhXS2xXdfeHmp23U9Xu3kYTpLWIhAIB65feaLvFxcdHLh67c5jK/d5ojXR1PSywJLVh3rS+bd+YeUahrzAjGNdluEeVWRmNlI8OfUtJZbek5ia94U0FYoSwjzd+Szjpf2WcuUr+ofeKvvj/tG6E7NTRyfSibaM53DKIT0+Awza6J48AgoXU9CYkool0zIesvgtxXvBBavw2998Fv/+rZfim9e8Ejf94G348hdejNZGF056AD4G2kETKA7P45MfPQ/Xfu0N+M51r8JNN12On9/+b7j+e1eBMxUc6Y3oXWAzWiMtMlOnEB0anqDI5DaBSwNkt8TI8cbziw71jR5b3NDAvVTgRcePvu+Am3+DW1MH2wwiSsX0KygMRRj+57y8o+OH4HVXUDuvDUpPeHDolFZVQZAwn8vB4QA9Dt3vV5HLJGmEgOdayKbnIbcpooytjOnpj3575cJaogFjuu/JdyaXkS9JOX58800b3/zmNwcKGX/hg6T+hS1Yvbi4+MsTExOmy30Pz7IgXI+CcqaPJGZ/wGJUBPUtqenhIuEkoYgsvHQWNfCdeqS9nUOVNYDze3sHF3d33NZ0bNfKS4Y6Ra5BFALQ5wzPdx9tbH5ZwlCgUeo0TDjChCECiGUt9OnAoaB65eunJ74OXk0lkXcPTk/vzsChwgnKT4Guq7B4hAEyT3EF8QgoEAUxZvjO8QtCAfhmFcg46b57DmCwuxvnnbkQCxss2shxBNRxaG4CGj0edBPIpJGOT8EUcfi1EdRUJ9GyWENZjYfv/eB6mKoC4WpQhQmhK6D+QFCpFNUGhANP2HAUD7ZwwcUhFA2FS6NVdg0O7m4pib5bZrxxYuKHe6z0+4c5p87aAnIoDO4RtEGOAPdXRt6zNlR6vy+eRdhUkMjMQTF8MAw/vZMCj/Rm2a9UrDxDDKEDqh/QDAEf46VyuuKlrl041tkzMvJjQzUKP4cWELJ7CCHQ19f3V+2gKwUMf+Hj4OFDrzC5GyubqcSgM9FUWvlevgp3eHLqfXJVYpGPjJsRCSiY6x9cHsy4vy5UePLx7xdf8qHrN28uHHZu+c1//KNfl3b03VZfXXOvRtym3yQzAshQZXORYoyWlX7x0sGTytQYiVw8NDv/dakU0ttkqdhCCNhUcl3V2ILKBJVqo1ISKhzmuEIFFIUUUJpyntME8hag8/PKd95Iz0Q+2yYUeldNzUHSQLcD5JIAj5PCoQA8Tu/CzcDg4AeGZnHl+76N/QdmkWW8ohK/y5Wal3YhNVhndzlu5HrCAwTYER+8XUJW8odZec+GUIUYnI1d014VfR2z8PKhga+N15R9Yox8zoVD8KjQbjx1b3xR1Z2t2cw1YmoWxb4Q+3AQIk12zuGuuU2lMuFKprNfTwGEAWQBei4FFunOZ1Io8vLwDw+u/8XCmsUsQmNl2VtNRWfkp9Kj6XDoKPYf3HMqvZQUrazyjEF5xjWfrLj5gs1vmJqarMrlc4UclZyJGua+gzNjN8uMvavWXdOciIOLEuhhQFVNeJaJABmD0cHn8Hxuu4cCa1E5N7O9uWNgqqdt2fz+6uh7tlf5GJEAPcXFRfp0bI1wWNHNwVGymCBbpstK7nx+//BV4NVsKu8cn5+/S24KegKwiFRVDFi0QEXUJeGWAAAQAElEQVQo5CC9DNVIYVcKFUlA55cKgCAbOXzbbEQ2sgqsvCadCD521THc9OMeMrWagglQ0EFYVAiEPNjePHIMbBUEkcn6MDxu4IrX34Hde4A02SHpsL08lVOhRxX0biSDY5D5gt6Bmo3Cj5IEyXBB3ggqOSA0Wc8jlRAj47EfrvBHCp7qecdOfGaoOvK9UR/o1SwUsY11YvySkgwQJD9t4cARAlbeheop8BGRKsfDANsgTtoVPEWwLZBxFTgADLr9MBW4gtq8PBy4llk4Ojr6G03o9+h6qDBWyb7p2bnweGz0E7L8LwHlL6ks62YS2TdpmiqT0HUBz/XQWF4m//TJ+8GiReE6K/NmP8+pSjmH0yBgpSlY1lFEDsV0+cVDwxuHFtTcc+ulUF/yxBNbS5zcklTP8XB1On1N9WS2z2sse6ClInpPdna2XKV7cDwgobgwVyxJPdB16FWy48Vl1WvHcu615BGFLnMEhKozuLapNIBLhrpM6WSmSgUiCljSXQjWVflFvDq/VcliBzg5HhWKFiIO4ENX7cADD++D5WnIU+lUXYeUtmaorKtDKCZ0sxyvfe2tOH4C4CIWUAWEoYOujW0sOHLM1CDBLqWX8nLslze7hcaVmk6cNgcnlc0ivfItiz0oYiSTvGZlbdXZbIrndQ6/OVZV1pXSNZhsF+E7pKjw6wosKwdVVaFQHvl8BhoPhvO5LBiugWET/AYYR3kwyAdDUeHyeMbv80GlB4qSsJnj3ed/b0VtneynOBy8N0t8Cj9UlvGFrt7OwhaDTD9TkO2faV1s3rw5unP7jg0uLVZw9G6ewwe8pqKij0gkjdHQe6b7TgTqinyw5xwEKawgB6t5Ofj9Hplgo8gSEEOTF7Y+XnpItlk3M3p8okbflBM6TBeYGJ4+d6q7b1OObtvz6bB5RDFkAzf07Kv7AJBaXVS0rn96bDcdApVEYiDQKhk6A4xNQF0vOCCOTMZVaWSRo4eDZgE6EQm+OYEK5OizXNBg2UTAZ+pI21kYPM7gIhJxy4FLYQlNQFEUOPPs0SY93AZxGdc4jg8zM4CMvSUvQBo81wYEXYOsTw30CIYwuNBUYZBfJng5bMOgyKL7EIYCUDFARQEU5Fk/R2oc6KJ3ZPzB1WWBwl7V/XZqDerqkaQSZjUg62Xlb+QRIkIhgPl0CqESk8aQRSigI6Ab8LhNLiwDAQ8IsU8jm4NURCdvI5l14DdDKOHKblGk7Ebw6o9NXaupiqeTDoX1pa0d29/Z/LznPW8Ni5/xrTzjmqyoqdpHFAgOW3DY4BuoLAl/77Yn/1ixSfHeG5SCoDsNMEi08gJ5BtI6B52mQBTuRVGvUMyWRfOp9kNNZbd6gDh/JLNjOpffJIJR+LRAgflFYR/myIRJVcdYOPqGLTHEwGs4k7rJUxXhKfwgMImCQCUTJHeZByJlqXQGEDpTGkG4fMhKLORLVqOjAvUdNpmcZYykKDbmsylwBkF1Qw08QwVUH6c5E6rZzNmqDJpeBFUz4HK6aV8KUA9RsGjiBD1OoW+10CEV3kOe3kd6y0J/jgafUKCrCjR27pEfYHnhlxlQIRQDVEmk2TIPiPF0Tu5TiS0dU8mtM1PP6afSxllDpSIGA4BFuuHkEKYSJblZrIJ5nBHyVFhF05Hl9J+jgiSYP2XRGtneYf9FgTBXfVlgPoN81+C51zQ1RVkFpaHAlxS40CFA8sAkEvF44XBflj8TkON8JvUKdXpOdL9QIcdcuvOiQFDmecUlJYWf697X3nCufeRINEDCAR9pFXA01lFV5BjgBGjpqg0oigLFtlBnhFE8kbx0qMz/mAeItRlrR66uqjdNJhX5IrATWTiU1khR+PqXDk38ELwqDOP2GJzFOakcAhQAcXE7WyfTVIIuTEgHJIv9GqBSh6TToAwAOT96JkDaVCEkryAVh6TBEcxWAJXAG8uXqahvrEacy+4EvVJOqcW2J5IYniindYeRJf2uN4kLL6gqTC0qB+AXgMb+BDsUNCpipFgEhKLDIW0eNJLhgo6Xigk4tgJV6GAmFFVldQUqtzqIgurkwjIFxrJOY0NF8T0sxGsn5++drK35fpLBeZ6KKH++o2uAIQCPRmsSlwoDPr51RSDjZJHWPSSKQ9f0G/qruZ/31rmi0HSSR1mCU5+pGKgORtHEWHJNeWnhOKg0bP7AIDoh6XVAugS6e/pa8RdcyjOtu7ht+Vnce1pgaD74aIFJutnigH/Hwe6B/RLHolDRmyPcmS0rKsYsl00TdKd9Ds6dMYz6jKYizekxYwNpWk6a3mt0do6eSEM4kT8tXlX672Orl38tkUi1+Lj0tSnpGXJ2ytCxfy77IYl/WXHpZTN5+0UWYxpKApQWPNbzpLgUcha86CFUCk6DCq6WZRWQt5AJIV2aJQBqkEsmSr2XP4VlE8hLKABDC1kV9XWNKC5tg6K2YHAkgvd/+Jd46at24vI33Ybbbu9k9TbYTjGq69rgqZQAc6SGSip0phXSRGzwOJ/aVA+bhRIoI6YAgx6O3UFwg5NVOA5SI0nLpADhQpIqjRasNDIZv3BVVf3rwGtHzn7nDA0xzjEKUwXtWg6HUx0wR0PMKT5YHJTBaVuW2dReR+g/XzGfv2XVdPr6I1lvYbao6MHZXL5gFHRTMOdiaHBxBdGjY3i4W4dCAxf0UAZcW4DHMdWnn37682T5MwGS/EyqAaZfOy/HaC/PoCFPDdcVFUFDf1C23lJTE5g8MfQyH+OF+UwCiZCB42F19Uo7+VBdJjOcr6qbzwcCmKd3GqIFpSrrfu1fubxjyiBTiEfMJd5qHxt6b9FUCkF6kpidQ76uDAcd6/UfnpuLc8dP752b+7FDRRGMI6RUdA7WYOc2IavkKUJXZrOGRjs1CoqxdlU7GQMGoWCsbLPMoztnGWmQiiB1ExQOmOsSEfUXXLTCHypCf4+BD77/tzjttF9wow/glg+27wXe854TWL7023j8URfzyXqYxUBeJZAOlyBvFUxxISHdpcdpFIYLh9+KCbS2NsFgbOjzc+lGqpkFCYKrWdOnwhMOiSUWiYKjMPUAusbHf3hKuLZ0S39/9mDGunDWH8FM2kGeVeUP9sJttccCbc2HYz4/RhmbxZMuAmxnWEAwZ3/pUEnJpp+WldU8Lx6f63ecS+ejUWQ1m4qdR5QDtweHVlzz5G/4KyPFv1DIjxyVEVI2qoqpqann4hleyjOsh/GpqZeqmgaFJs+xwub8zCD6Gtl+cUXF+WGhQPUEWSlglJf/6kVTUweuX7tW377ujF8PQESOcj6YrS3bkq7Soo19J15YfXD/0mRV6RlONJTyyFg/VxhllKjNJW3S1DFdUXLi9TGrEDCmw2Wfc6EJTTXg0fuBXsageihkOBRS4BEoMJm24RV8gsryV156Ke669UZ88r1vwsaFrQgxEDeQhe5REoJteCuSaXQJKpkoYz6JateeE3jlaz6Ln9wyW9gOEPQKOQRhwQ9hBDAVA171mlvw3e8/DMulYnjguAEhVMhL8kcwj8OCfFcU+3HFq16IH37r6/jm1V+ETqVJczqFKmCzga4qknTk84xr+F1AVmjvMVzIcUS6mIb7EVn09lT8vnRNzWGLXkjVTGg+E2P51EXRzt4VJ0LiYm9R+76JcATj5JHQ/fBy1lk+130iFAmOyPZnUKkSIf+Up6sMPYCQoULEZ9EqvFfL8qqy8I9zHCkgIC+Xvff0914q088ElGdSqaSkJDIxMb7YYR95KtKTbUY75udnZbpYFx/TRA4BbvxZNBtHqEdlfkyzKrtmxp8/FQ39sH9xXf3SwclPreudi++hosnyjZ2922YjgZcmTcF4yUbajSPHeT8WNPDo9MQ7CnWM0JK5RPL9CgcmA1CVrCcZyFEUNvMoE/AFxQDllwMdHNnhUSYOApqCpTUVuOqNr8V9P/o2tt58A77w9rdhfQs9iw2uvgCfk6OHcKCyM1XxweFWQXdvGoMDRCs7IuS5+vPYoyvySFHoedbNeMD2XeOYn6ZyuibbG2zrFcSgsby5KoC3veJC/Pb7X8PR3/4a17z7XXje6hWoUD3SZUNWtKltDmlMcOqTvBXsS45FUCNl/MfiwjjyXP/NJmav3BCqagevbbGZD866Ah49rcVg3FXMNzIbFwyM39184uDaw5Ula2aqKr8+w9DEIu4A8QXnU7JKARIGjuS5jWEIUkrjCrDDVsP4iix8oLc37sI9AEVBASSfLaussbFxiSz/c8BWf64KIALhc/VQEB6nOo0MAK+aipLr+SrcLaa+zk6mwMNihANBOOlU4U+FPrTz0LDjWf7nHTnyhst2dg/LyodOW/nhnJZP3vr8Cx6V34tPDP9uHjZkGJTJZpFUHJh1tbn3DsYfkOVjVu7aLGwO2eGnS3Vy+QaVhwIn9dIzFxifL2TDI4M8JiWoDIqKDIHUeD8CyGBZUxne+cZX4Sf/fg1+84Nr8PZXPBelBuCHDZ1qCE47UrEMjZnEUeiEb9e1+LRhmpySmNLNEDz42Bc9BDXDpNgN5FEbDuIVzz0f133uKtz679/Etz75MZzW1ogiK4sIQ4UgpxfTc6GxNdGATWHzGyoHwpWbzJAxlV9o0JjnAhDUrMImJRwxnk39O3h9cHjsd4Gmxt4EK2iqH6YZeYkHiQ2F66XdHfvXDvVfmdOUklHNe8G453zEUtWNhUI+RCJxdsQfpEe0qTSiQE9+cBA/qKlZxGI01df+WJOdkpfym0yHnU6/sJD+Mw+O5M/UYDHjpsvkT1AowsLYVebxXOsh+bqtofJ5yX37UG4GEAj4mT2PkJM4/9HmmrfL8tdz3pfvnY1VFw831E5H9/R+IXhswqjNYxWevOJ8m4rHIxodWSrs8em5f2MWFpZG1k961rlJCswieBLIOUk0X/z6vWggaZLAGZkMElQQwOB0pto2ioqC1MAkPCsGOz6OKnrE8xYvwJff9TY8eteP8aNvfxrvet0rsbq1oaBcCldCPvJapQ77C4wl31XwaCNPqamwGdSqyLKfHOO1PC4+ay2+etX78IvvXIPrPvI+XHHe2VhbXgZlYhwRxp06FcnidkSW3k3nYsWxBcMDQJA+PogcpI9+gSsEg1hlQJ2jstBZQuqbw/Y0Kky5iTNbSgPrWRudqfgHJ5nIW0EaTH7JHesXn8lPPLqk+e3b68rfuaupvGoFp7c16dyd6xKJL1w4MbFTlu8pLf5wbTwJ5BLgCRNSVG5D0xBOZ7C8pOQcWSdgGAftbAaQYxfMIS26bj6fqT97K3+2Bivkc7kWaMTsefDyLooNpb9cDxQ2JtsjRcuryWaT2uzQCsMh0jqdQG0q963Dixbs2bZ82aMda9d0VE7E7woOTpaGHRtlAf0z+Wy+lKixd0n9yyMqhZS2YQkBUVODfmX0p7IsYeEVeSjCpuowPOMTHD4Kb3YJkgNNCcLgdoDpAj6CFJ4KqX6AjEmkpTvz8/CySaglEWi6C0P3IBQHBjHXlISxdkZDuQAAEABJREFUbvkivO9tr8HPvnctbrr2s3j5+RvRWhGCj0S43FNjrAzVATR++4i7odTEpmWNuO4L78O+h2/D9V/bgpc//2wsbalEUGfFfAIyIKdLBxSFDEmzXwGfz6BSpiHPGiNMKzkHKrcAtILWgLGdRsMwOEaV7QQzBKSz5AIZwq8gTbI9Ty38KuP5A8O/LF6xzM1TGbxkFo055XzwCs7M/q7Etq+lgffvX9hw37ZlC9760NplF9+zvO3Sx5prH4gmUl+oYMwYMDkSD/BUAZtxabEQKPVQUMoS09wVMNRBcNdd8hkKYFlObQ0XX+ziT96s+ifLZWG5ruv1oKVz9oDJHJF3J3bOzs4zyc1n+wUmWaBwZaZKpcoC9cVhFFOIka7+tc09w2fW9Y4tCXE6s1Ub0yUO6sZHPnH2I4/Yu9rbq+oSzjVVXJVEfWFMk7mjRcE73zuMjMRtpawr5VsIATowyMshn8kPmQSkllF+BhwUM0dCgG+D4BIcHVQqCyoDWOGPAJMM+ew8A+15uGoeWblpxb3h8kAEESWHUiON55+2Ftd/7tP49Q034PrPfwIvv+A86OyDqLB+aQs+/aHL8cNrr8Kvf/RFXH7xqagxcoiKJAJKAoqeRsabQ8qLAYKMUPKAYgG6CmGayOcyMJmmsCirPEIAqgjNxE9hUplsDtzh5KkAcqCMcyw2Bwdk8+BZoQAmZhPvfervAndOT3wnHXBI3zwiPX0fJSqsm4z3pFy1Kzs0b5YMJ89vHpj4dsOhjrvae/tubZ+dOzdA7+snP/JphzzV4LkqSqJROJksuDB6xQ1NTb5HOjqSAQ9d0tvD5hAg5KKsPjGTqJd9/Ckg5X+qmGWa1p6cmSqF5wGUkp9ZpQGjgy9sAbTMdGwDuAeigDyQVZhIJ5IwuNnWQCZWS47MjVFYPphcUSRSeRxbXHLBwea6N5bOJ7qUqenqEq6cZucT0MuqcHBskmiBdSWVb0g6OeFxMB48kOeQ+sNuwCyA7Ac8eg0FxXy+oL0ZL26MYjMJXMzSckKAG5CmIEGkYYDT8om9+5CZjyMQDpDYLHTkwAxouRRUCjukCijcnXdYp7G4CC/m1PXJ970Nt15/Db7xiQ/j+i99AW96+Utx1qqlMHJpmIQwgx4tn2aAn4X81178xBEMBiGtOhmfQ1/Xcezbu4v9paC4VOKJYVRyCpOSOZW0XkIreMnCMiwvC0q94TjJZHodQ6MSMgleHkHernRVgJjy+98GXrtn576SVC2OPoMacsqur3kl6ypN1RX7gpwJIuk0ool5tCoa5L/Vqc+nUc4t9nRmnqtPFyb3BBUSOjsdg18AcyODyPv9pAgo9ZuHZVhH/YfL/RUXAtHS0sXs9k/eyp8slYWKVku5kQDQCoVMIqzpj8girTpaKzI2iTHhCR2urkEJ++CZGky6dJsMzNO8g5EgXDcDP117tQvovbP31k6nvxedjoVsxiMJz0JeLnEDRXjXwOh+iTsJ+90WE/KIg2NBwStx0JQf5PQjqOAKPGSR4CSUxWmMk15WUoQ3c1p7Q1TDcynT1dEiqKTBdS2EyopRXFWK3Tt24MjWrZg90QNnbASmmgICDhSuTpFRALq1gBHkrrcFPR9DdSiP1jKBprCHJRUlKHICsCYtBG12YGmsT+Cut6aGIDIa8v1zmD/Sj94dh3B49wFYXBVHKovAwcNn5NBe4sMFFUV4hQm8q7kJry6N4BzSXsltFQ6XI3LgOVl49KQGMwQ1BHlA4bTuU/xkhUASauEXm1+MxfpL66pT0tAV20F6evJbIyE6m4HjLw+RLxEe4gX8lA1xzDE+c4IGMuSHP2xAMWzkeaDs0w0YnAH8AQ2RkB81plmIoxqqKrdSLGBUAJ+mki6AerWBJP3Jmxz8k+WAay8FFUETgPy9kc3quhnYzheay2pO0ZlQFQUqNd1hj2lObTlbqgK4jHaRc3PIOhmA/lMSF6ZfqFR9MFNUMFpqSdTP2MCG7Qsgbfi+TXQ4d/Hi0r7ZmQpHuPLzJAiA4wZf7AtQAHgsN/0GNKb98zMoi89iOQldxxVpswBMehpQMAqZWlpfj4rmZmw4dQOqqyuRS6Vx4vBR7H3wd8h0n4CdSACFDsh9qiiXNVTGDPycstIzozhxYCc0JwcnnoBJhROayQGyE1ZPzcaQGh7HRFcvPVIPYowGSorLsH7DRixY0o7mBW3I5rLwcjkqbg619GKnUvlrY7NokCvA5DyQyBTGYRqFkcHjf8ROQ+ZTWhOX/zYDfJejn8ok21ZUtlaAV+/0zLf0MGmhVhmuXRJ0gCDj3KAOyFgtx1Aky3jBpFf25PhYL8uYiy/4fFROzibhSARpy0Y6EUNDxH820cJNZbfqJIW9w6KyaqqBVDa7Wpb9KWCTP1UMEOk5uqqADkFOp4hRjlunprrAqzrku0TQfBQK0WMFlx0bHIh0kw4JNA0TigoI2d7VIGDQ8qgkHKDD43eHAXKSq4sIPUlGCExkMgfAaywdO9sxREVBa/hN3kIygCHaU0lIZfOEhxyPe9gFPYoDQYFbdho63RgdI8Iknp0SgwcIEmb4YTJeKG1qRO0KCnrlatTWL8T42AynpR0YPLYb9mw/YM0CyLGJAggDCuMsVWUvNA7VR2NR0kA2Dis+iRiniX17dmHv3r2QfzUdra1BA6fE6IImaBwXKAgnr5I2A0IEKGUVKsmBnC5NleNyyFsPuipODpfhA2jA0nCzANsICA5eZyOPEsgz7SpGZCY3U/i7x5FU7qFZz4DFLRLp5AS9mS40aQ8F3mdNgbh0NV4eJumXh/MhTYNH5B5Xm3KhkCHPLAEwG2Er8VzwenBkZEb+IY9DqhSqus0pdH5u5jn4M5fyZ8qp5fZGl8GyrKjrBjyB7qfaFBvaOSaFlsykSYyKouIorBTgpwIp9FoJ7k0pIBsyNgoCYUPN1GUOdF3AyucQDvnQPzaHvKZiyknfxypQw6HTXIUc5iDJTZkF4SlMSmwKHJkjy+TbA4cMqFQuCZQ+61qQ3lB6BBKGfIarPlptYZfd0CH/zwM0T4TKK1DV2IbmtRuxfPlypLNJ9PQex4mjBzHQ0wnQSMANxHQmD42Hso5rAYaKudFBDHSdwJ49ezA2PopVq1bhtNNOQ9uypaikIoEe0eYWgTQyhwfFhtAZr1CZ5D6A60IhrSCubCYpR/AkCCjgOAhSgThYyAzXA3zkuxQoeV8Yuw0PQtUL3mLaNA8qNdVIsbFDCPmDcLMu/H69UFdVVRiGIE8ccLaDPCeVhqlSbgIqXBq+lbZQFKLB5QERm6u+voUBJDhUX/A4FB0204oASZKE409eJOFPlhd4qqkK+ajBsfII+8yDT7XQs/mIQsb4fCrn4yxy8ThCgnJIuxywAsOvgTMGAjpb8Ewrx9hABkA2rUnh1FhERuUTWUQZd1UuaMWJ/v5B1kR8euZcl6tKmX4KJKESpDJJxpKn7Iil4smXYAIuM/7jVsgCzjUwQiEoDJSFaoLaBO4VAvK4nsyEPwxQYfzRYizeeDoaWxehrLqWk54KxxGAnJ6DUeSpWCr32lwu9fuHRxEpq8CS5SuxZN1ahFsaoFKAsjsygripgAx4heMUFNGj4Tic4ilVSkmD9KxcXMEXMJn+D3qfLmVxUaFSolK/ZR2VSpJOpzbJ9HsmJyfS1SXIhHRYKhDnob1hGKTd4WwACMoiwPjLznpQTR3CNJCkt7FpGGnSZ1BhIoafntlCqSYgF0gRizEDgJJI+IhN+SqaQs7KSdjlnh5P/1n2dLfydAVP5hfpug6XVmWRCNKLiOGj6QLXtrWZWjIVVCj4PK1Q9/mhMq5wLAUZ6EgWBT+XLg5fZ2lgGAbkczYUpj26X8broNFA4YB83Dyz6OITiju3hVVlv5MTc8sK5kWhFITETNm34LvwXUjwwyNQkeSL7KPyewUQQkC6b0k7dAOZmTnse3QrDu7YiaGuLigGFUsxAKEDjE2gMh2IQM4Ruj+A0vpmtC1eApVeic4ZMobQiSfH6SjPaX312vUorqxBtKERIO0uYyGLy3GQVxIHdBVgMG7RwHr370N/ZxfiM9MA+QTS5nDcsnreoUuApB5PewmIQpkjXRVTckx5GjZnhfX8LNwDycSuFAkVqooAV9YyUygaNFVHQAvRYymwNB+M4sofaCVl/54mX7Os76PMbIlXKDCpNFmeNE8NcqHiuuXg5QsYvZqhUjlJJ8cpSIvmeW0setr7zyiU3iytQ/apsVPqA5fV1rDEZk5MhDPDY4rGpWyosENuI0ErsPUQxhUdneHAd45Hg5+IK6Z0ABSOAVMOgLMGj8agqCpsMtixXFq/h2knX9jJPbekpF1nB6r09yxjsnALPhWCzC4A5SDz4FGJmC+nFzoRpgAhhJz5CtXAVaSf3mfRgoWorarGxPAYnnjgQRx64gnMjY2hIE/SIhUAmRzUkjJ4XG7TigrKJjg/qIpANpUi/QZ8QT9ADwDmeUlOWTQ2hcdNekkU4DSXnZ1GbHAIh5/Yju3bt8OjwpYVl6CkopLtyEFqkq4qIMuodyr+3CVHJ0Gwok5FlfLQNR2GqmFlSclSZiOZtB4yyWfD0+Byk9KhR3OFwjjfQi5DU6NSxYUPM6bvC2pV9XtiQoVKr2Ul8hD0ThPyZzOhMPwK4KMihoJmmcRrKtqcDOzBfNBHkWzh2Ha1LHs6KFR9ukJAqVCo5SBxjucSJeDkcjJihc91ayJQoblAlkvuFJkai0QxGghhOFr8jY3dI8OndgzPzlZWfmWeS/lhMmCA05zmNyEN2eYyVtUMeNQCxWeiLzH3S0lHVojFRHlyDFQamfd0UCD+yTpCiIIiCSGoCy7oOCGZDyl8Cj1IoZbV1WHdGWdg2ZJl8Pv9OHr0KA4zDhrv70NiegoFKXPFJQwNkC6OQYeqKwVFaW3izhGVAQymYedo9SmIcAhQVGSmprnKG8FAZyf2HdiPSeJqbGvBmRc/F61L2xHmqhKURmE6JA6PUy0dNXlpQTzd4J7MV4lfJuUwHXo2IQQs26LXcITjugtlWd4T+6j3VHoahGQuV74xxYFSXYG5cJgy8WOmpnpbZXd3j9i715quqvj0mG4g5vNhngsDXzSCBFfEqqlD0HsotlMl8WqKMiVtDbJzZjj0upGiohYmn/Ymt562jAVe1GUHlD1jChTwlhSFCgplpPKcHAR8ho4JxiAjJGqH4mK0peHwcGPzv7Nx4e6oqv/6sdqKvr0RE+MVpRhO5WALDUl6J3lir2omspxG5nM5Lq8A1W8u0KCIQvjHvgtaXMD0nx/iP39CCEH1PpkrvZVNJlgUALIZgIwA6aSmAZqKSHkZFqxYhTVr1qC1sQ5jQ73Yt2s75gd6MU5AQWmyrKvA5VZEbXkxyiIMquWKQ2UfVCiFhjHVeQxd+w9i3/Zd6DjcAZ8ZwNLlK7Fw9RpEGhrg0lMgEIBNJbIkHRQiwkXwc/pRaTUaRMGT4k9cakGiIEc4DLaRY1LfIOgAABAASURBVFOEwojAQzAaXSybTmWz3Tn2EYoE4eoCc14ek36BPbk5HI4aOF5bvKejNvomWVfCgYrAtV215Xd3RgM47uUwzD3CpAZY3LKQh9WhYIjuln3auRnYKNgCeyfrFDrxXKnE8XSgPF3ByXxRDE0Hxw08WXM+HqeogNKScFEulYSiKChtqnnF2qEB8aq5KXH2vh0rLt+1rRNPXq98/PHRCw53t7xkfE5sHJkW0era1bYroAcDUCjkPGMzhV4wqWQ5/0BunjXY1CLB9vpTnbJH3mQiM+UtP+SbIOtJ0rgTAclsCcwmXUBBGPR+BUXiPpBcfcGjVBQBcgeB4mJCEVZvOAVnPfcizM7NoKe7C3t27sTs8BA5nIUS8MHiTroE0IJBZRrt7UHvoQPoZmxk5/I4ddPpWH/GWahcuBBFnFZBRXa5467wvEy6SkFF0gwfZeKAmzl0VPnCyAzVIKmkhc+nu2W8pNG7S9tS1ZN1XY5BplKZ1ArZbiw2EVPJy2QihWw6C8mD8qqqy8+btcSFQ4Pi+YcPrH/9I9uPy7oS3rHr+MzzT3RdfM7YhDgjlhKuqT+3rLGGpOVIrs3x5mQ1KrsyL/vhcAoqYFNWKmfrQuHTPJSnyX8y2ysGkUjmkxVSWaH4dQYOkjdO2E9mZ/I5OgDvA/dWVhY22p5s+PSvvPfteS5TFV2hZ8rCVQQVRXDJnonJRkkrUyv7ApUK9IkFT8UCmUdVkFkngXlP3ScH7VCJFAghv0BlAmzpmYgf5ALkFMZ4hpUgx8PgBgxiWFEDCkajoImbkBs3nYoFDMh9wRARyF49qKRDl3gkPk7bBqfRAJfnK1auwpL1GyAiEeIgHnpaVmVah9D1QtL1BKCokF4eMq0bEFQQ6gTzxFND+JNvKUhZwSkgARShQNqUJtSwzA/ZasZRXNDZw68IFAsDXv/MlsPNzZWy/M9BcXnZ50ZHR+HzGdDIJx9pl20U4cjFKAQ/BB8SGD2U8vNpb+VpS04WEI1MSPJRELH8kuBCrqldBBikJmem1kbz+YlbF60o/J5Glv//cGt7e8POojIvPRHbWBstgUZsQkiBES8Daxt6RrYhQU/2CTBdAMECWbNAhXxIYN5TtyyXivfUmw4QUnYSQAwuERWaCBTy5bcEUDBQNWayguxAaFCDUe6nlSMQKQFMP5XKg8t6nqICsm6kCGW1dahqakawrgEQAgCBbcG+4FH9JAEEjyDzRGEPje1luQCNSIHcM/JkGn/5JT2QbCU8lwQCyVAq4XkuJCkMwSFsyiXrNWuJzMEfLFq0Ttb9Y/D5xYsX7l+3MjHePbi6yPDDr+qQ8R1jNVoIkLNl4ABI3kl4Ekf4yfcffZGTfzT/PzIlJgnMccgAS5NsAFyowmVXuXQGAUbAjcJDSS7xDVb7o3dDUfC7ZXBQwUDQSaSRnEsjbCpkscsZyf0vbTzmyFx2ydSTt/yQBRKYJcv5+vM3BSqpliBlLNu5EPBozRAqIKceReeYDKYpI5M803wAd8hlucv9K4eKghy1zmZ3skwz4XEbwVFUuBIP8UECOxHsRNCbKBJcgM5DloCpAjhUUIttbAKrM++Z3UKcrOeR7zLFETyZAyjkiaAntrmXZFOqBo3Ul8pVluS83bLuH4PFgaJvZruHQo08StKTeYCy9CkKfEIyhS0cqixfEGSFBJmGy54KiT/6YNd/NP8PMonpKRx/gIqbaNIQ4GNwGtQ1ns0l0GyI+T9o+J+S5Y7tBHmir3NaUOk3ixnjunkX5Cmp9VAwCbZ4ivmUA1wqILNQIFLIHPn1/8NJ9///557keaHlfyqSjH8qg73DofBB5YDug0svk6cS5GnheVpP3nEZj6hEpRQocSkkSA2QSsS6FvnOamzHcnblCj4k8oLkqaiFN/nHvEK/HhO85Uhkt7ItP//6WxSwQk+FAhKfx/6kkSh8mwSDhl5pGgeeroPofKq7lDZSqhgwKBeT4zE1GpaHwj6Uxunv9205DImf1Qshz+/zAfxh+kkO/GHWH6Zdar6Hgp6SC7KyB52oAX66tiKQ8xzuP9mQO8j6fOzwU60fbm1te3RJy4KnvqOz8Qei8DCXi8PikraQT2uXLFHork1XC8o8DSJFURQE6DDDIxTuQoK9Fj7+41HI/o/PP5oSrCQ8heM4CQrTCmvKvl0qN7UGIDM9WqfHNxQNqqpCpdcSQrAdi/lWJIOZD6q4S1BUUkoeeEQk2ImEk5VJpzQAtsEfXqyDQj7L4dHwvT8s/YvTmlCyspEJCMkrm+hUV4HuClBwUFULQdMt/F0feP1k3fKWH5+y+vdTYHh+ZoeaoDySScgY0eaueJabppqpcQ8FsC1LKGxHUgsCl3xiF7xl5h+HQv0/XkSaIOYUeNCIgqwjCwFVcRmtSvzuqMccrv7BGBVBbguEHG/vkfamqiOL235U3TPYtXAs1bm7rvGBI01NVSV5sdXhiihAC/DolrNpgLKA5LFCxut+jRs9gA6MCBLELgF26jItbyEfvwfl9ymZkHU8VpBt5JvypbBQwE3y/1NafstyhY2koWgKO6F5eLRQhR5IpZLohgqVrBTMl43pfyBrQV40INvKwZFg26ABFEBhRUEAx1IARQBPKQ87dGVa4iORKg1I5ZvZkOPHX3kpujoim5qBQEjQSFzLheaC2uUANEkdFortzI7HFjS07GxqvLq8e6insWdo9/EFbfd2VFc3VnjZvmoeYHukzSUxaTbLcu/NghIjApAX8iTtP9HowZuWZU8HytMVyHwBd04lE6RSSYZqMtNRigsvV03JQeiuhoAWQjyd56pcf1/JzNxxvbf7tbWcCou4VK8aGzk3Mjo65mRT12WkkLjXIRQFesDgqlEh7xUKS8Cny8AFUIATBEAA8kMqCFMyCVAIhXwhc54hyDZPgcs2/x8IKVnPJtPIRr5VKoxwLFBjoNBi4dAJkMmqTHvMpwZougqTSmdqCut4EDIkoJKAvOIHpIA8aqw0HKiC3wAoMFkm66ieB4N0aPSOhbGy+OluURjwfy2V7RRVH5QlpmmWBBjvmbYCg7GeR/w296J0KlU9xOcXpzKH6qYmr1zFsS2ysggO9V5QGZ/sr4H1FTufRJr+zfGRToYhjk/DbDbhSLyKKidOPMl79kj5OYpIybKnA9Z6uiJwKKJgAeDF8cPjGyRSvrgki+c0Ay4DgWwqC5PBdmJu9hxzPl5Ux3yT2w0mrbhO11GSzyMxM7PB5DmTChWejFMY0AqFqsrBKARV0ZZLvLZmHLLArgS/JPAlb5kUUECiCnCSFvBinMOnIxSKkypPS4WsxzzKHifrS+olgBdxyDoF4CfjJOnKZROiYHUb9PUs4JueVOarVAqQRsizN6lsFAwHzs+T+zVgK1IsqYa8pBGQLTQYDw67k0t6mSerSaWSdKkkRyqUTIO0iP8YkETxB+AWmv1BBklyoUN4DLz3yPyQz7eO3oScFVAVpVBf/hxFATDd0bvUnJkLllHpw+k0gukkyqn84ZyD/HRyo+ranGFUWJQJJxB4mkmalYKiZrKZYo/YBPGA3AXbcZwzhc+necg+n6YIZIg96ZBMm07d5jAoaGi61iYbzAQCSVQ3Is+hcS6HQuv2kfFB1tXoelUpHRXwyCmdXimoK5ABuciTRAfQaeUOB+OwnenXEQ6VXQRe+UDgRJoj0KQwbWY8eavEq5IGkPkcI3MVeHzKdOGtGbBonS7rgUFmwZkoVDC6c4cvaOxUEBhjkGuQ7Ugd3wLgGOFJLBJcyG5ADwNpPAKwyUhXYUInIr5AzwJObQp33WW+J8d6shGk4risIxVJvqW3AMukwgOCN5UMHkgWdFYWHqkgSJR48uInIPvjtxylwrcgSBKlcqtM+4gj4jiHmERDVfnmPAfs0Ns6tgWbUzG43+UoCoL0oiHVQI68tshTxeQYiEDjClslYoNE+ggKbcNPHmZyLubz9rjEm3LsYgesRLrZCqTVg6v1yrKnA1n76cpk/pDc1yCLoRg6QWBmLl0rC94/OjqdCwQYwrmQg/T5FTiWRe9jw6BXyuYzXGXnT25eUrulgti0cM8QsCjYdMZiPUDKKBtPoClcUvhnY/b29sYhBUyLUdgRB8HhoABK4Yn/fHk4OWQqmiKBpdL6pTxUReGXvF1Qdig0LwifHJWtBIDCN5HINNtD5kNegg/Z/iR4kqYC8LvQRhCnrMNqv79dyXQoRPcUqK4CCZB4ZTuCIwTk5++b/X8JUfgmEr7lU6Ei2MzkwpKrUgdCCKnquHNoaIxVUKXqp8nJKc8tbTlkf9CkA2U9jsfPDdg8ZwiVtAd8AXicGWSbJI1e47GQTLs5G5qiw2EnnubDTM4tKBSEXuewgtQBvgokzyfTozL9dKA8XcGT+VlVUQtJl8RalicV//eHg6pf1/0haj93y+fnc+DeGLhJi5SVgc6zLxHQYcvmOug9cnAMYE7NIR9Wp/whzLpZQCUF4TwQHZuJXlvSFpGd1ZcW3ys5VrBiZkgUClymyF6Fb8EkCwsvJjWCzqBaJ406LdHw8rR+wGQ+qJgqhcrqoCRQuJ5s6FG4rqDRkQavwC6ZIDaPhEpwSbhLLDyZB2MU0BuDgvEIoCcUEi9JEvRgcInZIfCtEHSmJch+haPQQQoUcBCPIzTkFYG8UEEUYAHhP26FSUEcIG6iQZbTlRyMSxTQNOToqirqq+9nNe9WQC1PJKvMZA5+VYNLj5/jeamSdRBUBeKpBMAtETkz2HMJ+NjIMCgzxcCcDbi6AdWnkzUeMnQPRkkUSmXlJKthPhFb4Eki+KGqgGYogJU+wc+nvVnjactkgee5DhQyXk4JCmvzHPhCWSAhnsscTWZToEdFyMTJMMMBPLrZPN1umudZBrfzoamY50nwLIUr6mruODxn1UxHwovGyDDupaEyFESuZwDNmrYUvOqLix9nV+yXH0/eLiUm4eQnuc22sg6NtZAlIOnMQ0EerrDIZmZLVyVA0lmZb1BKHrcsCsBvl57S4bcEj2UA8TKfLQFaNziFcjBMSyUjUIlcoZHFsmdZS4En6xfgqbZ8szs8BRInQchv2YQEuzRSiyjyFJLDApd9u8rJ0ZF9rA1IlOClqkyxbiGTo+MwmQuQjMfAKxWJtEwdPaoFpYwYD1LXYAY1cJJAljOG6jdZV4XOclPVoLLPVDwPP88ZTca0WcaEHq06T8+l+nzwV1biLXv3koFEDvd8P89CJel5EpbjviFzuT7n82luSerTFP0++3eutEBSKhG7zG5CQdFxfKj/+3nuKUhFM4UKOw64tgJdDSCfchD1FSPBHdgsLdThCPOBMPqN8PlnA3bNaGK6r7gEcg2aTKYQ4Ooj7CaXgZfnZXdz7B4dYoF/HAvkCO2TXGUngMp6giBvSZOn2HAUC3kNBL51wDJJMQUlg2KXiiPBUVmPUEBCqTsiCwlCMIiQiggbBcWjoEHh8wOgIB0KBALsA+AQIRVJKqHDPPnNKvgPcOEpsm9T+GDpAAAQAElEQVRSLiRInByBoCvmt0NaJd/yVHhJW+GbA2Kp7L2AWzZXiUJ6WBAFVJMkK5w+Vcl8L6Bqu0gYasuK1hUxbvAcGyqnN48uL0/GJdjW9omCMmUyKQiOH9LDkBRp/JLfXmwOpq4jQY8mz/EUGv8MnA6JV0I6lw3mshn4qGhyvIqmTsv8PwV/VqF0RXtMEYCgq5V6pVJggaC+GLxs09yep3siq5Cdd8AZDpIJ2bwFM1qMvuQ8siXFGKAwsvVNg/GK2g/0Z/AyNi3c6Yba651IkNakwU9hNhZHCv8O0fbuoXs5cw0IWo4DFJhMnURBYGQUCIL5TxFfUChZSMuX9QpCZgVP5nGeULyTNZmEVIIC0ECIQuoOFMkt+VEAl08XQg5WSpJ0uYJSkEBKVNeFynehnJ4Fso8CkDEcp0fXYdPCHHYp+4MgOtYT0hhkn54NnTgU72S+yjergi/ZWwFYUrhVPgOaTp6yRuEvBgT7dhHVjeFw3dBD4FWh6Rf4OdUbnBUyXFVPs8MpKsA4hTHItj2kdTRoYDjgw6ipopuGNhFU0c+pxldaChl3+YI68paDZM7ClGX/jGhxSlnZQoUJSX6WB+LUSBiB4L3M+pO3bPMnK9iuvU8IAY9TmKzo8mGpyhl8YWxmpifDyd3Vi+CZClRqu0rWZJ0c5sK6ZS9uefCQrry+t7a5rKm7q/GUruNffUVnx+93bifV3K9neRxj+H1slcfcxMDzP18bLpxmL1/YfNwj48kfFOSlskcJfNH8C1kyKTztZNozGT/oxANIXVCoiboM4GwdigRHhUoJCyGkaOFR+ODyT7fC0OwwXJcBK8cicYNTB1x6LC/DviWkKEi+vRwU5qs2kVP0dH5cuWrQHIOd6gVwhAqHSmUpKiwqFh0GqJ0so8pwygd1088tbflvJ/hpiTLO0qh94kmlL4xXAPItXy5XbSHSFVB8MKAxpaC2qKz7kUdgb6mpCeSHx15XZpis7iAGB+H1a4ZirW0PumtP/UV61brvJzauv25245rrRtaveffAutXvHFi//LID1XXPm17QtHoiEDgzUFrWbWdtGFRC1/BhLDH/G/DKevZGvmByv02+QS5nc/b2k+mnfypPX3SyxNCNSYdxlKZTmgLgVIuMbRf+GHA0kYhXtbXY81zRuYqGJAuNisp9KV07bzyZKV/c0XXexSMzN774+PEZie0ny5e3/GbR6pfesWhl4Q8VL9/TeU9dadXAXCyJMOf6Ig1YHIwW/kY/LJTPqhyEbEduFV6Fhwd+KnjqEvySaRcqXAaa8ASkxpicP0I5D8iylLqArAeRc6BJ78mAQCWtKmMChfWUvAeVghYu63oEmfg9SOXx2IsHSA8jlbwArMcs0JVyeQTQS0jQqCym5cLPPkzLhsIVFCTwu8A8WWa7J3e0qUQKQdAoVGqeHJWQOCUQvbw18sDlhJ938wUaHC5vqoqDX5NljZpzblUgiHQsBpuBu9yUPBibPn/ZvoPnLXvw0Us3PPjEm06/9/F3nH7vtnec9uCj1576wOPfOm/r4Z8858jAb0/p6j+QiMeP5q1cuaIomGXYkeL4xtXcgMSdTKeeQ3HAIt2GQYOhIcLJH5FlfwrkGP5UOdJWeiAUDB+xGeCxX9AAkcg5hd8Vfxewslrm157fg8XypANMav7e1qz94Lq5OflLPLHT52vuKot+ore5dkdr7/GeFXPjt62PT397TxhlQ6WltZW2lvSTaSo9oD+VwapQ8ZckQQ+f6Hk8YhjHVZaBDFZ8fgqUJRSAQu/iMF/KX6FVUoXIcgGHXgEs01hQSW7s+fU9OPyt7+LQt3+Ig9/5IZIPbMXcg49h+qFHgYMMFY4dB6aGgYkhjoRaxziusLKQUtV12FROz9agCZPqagIukdL7gEpBSvjNASt5wEsCudmTeKbGkTl0EKMPPIyZh7Yi/cg29Nx8K/v/ATq+ewOO/eznSEwkoepAhrvvOeJU1SBHo4FZ8BGx7F6OmcOmbSgcG+jYXOQVG7Zwu3/b1fVbVkN7WdlHPS6VXQNwae+lNTUnoqq/T5ZJuPvUU1uPrDzr7CNrznjdb8/f/DqZJ+GhlugnOupDH68K46b83EyRrhuwdBPlrQvGrjo8OCfrpLNWPdkok7QTB8L0JWGrE4WMP/FQ/kTZU0Uz6fT8KM0DdFREDoSjRSvqTbNVVhiam3swTmXyh8IwzQCmpqZfutMfftHeQPFHjvqCbp1j9dY7uU9FJkY2tLCeOjmGikQitFor7tBnZoZj01NLC1MDrTlEtoqRqYaflJcXDpWbKst+JOT8Rc66yRwUT4fOuMBhnhysqmoUNuCQkKSmIsay+QAt1vTDpWTGJsZxYM9eHN67F/seewJ3/exW/Ow71+NHV38b11z1aXzxPZ/EF9/ybvzwU1uw53s/RNftd2LowW2Y7+gFAwpovjCHrSFMUeflP4GTtQCdiq0awPAUcoeOY+Du3+Gx73wHv7v663jwxhvxmcvfgm98+NP42bXX484bbsadN/8Uux/dikM792Dfnv3oON4Fs9gHUVaMuC+IVLgIMc2kcikcBdgfqLyAKzguZuXhQmU5VAeesNHSWP5D8PpeW21dWdba4PFg16Cea5rAUG//ovlc9hsAK/DOpdMzDKwfGpyeucH2+1/ELNxXX1ZTnrI+FYinPu1MzT/Xz94sTsVuMIwZz7tN1mkrQSTtoVXG8LoqKHMPmmbQO+VOyPI/BST5TxWfLNNNczc8pgnSS03OxP3Q9fXMwWgqf39eC2AqlkAQGqotB3WZ7O0NTuZzNVw5+eEgFc/Ax56iXHXUBoNwcnnEM5lyNRyCXlU646+pcKHpjA8ExOQU6g3jNRK3Mjj8NVrttLTYAIWocOAWYwpZRlKQd2zkqVyMdjAqgB5VQSetrZvL4VR1JSb9GpKlIaSLAnBKIsgH/AiUlKGmoQ7NzY1Yt6wNyypLEJ5NYOyBx7H/ez/FvZ+8Fje98yO45V0fwUOf/SomHtoGH5WpyjDhDAxi+v6H8OBnv4K7PvJ5/Oxdn8b2b9yErl9sR3p/B+yeEaysqsLi+jo01lUjGI3CZp9ZjjkZCCARDGFC9SFTVoUhLYABfxAniPcExxAjY20OjGziE1QjgMPlJoiClE3vabigtk2Xhf3Xg1ddyn5LeHoO5Tp4fse6nN6LHYHWydRb+2oX3PdwU5PvRQcOxE45vlMMtNfuGisKfIbNUG2WvCk87SCSNxEUOgzdx31DCzPk35GZqbtlHV0pPkMRqM6yS4tEyDpWJk0rk6V/GpQ/XXyy1HGcOziYkx/shErLqdA6S2a8ZniqO7xgCXyRMqSzSfgZ0JbxmMXv5uFkbIQ54GgQ0Mgtj355IpXGHD1ILxnYq+FjM0gsGE/E3jHH3Vxd11FMZTBTiY9fFUbpXk5EDeWRm1V25Np5qquAxtWMYqjMAXQqoVSsLL+2D47i18fHcfOhafzoaAw/Oz6Bn3WO4baOQfz4UC9u6RjFLYdG8OujE7i7Yxj3Hh/AztFpdGUcDORcxOh5Shpbsbh9ARqiJcj0DqH7gcdw21e+hW9/eAt2/OxWfPVdH8dNX/gWurbtQ3ZqDo31NSiuqURZaxU9TjX2DU+gj/HSQ53DuOfYGO7rHsUdR8fx04Mj+PnxMfyKtNzaOYKbD/fjO0dHcOMR5su6PX3oSiSpPCcVSY6pwG8KWaZ1wwDIv/oK87ZtT05J5Wn7Yzo3Kk0H9DGAnzwJKjqKMhkYI8Pn12XTh7eubisna/C2392/4a03/bJw7lemmy8uU1TYXLn5ye9MKgXX0DHDdFcq9bisP5dJnZlngiKiYiv0UC5UQ7+HWX/2Vv5sDVZgfLRXeigpTH4WLCeRy71VpiV05FOfn5inF0IAFt2JxfFnXBfRIgHZTrEAjZDOaUhGq3AsGLrmrnRa3zCX/FzjYHzOVxTZWlxbnuHcCtfLopQKuaa86oMS94mp+Svp3Ub9IFI4sHl84xIEh+oUVlsaclCwM5bBdjJ9lwdQESE3aeQ/47JbQSG9k+9tRPgI4V4K4S7CTRMxXDMUx7djHr4xMYdvjw/hgWQM2fIImmqrsLKsCCtDChrngWBnHAvpKNaXFaO5uhy+5ho8lo3hXsYBX+sax0epLD9Iu7hmcBq/4FjvpETuYLuHSdNO9nmYsJtwiHCEpiG/JZ2Pst5O4p1lfo7jyJFOOhp+yVuhXilw81lw0TD9htHcO2TuHbVVn64WAmGhwskJMPRkDOtB11XYShbRsILiTKxNO9w9eW9rVeGMVLbb0l5eNTHcucKzUuDxKSwvDTopGCUlMBoburZMTSVlvdlU/gO2Ak7DgMIKjut4Tmr+Dln254DN/lyVk+WqotzqcHWiKwpFiQI0BgJrZOm+ydj3QlWVMLj8dzQKXdjwB1R6LA8KBKaywLDpw1Bx5MYOkW08d3LovVsgbQ7YWRW+PB2be3guHvMrhgK/qYEeCqdVVH/ws6X+wrlhWXHRN2SPirRFlT1yNSI34gSpcAlC8yNGIU0TphQDswzM4wASqkBSAHkdSPtVpPieY/sZwjjL+whjpHCQ74Mu8GA8j1sHp3Bnbz8OcA8tHo7CqKiFWarDH9VRu6AecfbVkUjj1iM9+Pk4393T2O8AA8Qx4zMwzPck+51hX7MaIPuLK0CKXnmOsViME/s4+5xjcD8ugGnWkeUWvxVFLxgrmC8NEVz5qUwEFQ2tpeYXyDP32pKSyNrS8vcbaXoW8iHtCyDJaTPreFSqPBeiNhQnAx89eqsfaE5l7r6nofxSkoUtHVPjtlA2JohfGOSLA5gBA52joziRnP+yrNNaFFjLbGHRMHWfWQgpisJFUv9TsvzPAYf656o8Ve7eKFMeB6EKOUwFKcV7n8zbMj7er5UXDU5n5uBQmTTFpfwFVM9ANh9Bvqxx547K6lUrJidf//y5OSk/7KuoeE1PyOe1JOwbqxSj3OX0KIhbYeAepedxDxzDmaGyj4JX/0z8y6qm7M6Dps9vkGr550sy6QkXaS8F+U+T5RRJF7nlqRSdgiD3nkxXAOSQ4px8g4yi84Sn6swmIrgSnUTFVRQgFeO3aeCbk2l8rXsAt8YtHCptxCNaGI/4Irg5Fsf1MylsJU6pPDG2pL2wfwOxrCBOExA+uPJshXWIHiQRdi5HHytoEuyPpIB8gl8pWFVhVFxRQhJWKANAD6STMhMCxYq5t3M6dzV4LS2JfMQbm/CDq+K4BvTQAK2mxi+WNtTTW9nwMY70ci404tHygDYex4KMeuu9rUs+w+ZYN5/ZOV8c/YSl6VBYZ3Y+D19pGINC/FiWZx3rTbRJSHLy3GIBFO6kp74ny54JKM+kkqzDbZaBQMCXsil023Og0yrSeXt1U1NhpYvuZOJb2VAAKn1plns+pqrBVQ2MCaBuemDjK/r6Dko8tyyqe86ulrrexlz2xxU8lnGzeYzxUHKwKIJ0U9O2NAcaoKWW0huWzM2/7TMVFYXVqluiewAAEABJREFUZEtDzWWUj8fxSTQgn1G4OAKPCckAkC5QpBAOGapS/WxarFcQqPwXSUCL16hq4NYDhBQ+G/ImCj4BGYSmVSARAKSybM8Btw6N4/snunHb9CyuO3QU982lMMTaI4QE60qztThGh3wRmsZchTGHV3hrjEvAMoUeC9Qsj7RJcEkZK9BFuDg5HgWqOAmsBrC5IvEhz2LXq4iYhf91xnfqzAXBqckPaal5mPTmFuOmoqb679d3dl7Vk4h9PEveg8Yux6MpAn4BNHFREJqNoSY+/7GDLUuuYSClq4b/PfJfXIGiIRMwEWxue2RLRwfVD4hZ1mlcV0HSAKiSTE9VxQ6ZeCagPJNKT9bpyOXte8gCKKpGz5ORwlqSmjU3y/JDU4kbZ4JBzFGr/bQ8K5VFWljorxCF5erWskB1X33p5MaxkXvqx0eadXqkHLcZ0tWVie6q8neeMhMXdSf6zkhV1R9LOxwKzyZKrRxeWVW9+wtFDcW7ens7mxa2vqXAcBIhhOyVQCWB4oPKjT3Ns2EUbN5Fkn2nTSBPnniKHKYCDSoUWQ+AwylBahq7KojXY17hZoZND8UuQH3CLDPl9DjJ9wxBKpDkvKwvHQpRogAMFD2HpYIBEbIAPZD95IpUKhvRsh8HDlzKSrYGmAToyVQOxvLYm8jDJG81ds7hQ1WB4tLA5btnZ4+yNp7jCzxeaaUR0V3KAJL/sDKJwk9YWmfmP5erqbdTQoeum3C4WSuIx6OxRoi33plF8dix91Rqer5oeqak3DQwn7MxboZweD79aYl/ZW3Z81IWlkHVgcIvLRT4feYOy0pTD2WNPw/Kn6/yHzVs275DpRVajk2ideS5d2Sncu+RNd6VHJ+aKYn2ONzPyKTpcinENAU85VekLNBYUf1JbWa+XE94UFjWIzyMlZd9o19LNzynZ/hbEocETdNiOpmaoWJWGDqsQweLTynCu2VZX2fP9xpLih9XXY6XEuINofqpHYKOQEAKRgrJpBIxg/lA4Q3wJXDyYmNZ6clPj5lP5jAF1jsJ4GURpHok+ZZAPaPPOIlWtoFsLEF+yDfrFfLkW4LMewpkf0/BH5Qpisq4yYXOo6s8lT3HQckmQUrG52DH4Mz8TbL6gyG8w+ibK6/xKfC47WJZFu3BRWx47OP7Fi2qIWrvRD736Xl6Z4dEOESiaCo84jdUBUEaUJS4i1wbReSPRWXKcYtlzhfCS06ceFj2kchlXltgAOnQuZ3AatAV5QFZ9kyBZD/TqoV6t1CpYHJpLwckO+Qsc+GqiLlAlp4Q1gtijkpxKVQaDbrhQ8pRC2VHMu4XRqN1GCsqRldFzde3LywvWT7c/56z+2OxWwHj3orQvz0R1b3AxPAmwfO9MKfU7HwSrWETNfNTn7yhurrwr6cNTM6dXl8cPmjqVCROXx4ZpTNgsOHRo3hQdU2GF/AJnVsVKh2FRsbLYXr0Dg7yNFu5ggElIGmWQN6zNf5iUNnYdBVI0DwFggBOUpDvJ0HmSfjDPJlWWS7YsUu/xYbI5wDDHwE4RTmKjiLN2L0SOINd4Lr65gvCtu+bIYNjybjgQhgmlcHLWagxI1CEuF/WO29o5DOB6rLDecVBwuV4uBDyNAPpnEAmZ8LwFQGaDlvlN985XxC5sugrZNtNkUjJ6HTqUpkG6bKtLBT6QDOtF4L1Qv4zeCjPoM5/qqJp2mdzDDD5LuSzb8ync1fIj3d0dB/1t7QdiVPQrm5AUNNbzGCBoIv7+gamLa86pRdVn947dOW/Pbmf8mB91etOX9DUvzidvW6ZoiI1m0Sa2wbTDKzdUISBZg5+bkmcXhS46wfc5ZX9LCmt3KBYGVmDPXmw8mkYARNSSTIM9jyo8Kg1CjP0AoA5LkBV5yf+E+BvuWQPCnGrZL5KRMrvQTBHACxTmFLYpcKvkyCYg6dAAFKA/kAIee4hIZuB4Vperc/3nEcA+7ry8tB6I3RXtT9EXDoSdJkevdloNnu5Wln5HkvXfuivKGu/7tzTziYmHNHUL4wE/Mj7dMS5Gk1nLIS4G69QUJkU+cQgPs8ZJs1OtYpSXHLw4M9lO7vI/LglE6wHKpuktKas+tdTOLmVIIueCch2z6Te7+vYtv0zVVXhUHBOIVdFzMYVi8rKwvKzIxb7iFVTAxl7FHGF1TY2VXGkrOwaWXbxVP/42QTSLHaEomefKC72muPzN2BsqLqUmZlYFrmIjvnKyu9km1rPGvOFU2m67cqwgDnery7OZEd+VFtbek93d27TihXcM3VGFNiQsW+egqDUAOHBNVTkQOqEBpBxUmYqUzqBDgpwmZDAPgtt+PnX3BKFRQQ5NrYIEh1fvGXJf4BghwpBvmXnpFBSR8og95egsmounYHG3DLYI8uLi4u3z8/PXl0H//nB6ETN8JAe4so3Y1lQdANupOi5bQ5+XDU8/I0FE+NvWLR1m3j7g48Xpq3Nx/t/eqK28dMJxYRJc/P5/MimEzBEGtGAS69tIcd51aPCzcL5GInFRW1tkb7p2ct5rCg/wViGbw+GoV7HxF90K39R7ZOVj1KheK4DskhBTuhgCFoxPz37bln88u7u38TLShBjxCp4+BmeT6HBSr1nqLb68UMVFZ86Vlb3yfHKhscX29mHyubm0EBvBEbhlu0hWxTGQE31LxqHxt7W0HV4a7ok8q4kNw7pjBAgE5pJ7SrN/PXNZMB9hw6lLly1apkB+mVKU2OZ7B+c8uC4oJy5h2KTRk4RfEohMpd+QaHOaWylAxQhPIXvv+6WCiSxO1QNjwCprcKGfMvtDFnusW88CQrfgoDCJalxSQ8kFTBoGEG43uJw0fK9PFiXVc4O1N8YHR8L1Aogn5iDwvhVURQIoW443NTwrl2LWp+zp6WlQdb9Q3j+waOfHILaEi8qGptzLE6qeagcspN3GA5YPH6KYoD2tu5E3+dluyEr+eaZjFPMEyAY9JRyKJWlFd1do71/UfwkcSny8ZeC67rvkvtRiqoiy8DbIjtSEJ8hngK+PZOj670gLYPxjRYCVC8DfWLs1IqZyU/UZaa26NODm+QcHS0RmJtJoigawjhXat2l1Z868/jgpcRTuKfddFgJ+0BHhzA54o9nUDE7cdppfv3gtVSqX/Gs6uxFi4qKDBwzbEAjk5BzAZ1qRtoAlzbvkqEu8gIUmcyRqPkBcpiTiPyC/PxrgPgVYhUESEWSrkailSBdogLWgJRPoZunHqKQ6xa6VWQ9FoTgHV3dFC3ZFo8XTvs7Wip3lg2OvUz+A/bpXAJFRQFSm4PG1aASm/1k6dTUN0qHJ+4pm4kN7Db93qMlRd59VeXe/a3N7yQ6XBiP9zXOTNWMa85rlZCKHO0nS7rk4m2IW+vTJXVv45A9WffI4PiXC3ZFYvLJLJVc0DtpX5Vlfykof2kDWZ/T3sPhcHiPQ2WCLgoCc6Cj1Sz+kix/59DYHq2xfmuK87VLhtlZoISDqQwo0FI5FLPXkA+IpzyoQQUDmTymS6vefW535xb8wVWkOM/NcYBBn4ZMyobJpYsvkYLo7W06xVDu/vflDcV3njiRmMmj3Q8c9gvBxQA75Lkg6Nmgqf9ZmAUOSp/iAVKo8sXUX30Tn9Rhj++Cdkh8fwhELMtcAEwWbg6dAkOhOnhxJgNZ0cUzlRWPcIFyfQ0CB9trflU8MXFKFcfg4xhgaAyq0/AHODbyIEBPWOzYKGfYUcytiRZFYA3Ti2Zn0Do3f+3xxUvv+XFjYzPRwwj598ezdsERc/2AOK2ztH3FyN7+E9+V5e0NdV8gMUKoNELOEnIoPt2YWz+24fuy/C8FOb6/tE2hPld5Hy4kOK1x1qNS2cjCe/vKsrKFMn/bdOzlo1ySzlsquPqHdAiunAYBKCTeRJAzk44Z1cSQP3TBGcM917Lo9zcDAq1iaOqCYgtIxW2ock5TVPiEglJqacng+GnnKGWz32JMJRvNACvWrF7+edfhoQEZDEUBZxAIFtI44aOgDUJBmqpNcvIEi+UupNYpgvVl+R+Ayv4Ea8jyPwpUYCKBBNml9JDSU/odgFtFJ/GqotCUZNDDMJ8EaBInMxQoXlvdog/HgYVbAPfqujr/WWbDeOXw5AvovAHVQ4KKkyFtjgJkczb8JtiKjWkQnpuDqmShMz4K8rSgXHERTsYQGR19ztKJWO+R0tIPlQjnTsl/ubfmIUB+R3E8n3ub7O+8tS1F3WMjb4KiwbNc0qdwKAJLl7VvuQ23cRT4iy+S+Re3KTTIZrMPGobRIT88Dlra/XRu3t8zPf0Fmff6/v7xRG3jjXHPD9f1Yy7JXArApGtKkviZvIIp7nX0+ZXzLpydLSx7r1512uU/vPAFX2RNtFZXbzLTWTgUiBUyMWG5p8V49ir7MdlfAxVM7e3BeWW1x25qW1I4U3x036GPnr9m2UuKAmYXuwIYFMgBShBEqnJ7QdWYcFlEMRvEYei0TGbJKVxVVaaAQCBQeDu0eplf+PhjD88D9UMig0f2S9Q+ikRmmyZ9JotdehTZ1MfNRkmHSkUw2HdEUQ6vbmm94MTwiYJX/0553YIzVa8jNDYZruT6FXlghu2TixfuGG9t7OqjG5slqSnmpVjm8/uhc/HhMEYS7CCf8aBagI9xUolloZ1jq05nvujMzjfrqtRCP2ZsFdrihSc2Hz30GzZB99j01yHUUjljG0Jl4KIiaPgHg0XBf8dfeckx/pVNQSa6r4c0TWJxNZc8kIAXLygvP1MiveDgwddH2hYPeVoAEVVhfQ0JutVkwId+1cFQWFt+wUTqQVn33trqqxYP9dxo9RzlthRgGngh/AK52tLUITXX1gY8UW1bH7B45JDmlJZNxxC1EjBPHChvHx/e+2Bj4xtvbW837t935I74fHLhWcuX/MT0XM9QTeSgQFp5hud5LoWh8ttl8J52beRknMdgVyqOVCDwSqfTfAKKohTef+qhKVQcblGAiiSYli0diiZFwULReVOYUGBx118jIuqFt7qp5TtXuu6qPb1dhaD3h+VVL13vpTrLpsaawsJD3lUwRzozNU3frjt0eNOyo8cXnmhbcMlgpOh3UwyCwkWlmKaFWuxDMPhRVCI2AIPxaijE0D6XhpKPI2BnEPF07pP5yXcHJg+3d3uJwh+CnLuwZf3Y6PzlVt4mdUI6Q6q6I73TBx955BEbf+Wl/JXtCs0sy9oV9gVuYOTLkMWDpuuwSN5UMlnwUrLSjnT6dT3UfisYRop7Ih433VzhwPBrl104MXdE1rltZe3Hm3Kpz7fSVBbW1clfeCDnM14T96nonppuOjeOHhqm0llS9nGLXsfQAYZVKNKAeo6giQysnpj43mLP3n19S01h1fPIvoOXPX/NmvWtpcX7dLLKNClK0qYIDQ6RUdcA6a6E4MrHRjAYhE76JT0aFUy+5RQt3xKEEBDiP6CQRzxONkdVUhHgJm7eteGB+Pj0OL0rDKBc7vj7SSzJ9KqigSfOXLhw9db+3sKU85XKFcHfNjXddwZNxTQAABAASURBVIpm31YRm0OVpJPMZIyKsBFETg/8TvYj4bJdXXedORC/aLa2+ozRsuL9E9wOSPqDsMkMywFkLDbPuVPWhevBzbvwmaSLY5nnznq6rAKHLefK1+zr6JZ19nf2ftEDiSVPBPtkCyxpW9T5+L4dt+FvuDjOv6E1m7pu6irNgyc8E7alwSOBWTtzalWxUXDlL+vpeGh6xcJbTnBQvuIwAgxmAvkM6nLWzb1A49Fg4PNLOyc+HYrNI+BXbjmb1nHD+vaqWGk00afaNWcnMC0H3llSflsgnf2kQ+uFSY2yyMSki3Q6Dz8c1KseSgeHV2waTwxsr2957/Vr1wZu27dv75HJ8bUvPv30jWcsa39Y82zP01XQ9QCuIAI5AMG4xId0KgWXUmEuPakrOc2RiMJbsBrkPPYHIPMk83S4jD1cZPNp6qfG+h7Cmgkf8w0vj4DueQ11pfecdurSDd2x9Gl3dHYWDsm3NS15z8VWLLlsLnZ++dwsSjXAIFKHcRL3LYkvhZBtb5FdS+CqVro6rOsd3Fbb071muH3BmZOVVTsTPIrJkBcqe5b1PNuFn8ahGCjEXHkrg3xIw3BNTedzjp34uqyzsaLmq2lo5+Shw6ORyKYueVhWVf4WlruEv/qWPPmrG8uGlMNEIOD7nK74oSomFFLH0ANzc/kPrq4vWyfrnLtt26sDy1Z19SSTSHDPKcDMYD6Lcij9LSn3qkWMsyJ03XmBbSzCnFYUv/2JgwueM42xh5uafAf8xu1RK//igOfANDSkqAzJUBjzxdxdro5inLFRGh6UbBZ1nA5rJye+9lzH6rhn5ZIXbdm8WfvZtm07H9iz55zLVm0uOWPhgu/XRaN9hmd7fk7XBoGeVnZLw3ah0WvJP2wVHIcncQo5Ivn1X0FhmcKWOh+CCuRyilHpZW07ifqiaP85y5Zff/GqdTUnusee++ATR+Xv6/DTlQtfdGDZksPVY6PX1M7PoiydREB6E+LIpUD+gbrroZjHIvHhodW/WLWqcHS1rLjsLVvPOK3rhuesX88u8Zx9hx5b3dm1cSJSdpZVU7ov4QFB7pBnLZszARERkzAFpojXbqpKnbCyhWOcC5oWLu6cHH0vdRDg9AqO3/FcrFq95ncPbHvkEfyNF7v7GzGw+Tw9R1FF8RHbtWDKbXsX8BHzyOT0zSxmCngilzhjKlKMHF20PLdyGEsFVAUGg0eLG5F5xjcZLfgE6+O927dntgDu1kCgenkmcajJdl+oJ+JkskpXnoMdCkwcC/mu2F1aeuojwcCasUWLnzdRXXPntF+HURKCbqXg6+pqbOvuv/3yqcnZe1taXi3jqxsPPBJ79MiRNw3PTre85JRTzjtvw9prVy1deshj5Ow3TE8S6jLgZ5p0aZDfwvMKqiWoXAX4g7dHQdgkOM/2nJ29FQvbnjht9eovnrZ6xXld8dnmu48cfuttu3ePswruaGu7rHfNmr6lXcO3V/X2LotYcRpHEkK1qYrgtoDCeEuH7vOzBxU5Go/Ps9CUmH6ObF8O5w6MjrSVHOnfJY1M5kk4pWtoa8PAzNp0UfGp05kMsvTUGnEonoZ43kOcBrfHSl/8tkOHCof0h4dHbstBF4Zchsq9M89GTV31VDKXfoHE97eC5NnfikO2d5Pp9JugA3luOkmkFpUqmcOiqkjkPlnhTUeOTExXVry6lxNElis9hZ5GuB6t0YHNwLikrHx0aV9fIX6S9W+tCS+qi5p73amZBVEqYYjxwDg9XKq09LMzZTUNZwxN3XBJ98D2l3aP7j/twLHfrujuf0EqGlk4ks9M6EEfQtJT5XIIdfWFF84lbt5k+NM7Vq245kcLFxZ+BfrTXbse+s0TO9696/ChlQxBlHMWL1p3wZpVH7pw3ZoHVjbW9y6uqhpdXlc7s6quen5VXd38stq6ufaaupklNXXTS2vrBlfWVe9fUV91+/q2mk+es6x5VdKBsq+z+7SH9u+/6v79hwoLjWtXrKj7zdr1Vx1ZuzHfPpu4yX+0o2kpjaiIFlVMN82FLuaD/m+kqmqC6VCkMylM5B0qk+Uhy+k3qGgom0u+p6utzVy+e/dQXNevrQ0Ul5/d35+VPLp9TfvNP12xpuB5splUuRCgUipIOHnMkrfzRSWYrK695mWHhx+V9euKi++YsXPLspzespwaVZW5FFZ9c8N7O578PRRz/qab6P6m9r9vnJmf2OELaZ9zhMvVHgpWJ1gan58/d1FpxWVM4iUdx2+Jty95V18whDg3r1wql6pIpbLg6bbyCJjBir+uK29bnLKPGxNz1SHDgEshyCktW17+84aJmY8v4+CPlJdXDUWClw1XFL9ld2XZ89kMG4enuqbN8Ip53ezNaYCmChSzbSQ2i8CJo2pl97H3LJvqHz7a3nRka0vTW+9obV27hStD2fauQ4f23bPvwJfv3rPv/O1d3a0HhodqDwyPlK0xfA1nlJU1HhwZLjk8Olx2ZHS4/NDIcOO+4bE1+4bGX7K9e/TTvzty0hA8QPysrHbhduLuaVr46Dl9o0Ot3X2f9584ppelZxEVOdgupyMT8rQJMwLoDpR9uWZ0NN0p8PJZjjWes2HofkiD1GiUgdh8i2VZ54HXJce73r2us3P6SDuMgcaKxxZ1D7x67fjI1sHS0u7SVO7XIQUwOWbLUDDGE4bkotbbzt1x9L1sivWtra8bn4u/UFVo9czwCNQ5rFy+4t6dj+2UMwlz/vabJPztSJ7CkJ2Lf7yssmKbwjjEgwIPWgH6ZiZ/3N5Qfrqs99wd+7/pLlrw0zGuqGK6ipxw4eNUNTU1XbWqOvrhrpLgha0zs13ldN81kSCEY2EunUI+Wh6bNQNXShy/XrZonZacHYsmUzcVz8S+U51O/3pbQ/W9v26uqDxtYmIyWRK+Ys6iy1B1eFx5BRUPYTuLcq64mmi9ocH+pQvjqW+3TMT2vAR67sCZZ+6/o73tq7euXnzW9S0tRVs284QDEFsA5fre3vmvHzgQwx9cWzZv1ri3of5gUVn4hqUt63+9YsVVO1aevnN47ZnuSmRONExPfLukv+fMBZkU6rJZVFh5FHEcputBemXHA+mSoEExla9I1KfFYgdmw/6r1XAAtpNDJGhC57uIMU5IUT8h60h4cOXC2nCy5DHfxPTpTcTdkIyhaG6mtYiFUpiJTA7zmgF3YWvP6m27C/+OxOmL2zbv6+m5waMy5RmWKJQNq6Ohvq5vYduigjHK72cDJA3PBp6ncHi5VOZFNgMk8ozhKZBjiaNronNsauvyhqJifmLjo9tfZS9b9Mg4g+oEYyhG8/DTOjNjsc+UJq3fVduAn/44SYH4AgpsU8VgMHL3uoGBMbmDvnBq4OfFBjH5VEpFRYTnd/UjYxe0pNOFn2Ks6B5+1F9e0ZVksJuwc3CosDEXsA0VKnGXCQH/3Dya6A0quTlasmv3qk3js+9b2z30yMbxkdhLjxRbE6tWuO889ZTY1PrlwwMrFu3pW71mV8+K1btHVqwZePPkhNUUVO2N0+n5tf2Du1aOjny+puf4KcqxAwgmZxFUMzDDDhy+VcUBT6coQhXCU6C4BnTbB831IWIpqBwffdXO+ooLORr0+Iwvj+dmoYosRC6JkOEhx6kvPj5yyk9Xr66RdYpS7huc2dwpfsVAwCQTuL8V9ingLgU0fxjwlSBbXBk/GIgtk/XPo4HsPt79kEceOsKCKlfIqgIZjzfWt7zktttuy8t6zxYozxaip/AkEonppvr6F8pvlw8PAg5UunqIobnUjheuaooyG+t27D470dzQORX0QZq/IshgPYAiepVi3YAp2NID8lwV5oXAnGF2gldjbcXSkkS2RedSMk2Ln6R7T1JiRaxbls6e9UBFcMVDtRUrfUKLexSGqmuYpmear6p6Xb6heU2gNLxNZaCt6ETmZGFkkyjLZlCZzKA+kcYiltUm5uF1dEB0HAu7nV016O5di+PH1uudx9eZJ443aB3HsZABb1Myj8UOUMUNoCIqUoVwUU4Z5xMA1xmg/nDkFoVnw2OZK0ikJwrKpdN7hzwVDYoKc3a6sN/0qr6+CbOm7NNxwfYEDhvhqB8+4SKanHgpePmmp+8MuUxkLaQTGXKXdbk4MCJhjGRtpOvqsN91ql7/SH92M3l9bGp4uw0Il/wCp8M8txEsLjzWrV3/7q1bt+7Hs3w96wol6esbGrqzoqLqS15huOxCcpZ7M7GUvfD+Q/2PyzoShuYzyxNN9V3j9E7xjENH5UOCFjeXI6NsFyEKXXNYU+jwDEi9A1F6Xl7Q06jIahpmGsqWjNZXfDMZDMBO2Gidyx5cHE8eMGem10VojV7WQZzKuisY+W1FR/f+WVV7bM4Gpvw2RFvF14oWNGzLUSkT3BvTGPw7ng1F9eBTbNipBLyMDcNREOYwIvAQ5RRUXlQCw/J4WC3g2TYyeZuyUpHhNJ1niETHC1XSbgLCcwCC/HvFHKdeS3HhEbdGM9OoKPlUDlGoeLSp8uXgFfPlrp0vDcbTAQ1xG5ih0gR8GhoM5fUsRtRxhsr9RjzEjdRAKAjNB8zlgEnS4bY04V4nW/76J4P2jo7Re0YT+SWa34AgLsEwgMtwtLQv+NXuvbv/09mpxP1sANn0bKD5rziGJ0c/XF1R+Ssh2IU0VzkgM4i8qrY3lkUfuYgrl5cxuN6w++jC/KKF+2cDPswyvnG55PUzTWMCt3WgUCm4N4iIk14ge9kzPHl0KlDGqdSAbhjfWNc5enzd8YF3dYQC6636+h0BKkUxV3fyz6wUzgN+w0SgtGzPqxjMyvZHLe+qfFXxfemorzrSOfR+6KFzFZ/xbU0REGR8jorsUfD+gM52ISfc0vi7aEvTnpKiCD2FjSw3ixLxGfjNAKhTQCg4lqvk07PUBM/XqHtwLcDKgpuuKFwu8dkaIMs8bgV4rGBzBB5cGIx3QixYoBpf3rOksXrD8cTMcTPwsWlHhcnD9WAwACeegTY+vWq8qeTlEZHdkYnNFcmjnBRjqAQ9Xq7Uh/mWOtyfiAffwnFK3lbrgfsTjthocjc9l82Dsz1oJ4j6gwd6O068CH+nS/k74S2gjZRFXl5dWbGHhg2aJcCYxaYURqZjZx2dmbmnUImPtdv3rsksqX00HvUhz2mAMoOiBeBpgtZvQc9l0RybvmRHW1uEUaZzvKr58nFFg5lx3z0QKS/8sO+Csek9LUNDmybK/O9M0CNIhYSuI5nPwtW9O9kNvrp5c9l4feN3pkpbnresPzV+sLIyODk1/D3Pst6W4fQppwOVfeYsD6NxC3NB9d9Cx3su8h87sX7eTv/KIv1eEFBKDCSUPBL0bLOmz6iaQEoAbqyhPjtjK/RKfhhQ4dMU2KoKmziZDShgLiCoSK7iwhHUPFAn6X69ntGGgG28jZ+4pG/qWxlfEbLzafg8FZWagTIGgaHx7M/UpNWma0Ceiw3Hb2KUJwfzDU29d4UzgbdwtSjb7+ru+U1GaOfR6SObyUEsz/FVAAAQAElEQVTy33aAxpqqY0vLqwrnrLLe3wM4xL8H2pM45d7G6PjAelVBtyAD4Lpkso/jUzAWi59dEvDtWtXUVIipTtl9aPNMQ/X1w5qOJHeJ054GmyAYH8mgUxmdbwjPzn5CYr60c9ePc+UlF6eLow9XLVr88UcXrvymzJcgdP0ef1iN+3w+JNMpZH1A3Mj9RJa9/5FHpl+94+Db1u3daz1UVXWxP5dJZufnXwsqYJhrbpf0gQIyg2HMm0B3T/yHsp2EadP3sxjz0pzKMvSkjkdlUDzMpFOlD3MLQ9YZsu0bfMUVsGwVtiWgCgOeKwCCClDRCABkbOSR8y4zc46NDKdZi56oa37+43jy0kzfNw2hIptIwRAmihSTUy9A/UReA2I8nxnkKhkrVjyydO/x1vduH87In6NUmfoDGaGfH89TkQCIwn8KDJ8+Ub9w8YrHT5xI4O94cVh/R+xPoi6vKD41GggN+miils25gPkeuRpPZ9cPDg9u21RXV8IsnLHv8FsnW5vfOejTMSdo3fRCQjFg5zwEhYYa6O/bUVP/dll3/cDA3fWjo+eYux8rO6vz4Dtl3t2cRkPxzL2wPMboOeQp/FS5OXXECozK8qfglyvWfJLT4l3B9DyKDMCl9YJgCB9XYSYyCGI2WvXNswFO1CdbtQ1N/XygLIxZ5nDhxukPCMBFhBwM6k6LrOXqakeaCwAr70D3B5DnMYhKZTIcFUZehcq3y/E4BA8qW6vsy8FkAJhd23bWUF3Rm/DkZdiZCkUBDDUImzjSuoN5LYeUqmBONTAdLUFs4cJr23fsJ5mAnOa6D/bdE89b56Y5GI+gwCPHPc7HoemFixac+wjPSZ9E/3d7keS/G+7fIx4fH5+qbqpeGoz4uyg+0Ghg0yuQT0ja7tIDw8PTC8rLV4HXc/ft+tax4uCCVGtzfJorl3nhQdN9XDUJKNwpr07PfutwfUnv/Q3Fp9+9oS0CXj9Zvrz4wYqS97eMj2VDWas1m3ShQMDRgYTh+97rnwxSWbVwh33Bt/sp7HLOHXRgCFKpPE5zDjeI8txmSLkW7Irigte7e+VpL//dkrXVsmHW77/Z4A4/qxeCXJUrJyWbRURT18lyuqD9hqbDMAzkchl6E6UQtyhcOdKZQaFbsgkWqQPfso3LR7Q0+p01W/dvfcfezu/zE7e21C23Z6deLmMty6VqKDoUEjlLzZ/wG0g2NqGruPh5Z+zYW5juV9VXrd/Z3Z2Zs71NXHwShQNDU6lONnyGMbZk6eLFBw92HGXB3/1W/u49PNkBp79kSVXFqf5wcMChbVLe5KkAfCY4eYjRqal9q6rKnyurv7Gnp/t211o00Fi3e4zCyHsO/MEQ5CZniZdDWXy2uTERe6x1YPLE4eKiY6sHhmYXZqyvRHJZ+KgoUe475bMuctznsZToPonz7rbG1b9be1Ix8un0bSZxankbpg14aXARb1Jxdeh+gbyWuueCA8eo/MDyiHLdAt0pBLG+nHILUjYMT7Cuj1ObQLGpIWqIwh6RmrW7QgFfKs8Vo21Z0FTBYTpUJJcknARXceEJl/kudE6xIS4aihL2KWPl5S/rrSg5/3h56UeXj4wdqnDBoFyHQqXP2RZmZmMQZVFMNdTM3mPlm192rOu3RIrl9W0vOD40uzOjmsLWTeLlWDwCPZRpqpNtSxacv2vXrhlZ9x8Byj+ik6f66OQKJJFINZVVVx4ojFxROS3QXmnRrCN6xqd+W1NeUviHGT7Ks7+zd+87pTsafkW8sQb9GoNk1UWey/gSRUGNA5RMz1e1pTOL61NJFNs5RBgEmxSWkydOxhiOpmNiLlU4S1ykWe9qSI9/gP3A0pyvQIdUa3ArCib3wmyP3owKNs9Yz1dZ8W1Z74YNS16x6+iB0qzqvUZ+W8L3cFll/VHH0ZDIWTD8Pq7mbHj5/AXXr4V+YU/PpC8aHcgB8BNnjqtNqUCO4sJVAFuQaM8FAytApuFR2TwkJ6fWBGemf14yOXtf6dTMZ+t57lJM+tNUpCzfk2wfKy/FUVX98FkHe0uvPN7fD171pVU/6Bwa/pUFVWS4kk5RiXWfwZKCMh5f29TSdvDgwX+IZyp0ygeHyec/+J4enVhbUV23Qwbp0vvnaU30UnwylpiZf6MJPNb+ZFz1ktHZn//ETdZOLK4/Nl1WhDS3HnJpDUh6KDN0aHkbPtWDUGzYjgVdV5gG5nMuRMToe8H0dEIOr8TVLgu5zhUy/aIDB/oTWq4vq1LIhFwqC6GpVDQTMbMIA0cH75H15qKVe8TqtZfs82ufld9n9/dnR3jkGGdM5/gUTtdpCEFSEqnVxZm6sKzTE5+b9aJFkH9wKqefnOIho3mQbznFa/RKBpVW1pXfFg+xS6NBmH7Q6wHRYASGL4Q0FSStA0M8+/NWLvIeUNVVLxyc+ZJst6GkJFIGPDo/M3WFSq6pNA1VUQDhIqcCrl85Ud3QvP7vHYDjj1yk4o/k/v2z3Mnh4U01dU3XAeSA45EtKIDr2tBV4/RexlWtxZF3SFI+dGJ69LSdx9r3ee6ZmdbF/aP+YmQCRYhzg9OlIgjhQaGgdAFkkzZUxjmCwtBVbcet5eWheysrK+J9Ixpi2aIbFpyM1QK+yNUOR6/z+MYMGshz1SYPVWd07R1nA7bs9733PtL94gcfues1T+wtTC8ybzCX/nq+uAyebsJkgMxuYKfoI3LKElnulRd/LR71fyRbHFirFQevsCEKDkmWSRBCheCYFQ/SlhAKsO8sFZM8AK84z/1maCCTET/SbY2Yqql518Lde5X3jUwWfpi3tLrkPUdmZ2MetDOJgj6OClQIGly2BoqLi+9wM+5iGWIUMv7BD7L0H9zjH3Q3OtD7jsbK5jfpwqSNAeQ1GHYgz2W5C0WMzM1/s8Fv/GxhGDRI4E1jc4/dcmBv68Gysg8d9RdhMlyMWSiwaZ0a+elXKSTuX+XdIGxLA2aTrzzPcA+fE/Y/ELYBNQ2UJsSp4JWdztzpWj7MZ4CZVB4up9Op7CySEeMuFuORmpLzD9ZWf/RgceVHtlXVvOO2RdWvlvnPmZrq7iLqLDd5zJwC0wHCqokaNVxQqNUHDvxqUf/gF2rH4vtGVOdh1xEw8wp0S4Xq+WBzrBZBcH9JJU3ZZB6ChqE5Knz+IBK6h76gQP/i+tvuDWmVm7v6CouDzdxeqdGNG7vHZq/JCogUvV4K9HyCvl3nnpZrYd36VZ+bGZ54Mf4bL+W/se9C1wPDnd+vKi1bXlIe7c9ROFxsQVE02hwVBSomM/mXTyQw2RgxPt7eDmMLDfLlPUe/vHlqUBzyBd87GAligrvr0/QW0+Rtjp4j7ygIBMIIMHBRxmeaMj39y0OMr4JCwfJw9Ooj1bUfK7b1+mh51YzgZlA4FOZWlIugonz54r6xgesBfSGcn9dMT322KZf7XPXM7DdbYombf1WCekm0sOy3maRR40pN0QxociGQybxxW9mi8APNFZUPtlVccHBh2Scjpu82lVOXSu+jcX6jzkIIeizl5ERlKQanWT8ypHVI0XGQu49DdRVf7SgONZ23tfNlb3uiZ3Lz5s3a2tLGz+zrH5mds5zLSS6oe8hyhempKmhH0Axt7swzTj1rz64DH5P0/XeC8t/Z+VN9D00MHXGCWF1bV/crGi1yXNl5ZJVNC7RYKQWI8fn8pwePYWdbpLjw2yrweulY7zV7g6GSQyXhD52IlKJXD2Ca+VzcwWNALBXIT0XjhjmEQbO256EMdJo1mdhnwkhty4wOlAaEA4OCNBiVF+fc+EhQO+88E2+wx+PFIb8GuEmU+jxUcINxZU57ZR/ga07EerxMAi6VNOsBBufaaGJqQ3swvq1+ena8YWzy3rKR6S3+8dg6nQPSTUD+6iDPXXudh5OeaiHm5DGjCExzS+QYPdZo+9JrDy6qqzjzxNAH3nhsbIDDwKqmqted2LXn4LGZoY/lwQhJKiL7gyP79NEIHNTV1u0/d/OFrVu3PrEV/wTXP4VCST7E+mOx4eHhF0VLS1+sqMqkzCuAqoIyARmKjIdVQ4nYTQGhuBWRSOEnH/82ODh3Sc/olzePT4n+ysoLM8sXPXjCB0xHwxilwHLc9U65gNx60D0HpRSIL5WC1BXDVKFS4Txau8Jp03DxuWDKvr/CwberQ0ZBKQ0GSSYlWETXWW47X/IDmVLHvq/EF4AnSCH70G0XRiIB38zMihZ6wTZVR3GGmpcDgiGTtGuI0zM50QhG2OQE+xsuLkZ+6ZLe8Ybad/0uMalu2r/33Vfs755iMVoaqy42DIwe7h+/YTadaj85fhc5xpcuvSLoHa183luzet27yLM1v/3tb+dku38GUP4ZiPhDGmIzM3e0tba0VddV3Ueb5EKQ2sAKpmFC8D/b86gcrpidn/9dEdRH24ORV7FYEPCKvr77lu7Ycd4DFf7yHTVFH51ob0kfY/1cOIp0RsDLAn7GO7pQIYSA/AVAltFxgiorvZqP02cgbMKgFmVSeXoAj21sKJbDNJ2V7aGyOAJ5eG0xZrF5wm9SwD5OZyW6AR+XdU6C7bi1YSoKDNPAZDKHOd2PMV8RDqs+jLcuxdTKU75+oHpBS8ueA62nHT/yzS1ELelvrwq/LmDisfHpmbvcPKjTVF8ICKFCbj8IGgBXH6iuq957+hmnVe7dv+ubst0/Eyj/TMQ8RcsJnjeNDY9eWFFdc2EkEunz+/3I8WyKYoWu6aCTgapqtHycOZzJ/iQAOFWBwL8tLgsvlDi2dI5Ov/JQ5+dP2XskuFOx6ncKXDHT3HRDtn0pjisGejQ/+s0QeqFgnB4mE/Rjju9ZeoBZ7kXlNQ3BkmIKUYPDfmxFhz8chBbwYyo+jyRXlHm6kLSiIklly7Gcu9QYYttsWSkGdRMjkQiOGT6MVlZjbuGi/UM1dVftcLHy1P27xXO3P37lmw7t6pO0rm+rWtpU6X+PKuAen07ckLFweoarRkMYyHLMAgo8Fbw8KKY+tensM189NjC07rHHHit4Mxb8U93/lAr1FIcmR0fvi8fjbeFw+AOmz59QNQM5xjuqZnIl6CLLqShBU+ZhqYhn09eNzSaO1/tw66Kg+mriEAS8azYz/OLZ2A1Leruv+ObRI+ptPr3+iYaGt46u2nTY2bAZVusCDNGLZUvLMMLgOVdUhClqbH88gXnuPczTA83kHYyl85h1gGwgBB7nsI6LVDCIOW5uTvp8mCorg7N6OfpbGjG6Yd3Eo011n7qnPLLwh+Ex35J9u9dcePzwFz8wN/n7P8JYEQ1fXufXbt/TO761P5a5husI4RI/tRim8AHslyqEHFwqtcgsW7fmc2esOaVm+wNbb5Hj+meFf2qFepJp7uTk5Fez2Uh1aWnplRDCy3MHWZbpPhOeBp4LAjI4zrgQM1lcOp5ybg4Dbm1A/UWNX31lnYnCb6m2MG/L7OzwFcc7rj/zkd+tWPHo/WLxkQ6xQ/NqH8lmzu2IRt4yVFXz0Znmtq+7G5C62QAABepJREFUa9bcZq1c+YS9avVRd/WaI/aqVYdjCxYejC9e8MhAdcVP5pcsuu54JPThAz7/m/cGzPPuz+eW/Xj/YX3Vzn3i1Ie3Vb1m35EtH+wd7vpmN3WCxLaXlLQ3BH2vqfEZtwQBryeWuHEub7/IEyih62ENA4KDUbmydRnr2TQWhbHYuvUbvrtoxcqWI7v2feyRf8DhLgn5m27lb2r9D208kZqYGPt6WVlJpLq29vOaZk7nefxBAwY4CgpGWjLyEOCqEA692UTaeclkxr1lModOP8QjnBp/WG/4X95iRgoK9hT575xOj75pJv7Qq8emv3v6oSOfX3/o8JULdux62ed37Nj8/p07V35g9+61N+3evWbZwYOrlu/Zf/aZx7svW7vnwDsu6B/80gumJ7536cTEg++YnT1KhZXxcwHt4nC4tCEafE2pjm/7gEeH47NPTKayP57M5l/JbSk4OpCmRxJ0TWrGRcgxYEJFSAmgOBjNti9b8eMFm9aW7N69/S0dT/5tXwHxP/lD+Sen77+QNzU1lRwbGfpoeUVxY0ll1RVmuLgbhSlCgwejAA50ZG02Zb4NDbZqIgNxVhbi9VN27mcjuflOKpdXWxJ9oKIs+rXK2pIrmxsqL6mKhs5eWFOzeEVlZXAzoH0XsG4DHEL+D5WFmJW6ujp/C2O2xXVVmyvD4ee1VVde2VRZcXVR0HyEsbPXk0xMj8RSP5638VahK2emHBR5hsbwn0g9FOiTRqApJu1BZb4Fn+KbaWxuemtdbUP9gSN7Lz+8bdsc+/ofdSv/o6j9A2JHR0fTs+OjN+TicwuKo2Urqyob7y2LVsYUWnlQBKhGKhRKTLBN4Qf6isfwxOPU6NKLoTAPTczFzp2Lp947MRK7enQsfudULPnQfCp7ZGB2buiQYXRx2jxYJLC/WIj9QWA/zw73hwQOhBR0xsdGBibjqf29o+MPTyYSvxmcnbq6f2Lyyngqd1beBbjLAKGonI4V5CxBR6oglwfzDIDUgSs/CA1FleWJ0tqqnbWNzafF3HjZwZ6D1+/t3Cu301jvf96t/M8j+b9SPDc5fGh8vOc5npKprywvf2OwKPgTj77Koxg9Vtd0nc8nh6oygNEAzjRwqG225cDQTMgfwwEKV3ExNeu6xfF8vikNrOAZ9KocD2a5pbQqlrdWMVZbmXPRmnG8cs5YAbnxytgdeWqRIG7OuFCJD9AKyuRRwQWnX3AlCBZ6KispildcWrp1wfKlbzWLAs3jI/0bewaOF/4MH//DL+XvQv9/E1I5HQ5PDfxgIjZ6mYWsCJRGz6uur/lpSXlZT2l5JXRuFdBNoQBUHs9VKHYFgrvW9CVgAXzcO8o7NuWvgttLBUjzW8iddioinQpUTVBdAZvHKooLCGqVkJrrME0FkkoqpJYxyAan4WCkxKttaBlqaGu7q6Km4iVw8src2PBZXQcPXj9y/PgM/hddyv+isfyXocRnJh4cGxp41eToUFsuNb/Us+yzTT3wrlAgcr+ARhVQQH2AIgwqiEJQkeK85EEBHRc86XIMejcBWJzDZJ4EV9FB3YHtotBeo7L9vnPPo8fTEQz4H6ooK/lMWVn0HA3OsuH+Y82D3ccumRwYuB3/i6//1Qr1h3JLJpMdtp19JJdLfjOZjF3guXKtZQc0+BdnXO+1wUjFZ6Lltb+obWi7q6GlfWtDa/uR+pYlI02ty8bblq6baF60cnzBsnWjjQuXDVbUNh+oqmt9qKKm+dfF5fW3eVrRp81g5LUe9FM4zYbzdkYkU7PnTk6PfGJ6euTh2dnxDqCgg3z9777/zyjU04gxk0PiBJC9aX5+/BOzU4OXjgx2XjLYe+Sswa7Dy4e6j9T1deyv7j68p6rv+MHqrsN7agdOHGka7juxeny459yJ0b4Xzk4NvSyfjn0ym5q/iX5sN/tJEv7P3v/XFeqvETynyr+m2f+NNv9SqP8bcv6HjfJfCvUPY/X/jY7+jEL932DCv0b57HHgXwr17PHyX5jIgX8pFJnwr/vZ48D/AwAA//+n5OLhAAAABklEQVQDAOA6PXBzDHOSAAAAAElFTkSuQmCC" class="cover-logo-img" alt="Logo">
            <div>
                <h1 class="cover-app-title">RyuExam CBT</h1>
                <p class="cover-app-subtitle">Computer Based Testing System</p>
            </div>
        </div>
        <div class="cover-badge">EDISI TAHUN AJARAN 2026/2027</div>
    </div>
    
    <div class="cover-body">
        <span class="cover-category-tag">BUKU PANDUAN RESMI (OFFICIAL MANUAL)</span>
        <h1 class="cover-main-title">PANDUAN LENGKAP<br>INSTALASI &amp; OPERASIONAL<br>CBT UJIAN SEKOLAH</h1>
        <p class="cover-main-desc">
            Buku panduan komprehensif implementasi sistem ujian berbasis komputer (CBT). 
            Meliputi instalasi jaringan lokal (LAN/Offline/Semi-Online), hosting cPanel/Cloud, 
            serta panduan praktis alur kerja Administrator dan Guru Pengampu.
        </p>
        
        <div class="cover-feature-grid">
            <div class="cover-feature-item">
                <div class="cover-feature-bullet"></div>
                <span>Instalasi Jaringan Lokal (WiFi/LAN Offline)</span>
            </div>
            <div class="cover-feature-item">
                <div class="cover-feature-bullet"></div>
                <span>Instalasi Server Hosting &amp; Cloud (cPanel)</span>
            </div>
            <div class="cover-feature-item">
                <div class="cover-feature-bullet"></div>
                <span>Panduan Operasional Super Administrator</span>
            </div>
            <div class="cover-feature-item">
                <div class="cover-feature-bullet"></div>
                <span>Panduan Guru: Bank Soal, AI, &amp; Koreksi Esai</span>
            </div>
            <div class="cover-feature-item">
                <div class="cover-feature-bullet"></div>
                <span>Anti-Curang, Reset Login, &amp; Live Monitoring</span>
            </div>
            <div class="cover-feature-item">
                <div class="cover-feature-bullet"></div>
                <span>Cetak Kartu Ujian, Daftar Hadir, &amp; E-Rapor</span>
            </div>
        </div>
    </div>
    
    <div class="cover-footer">
        <div class="cover-meta-group">
            <h5>Diterbitkan Oleh:</h5>
            <p>Tim Pengembang Sistem &amp; Kurikulum CBT Sekolah</p>
            <p style="font-size: 8pt; color: #cbd5e1; margin-top: 2px;">Didukung oleh Apache, PHP 8.x, MySQL, dan Progressive Web App (PWA)</p>
        </div>
        <div class="cover-meta-group" style="text-align: right;">
            <h5>Status Dokumen:</h5>
            <p>Versi Rilis 2.5 - Siap Produksi</p>
            <p style="font-size: 8pt; color: #cbd5e1; margin-top: 2px;">Semua Hak Cipta Dilindungi</p>
        </div>
    </div>
</div>

<!-- ========================================================
     HALAMAN 2: KATA PENGANTAR & RINGKASAN SISTEM
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>KATA PENGANTAR</span>
    <span class="section-tag">PENDAHULUAN</span>
</h1>

<p>
    Puji dan syukur kita panjatkan ke hadirat Tuhan Yang Maha Esa. Perkembangan teknologi digital saat ini telah mentransformasi dunia pendidikan, khususnya dalam pelaksanaan evaluasi pembelajaran atau asesmen siswa. Sistem <b>RyuExam CBT (Computer Based Testing)</b> hadir sebagai solusi terpadu, andal, ringan, dan modern untuk memfasilitasi ujian sekolah mulai dari Ulangan Harian (UH), Penilaian Tengah Semester (PTS), Asesmen Sumatif Akhir Semester (PAS/PAT), hingga Ujian Sekolah Berbasis Komputer (USBK).
</p>
<p>
    Buku Panduan ini disusun secara sistematis agar dapat menjadi acuan teknis dan operasional bagi:
</p>
<ul class="checklist">
    <li><b>Teknisi Jaringan &amp; Proktor:</b> Dalam menyiapkan infrastruktur server lokal (LAN tanpa internet), konfigurasi router access point, maupun instalasi pada server hosting berbasis internet.</li>
    <li><b>Administrator Sekolah:</b> Dalam mengelola master data siswa, kelas, guru, keamanan anti-kecurangan, cetak kartu ujian, dan pemantauan ujian secara realtime.</li>
    <li><b>Guru Mata Pelajaran:</b> Dalam menyusun bank soal, mengimpor naskah soal via Microsoft Word atau Generator AI, mengoreksi esai secara digital, dan merekap nilai akhir.</li>
</ul>

<div class="callout callout-info">
    <div class="callout-title">ℹ Keunggulan Utama Arsitektur RyuExam CBT:</div>
    Sistem dirancang dengan arsitektur <b>Hybrid Native PHP &amp; JavaScript Modern</b> tanpa dependensi framework yang berat. Memiliki konsumsi memori sangat rendah (low RAM footprint), mendukung Progressive Web App (PWA) dengan offline caching, dan dilengkapi fitur penguncian layar (Anti-Cheating Kiosk Mode) yang mendeteksi segala upaya perpindahan jendela browser siswa.
</div>

<h2 class="chapter-title">
    <span class="num-badge">⚙</span> Spesifikasi Kebutuhan Sistem Minimum
</h2>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 25%;">Komponen</th>
            <th style="width: 38%;">Server Jaringan Lokal (Offline)</th>
            <th style="width: 37%;">Server Hosting (Online)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>Sistem Operasi</b></td>
            <td>Windows 10 / 11 (64-bit) atau Linux Ubuntu Server</td>
            <td>Linux Cloud / cPanel / Cloud VPS</td>
        </tr>
        <tr>
            <td><b>Web Server &amp; PHP</b></td>
            <td>Laragon / XAMPP, PHP 7.4 s/d PHP 8.3</td>
            <td>Apache / Nginx / LiteSpeed, PHP 7.4 - 8.3</td>
        </tr>
        <tr>
            <td><b>Database Engine</b></td>
            <td>MySQL 5.7+ atau MariaDB 10.3+</td>
            <td>MySQL 5.7+ / MariaDB 10.4+</td>
        </tr>
        <tr>
            <td><b>Spesifikasi Minimal</b></td>
            <td>Intel Core i3 / Ryzen 3, RAM 4 GB (50-100 Siswa)<br>Intel Core i5 / Ryzen 5, RAM 8-16 GB (200-500 Siswa)</td>
            <td>Shared Hosting (100 Siswa)<br>Cloud VPS 2-4 vCPU, RAM 4-8 GB (&gt;300 Siswa)</td>
        </tr>
        <tr>
            <td><b>Klien Siswa</b></td>
            <td colspan="2">Smartphone Android / iOS, Tablet, Laptop, atau PC Lab Komputer dengan Browser Chrome / Edge / Safari versi modern.</td>
        </tr>
    </tbody>
</table>

<!-- ========================================================
     HALAMAN 3: DAFTAR ISI SISTEMATIS
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>DAFTAR ISI</span>
    <span class="section-tag">SISTEMATIKA</span>
</h1>

<div class="toc-container">
    <div class="toc-part-title">PENDAHULUAN &amp; SPESIFIKASI</div>
    <div class="toc-item">
        <span class="toc-title">Kata Pengantar &amp; Gambaran Umum Sistem</span>
        <span class="toc-leader"></span>
        <span class="toc-page">2</span>
    </div>
    <div class="toc-item">
        <span class="toc-title">Kebutuhan Perangkat Keras &amp; Perangkat Lunak</span>
        <span class="toc-leader"></span>
        <span class="toc-page">2</span>
    </div>

    <div class="toc-part-title">BAGIAN I: PANDUAN INSTALASI &amp; KONFIGURASI SERVER</div>
    <div class="toc-item">
        <span class="toc-title">BAB 1: Instalasi pada Jaringan Lokal (LAN / Offline / Semi-Online)</span>
        <span class="toc-leader"></span>
        <span class="toc-page">4</span>
    </div>
    <div class="toc-sub-item"><span>1.1 Topologi &amp; Skema Jaringan Lokal Sekolah</span><span>4</span></div>
    <div class="toc-sub-item"><span>1.2 Langkah Instalasi Server Lokal Menggunakan Laragon</span><span>4</span></div>
    <div class="toc-sub-item"><span>1.3 Pengaturan IP Statis (Static IP) Komputer Server</span><span>5</span></div>
    <div class="toc-sub-item"><span>1.4 Konfigurasi Windows Defender Firewall &amp; Port 80 Apache</span><span>5</span></div>
    <div class="toc-sub-item"><span>1.5 Konfigurasi Access Point / Router WiFi Ruang Ujian</span><span>6</span></div>
    <div class="toc-sub-item"><span>1.6 Pengujian Akses Siswa &amp; Troubleshooting Jaringan Lokal</span><span>6</span></div>

    <div class="toc-item">
        <span class="toc-title">BAB 2: Instalasi pada Server Hosting (cPanel / VPS / Cloud)</span>
        <span class="toc-leader"></span>
        <span class="toc-page">7</span>
    </div>
    <div class="toc-sub-item"><span>2.1 Persiapan Domain / Subdomain Sekolah</span><span>7</span></div>
    <div class="toc-sub-item"><span>2.2 Unggah File &amp; Ekstraksi di File Manager cPanel</span><span>7</span></div>
    <div class="toc-sub-item"><span>2.3 Pembuatan Database MySQL &amp; Pengaturan Hak Akses</span><span>7</span></div>
    <div class="toc-sub-item"><span>2.4 Konfigurasi config.php Lingkungan Hosting</span><span>8</span></div>
    <div class="toc-sub-item"><span>2.5 Pemasangan SSL HTTPS &amp; Penyesuaian PHP Limits</span><span>8</span></div>
    <div class="toc-sub-item"><span>2.6 Troubleshooting Server Hosting</span><span>8</span></div>

    <div class="toc-part-title">BAGIAN II: PANDUAN PENGGUNAAN ADMINISTRATOR</div>
    <div class="toc-item">
        <span class="toc-title">BAB 3: Hak Akses, Pengaturan Sekolah, &amp; Keamanan Sistem</span>
        <span class="toc-leader"></span>
        <span class="toc-page">9</span>
    </div>
    <div class="toc-sub-item"><span>3.1 Login Administrator &amp; Keamanan Akun</span><span>9</span></div>
    <div class="toc-sub-item"><span>3.2 Pengaturan Identitas Sekolah, Logo, &amp; Stempel Ujian</span><span>9</span></div>
    <div class="toc-sub-item"><span>3.3 Konfigurasi Kebijakan Keamanan Anti-Curang (Kiosk Mode)</span><span>10</span></div>
    <div class="toc-sub-item"><span>3.4 Prosedur Backup &amp; Restore Database Berkala</span><span>10</span></div>

    <div class="toc-item">
        <span class="toc-title">BAB 4: Manajemen Master Data &amp; Administrasi Ujian</span>
        <span class="toc-leader"></span>
        <span class="toc-page">11</span>
    </div>
    <div class="toc-sub-item"><span>4.1 Manajemen Data Kelas &amp; Mata Pelajaran</span><span>11</span></div>
    <div class="toc-sub-item"><span>4.2 Manajemen Akun Guru &amp; Hak Akses Mapel</span><span>11</span></div>
    <div class="toc-sub-item"><span>4.3 Manajemen Data Siswa (Input Satuan &amp; Impor Excel Massal)</span><span>12</span></div>
    <div class="toc-sub-item"><span>4.4 Cetak Kartu Peserta Ujian, Daftar Hadir, &amp; Berita Acara</span><span>12</span></div>

    <div class="toc-item">
        <span class="toc-title">BAB 5: Monitoring Ujian Realtime &amp; Audit Trail</span>
        <span class="toc-leader"></span>
        <span class="toc-page">13</span>
    </div>
    <div class="toc-sub-item"><span>5.1 Live Monitoring Aktivitas Ujian Siswa</span><span>13</span></div>
    <div class="toc-sub-item"><span>5.2 Fungsi &amp; Prosedur "Reset Login" Siswa Bermasalah</span><span>13</span></div>
    <div class="toc-sub-item"><span>5.3 Fungsi "Paksa Selesai" &amp; Pemantauan Log Pelanggaran Layar</span><span>14</span></div>

    <div class="toc-part-title">BAGIAN III: PANDUAN PENGGUNAAN GURU PENGAMPU</div>
    <div class="toc-item">
        <span class="toc-title">BAB 6: Pembuatan &amp; Penyusunan Bank Soal</span>
        <span class="toc-leader"></span>
        <span class="toc-page">15</span>
    </div>
    <div class="toc-sub-item"><span>6.1 Membuat Bank Soal Baru &amp; Parameter Ujian</span><span>15</span></div>
    <div class="toc-sub-item"><span>6.2 Mengenal 5 Tipe Soal (PG, PGK, B/S, Jodohkan, Esai)</span><span>15</span></div>
    <div class="toc-sub-item"><span>6.3 Editor Naskah, Gambar, Audio Listening, &amp; KaTeX Rumus</span><span>16</span></div>

    <div class="toc-item">
        <span class="toc-title">BAB 7: Metode Cepat Impor Soal Massal (Word, AI, Excel)</span>
        <span class="toc-leader"></span>
        <span class="toc-page">17</span>
    </div>
    <div class="toc-sub-item"><span>7.1 Impor Naskah Word (.docx) Format Tabel Standar</span><span>17</span></div>
    <div class="toc-sub-item"><span>7.2 Impor Massal Otomatis via Generator AI (JSON)</span><span>18</span></div>
    <div class="toc-sub-item"><span>7.3 Impor Kunci Jawaban &amp; Bobot Nilai via Excel (.xlsx)</span><span>18</span></div>

    <div class="toc-item">
        <span class="toc-title">BAB 8: Penjadwalan, Monitoring, Koreksi Esai, &amp; Rekap Nilai</span>
        <span class="toc-leader"></span>
        <span class="toc-page">19</span>
    </div>
    <div class="toc-sub-item"><span>8.1 Mengaktifkan Jadwal &amp; Rilis Token Ujian</span><span>19</span></div>
    <div class="toc-sub-item"><span>8.2 Koreksi Jawaban Esai / Uraian Siswa Secara Digital</span><span>19</span></div>
    <div class="toc-sub-item"><span>8.3 Analisis Butir Soal &amp; Ekspor Rekap Nilai ke Excel</span><span>20</span></div>

    <div class="toc-part-title">BAGIAN IV: PANDUAN SISWA &amp; FAQ PENGAWAS RUANG</div>
    <div class="toc-item">
        <span class="toc-title">BAB 9: Panduan Siswa, SOP Pengawas, &amp; Troubleshooting</span>
        <span class="toc-leader"></span>
        <span class="toc-page">21</span>
    </div>
</div>

<!-- ========================================================
     HALAMAN 4: BAB 1 - INSTALASI JARINGAN LOKAL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 1: INSTALASI JARINGAN LOKAL (OFFLINE / LAN)</span>
    <span class="section-tag">BAGIAN I: INFRASTRUKTUR</span>
</h1>

<p>
    Instalasi jaringan lokal merupakan opsi yang paling banyak digunakan di sekolah karena <b>100% bebas dari ketergantungan kuota internet</b>, sangat stabil, aman dari kebocoran soal ke publik, dan memiliki latensi super cepat (&lt; 5 milidetik).
</p>

<h2 class="chapter-title">
    <span class="num-badge">1.1</span> Skema &amp; Topologi Jaringan Lokal Sekolah
</h2>

<p>
    Prinsip topologi lokal adalah komputer server sekolah berperan sebagai host web server dan database MySQL. Klien (smartphone/laptop siswa) terhubung ke server melalui Access Point (AP) atau kabel LAN dalam satu segmen alamat IP (Subnet) yang sama tanpa memerlukan modem internet:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num">A</div>
        <div class="step-content">
            <h4>Komputer Server (Pusat Data Sekolah)</h4>
            <p>Berisi sistem Laragon / XAMPP, database MySQL <code>cbt_ujian</code>, dan aplikasi CBT. Server dihubungkan ke Switch / Router Utama menggunakan kabel LAN CAT6 Gigabit.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">B</div>
        <div class="step-content">
            <h4>Router / Access Point Ruang Ujian (AP WiFi)</h4>
            <p>Memancarkan sinyal WiFi lokal di setiap ruang kelas (contoh SSID: <code>CBT-RUANG-01</code>). Satu Access Point kelas standar mampu melayani 30 - 40 perangkat siswa secara simultan.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">C</div>
        <div class="step-content">
            <h4>Perangkat Siswa (Klien Kuis)</h4>
            <p>Siswa menyalakan WiFi di HP/Laptop, menyambungkan ke sinyal <code>CBT-RUANG-01</code>, membuka browser, dan mengetik alamat IP Server (contoh: <code>http://192.168.1.100/ujian</code>).</p>
        </div>
    </div>
</div>

<h2 class="chapter-title">
    <span class="num-badge">1.2</span> Langkah Instalasi Server Lokal (Laragon)
</h2>

<div class="step-container">
    <div class="step-card">
        <div class="step-num">1</div>
        <div class="step-content">
            <h4>Unduh &amp; Pasang Laragon</h4>
            <p>Gunakan <b>Laragon Full (PHP 8.x + MySQL)</b> dari situs resmi <code>laragon.org</code>. Pasang pada drive <code>C:\laragon</code>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">2</div>
        <div class="step-content">
            <h4>Letakkan Berkas Aplikasi CBT</h4>
            <p>Salin seluruh folder aplikasi CBT ke direktori <code>C:\laragon\www\ujian</code> sehingga struktur berkas berada di <code>C:\laragon\www\ujian\index.php</code>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">3</div>
        <div class="step-content">
            <h4>Jalankan Service Apache &amp; MySQL</h4>
            <p>Buka panel kontrol Laragon lalu klik tombol <b>Start All</b>. Pastikan Apache berstatus berjalan pada port 80 dan MySQL pada port 3306.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">4</div>
        <div class="step-content">
            <h4>Inisialisasi Database MySQL Otomatis</h4>
            <p>Sistem RyuExam CBT telah dilengkapi <i>Auto-Database Provisioning</i>. Saat pertama kali diakses di <code>http://localhost/ujian</code>, sistem akan otomatis membuat database <code>cbt_ujian</code> beserta seluruh tabelnya jika belum ada.</p>
        </div>
    </div>
</div>

<div class="callout callout-success">
    <div class="callout-title">✔ Konfigurasi Otomatis (Zero Config di Localhost):</div>
    Pada file <code>config.php</code>, parameter <code>$environment_mode = 'auto'</code> telah aktif secara bawaan. Sistem otomatis mendeteksi lingkungan lokal dan menggunakan user <code>root</code> tanpa kata sandi. Anda tidak perlu mengubah kode apapun saat dijalankan di server lokal.
</div>

<!-- ========================================================
     HALAMAN 5: PENGATURAN IP STATIS & FIREWALL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 1: PENGATURAN IP &amp; FIREWALL WINDOWS</span>
    <span class="section-tag">BAGIAN I: INFRASTRUKTUR</span>
</h1>

<p>
    Agar perangkat siswa dapat mengakses web server dari komputer lain di jaringan lokal, komputer server <b>wajib memiliki IP Address statis (tetap)</b> dan port 80 Apache diizinkan melewati Windows Firewall.
</p>

<h2 class="chapter-title">
    <span class="num-badge">1.3</span> Pengaturan IP Statis (Static IP) pada Komputer Server
</h2>

<p>
    Secara default, komputer mendapatkan IP dinamis (DHCP) yang dapat berubah saat router di-restart. Untuk menetapkan IP Statis di Windows:
</p>
<ul class="checklist">
    <li>Tekan tombol <b>Windows + R</b>, ketik <code>ncpa.cpl</code> lalu tekan <b>Enter</b> (Membuka Network Connections).</li>
    <li>Klik kanan pada adapter jaringan yang terhubung ke router (misal <b>Ethernet</b> atau <b>Wi-Fi</b>), lalu pilih <b>Properties</b>.</li>
    <li>Klik dua kali pada <b>Internet Protocol Version 4 (TCP/IPv4)</b>.</li>
    <li>Pilih opsi <b>Use the following IP address</b>, lalu masukkan konfigurasi:
        <ul style="margin-top: 6px; padding-left: 20px; list-style-type: square;">
            <li><b>IP Address:</b> <code>192.168.1.100</code> (Sesuaikan dengan subnet router Anda)</li>
            <li><b>Subnet mask:</b> <code>255.255.255.0</code></li>
            <li><b>Default gateway:</b> <code>192.168.1.1</code> (Alamat IP Router/Access Point)</li>
            <li><b>Preferred DNS server:</b> <code>192.168.1.1</code> atau kosongkan jika full offline.</li>
        </ul>
    </li>
    <li>Klik <b>OK</b> lalu simpan. Sekarang komputer server selalu berada di alamat <code>192.168.1.100</code>.</li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">1.4</span> Pengaturan Windows Defender Firewall (Membuka Port 80)
</h2>

<p>
    Penyebab paling sering perangkat siswa gagal membuka server (loading terus / <i>ERR_CONNECTION_TIMED_OUT</i>) adalah <b>Windows Defender Firewall memblokir akses port masuk (Inbound)</b> ke Apache:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num green">1</div>
        <div class="step-content">
            <h4>Buka Advanced Firewall</h4>
            <p>Tekan tombol <b>Windows + R</b>, ketik <code>wf.msc</code> lalu tekan <b>Enter</b>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">2</div>
        <div class="step-content">
            <h4>Buat Aturan Masuk Baru (Inbound Rule)</h4>
            <p>Klik menu <b>Inbound Rules</b> di panel kiri, kemudian klik <b>New Rule...</b> di panel kanan.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">3</div>
        <div class="step-content">
            <h4>Pilih Tipe Port</h4>
            <p>Pilih tipe <b>Port</b> lalu klik Next. Pilih <b>TCP</b> dan pada kolom <i>Specific local ports</i> isi: <code>80, 443</code>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">4</div>
        <div class="step-content">
            <h4>Izinkan Koneksi (Allow the Connection)</h4>
            <p>Pilih <b>Allow the connection</b> &gt; centang semua profil (Domain, Private, Public) &gt; Beri nama rule: <code>CBT Web Server Port 80</code> &gt; Klik <b>Finish</b>.</p>
        </div>
    </div>
</div>

<div class="callout callout-warning">
    <div class="callout-title">⚠ Tips Cepat Saat Ujian Berlangsung:</div>
    Jika teknisi ingin memastikan firewall tidak menjadi penghalang saat hari pelaksanaan ujian, teknisi dapat menonaktifkan sementara Windows Firewall pada profil <i>Private Network</i> melalui <code>firewall.cpl</code>.
</div>

<!-- ========================================================
     HALAMAN 6: ROUTER ACCESS POINT & PENGUJIAN LAN
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 1: ROUTER ACCESS POINT &amp; PENGUJIAN</span>
    <span class="section-tag">BAGIAN I: INFRASTRUKTUR</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">1.5</span> Konfigurasi Router / Access Point (WiFi) Ruang Ujian
</h2>

<p>
    Pemilihan dan konfigurasi Access Point (AP) sangat menentukan kelancaran koneksi siswa. Berikut rekomendasi praktis setting AP untuk ruang ujian:
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 30%;">Parameter Router</th>
            <th style="width: 70%;">Nilai / Rekomendasi Setting</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>Nama WiFi (SSID)</b></td>
            <td>Gunakan nama yang jelas per ruangan, misal: <code>CBT_RUANG_01</code>, <code>CBT_RUANG_02</code>. Hindari karakter spasi atau simbol rumit.</td>
        </tr>
        <tr>
            <td><b>Keamanan WiFi</b></td>
            <td>Gunakan <b>WPA2-PSK (AES)</b> dengan password yang mudah diketik siswa (contoh: <code>ujian2026</code>) atau tanpa password jika AP khusus ujian saja.</td>
        </tr>
        <tr>
            <td><b>DHCP IP Pool Range</b></td>
            <td>Atur alokasi IP yang cukup untuk 50 klien, contoh: <code>192.168.1.101</code> s/d <code>192.168.1.200</code>. Jangan sampai rentang IP bertabrakan dengan IP Server (192.168.1.100).</td>
        </tr>
        <tr>
            <td><b>DHCP Lease Time</b></td>
            <td>Ubah lease time menjadi <b>2 jam</b> atau <b>120 menit</b> agar alokasi IP cepat disegarkan jika ada siswa yang keluar-masuk.</td>
        </tr>
        <tr>
            <td><b>Pemilihan Channel Frekuensi</b></td>
            <td>Jika terdapat beberapa ruang kelas berdekatan, pisahkan channel 2.4 GHz agar tidak tumpang tindih (Gunakan Channel <b>1, 6, dan 11</b>). Untuk router Dual-Band, aktifkan <b>5 GHz</b> untuk transmisi data yang lebih stabil.</td>
        </tr>
    </tbody>
</table>

<h2 class="chapter-title">
    <span class="num-badge">1.6</span> Pengujian Akses Siswa &amp; Troubleshooting Jaringan Lokal
</h2>

<p>
    Setelah semua tahapan di atas selesai, lakukan pengujian koneksi menggunakan 1 perangkat smartphone atau laptop uji coba:
</p>
<ul class="checklist">
    <li>Sambungkan smartphone ke WiFi <code>CBT_RUANG_01</code>.</li>
    <li>Buka browser Google Chrome, ketikkan URL: <code>http://192.168.1.100/ujian</code></li>
    <li>Halaman beranda ujian <b>SMP/SMA CBT Online</b> akan langsung tampil dengan mulus.</li>
</ul>

<div class="callout callout-danger">
    <div class="callout-title">🚨 Tabel Troubleshooting Cepat Masalah Jaringan Lokal:</div>
    <table class="custom-table" style="margin-top: 6px; background: #ffffff;">
        <tr style="background: #f1f5f9; color: #0f172a;">
            <th style="color:#0f172a; width: 45%;">Gejala / Pesan Error</th>
            <th style="color:#0f172a; width: 55%;">Solusi Tindakan</th>
        </tr>
        <tr>
            <td><b>ERR_CONNECTION_TIMED_OUT</b> (Loading lama lalu gagal)</td>
            <td>Periksa Windows Firewall di server. Pastikan port 80 sudah dibuka (Lihat sub-bab 1.4) atau IP server berubah.</td>
        </tr>
        <tr>
            <td><b>ERR_CONNECTION_REFUSED</b> (Koneksi ditolak instan)</td>
            <td>Service Apache di Laragon belum berjalan. Buka Laragon lalu klik <b>Start All</b>.</td>
        </tr>
        <tr>
            <td>HP Siswa mendapat IP tetapi tidak bisa membuka halaman</td>
            <td>Periksa apakah fitur <i>AP Isolation</i> di router WiFi aktif. Matikan fitur <b>AP Isolation / Client Isolation</b> di menu router.</td>
        </tr>
    </table>
</div>

<!-- ========================================================
     HALAMAN 7: BAB 2 - INSTALASI HOSTING CPANEL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 2: INSTALASI PADA SERVER HOSTING (CPANEL / CLOUD)</span>
    <span class="section-tag">BAGIAN I: INFRASTRUKTUR</span>
</h1>

<p>
    Instalasi pada server hosting memungkinkan ujian diakses secara <b>online dari mana saja melalui internet</b>, sangat ideal untuk ujian jarak jauh, gladi bersih di rumah, maupun sekolah yang memiliki koneksi internet fiber optik berkecepatan tinggi.
</p>

<h2 class="chapter-title">
    <span class="num-badge">2.1</span> Persiapan Subdomain Sekolah
</h2>

<p>
    Disarankan menggunakan subdomain resmi sekolah agar kredibilitas dan keamanannya terjamin, contoh: <code>cbt.namasekolah.sch.id</code> atau <code>ujian.namasekolah.sch.id</code>. Pada cPanel, buat subdomain tersebut melalui menu <b>Domains &gt; Create A New Domain</b>.
</p>

<h2 class="chapter-title">
    <span class="num-badge">2.2</span> Unggah Berkas ke File Manager cPanel
</h2>

<div class="step-container">
    <div class="step-card">
        <div class="step-num purple">1</div>
        <div class="step-content">
            <h4>Kompres Berkas Menjadi ZIP</h4>
            <p>Pilih seluruh berkas dalam folder <code>c:\laragon\www\ujian</code>, klik kanan &gt; Send to &gt; Compressed (zipped) folder. Beri nama misal <code>cbt_update.zip</code>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">2</div>
        <div class="step-content">
            <h4>Upload via File Manager cPanel</h4>
            <p>Buka cPanel &gt; <b>File Manager</b> &gt; Masuk ke direktori root subdomain (misal <code>public_html/cbt</code>) &gt; Klik tombol <b>Upload</b>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">3</div>
        <div class="step-content">
            <h4>Ekstrak Berkas ZIP</h4>
            <p>Setelah proses upload 100% selesai, klik kanan berkas <code>cbt_update.zip</code> di File Manager lalu pilih <b>Extract</b>.</p>
        </div>
    </div>
</div>

<h2 class="chapter-title">
    <span class="num-badge">2.3</span> Pembuatan Database MySQL di cPanel
</h2>

<ul class="checklist">
    <li>Buka cPanel &gt; cari dan klik menu <b>MySQL Databases</b>.</li>
    <li><b>Create New Database:</b> Masukkan nama database, misal <code>cbtujian</code> (nama lengkap menjadi misal: <code>sekolah_cbtujian</code>) &gt; Klik <i>Create Database</i>.</li>
    <li><b>Add New User:</b> Buat username baru (misal: <code>sekolah_admincbt</code>) dan masukkan kata sandi yang kuat (simpan kata sandi ini!).</li>
    <li><b>Add User To Database:</b> Hubungkan user yang baru dibuat ke database tersebut &gt; Centang opsi <b>ALL PRIVILEGES</b> &gt; Klik <b>Make Changes</b>.</li>
    <li><b>Import Tabel Database:</b> Buka menu <b>phpMyAdmin</b> di cPanel &gt; Pilih database <code>sekolah_cbtujian</code> &gt; Klik tab <b>Import</b> &gt; Pilih berkas SQL cadangan sistem Anda &gt; Klik <b>Go</b>.</li>
</ul>

<!-- ========================================================
     HALAMAN 8: KONFIGURASI CONFIG.PHP & OPTIMASI HOSTING
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 2: KONFIGURASI HOSTING &amp; OPTIMASI PHP</span>
    <span class="section-tag">BAGIAN I: INFRASTRUKTUR</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">2.4</span> Konfigurasi File config.php untuk Hosting
</h2>

<p>
    Buka berkas <code>config.php</code> di File Manager cPanel menggunakan <b>Code Editor</b>. Sesuaikan blok konfigurasi <code>$db_hosting</code> dengan kredensial database cPanel Anda:
</p>

<pre class="code-box">
// File: config.php (Baris 20 - 26)
$db_hosting = [
    'host' => 'localhost',              // Di cPanel umumnya selalu 'localhost'
    'port' => '3306',
    'name' => 'sekolah_cbtujian',        // Nama database lengkap di cPanel Anda
    'user' => 'sekolah_admincbt',       // Username database cPanel Anda
    'pass' => 'P@ssw0rdDbS3kolah#2026',  // Password database cPanel Anda
];
</pre>

<p>
    Simpan berkas tersebut. Fitur <i>Auto-Environment Detection</i> RyuExam CBT akan otomatis mendeteksi bahwa domain yang dibuka bukan localhost dan langsung menggunakan konfigurasi <code>$db_hosting</code> ini.
</p>

<h2 class="chapter-title">
    <span class="num-badge">2.5</span> Pemasangan SSL (HTTPS) &amp; Pengaturan PHP Limits di cPanel
</h2>

<div class="callout callout-info">
    <div class="callout-title">🔒 Wajib Mengaktifkan HTTPS (SSL):</div>
    Fitur Progressive Web App (PWA), Service Worker, dan Fullscreen API di browser modern (Chrome/Edge di smartphone) <b>hanya dapat berjalan penuh pada protokol HTTPS yang aman</b>. Aktifkan fitur <b>AutoSSL / Let's Encrypt</b> di menu <i>SSL/TLS Status</i> cPanel.
</div>

<p>
    Untuk mencegah gagal unggah berkas naskah soal Word berukuran besar atau audio listening MP3, sesuaikan pengaturan PHP melalui menu <b>Select PHP Version &gt; Options</b> di cPanel:
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th>Direktif PHP</th>
            <th>Nilai Rekomendasi</th>
            <th>Fungsi</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><code>upload_max_filesize</code></td>
            <td><b>64M</b> (atau 128M)</td>
            <td>Mengizinkan upload naskah soal Word bergambar dan file MP3 besar.</td>
        </tr>
        <tr>
            <td><code>post_max_size</code></td>
            <td><b>64M</b> (atau 128M)</td>
            <td>Batas maksimum paket POST data yang dikirimkan.</td>
        </tr>
        <tr>
            <td><code>memory_limit</code></td>
            <td><b>256M</b> (atau 512M)</td>
            <td>Alokasi memori pemrosesan saat parser Word membaca tabel ratusan baris.</td>
        </tr>
        <tr>
            <td><code>max_execution_time</code></td>
            <td><b>300</b> detik</td>
            <td>Waktu eksekusi maksimal saat mengimpor ribuan data siswa/soal.</td>
        </tr>
    </tbody>
</table>

<h2 class="chapter-title">
    <span class="num-badge">2.6</span> Rekomendasi Kapasitas Server Hosting untuk Ujian Serentak
</h2>

<table class="custom-table">
    <thead>
        <tr>
            <th>Jumlah Siswa Serentak</th>
            <th>Tipe Layanan Hosting Disarankan</th>
            <th>Spesifikasi Server</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>10 - 80 Siswa</b></td>
            <td>cPanel Shared Hosting (Tier Bisnis)</td>
            <td>RAM 2 GB, 1 Core CPU, I/O 10 MB/s</td>
        </tr>
        <tr>
            <td><b>100 - 300 Siswa</b></td>
            <td>Cloud Hosting / Semi-Dedicated</td>
            <td>RAM 4 - 6 GB, 2 Core CPU, LiteSpeed Web Server</td>
        </tr>
        <tr>
            <td><b>500 - 1.000+ Siswa</b></td>
            <td>Cloud VPS Dedicated (IDCloudHost / Biznet)</td>
            <td>4 - 8 vCPU, RAM 8 - 16 GB, NVMe SSD Storage</td>
        </tr>
    </tbody>
</table>

<!-- ========================================================
     HALAMAN 9: BAB 3 - ADMIN PENGATURAN AWAL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 3: PENGATURAN AWAL SISTEM &amp; KEAMANAN</span>
    <span class="section-tag">BAGIAN II: ADMINISTRATOR</span>
</h1>

<p>
    Bagian ini memandu Administrator dalam mengelola seluruh sistem ujian, mulai dari konfigurasi profil institusi, penegakan aturan anti-kecurangan, backup data, hingga audit sistem.
</p>

<h2 class="chapter-title">
    <span class="num-badge">3.1</span> Login Administrator &amp; Keamanan Akun
</h2>

<ul class="checklist">
    <li>Buka browser dan akses halaman panel admin: <code>http://[IP-Server]/ujian/admin.php</code>.</li>
    <li>Kredensial Default:
        <ul style="margin-top: 4px; padding-left: 20px; list-style-type: square;">
            <li><b>Username:</b> <code>admin</code></li>
            <li><b>Password:</b> <code>admin</code> (atau password yang telah ditentukan sekolah)</li>
        </ul>
    </li>
    <li><b>PENTING:</b> Segera ganti kata sandi Administrator melalui menu <b>Pengaturan &gt; Akun Admin</b> untuk mencegah akses tanpa izin. Sistem otomatis mengenkripsi kata sandi menggunakan algoritma standar <code>bcrypt hash</code>.</li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">3.2</span> Pengaturan Identitas Sekolah &amp; Berkas Administrasi
</h2>

<p>
    Buka menu <b>Pengaturan</b> pada sidebar admin untuk mengonfigurasi profil sekolah. Data yang Anda masukkan di halaman ini akan otomatis muncul pada <b>Kop Kartu Ujian Siswa</b>, <b>Daftar Hadir</b>, dan <b>Berita Acara</b>:
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 30%;">Kolom Pengaturan</th>
            <th style="width: 70%;">Keterangan &amp; Petunjuk Pengisian</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>Nama Sekolah</b></td>
            <td>Contoh: <code>SMP NEGERI 2 TUNGKAL JAYA</code>. Digunakan sebagai judul kop dokumen resmi.</td>
        </tr>
        <tr>
            <td><b>Alamat Lengkap &amp; Kontak</b></td>
            <td>Alamat sekolah, nomor telepon, dan email resmi yang tertera pada bagian bawah kop surat.</td>
        </tr>
        <tr>
            <td><b>Nama Kepala Sekolah &amp; NIP</b></td>
            <td>Nama lengkap beserta gelar dan NIP untuk lembar tanda tangan Berita Acara dan Kartu Ujian.</td>
        </tr>
        <tr>
            <td><b>Logo Sekolah</b></td>
            <td>Unggah berkas PNG/JPG transparan (resolusi minimal 200x200 pixel). Logo akan tersemat di kartu ujian dan halaman login siswa.</td>
        </tr>
        <tr>
            <td><b>Tanda Tangan &amp; Stempel</b></td>
            <td>Unggah pindaian tanda tangan dan stempel digital berformat PNG transparan untuk verifikasi kartu peserta otomatis.</td>
        </tr>
    </tbody>
</table>

<div class="callout callout-info">
    <div class="callout-title">💡 Integrasi PWA (Progressive Web App):</div>
    Saat logo sekolah diunggah di menu Pengaturan, sistem secara otomatis meregenerasi ikon aplikasi PWA (<code>icon-192.png</code> dan <code>icon-512.png</code>). Ketika siswa memilih opsi "Tambahkan ke Layar Utama" di HP Android, aplikasi ujian akan muncul dengan logo resmi sekolah Anda layaknya aplikasi Play Store native!
</div>

<!-- ========================================================
     HALAMAN 10: ANTI-CURANG & BACKUP RESTORE
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 3: ANTI-CURANG &amp; BACKUP DATABASE</span>
    <span class="section-tag">BAGIAN II: ADMINISTRATOR</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">3.3</span> Konfigurasi Kebijakan Keamanan Anti-Curang (Kiosk Mode)
</h2>

<p>
    RyuExam CBT dilengkapi modul proteksi kecurangan berlapis yang dapat diaktifkan atau disesuaikan dengan tingkat ketatnya ujian:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num orange">1</div>
        <div class="step-content">
            <h4>Blokir Pindah Tab &amp; Buka Aplikasi Lain</h4>
            <p>Sistem mendeteksi event <code>visibilitychange</code> dan <code>window.blur</code>. Jika siswa beralih ke tab browser lain atau membuka aplikasi WhatsApp/Google, sistem akan langsung menghentikan ujian, memutar nada peringatan, dan menambah hitungan pelanggaran.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num orange">2</div>
        <div class="step-content">
            <h4>Kunci Layar Penuh (Mandatory Fullscreen)</h4>
            <p>Ujian mewajibkan mode layar penuh. Jika siswa menekan tombol Exit Fullscreen atau membagi layar (Split Screen) di Android, sistem akan membunyikan alarm dan mengunci layar ujian.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num orange">3</div>
        <div class="step-content">
            <h4>Batas Maksimal Pelanggaran (Auto-Disqualification)</h4>
            <p>Administrator dapat menentukan batas maksimal pelanggaran (misal: <b>3 kali</b>). Jika siswa melanggar lebih dari 3 kali, ujian akan terkunci secara permanen dan hanya dapat dibuka kembali oleh Admin/Proktor.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num orange">4</div>
        <div class="step-content">
            <h4>Blokir Klik Kanan, Salin Teks, &amp; Inspect Element</h4>
            <p>Kombinasi tombol <code>Ctrl+C</code>, <code>Ctrl+V</code>, <code>Ctrl+U</code>, <code>F12</code>, serta klik kanan mouse dinonaktifkan total sehingga naskah soal tidak dapat disalin.</p>
        </div>
    </div>
</div>

<h2 class="chapter-title">
    <span class="num-badge">3.4</span> Prosedur Backup &amp; Restore Database Berkala
</h2>

<p>
    Menjaga keselamatan data nilai siswa adalah prioritas utama. Menu <b>Pengaturan &gt; Backup &amp; Restore</b> menyediakan fitur pencadangan instan:
</p>

<div class="callout callout-success">
    <div class="callout-title">📥 Cara Melakukan Backup Database:</div>
    <ol style="margin-top: 6px; padding-left: 20px;">
        <li>Buka menu <b>Pengaturan</b> lalu scroll ke bagian <b>Backup &amp; Restore Database</b>.</li>
        <li>Klik tombol hijau <b>Unduh Backup SQL (.sql)</b>.</li>
        <li>Sistem akan mengekspor seluruh struktur tabel, data siswa, bank soal, dan riwayat jawaban ke dalam berkas <code>cbt_backup_[tanggal].sql</code>. Simpan berkas ini di flashdisk atau Google Drive proktor.</li>
    </ol>
</div>

<div class="callout callout-warning">
    <div class="callout-title">📤 Cara Melakukan Restore Database (Pemulihan Darurat):</div>
    Jika server lokal mengalami kerusakan hardware dan Anda berpindah ke laptop cadangan: pasang Laragon baru &gt; buka menu Restore &gt; Pilih berkas <code>.sql</code> cadangan &gt; Klik <b>Pulihkan Database</b>. Seluruh data ujian akan kembali 100% seperti semula.
</div>

<!-- ========================================================
     HALAMAN 11: BAB 4 - MASTER DATA KELAS, MAPEL, GURU
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 4: MANAJEMEN MASTER DATA SEKOLAH</span>
    <span class="section-tag">BAGIAN II: ADMINISTRATOR</span>
</h1>

<p>
    Sebelum ujian dapat dijadwalkan, Administrator perlu mengisi master data yang terstruktur: Data Kelas, Mata Pelajaran, Akun Guru, dan Data Siswa.
</p>

<h2 class="chapter-title">
    <span class="num-badge">4.1</span> Manajemen Data Kelas &amp; Rombongan Belajar
</h2>

<ul class="checklist">
    <li>Buka menu <b>Data Kelas</b> (<code>admin.php?page=kelas</code>).</li>
    <li>Klik tombol <b>+ Tambah Kelas</b>.</li>
    <li>Masukkan nama rombel, misal: <code>VII-A</code>, <code>VII-B</code>, <code>VIII-1</code>, <code>X-MIPA-1</code>.</li>
    <li>Data kelas ini akan menjadi filter pembagian sesi ujian, cetak kartu, dan pengelompokan rekap nilai.</li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">4.2</span> Manajemen Mata Pelajaran Induk
</h2>

<ul class="checklist">
    <li>Buka menu <b>Mata Pelajaran</b> (<code>admin.php?page=mata_pelajaran</code>).</li>
    <li>Masukkan <b>Kode Mapel</b> (contoh: <code>MTK</code>, <code>IPA</code>, <code>BIN</code>) dan <b>Nama Lengkap Mata Pelajaran</b> (contoh: <code>Matematika</code>, <code>Ilmu Pengetahuan Alam</code>).</li>
    <li>Mata pelajaran ini akan menjadi acuan saat guru membuat bank soal baru.</li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">4.3</span> Manajemen Akun Guru &amp; Penugasan Mapel
</h2>

<p>
    Guru tidak menggunakan akun admin utama, melainkan akun khusus guru dengan hak akses terbatas (hanya dapat mengelola bank soal miliknya, memeriksa nilai kelasnya, dan memantau siswa pada jam ujiannya):
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th>Langkah</th>
            <th>Tindakan di Menu Data Guru (<code>admin.php?page=guru</code>)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>1. Tambah Guru</b></td>
            <td>Klik tombol <b>+ Tambah Guru</b>. Masukkan Nama Lengkap beserta Gelar (misal: <i>Drs. H. Ahmad Fauzi, M.Pd</i>).</td>
        </tr>
        <tr>
            <td><b>2. Atur Username</b></td>
            <td>Tentukan username unik untuk guru, contoh: <code>guru_mtk</code> atau menggunakan NIP guru.</td>
        </tr>
        <tr>
            <td><b>3. Atur Password</b></td>
            <td>Tentukan kata sandi awal guru (misal: <code>guru123</code>). Guru dapat mengganti kata sandinya sendiri setelah login.</td>
        </tr>
        <tr>
            <td><b>4. Penugasan Mapel</b></td>
            <td>Pilih mata pelajaran yang diampu oleh guru tersebut. Sistem akan otomatis membatasi bank soal yang dapat diakses oleh guru yang bersangkutan.</td>
        </tr>
    </tbody>
</table>

<!-- ========================================================
     HALAMAN 12: DATA SISWA & CETAK KARTU UJIAN
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 4: DATA SISWA &amp; CETAK ADMINISTRASI</span>
    <span class="section-tag">BAGIAN II: ADMINISTRATOR</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">4.4</span> Manajemen Data Siswa (Impor Excel Massal)
</h2>

<p>
    Memasukkan ratusan data siswa satu per satu akan memakan waktu lama. Gunakan fitur <b>Impor Data Siswa via Excel</b> di menu <b>Data Siswa</b>:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num">1</div>
        <div class="step-content">
            <h4>Unduh Format Template Excel</h4>
            <p>Buka menu <b>Data Siswa</b> &gt; Klik tombol <b>Unduh Template Siswa (.xlsx)</b>. Jangan mengubah nama kolom pada baris pertama.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">2</div>
        <div class="step-content">
            <h4>Isi Data Siswa dari Buku Induk / Dapodik</h4>
            <p>Lengkapi kolom: <b>NISN/Nomor Peserta</b>, <b>Nama Lengkap</b>, <b>Kelas</b> (wajib sama persis dengan menu Data Kelas), <b>Sesi</b>, <b>Ruang</b>, dan <b>Password</b> (dapat dibuat acak atau kombinasi tanggal lahir).</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">3</div>
        <div class="step-content">
            <h4>Unggah Berkas Excel ke Sistem</h4>
            <p>Klik tombol <b>Pilih Berkas Excel</b> &gt; Pilih file yang telah diisi &gt; Klik <b>Impor Siswa Sekarang</b>. Ratusan data siswa akan masuk dalam hitungan detik.</p>
        </div>
    </div>
</div>

<h2 class="chapter-title">
    <span class="num-badge">4.5</span> Cetak Dokumen Administrasi Ujian Resmi
</h2>

<p>
    Menu <b>Cetak Administrasi</b> (<code>admin.php?page=cetak_kartu</code>) menyediakan berkas siap cetak berstandar nasional yang otomatis dipaginasi ke kertas A4:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num green">A</div>
        <div class="step-content">
            <h4>Cetak Kartu Peserta Ujian</h4>
            <p>Setiap lembar A4 otomatis menampung 4 hingga 8 kartu peserta siap potong. Setiap kartu dilengkapi <b>Kop Sekolah</b>, <b>Nama Siswa</b>, <b>Kelas</b>, <b>Nomor Peserta</b>, <b>Username &amp; Password</b>, serta <b>QR Code Login Cepat</b> yang dapat dipindai oleh kamera siswa.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">B</div>
        <div class="step-content">
            <h4>Cetak Daftar Hadir Peserta (Absensi Ujian)</h4>
            <p>Daftar hadir otomatis dikelompokkan per <b>Ruangan</b> dan per <b>Sesi</b>, lengkap dengan kolom tanda tangan siswa ganjil-genap dan kolom tanda tangan pengawas ruang.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">C</div>
        <div class="step-content">
            <h4>Cetak Berita Acara Pelaksanaan Ujian</h4>
            <p>Format berita acara resmi mencatat nama mata pelajaran, tanggal ujian, jumlah peserta seharusnya hadir, jumlah peserta tidak hadir (lengkap dengan nama/keterangan sakit/izin), dan catatan khusus proktor.</p>
        </div>
    </div>
</div>

<!-- ========================================================
     HALAMAN 13: BAB 5 - MONITORING REALTIME & RESET LOGIN
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 5: MONITORING REALTIME &amp; PENGAMANAN</span>
    <span class="section-tag">BAGIAN II: ADMINISTRATOR</span>
</h1>

<p>
    Saat ujian berlangsung, Administrator dan Proktor memiliki kendali penuh melalui menu <b>Status Peserta / Monitoring Realtime</b> (<code>admin.php?page=status</code>).
</p>

<h2 class="chapter-title">
    <span class="num-badge">5.1</span> Memantau Aktivitas Peserta Secara Realtime
</h2>

<p>
    Tabel monitoring memperbarui status siswa secara langsung:
</p>
<ul class="checklist">
    <li><span class="badge-tech badge-yellow">BELUM MULAI</span> Siswa sudah memiliki akun tetapi belum memasukkan token ujian.</li>
    <li><span class="badge-tech badge-blue">SEDANG MENGERJAKAN</span> Siswa aktif di ruang ujian. Terlihat sisa waktu mundur dan jumlah nomor yang telah dijawab.</li>
    <li><span class="badge-tech badge-green">SELESAI</span> Siswa telah menekan tombol "Selesai Ujian" dan seluruh jawaban telah tersimpan di database. Nilai otomatis terhitung.</li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">5.2</span> Prosedur Fitur "Reset Login" Siswa
</h2>

<p>
    Untuk mencegah kecurangan di mana satu akun siswa dipakai di dua perangkat sekaligus, sistem <b>mengunci sesi ke perangkat pertama yang login (Device Lock)</b>. Jika seorang siswa mengalami kendala:
</p>

<div class="callout callout-warning">
    <div class="callout-title">⚠️ Situasi yang Memerlukan Tindakan "Reset Login":</div>
    <ul style="margin: 4px 0 0 16px; padding-left: 0;">
        <li>Baterai smartphone siswa tiba-tiba habis dan siswa harus berpindah ke HP cadangan/laptop lab.</li>
        <li>Browser siswa tertutup atau crash secara paksa.</li>
        <li>Siswa tidak sengaja menekan tombol restart pada HP.</li>
    </ul>
</div>

<p><b>Langkah Melakukan Reset Login:</b></p>
<div class="step-container">
    <div class="step-card">
        <div class="step-num purple">1</div>
        <div class="step-content">
            <h4>Cari Nama Siswa di Menu Status Peserta</h4>
            <p>Ketikkan nama atau nomor peserta pada kotak pencarian cepat status ujian.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">2</div>
        <div class="step-content">
            <h4>Klik Tombol "Reset Login" (Ikon Kunci / Gembok)</h4>
            <p>Konfirmasi dialog popup reset. Kunci sesi perangkat siswa sebelumnya akan langsung dihapus oleh server.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">3</div>
        <div class="step-content">
            <h4>Siswa Login Kembali di Perangkat Baru</h4>
            <p>Siswa dapat langsung login kembali. Seluruh jawaban yang telah dikerjakan sebelumnya <b>tidak akan hilang</b> karena tersimpan aman di server MySQL!</p>
        </div>
    </div>
</div>

<!-- ========================================================
     HALAMAN 14: PAKSA SELESAI & AUDIT TRAIL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 5: PAKSA SELESAI &amp; AUDIT TRAIL</span>
    <span class="section-tag">BAGIAN II: ADMINISTRATOR</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">5.3</span> Fitur "Paksa Selesai" (Force Submit)
</h2>

<p>
    Jika waktu ujian telah berakhir secara resmi tetapi ada siswa yang lupa menekan tombol selesai atau meninggalkan ruangan tanpa submit, Proktor dapat mengklik tombol merah <b>Paksa Selesai</b> pada baris siswa tersebut. Sistem akan mengumpulkan seluruh jawaban terakhir siswa secara otomatis dan mengunci akses ujiannya.
</p>

<h2 class="chapter-title">
    <span class="num-badge">5.4</span> Audit Trail &amp; Rekam Jejak Pelanggaran Layar
</h2>

<p>
    Menu <b>Log Aktivitas</b> (<code>admin.php?page=log</code>) mencatat seluruh peristiwa keamanan secara detail per detik (Timestamp, IP Address, Nama Pengguna, User-Agent, dan Jenis Peristiwa):
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 20%;">Peristiwa (Event)</th>
            <th style="width: 25%;">Kategori</th>
            <th style="width: 55%;">Deskripsi Audit</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><code>LOGIN_SUCCESS</code></td>
            <td>Otentikasi</td>
            <td>Siswa/Guru berhasil login dari perangkat IP tertentu.</td>
        </tr>
        <tr>
            <td><code>TAB_SWITCH_DETECTED</code></td>
            <td><span class="badge-tech badge-red">PELANGGARAN</span></td>
            <td>Siswa terdeteksi meminimalkan browser, berpindah ke tab lain, atau membuka aplikasi di luar ujian. Waktu keluar tercatat.</td>
        </tr>
        <tr>
            <td><code>FULLSCREEN_EXIT</code></td>
            <td><span class="badge-tech badge-yellow">PERINGATAN</span></td>
            <td>Siswa keluar dari mode layar penuh atau mencoba membagi layar (Split Screen).</td>
        </tr>
        <tr>
            <td><code>ADMIN_RESET_LOGIN</code></td>
            <td>Tindakan Proktor</td>
            <td>Proktor melakukan reset login terhadap siswa yang bersangkutan.</td>
        </tr>
        <tr>
            <td><code>EXAM_SUBMITTED</code></td>
            <td>Selesai Ujian</td>
            <td>Siswa mengakhiri ujian secara sah beserta rekap skor instan.</td>
        </tr>
    </tbody>
</table>

<div class="callout callout-info">
    <div class="callout-title">🔍 Integritas Hasil Ujian:</div>
    Log pelanggaran ini dapat dicetak sebagai bukti otentik saat rapat dewan guru jika ada siswa yang dicurigai melakukan kecurangan saat ujian berlangsung.
</div>

<!-- ========================================================
     HALAMAN 15: BAB 6 - PANDUAN GURU: BANK SOAL & 5 TIPE SOAL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 6: PEMBUATAN &amp; PENYUSUNAN BANK SOAL</span>
    <span class="section-tag">BAGIAN III: GURU PENGAMPU</span>
</h1>

<p>
    Guru mata pelajaran dapat menyusun bank soal berkualitas tinggi dengan berbagai variasi soal modern sesuai standar Asesmen Nasional (AKM) dan Kurikulum Merdeka.
</p>

<h2 class="chapter-title">
    <span class="num-badge">6.1</span> Membuat Bank Soal Baru &amp; Parameter Ujian
</h2>

<ul class="checklist">
    <li>Login menggunakan akun guru Anda di <code>admin.php</code>.</li>
    <li>Buka menu <b>Bank Soal</b> lalu klik tombol biru <b>+ Buat Bank Soal</b>.</li>
    <li>Atur parameter bank soal:
        <ul style="margin-top: 4px; padding-left: 20px; list-style-type: square;">
            <li><b>Judul Bank Soal:</b> Misal: <i>PAS Ganjil Matematika Kelas IX</i>.</li>
            <li><b>Mata Pelajaran &amp; Jenjang Kelas:</b> Pilih mapel dan kelas sasaran.</li>
            <li><b>Alokasi Waktu:</b> Durasi pengerjaan dalam menit (misal: <code>90</code> menit).</li>
            <li><b>Acak Soal &amp; Acak Opsi:</b> Aktifkan opsi ini agar urutan nomor dan pilihan (A-B-C-D-E) di HP tiap siswa berbeda-beda sehingga tidak dapat saling mencontek.</li>
            <li><b>Tampilkan Nilai ke Siswa:</b> Tentukan apakah nilai langsung muncul di layar siswa setelah selesai atau disembunyikan terlebih dahulu.</li>
        </ul>
    </li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">6.2</span> Pengenalan 5 Tipe Soal CBT RyuExam
</h2>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 25%;">Tipe Soal</th>
            <th style="width: 35%;">Karakteristik Jawaban</th>
            <th style="width: 40%;">Metode Penilaian</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>1. Pilihan Ganda (PG)</b></td>
            <td>Siswa memilih 1 jawaban paling tepat dari 4 opsi (A-D) atau 5 opsi (A-E).</td>
            <td>Otomatis 100% oleh sistem. Jika benar mendapat bobot penuh.</td>
        </tr>
        <tr>
            <td><b>2. PG Kompleks (Centang)</b></td>
            <td>Siswa dapat mencentang lebih dari satu jawaban benar (kotak checkbox).</td>
            <td>Otomatis proporsional (jika benar 2 dari 3, mendapat skor parsial).</td>
        </tr>
        <tr>
            <td><b>3. Benar / Salah (Grid)</b></td>
            <td>Berisi beberapa pernyataan tabel di mana siswa menentukan Benar atau Salah per baris.</td>
            <td>Otomatis dihitung berdasarkan kesesuaian checklist siswa.</td>
        </tr>
        <tr>
            <td><b>4. Menjodohkan (Matching)</b></td>
            <td>Siswa menghubungkan premis di kolom kiri dengan pasangan tepat di kolom kanan.</td>
            <td>Otomatis mencocokkan pasangan relasi.</td>
        </tr>
        <tr>
            <td><b>5. Esai / Uraian</b></td>
            <td>Siswa mengetik jawaban bebas dalam bentuk paragraf atau kalimat penjelas.</td>
            <td>Koreksi semi-otomatis/manual oleh guru di panel penilaian esai.</td>
        </tr>
    </tbody>
</table>

<!-- ========================================================
     HALAMAN 16: EDITOR SOAL, GAMBAR, AUDIO, KATEX
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 6: MEDIA, AUDIO, &amp; FORMULA RUMUS</span>
    <span class="section-tag">BAGIAN III: GURU PENGAMPU</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">6.3</span> Menyisipkan Gambar &amp; Audio Listening (MP3)
</h2>

<p>
    RyuExam CBT mendukung soal berbasis multimedia lengkap untuk ujian Bahasa Inggris / Bahasa Asing dan soal sains bergambar:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num">A</div>
        <div class="step-content">
            <h4>Menyisipkan Gambar pada Soal &amp; Pilihan Jawaban</h4>
            <p>Pada form editor soal, klik tombol <b>Upload Gambar</b>. Sistem otomatis mengoptimasi ukuran gambar (WebP compression) agar hemat bandwidth dan cepat dimuat di HP siswa yang sinyalnya lemah.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">B</div>
        <div class="step-content">
            <h4>Menyisipkan Audio Listening (Soal Bahasa Inggris / Asing)</h4>
            <p>Unggah berkas audio MP3. Anda dapat mengatur <b>Maksimal Pemutaran Audio</b> (misal: hanya boleh diputar maksimal <b>2 kali</b>). Sistem otomatis mengunci tombol play jika kuota putar siswa telah habis!</p>
        </div>
    </div>
</div>

<h2 class="chapter-title">
    <span class="num-badge">6.4</span> Menuliskan Formula Matematika &amp; Sains (KaTeX / LaTeX)
</h2>

<p>
    Untuk mata pelajaran Matematika, Fisika, dan Kimia, naskah tidak perlu di-screenshot menjadi gambar buram. Tuliskan formula matematika menggunakan format <b>KaTeX / LaTeX</b> yang diapit tanda dollar <code>$...$</code>:
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th>Notasi Matematika</th>
            <th>Cara Penulisan di Naskah CBT</th>
            <th>Hasil Tampilan di Layar Siswa</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Pecahan (Fraction)</td>
            <td><code>$\frac{a}{b}$</code> atau <code>$\frac{3}{4}$</code></td>
            <td>Pecahan vertikal rapi (3 per 4)</td>
        </tr>
        <tr>
            <td>Akar Kuadrat</td>
            <td><code>$\sqrt{x^2 + y^2}$</code></td>
            <td>Lambang akar kuadrat sempurna</td>
        </tr>
        <tr>
            <td>Pangkat / Eksponen</td>
            <td><code>$x^2 + 5x - 6 = 0$</code></td>
            <td>x kuadrat plus 5x minus 6 sama dengan 0</td>
        </tr>
        <tr>
            <td>Matriks &amp; Integral</td>
            <td><code>$\int_{0}^{\pi} \sin(x) dx$</code></td>
            <td>Simbol integral batas 0 sampai pi</td>
        </tr>
        <tr>
            <td>Reaksi Kimia</td>
            <td><code>$H_2SO_4 + 2NaOH \rightarrow Na_2SO_4 + 2H_2O$</code></td>
            <td>Notasi rumus molekul dan panah reaksi</td>
        </tr>
    </tbody>
</table>

<div class="callout callout-info">
    <div class="callout-title">💡 Pop-up Generator AI:</div>
    Guru dapat memanfaatkan tombol <b>Buat via AI</b> di menu bank soal untuk meminta kecerdasan buatan menyusun rumus KaTeX secara otomatis tanpa perlu menghafal kode perintahnya.
</div>

<!-- ========================================================
     HALAMAN 17: BAB 7 - IMPOR NASKAH WORD (.DOCX)
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 7: IMPOR SOAL CEPAT DARI MICROSOFT WORD</span>
    <span class="section-tag">BAGIAN III: GURU PENGAMPU</span>
</h1>

<p>
    Guru tidak perlu mengetik soal satu per satu di browser. Cukup gunakan Microsoft Word dengan template tabel 2 kolom yang sangat mudah dipahami.
</p>

<h2 class="chapter-title">
    <span class="num-badge">7.1</span> Struktur Format Tabel Microsoft Word (.docx)
</h2>

<p>
    Buka Microsoft Word, buat tabel dengan 2 kolom. Kolom kiri berisi label penanda (huruf kapital), kolom kanan berisi teks soal, gambar, atau teks opsi jawaban:
</p>

<table class="custom-table" style="background: #ffffff; border: 2px solid #2563eb;">
    <thead>
        <tr style="background: #2563eb; color: #ffffff;">
            <th style="width: 25%; text-align: center;">KOLOM KIRI (LABEL)</th>
            <th style="width: 75%;">KOLOM KANAN (KONTEN / ISI SOAL)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td style="text-align: center; font-weight: bold; background: #eff6ff;">SOAL</td>
            <td>Ibukota negara Indonesia yang baru (IKN) berlokasi di provinsi...<br><i>(Dapat menyisipkan gambar soal di sini)</i></td>
        </tr>
        <tr>
            <td style="text-align: center; font-weight: bold;">A</td>
            <td>Kalimantan Selatan</td>
        </tr>
        <tr>
            <td style="text-align: center; font-weight: bold;">B</td>
            <td>Kalimantan Timur</td>
        </tr>
        <tr>
            <td style="text-align: center; font-weight: bold;">C</td>
            <td>Kalimantan Barat</td>
        </tr>
        <tr>
            <td style="text-align: center; font-weight: bold;">D</td>
            <td>Kalimantan Tengah</td>
        </tr>
        <tr>
            <td style="text-align: center; font-weight: bold; background: #dcfce7; color: #166534;">KUNCI</td>
            <td style="background: #dcfce7; font-weight: bold; color: #166534;">B</td>
        </tr>
    </tbody>
</table>

<div class="step-container" style="margin-top: 14px;">
    <div class="step-card">
        <div class="step-num green">1</div>
        <div class="step-content">
            <h4>Buka Menu Detail Bank Soal</h4>
            <p>Klik bank soal yang ingin diisi &gt; Klik tombol <b>Impor Soal Word (.docx)</b>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">2</div>
        <div class="step-content">
            <h4>Pilih File Naskah Word &amp; Upload</h4>
            <p>Pilih file Word Anda &gt; Klik <b>Upload &amp; Proses</b>. Sistem akan membaca seluruh baris tabel secara otomatis.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num green">3</div>
        <div class="step-content">
            <h4>Pratinjau &amp; Konfirmasi</h4>
            <p>Sistem menampilkan tabel pratinjau hasil ekstraksi (nomor soal, teks, gambar, opsi jawaban, dan kunci). Klik <b>Simpan ke Bank Soal</b> untuk menyelesaikan proses.</p>
        </div>
    </div>
</div>

<div class="callout callout-warning">
    <div class="callout-title">⚠️ Aturan Penulisan Word Penting:</div>
    Pastikan penulisan label kolom kiri menggunakan huruf kapital persis: <code>SOAL</code>, <code>A</code>, <code>B</code>, <code>C</code>, <code>D</code>, <code>E</code>, dan <code>KUNCI</code>. Jika ada baris kosong antar soal, beri jarak satu enter di luar tabel.
</div>

<!-- ========================================================
     HALAMAN 18: BAB 7 - IMPOR GENERATOR AI & KUNCI EXCEL
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 7: IMPOR SOAL GENERATOR AI &amp; EXCEL</span>
    <span class="section-tag">BAGIAN III: GURU PENGAMPU</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">7.2</span> Membuat Puluhan Soal Otomatis via Generator AI (JSON)
</h2>

<p>
    Guru dapat memanfaatkan kecerdasan buatan (Google Gemini, ChatGPT, Claude) untuk membuat 20 hingga 50 butir soal siap pakai beserta kunci jawaban hanya dalam waktu 1 menit:
</p>

<div class="callout callout-info">
    <div class="callout-title">🤖 Prompt Standar Generator AI (Salin ke Gemini / ChatGPT):</div>
    <pre class="code-box">
Buatkan 20 butir soal Asesmen Pilihan Ganda untuk mata pelajaran IPA Kelas 8 
materi "Sistem Pencernaan Manusia" tingkat kesulitan sedang (HOTS).
Keluarkan hasilnya HANYA dalam format JSON baku berikut tanpa teks pengantar:
[
  {
    "type": "multiple_choice",
    "question": "Enzim ptialin di dalam rongga mulut berfungsi untuk...",
    "options": [
      "Mengubah amilum menjadi maltosa",
      "Mengendapkan kasein susu",
      "Membunuh kuman penyakit",
      "Mengemulsikan lemak"
    ],
    "correct_answer": "Mengubah amilum menjadi maltosa",
    "weight": 5
  }
]
</pre>
</div>

<p>
    <b>Cara Memasukkan ke Bank Soal:</b> Buka Bank Soal &gt; Klik tombol <b>Impor via JSON / AI</b> &gt; Tempelkan (paste) kode JSON yang dihasilkan oleh AI ke dalam kotak &gt; Klik <b>Impor Sekarang</b>. Seluruh butir soal langsung tersimpan rapi beserta kunci dan bobot nilainya!
</p>

<h2 class="chapter-title">
    <span class="num-badge">7.3</span> Impor Kunci Jawaban &amp; Bobot Nilai via Excel (.xlsx)
</h2>

<p>
    Jika Anda telah memasukkan butir soal tetapi ingin mengubah kunci jawaban atau bobot skor secara massal:
</p>
<ul class="checklist">
    <li>Buka Bank Soal &gt; Klik <b>Unduh Template Kunci Excel</b>.</li>
    <li>File Excel akan berisi daftar nomor soal yang sudah ada. Anda tinggal mengetikkan huruf kunci (misal: <code>A</code>, <code>B</code>, <code>C</code>) dan nilai bobot per nomor.</li>
    <li>Simpan berkas Excel lalu klik <b>Unggah Kunci Excel</b>. Kunci jawaban di seluruh butir soal akan diperbarui seketika.</li>
</ul>

<!-- ========================================================
     HALAMAN 19: BAB 8 - PENJADWALAN & KOREKSI ESAI
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 8: JADWAL UJIAN, TOKEN, &amp; KOREKSI ESAI</span>
    <span class="section-tag">BAGIAN III: GURU PENGAMPU</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">8.1</span> Mengaktifkan Jadwal Ujian &amp; Rilis Token
</h2>

<p>
    Bank soal yang telah selesai disusun harus diaktifkan jadwalnya agar dapat dikerjakan oleh siswa:
</p>
<ul class="checklist">
    <li>Buka menu <b>Jadwal Ujian / Bank Soal</b>.</li>
    <li>Pilih bank soal yang dimaksud lalu ubah status dari <span class="badge-tech badge-yellow">NON-AKTIF</span> menjadi <span class="badge-tech badge-green">AKTIF</span>.</li>
    <li><b>Token Ujian:</b> Sistem menyediakan 6 karakter token acak (contoh: <code>KJT89X</code>). Bagikan token ini kepada siswa di ruang kelas hanya saat bel ujian berbunyi. Siswa tidak akan dapat masuk ke naskah soal tanpa memasukkan token ini.</li>
</ul>

<h2 class="chapter-title">
    <span class="num-badge">8.2</span> Prosedur Koreksi Soal Esai / Uraian Digital
</h2>

<p>
    Untuk bank soal yang memuat soal Esai / Uraian, sistem menyediakan modul koreksi digital yang sangat praktis tanpa perlu mencetak kertas:
</p>

<div class="step-container">
    <div class="step-card">
        <div class="step-num purple">1</div>
        <div class="step-content">
            <h4>Buka Menu Koreksi Esai</h4>
            <p>Buka menu <b>Analisis &amp; Nilai</b> (<code>admin.php?page=analisis</code>) &gt; Pilih bank soal ujian yang memiliki butir soal esai.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">2</div>
        <div class="step-content">
            <h4>Pilih Siswa &amp; Tinjau Jawaban</h4>
            <p>Klik tombol <b>Koreksi Esai</b> pada baris siswa. Sistem akan menampilkan teks pertanyaan, pedoman kunci jawaban referensi guru, dan teks jawaban yang diketik oleh siswa.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">3</div>
        <div class="step-content">
            <h4>Input Skor Nilai &amp; Catatan</h4>
            <p>Masukkan skor per butir esai (misal rentang 0 s/d 20). Anda juga dapat menuliskan catatan umpan balik (feedback) untuk siswa.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num purple">4</div>
        <div class="step-content">
            <h4>Simpan &amp; Kalkulasi Ulang Nilai Akhir</h4>
            <p>Klik tombol <b>Simpan Nilai Esai</b>. Sistem akan otomatis menjumlahkan nilai Pilihan Ganda murni dengan nilai Esai menjadi <b>Nilai Akhir Ujian (Skala 0 - 100)</b>.</p>
        </div>
    </div>
</div>

<!-- ========================================================
     HALAMAN 20: BAB 8 - ANALISIS BUTIR SOAL & REKAP NILAI
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 8: ANALISIS BUTIR SOAL &amp; REKAP EXCEL</span>
    <span class="section-tag">BAGIAN III: GURU PENGAMPU</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">8.3</span> Analisis Butir Soal (Tingkat Kesukaran &amp; Sebaran Jawaban)
</h2>

<p>
    Menu <b>Analisis Hasil Ujian</b> menyajikan data statistik akurat untuk evaluasi butir soal:
</p>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 25%;">Parameter Analisis</th>
            <th style="width: 35%;">Rentang Nilai</th>
            <th style="width: 40%;">Interpretasi Edukatif</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>Tingkat Kesukaran</b></td>
            <td>
                <code>0.00 - 0.30</code> (Sukar)<br>
                <code>0.31 - 0.70</code> (Sedang)<br>
                <code>0.71 - 1.00</code> (Mudah)
            </td>
            <td>Menunjukkan persentase siswa yang menjawab benar. Soal yang baik berada pada rentang sedang (0.31 - 0.70).</td>
        </tr>
        <tr>
            <td><b>Sebaran Distraktor (Pengecoh)</b></td>
            <td>Persentase pemilih opsi A, B, C, D, E</td>
            <td>Mendeteksi apakah pilihan pengecoh berfungsi dengan baik atau ada kunci jawaban yang salah input oleh guru.</td>
        </tr>
        <tr>
            <td><b>Ketuntasan Klasikal</b></td>
            <td>Persentase siswa &ge; KKM</td>
            <td>Mengukur persentase ketuntasan belajar satu rombel kelas terhadap standar KKM sekolah.</td>
        </tr>
    </tbody>
</table>

<h2 class="chapter-title">
    <span class="num-badge">8.4</span> Ekspor Rekap Nilai ke Format Excel untuk E-Rapor
</h2>

<p>
    Guru tidak perlu lagi menyalin nilai satu per satu ke lembar nilai. Cukup satu klik untuk mengekspor data siap pakai:
</p>
<ul class="checklist">
    <li>Buka menu <b>Analisis &amp; Nilai</b> &gt; Pilih bank soal dan kelas yang diinginkan.</li>
    <li>Klik tombol hijau <b>Ekspor Nilai ke Excel (.xlsx)</b>.</li>
    <li>Berkas Excel yang diunduh memuat format rapi: <b>NISN</b>, <b>Nama Siswa</b>, <b>Kelas</b>, <b>Jumlah Benar PG</b>, <b>Jumlah Salah PG</b>, <b>Skor Esai</b>, <b>Nilai Akhir</b>, dan status <b>TUNTAS / REMEDIAL</b>.</li>
    <li>Format kolom ini langsung sesuai dan siap di-<i>copy paste</i> ke aplikasi E-Rapor Kemendikbudristek.</li>
</ul>

<div class="callout callout-success">
    <div class="callout-title">✔ Fitur Hitung Ulang Nilai (Recalculate Scores):</div>
    Jika setelah ujian selesai ternyata guru menemukan ada 1 butir soal yang kuncinya keliru (misal seharusnya C tetapi tertulis D), guru cukup mengubah kunci jawaban di bank soal, lalu mengklik tombol <b>Hitung Ulang Nilai</b>. Seluruh nilai siswa se-sekolah akan otomatis dikalkulasi ulang dalam hitungan detik tanpa perlu ujian susulan!
</div>

<!-- ========================================================
     HALAMAN 21: BAB 9 - PANDUAN SISWA & FAQ PENGAWAS
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 9: PANDUAN SISWA &amp; SOP PENGAWAS</span>
    <span class="section-tag">BAGIAN IV: PANDUAN LAPANGAN</span>
</h1>

<h2 class="chapter-title">
    <span class="num-badge">9.1</span> Panduan Langkah Siswa Mengikuti Ujian
</h2>

<div class="step-container">
    <div class="step-card">
        <div class="step-num">1</div>
        <div class="step-content">
            <h4>Sambungkan Koneksi</h4>
            <p>Siswa menyambungkan WiFi ke SSID ruang ujian yang telah ditentukan.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">2</div>
        <div class="step-content">
            <h4>Buka Browser &amp; Login</h4>
            <p>Buka Chrome / Safari &gt; ketik alamat URL ujian &gt; Masukkan <b>Username</b> dan <b>Password</b> yang tertera pada Kartu Peserta Ujian.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">3</div>
        <div class="step-content">
            <h4>Masukkan Token Ujian &amp; Masuk Layar Penuh</h4>
            <p>Ketikkan token ujian yang dibacakan oleh pengawas &gt; Izinkan permintaan <b>Mode Layar Penuh (Fullscreen)</b>.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">4</div>
        <div class="step-content">
            <h4>Mengerjakan Soal &amp; Fitur Ragu-Ragu</h4>
            <p>Siswa memilih jawaban dengan mengetuk opsi. Gunakan tombol <b>Ragu-Ragu (Kuning)</b> jika belum yakin. Navigasi nomor soal di bagian atas memudahkan melompat ke nomor manapun.</p>
        </div>
    </div>
    <div class="step-card">
        <div class="step-num">5</div>
        <div class="step-content">
            <h4>Selesai Ujian &amp; Logout</h4>
            <p>Pada nomor terakhir, klik tombol hijau <b>Selesai Ujian</b> &gt; Centang persetujuan konfirmasi &gt; Klik Ya, Kumpulkan. Jangan lupa klik <b>Keluar / Logout</b>.</p>
        </div>
    </div>
</div>

<h2 class="chapter-title">
    <span class="num-badge">9.2</span> Standar Operasional Prosedur (SOP) Pengawas Ruang
</h2>

<ul class="checklist">
    <li>Pengawas mengambil amplop berisi <b>Daftar Hadir</b>, <b>Berita Acara</b>, dan <b>Daftar Token</b> dari ruang proktor 15 menit sebelum ujian dimulai.</li>
    <li>Memastikan seluruh siswa meletakkan tas di depan kelas dan hanya membawa kartu peserta serta smartphone/alat tulis ke meja.</li>
    <li>Meminta siswa mematikan data seluler (SIM card) dan hanya mengaktifkan WiFi lokal sekolah.</li>
    <li>Mengedarkan Daftar Hadir untuk ditandatangani oleh seluruh peserta ujian.</li>
    <li>Jika ada siswa yang mengalami kendala logout/baterai habis, pengawas segera melapor ke Proktor untuk dilakukan <b>Reset Login</b>.</li>
    <li>Setelah ujian usai, pengawas mengisi dan menandatangani Berita Acara Pelaksanaan Ujian lalu menyerahkannya kembali ke sekretariat panitia.</li>
</ul>

<!-- ========================================================
     HALAMAN 22: FAQ & TROUBLESHOOTING CHEAT SHEET
     ======================================================== -->
<div class="page-break"></div>

<h1 class="section-title">
    <span>BAB 9: FAQ &amp; TROUBLESHOOTING KENDALA UMUM</span>
    <span class="section-tag">BAGIAN IV: PANDUAN LAPANGAN</span>
</h1>

<table class="custom-table">
    <thead>
        <tr>
            <th style="width: 35%;">Pertanyaan / Masalah</th>
            <th style="width: 65%;">Penyebab &amp; Solusi Penanganan Praktis</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><b>Siswa muncul pesan "Akun Anda sedang aktif di perangkat lain"</b></td>
            <td>Siswa sebelumnya telah login di HP lain atau browser ter-refresh paksa. <b>Solusi:</b> Buka menu <i>Status Peserta</i> di admin &gt; cari nama siswa &gt; klik tombol <b>Reset Login</b>.</td>
        </tr>
        <tr>
            <td><b>Token ujian muncul pesan "Token salah atau kadaluarsa"</b></td>
            <td>Periksa apakah huruf kapital token sudah sesuai (bersifat case-sensitive) atau bank soal belum diubah statusnya menjadi AKTIF di jadwal ujian.</td>
        </tr>
        <tr>
            <td><b>Layar ujian terkunci warna merah dan tidak bisa diklik</b></td>
            <td>Siswa terdeteksi melanggar batas maksimal keluar dari layar penuh / beralih aplikasi. <b>Solusi:</b> Pengawas/Proktor memeriksa riwayat pelanggaran di menu log, lalu mengklik tombol <i>Buka Kunci Ujian</i> jika siswa telah diberi peringatan.</td>
        </tr>
        <tr>
            <td><b>Gambar pada naskah soal tidak muncul di HP siswa</b></td>
            <td>Periksa apakah folder <code>uploads/</code> pada server memiliki izin akses (permission 755/777 pada hosting Linux) atau ukuran gambar terlalu besar sehingga timeout.</td>
        </tr>
        <tr>
            <td><b>Audio listening tidak bersuara di smartphone siswa</b></td>
            <td>Beberapa browser smartphone (khususnya iPhone/Safari) memiliki kebijakan <i>Autoplay Policy</i> yang membisukan audio otomatis. Minta siswa menyentuh tombol play secara manual dan memeriksa volume media smartphone.</td>
        </tr>
        <tr>
            <td><b>Listrik sekolah padam saat ujian berlangsung</b></td>
            <td>Sistem RyuExam CBT secara otomatis menyimpan setiap jawaban siswa ke database server sesaat setelah opsi dipilih (Auto-Save per click). Begitu server menyala kembali, siswa tinggal login ulang dan melanjutkan dengan sisa waktu yang tersimpan utuh!</td>
        </tr>
    </tbody>
</table>

<div style="margin-top: 36px; border-top: 2px solid #e2e8f0; padding-top: 20px; text-align: center; color: #64748b; font-size: 8.5pt;">
    <p style="font-weight: 700; color: #1e3a8a; margin-bottom: 4px;">RyuExam CBT System - Solusi Asesmen Digital Cerdas &amp; Terpercaya</p>
    <p style="margin: 0;">Dokumentasi Resmi Versi 2.5 &bull; Dicetak pada: 03 October 2026 &bull; Hak Cipta Dilindungi Undang-Undang</p>
</div>

</div>
</div>

</body>
</html>