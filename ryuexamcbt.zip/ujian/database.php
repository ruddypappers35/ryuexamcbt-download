<?php
if (defined('DATABASE_INCLUDED')) return;
define('DATABASE_INCLUDED', true);

date_default_timezone_set('Asia/Jakarta');
require_once __DIR__ . '/config.php';

// ==========================================
// CLASSES FUNCTIONS
// ==========================================
function get_classes() {
    $pdo = get_db_connection();
    $stmt = $pdo->query("SELECT id, name FROM classes ORDER BY id ASC");
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
    }
    unset($r);
    return $rows;
}

function save_classes($data) {
    $pdo = get_db_connection();
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM classes");
        $stmt = $pdo->prepare("INSERT INTO classes (id, name) VALUES (?, ?)");
        foreach ($data as $c) {
            $stmt->execute([(int)$c['id'], (string)$c['name']]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ==========================================
// MATA PELAJARAN (SUBJECTS) FUNCTIONS
// ==========================================
// MATA PELAJARAN (SUBJECTS) FUNCTIONS
// ==========================================
function get_mapel_list() {
    $pdo = get_db_connection();
    static $initialized = false;
    if (!$initialized) {
        $tableExists = false;
        try {
            $tableExists = (bool)$pdo->query("SHOW TABLES LIKE 'mata_pelajaran'")->fetchColumn();
        } catch (Exception $e) {}

        $pdo->exec("CREATE TABLE IF NOT EXISTS `mata_pelajaran` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `code` VARCHAR(50) NOT NULL DEFAULT '',
            `name` VARCHAR(150) NOT NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        try {
            $isSeeded = false;
            try {
                $isSeeded = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'mata_pelajaran_seeded'")->fetchColumn() !== false;
            } catch (Exception $e) {}

            // Hanya seed data default pada instalasi pertama kali jika tabel belum pernah ada
            // dan belum pernah ditandai seeded sebelumnya.
            if (!$tableExists && !$isSeeded) {
                $defaultMapel = [
                    ['MAT', 'Matematika'],
                    ['BIN', 'Bahasa Indonesia'],
                    ['BIG', 'Bahasa Inggris'],
                    ['IPA', 'Ilmu Pengetahuan Alam (IPA)'],
                    ['IPS', 'Ilmu Pengetahuan Sosial (IPS)'],
                    ['PAI', 'Pendidikan Agama Islam'],
                    ['PPKN', 'Pendidikan Pancasila dan Kewarganegaraan']
                ];
                $ins = $pdo->prepare("INSERT INTO mata_pelajaran (code, name) VALUES (?, ?)");
                foreach ($defaultMapel as $dm) {
                    $ins->execute([$dm[0], $dm[1]]);
                }
            }

            // Tandai sudah di-seed agar data yang sengaja dikosongkan/dihapus tidak otomatis terisi kembali
            if (!$isSeeded) {
                try {
                    $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('mata_pelajaran_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
                } catch (Exception $e) {}
            }
        } catch (Exception $e) {}
        
        $initialized = true;
    }
    $stmt = $pdo->query("SELECT id, code, name FROM mata_pelajaran ORDER BY id ASC");
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
    }
    unset($r);
    return $rows;
}

function save_mapel_list($data) {
    $pdo = get_db_connection();
    get_mapel_list(); // memastikan tabel sudah dibuat
    try {
        $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('mata_pelajaran_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
    } catch (Exception $e) {}
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM mata_pelajaran");
        $stmt = $pdo->prepare("INSERT INTO mata_pelajaran (id, code, name) VALUES (?, ?, ?)");
        foreach ($data as $m) {
            $stmt->execute([(int)$m['id'], (string)($m['code'] ?? ''), (string)$m['name']]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ==========================================
// JENIS UJIAN (EXAM TYPES) FUNCTIONS
// ==========================================
function get_jenis_ujian_list() {
    $pdo = get_db_connection();
    static $initialized = false;
    if (!$initialized) {
        $tableExists = false;
        try {
            $tableExists = (bool)$pdo->query("SHOW TABLES LIKE 'jenis_ujian'")->fetchColumn();
        } catch (Exception $e) {}

        $pdo->exec("CREATE TABLE IF NOT EXISTS `jenis_ujian` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `code` VARCHAR(50) NOT NULL DEFAULT '',
            `name` VARCHAR(150) NOT NULL,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        try {
            $isSeeded = false;
            try {
                $isSeeded = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'jenis_ujian_seeded'")->fetchColumn() !== false;
            } catch (Exception $e) {}

            if (!$tableExists && !$isSeeded) {
                $defaultJenis = [
                    ['PH', 'Penilaian Harian'],
                    ['PTS', 'Penilaian Tengah Semester'],
                    ['PAS', 'Penilaian Akhir Semester'],
                    ['PAT', 'Penilaian Akhir Tahun'],
                    ['US', 'Ujian Sekolah'],
                    ['TO', 'Try Out']
                ];
                $insJ = $pdo->prepare("INSERT INTO jenis_ujian (code, name) VALUES (?, ?)");
                foreach ($defaultJenis as $dj) {
                    $insJ->execute([$dj[0], $dj[1]]);
                }
            }

            if (!$isSeeded) {
                try {
                    $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('jenis_ujian_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
                } catch (Exception $e) {}
            }
        } catch (Exception $e) {}
        
        $initialized = true;
    }
    $stmt = $pdo->query("SELECT id, code, name FROM jenis_ujian ORDER BY id ASC");
    $rows = $stmt->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
    }
    unset($r);
    return $rows;
}

function save_jenis_ujian_list($data) {
    $pdo = get_db_connection();
    get_jenis_ujian_list(); // memastikan tabel sudah dibuat
    try {
        $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('jenis_ujian_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
    } catch (Exception $e) {}
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM jenis_ujian");
        $stmt = $pdo->prepare("INSERT INTO jenis_ujian (id, code, name) VALUES (?, ?, ?)");
        foreach ($data as $j) {
            $stmt->execute([(int)$j['id'], (string)($j['code'] ?? ''), (string)$j['name']]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ==========================================
// STUDENTS FUNCTIONS
// ==========================================
function get_students($class_id = null) {
    $pdo = get_db_connection();
    static $checkedStudentCols = false;
    if (!$checkedStudentCols) {
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN is_blocked TINYINT(1) NOT NULL DEFAULT 0");
        } catch (Exception $e) {}
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN ruang VARCHAR(50) NOT NULL DEFAULT ''");
        } catch (Exception $e) {}
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN no_peserta VARCHAR(50) NOT NULL DEFAULT ''");
        } catch (Exception $e) {}
        $checkedStudentCols = true;
    }
    
    if ($class_id !== null && (int)$class_id > 0) {
        $stmt = $pdo->prepare("SELECT id, class_id, username, name, password, is_blocked, ruang, no_peserta FROM students WHERE class_id = ? ORDER BY id ASC");
        $stmt->execute([(int)$class_id]);
    } else {
        $stmt = $pdo->query("SELECT id, class_id, username, name, password, is_blocked, ruang, no_peserta FROM students ORDER BY id ASC");
    }
    $students = $stmt->fetchAll();
    foreach ($students as &$s) {
        $s['id'] = (int)$s['id'];
        $s['class_id'] = (int)$s['class_id'];
        $s['is_blocked'] = !empty($s['is_blocked']) ? 1 : 0;
        $s['ruang'] = (string)($s['ruang'] ?? '');
        $s['no_peserta'] = (string)($s['no_peserta'] ?? '');
        if (!isset($s['username']) || trim($s['username']) === '') {
            $s['username'] = 'siswa' . $s['id'];
        }
    }
    unset($s);
    return $students;
}

function save_students($data) {
    $pdo = get_db_connection();
    static $checkedStudentCols = false;
    if (!$checkedStudentCols) {
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN is_blocked TINYINT(1) NOT NULL DEFAULT 0");
        } catch (Exception $e) {}
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN ruang VARCHAR(50) NOT NULL DEFAULT ''");
        } catch (Exception $e) {}
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN no_peserta VARCHAR(50) NOT NULL DEFAULT ''");
        } catch (Exception $e) {}
        $checkedStudentCols = true;
    }
    
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM students");
        $stmt = $pdo->prepare("INSERT INTO students (id, class_id, username, name, password, is_blocked, ruang, no_peserta) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($data as $s) {
            $username = !empty($s['username']) ? $s['username'] : ('siswa' . $s['id']);
            $is_blocked = !empty($s['is_blocked']) ? 1 : 0;
            $ruang = (string)($s['ruang'] ?? '');
            $no_peserta = (string)($s['no_peserta'] ?? '');
            $stmt->execute([(int)$s['id'], (int)$s['class_id'], (string)$username, (string)$s['name'], (string)($s['password'] ?? ''), $is_blocked, $ruang, $no_peserta]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ==========================================
// RESULTS FUNCTIONS
// ==========================================
function ensure_performance_indexes() {
    static $indexed = false;
    if ($indexed) return;
    $indexed = true;

    $flagFile = __DIR__ . '/_backup_questions/.indexes_ready';
    if (file_exists($flagFile)) {
        return;
    }

    try {
        $pdo = get_db_connection();
        $chk1 = $pdo->query("SHOW INDEX FROM exam_sessions WHERE Key_name = 'idx_exam_student'")->fetchAll();
        if (empty($chk1)) {
            $pdo->exec("ALTER TABLE exam_sessions ADD INDEX idx_exam_student (exam_id, student_id)");
        }
        $chk2 = $pdo->query("SHOW INDEX FROM exam_results WHERE Key_name = 'idx_res_exam_student'")->fetchAll();
        if (empty($chk2)) {
            $pdo->exec("ALTER TABLE exam_results ADD INDEX idx_res_exam_student (exam_id, student_id)");
        }
        @file_put_contents($flagFile, '1');
    } catch (Throwable $e) {}
}

function get_results($exam_id = null) {
    ensure_performance_indexes();
    $pdo = get_db_connection();
    if ($exam_id !== null && (int)$exam_id > 0) {
        $stmt = $pdo->prepare("SELECT id, student_id, exam_id, score, violations, started_at, submitted_at, duration_seconds, answers_json FROM exam_results WHERE exam_id = ? ORDER BY id ASC");
        $stmt->execute([(int)$exam_id]);
    } else {
        $stmt = $pdo->query("SELECT id, student_id, exam_id, score, violations, started_at, submitted_at, duration_seconds, answers_json FROM exam_results ORDER BY id ASC");
    }
    $rows = $stmt->fetchAll();
    $results = [];
    foreach ($rows as $r) {
        $answers = json_decode($r['answers_json'], true);
        $results[] = [
            'id' => (int)$r['id'],
            'student_id' => (int)$r['student_id'],
            'exam_id' => (int)$r['exam_id'],
            'score' => (float)$r['score'],
            'violations' => (int)$r['violations'],
            'started_at' => $r['started_at'],
            'submitted_at' => $r['submitted_at'],
            'duration_seconds' => (int)$r['duration_seconds'],
            'answers' => $answers ?: []
        ];
    }
    return $results;
}

function save_results($data) {
    $pdo = get_db_connection();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("
            INSERT INTO exam_results (id, student_id, exam_id, score, violations, started_at, submitted_at, duration_seconds, answers_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                score = VALUES(score),
                violations = VALUES(violations),
                started_at = VALUES(started_at),
                submitted_at = VALUES(submitted_at),
                duration_seconds = VALUES(duration_seconds),
                answers_json = VALUES(answers_json)
        ");
        foreach ($data as $r) {
            $ansJson = is_array($r['answers'] ?? null) ? json_encode($r['answers'], JSON_UNESCAPED_UNICODE) : ($r['answers'] ?? '[]');
            $rId = !empty($r['id']) ? (int)$r['id'] : null;
            $stmt->execute([
                $rId,
                (int)$r['student_id'],
                (int)$r['exam_id'],
                (float)($r['score'] ?? 0),
                (int)($r['violations'] ?? 0),
                !empty($r['started_at']) ? $r['started_at'] : null,
                !empty($r['submitted_at']) ? $r['submitted_at'] : null,
                (int)($r['duration_seconds'] ?? 0),
                $ansJson
            ]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Menyimpan hasil ujian satuan (Atomic O(1) Insert/Update)
 * Sangat efisien dan aman saat ratusan siswa serentak klik kumpul ujian
 */
function save_single_result($r) {
    $pdo = get_db_connection();
    $ansJson = is_array($r['answers'] ?? null) ? json_encode($r['answers'], JSON_UNESCAPED_UNICODE) : ($r['answers'] ?? '[]');
    
    // Cek apakah siswa ini sudah memiliki rekor untuk exam_id ini
    $checkStmt = $pdo->prepare("SELECT id FROM exam_results WHERE student_id = ? AND exam_id = ? LIMIT 1");
    $checkStmt->execute([(int)$r['student_id'], (int)$r['exam_id']]);
    $existingId = $checkStmt->fetchColumn();

    if ($existingId) {
        $stmt = $pdo->prepare("
            UPDATE exam_results 
            SET score = ?, violations = ?, started_at = ?, submitted_at = ?, duration_seconds = ?, answers_json = ?
            WHERE id = ?
        ");
        $stmt->execute([
            (float)($r['score'] ?? 0),
            (int)($r['violations'] ?? 0),
            !empty($r['started_at']) ? $r['started_at'] : null,
            !empty($r['submitted_at']) ? $r['submitted_at'] : null,
            (int)($r['duration_seconds'] ?? 0),
            $ansJson,
            (int)$existingId
        ]);
        return (int)$existingId;
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO exam_results (student_id, exam_id, score, violations, started_at, submitted_at, duration_seconds, answers_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            (int)$r['student_id'],
            (int)$r['exam_id'],
            (float)($r['score'] ?? 0),
            (int)($r['violations'] ?? 0),
            !empty($r['started_at']) ? $r['started_at'] : null,
            !empty($r['submitted_at']) ? $r['submitted_at'] : null,
            (int)($r['duration_seconds'] ?? 0),
            $ansJson
        ]);
        return (int)$pdo->lastInsertId();
    }
}


// ==========================================
// SESSIONS FUNCTIONS
// ==========================================
function get_sessions($exam_id = null) {
    ensure_performance_indexes();
    $pdo = get_db_connection();
    if ($exam_id !== null && (int)$exam_id > 0) {
        $stmt = $pdo->prepare("SELECT id, student_id, exam_id, score, violations, is_locked, unlocked_by_admin, is_reset, is_forced_submit, start_time, last_active, state_json FROM exam_sessions WHERE exam_id = ?");
        $stmt->execute([(int)$exam_id]);
    } else {
        $stmt = $pdo->query("SELECT id, student_id, exam_id, score, violations, is_locked, unlocked_by_admin, is_reset, is_forced_submit, start_time, last_active, state_json FROM exam_sessions");
    }
    $rows = $stmt->fetchAll();
    $sessions = [];
    foreach ($rows as $r) {
        $state = !empty($r['state_json']) ? json_decode($r['state_json'], true) : null;
        $sessions[] = [
            'id' => (int)$r['id'],
            'student_id' => (int)$r['student_id'],
            'exam_id' => (int)$r['exam_id'],
            'score' => (float)$r['score'],
            'violations' => (int)$r['violations'],
            'is_locked' => (bool)$r['is_locked'],
            'unlocked_by_admin' => (bool)$r['unlocked_by_admin'],
            'is_reset' => (bool)$r['is_reset'],
            'is_forced_submit' => (bool)$r['is_forced_submit'],
            'start_time' => isset($r['start_time']) ? (int)$r['start_time'] : null,
            'last_active' => isset($r['last_active']) ? (int)$r['last_active'] : null,
            'state' => $state
        ];
    }
    return $sessions;
}

function save_sessions($data) {
    $pdo = get_db_connection();
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM exam_sessions");
        $stmt = $pdo->prepare("INSERT INTO exam_sessions (student_id, exam_id, score, violations, is_locked, unlocked_by_admin, is_reset, is_forced_submit, start_time, last_active, state_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($data as $s) {
            $stateJson = isset($s['state']) ? json_encode($s['state'], JSON_UNESCAPED_UNICODE) : null;
            $stmt->execute([
                (int)$s['student_id'],
                (int)($s['exam_id'] ?? 0),
                (float)($s['score'] ?? 0),
                (int)($s['violations'] ?? 0),
                !empty($s['is_locked']) ? 1 : 0,
                !empty($s['unlocked_by_admin']) ? 1 : 0,
                !empty($s['is_reset']) ? 1 : 0,
                !empty($s['is_forced_submit']) ? 1 : 0,
                isset($s['start_time']) ? (int)$s['start_time'] : time(),
                isset($s['last_active']) ? (int)$s['last_active'] : time(),
                $stateJson
            ]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function update_student_session($sessionData) {
    $pdo = get_db_connection();
    $studentId = (int)$sessionData['student_id'];
    $examId = (int)($sessionData['exam_id'] ?? 0);
    $score = (float)($sessionData['score'] ?? 0);
    $violations = (int)($sessionData['violations'] ?? 0);
    $isLocked = !empty($sessionData['is_locked']) ? 1 : 0;
    $unlockedByAdmin = !empty($sessionData['unlocked_by_admin']) ? 1 : 0;
    $isReset = !empty($sessionData['is_reset']) ? 1 : 0;
    $isForcedSubmit = !empty($sessionData['is_forced_submit']) ? 1 : 0;
    $startTime = isset($sessionData['start_time']) ? (int)$sessionData['start_time'] : time();
    $lastActive = isset($sessionData['last_active']) ? (int)$sessionData['last_active'] : time();
    $stateJson = isset($sessionData['state']) ? (is_string($sessionData['state']) ? $sessionData['state'] : json_encode($sessionData['state'], JSON_UNESCAPED_UNICODE)) : null;

    $stmt = $pdo->prepare("
        INSERT INTO exam_sessions (student_id, exam_id, score, violations, is_locked, unlocked_by_admin, is_reset, is_forced_submit, start_time, last_active, state_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            exam_id = VALUES(exam_id),
            score = VALUES(score),
            violations = VALUES(violations),
            is_locked = VALUES(is_locked),
            unlocked_by_admin = VALUES(unlocked_by_admin),
            is_reset = VALUES(is_reset),
            is_forced_submit = VALUES(is_forced_submit),
            last_active = VALUES(last_active),
            state_json = COALESCE(VALUES(state_json), state_json)
    ");

    return $stmt->execute([
        $studentId,
        $examId,
        $score,
        $violations,
        $isLocked,
        $unlockedByAdmin,
        $isReset,
        $isForcedSubmit,
        $startTime,
        $lastActive,
        $stateJson
    ]);
}

/**
 * Menghapus sesi siswa secara spesifik (Atomic O(1) Delete)
 * Mencegah penguncian tabel atau pembersihan sesi siswa lain saat submit
 */
function delete_student_session($student_id, $exam_id = null) {
    $pdo = get_db_connection();
    if ($exam_id !== null && (int)$exam_id > 0) {
        $stmt = $pdo->prepare("DELETE FROM exam_sessions WHERE student_id = ? AND (exam_id = ? OR exam_id = 0)");
        return $stmt->execute([(int)$student_id, (int)$exam_id]);
    } else {
        $stmt = $pdo->prepare("DELETE FROM exam_sessions WHERE student_id = ?");
        return $stmt->execute([(int)$student_id]);
    }
}

// ==========================================

// SETTINGS FUNCTIONS
// ==========================================
function get_settings() {
    $pdo = get_db_connection();
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $rows = $stmt->fetchAll();
    if (empty($rows)) {
        return ['require_all_answered' => false, 'min_time_submit' => 0];
    }
    $settings = [];
    $boolKeys = ['require_all_answered', 'require_password', 'prevent_multi_login', 'show_score', 'disable_token', 'dynamic_token', 'dynamic_token_all_exams'];
    foreach ($rows as $r) {
        $val = $r['setting_value'];
        if (in_array($r['setting_key'], $boolKeys)) {
            $settings[$r['setting_key']] = ($val === '1' || $val === 'true' || $val === true || $val === 1);
        } elseif (is_numeric($val) && in_array($r['setting_key'], ['min_time_submit', 'max_violations', 'lockout_duration', 'token_interval_minutes', 'sync_interval_seconds'])) {
            $settings[$r['setting_key']] = (int)$val;
        } else {
            $settings[$r['setting_key']] = $val;
        }
    }
    if (!isset($settings['require_all_answered'])) $settings['require_all_answered'] = false;
    if (!isset($settings['min_time_submit'])) $settings['min_time_submit'] = 0;
    if (!isset($settings['sync_interval_seconds'])) $settings['sync_interval_seconds'] = 60;
    return $settings;
}

function save_settings($data) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    foreach ($data as $k => $v) {
        $vStr = is_bool($v) ? ($v ? '1' : '0') : (is_array($v) ? json_encode($v) : (string)$v);
        $stmt->execute([(string)$k, $vStr]);
    }
}

// ==========================================
// EXAMS & TOKENS FUNCTIONS
// ==========================================
function generate_random_token($length = 6) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $res = '';
    $max = strlen($chars) - 1;
    for ($i = 0; $i < $length; $i++) {
        $res .= $chars[random_int(0, $max)];
    }
    return $res;
}

function get_exams_raw() {
    $pdo = get_db_connection();
    static $checkedExamCols = false;
    if (!$checkedExamCols) {
        try {
            $pdo->exec("ALTER TABLE `exams` ADD COLUMN `max_questions` INT DEFAULT 0");
        } catch(Exception $ex) {}
        $checkedExamCols = true;
    }
    $stmt = $pdo->query("SELECT * FROM exams ORDER BY id ASC");
    $rows = $stmt->fetchAll();
    $exams = [];
    foreach ($rows as $e) {
        $classes = json_decode($e['classes'] ?? '[]', true) ?: [];
        $exams[] = [
            'id' => (int)$e['id'],
            'name' => $e['name'],
            'bank_soal_id' => (int)($e['bank_soal_id'] ?? $e['id']),
            'classes' => $classes,
            'class_ids' => $classes,
            'token' => $e['token'],
            'prev_token' => $e['prev_token'],
            'prev_token_expires_at' => isset($e['prev_token_expires_at']) ? (int)$e['prev_token_expires_at'] : null,
            'token_updated_at' => isset($e['token_updated_at']) ? (int)$e['token_updated_at'] : null,
            'status' => $e['status'] ?? 'aktif',
            'start_time' => $e['start_time'],
            'end_time' => $e['end_time'],
            'duration' => (int)($e['duration'] ?? 90),
            'shuffle_questions' => isset($e['shuffle_questions']) ? (int)$e['shuffle_questions'] : 1,
            'shuffle_options' => isset($e['shuffle_options']) ? (int)$e['shuffle_options'] : 1,
            'max_questions' => isset($e['max_questions']) ? (int)$e['max_questions'] : 0,
            'created_at' => $e['created_at'] ?? null
        ];
    }
    return $exams;
}

function check_and_rotate_dynamic_tokens() {
    $settings = get_settings();
    if (empty($settings['dynamic_token'])) {
        return;
    }
    $interval_minutes = max(1, (int)($settings['token_interval_minutes'] ?? 15));
    $interval_seconds = $interval_minutes * 60;
    $now = time();

    $exams = get_exams_raw();
    if (empty($exams)) {
        return;
    }
    $updated = false;
    $use_single_token = !empty($settings['dynamic_token_all_exams']);

    if ($use_single_token) {
        // Mode: 1 Token Dinamis untuk Semua Ujian
        $max_updated_at = 0;
        $shared_token = '';
        $shared_prev_token = '';
        $shared_prev_expires = 0;

        foreach ($exams as $ex) {
            $t_updated = isset($ex['token_updated_at']) ? (int)$ex['token_updated_at'] : 0;
            if ($t_updated > $max_updated_at && !empty($ex['token'])) {
                $max_updated_at = $t_updated;
                $shared_token = $ex['token'];
                $shared_prev_token = $ex['prev_token'] ?? '';
                $shared_prev_expires = isset($ex['prev_token_expires_at']) ? (int)$ex['prev_token_expires_at'] : 0;
            }
        }

        $needs_rotation = ($max_updated_at <= 0 || ($now - $max_updated_at) >= $interval_seconds || empty($shared_token));

        if ($needs_rotation) {
            $new_token = generate_random_token(6);
            $new_prev = $shared_token;
            $new_prev_expires = $now + 120; // 2 minutes grace period
            $max_updated_at = $now;

            foreach ($exams as &$exam) {
                if ($exam['token'] !== $new_token) {
                    $exam['prev_token'] = !empty($new_prev) ? $new_prev : ($exam['token'] ?? '');
                    $exam['prev_token_expires_at'] = $new_prev_expires;
                    $exam['token'] = $new_token;
                    $exam['token_updated_at'] = $max_updated_at;
                    $updated = true;
                }
            }
            unset($exam);
        } else {
            // Token masih dalam masa interval aktif, pastikan seluruh jadwal ujian sinkron dengan 1 token yang sama
            foreach ($exams as &$exam) {
                if ($exam['token'] !== $shared_token || ($exam['token_updated_at'] ?? 0) !== $max_updated_at) {
                    $exam['token'] = $shared_token;
                    $exam['prev_token'] = $shared_prev_token;
                    $exam['prev_token_expires_at'] = $shared_prev_expires;
                    $exam['token_updated_at'] = $max_updated_at;
                    $updated = true;
                }
            }
            unset($exam);
        }
    } else {
        // Mode Default: Tiap jadwal ujian memiliki token dinamis masing-masing
        foreach ($exams as &$exam) {
            $last_gen = isset($exam['token_updated_at']) ? (int)$exam['token_updated_at'] : 0;
            if ($last_gen <= 0 || ($now - $last_gen) >= $interval_seconds) {
                if (!empty($exam['token'])) {
                    $exam['prev_token'] = $exam['token'];
                    $exam['prev_token_expires_at'] = $now + 120; // 2 minutes grace period
                }
                $exam['token'] = generate_random_token(6);
                $exam['token_updated_at'] = $now;
                $updated = true;
            }
        }
        unset($exam);
    }

    if ($updated) {
        save_exams($exams);
    }
}

function get_exams() {
    check_and_rotate_dynamic_tokens();
    return get_exams_raw();
}

function save_exams($data) {
    $pdo = get_db_connection();
    try {
        $pdo->exec("ALTER TABLE `exams` ADD COLUMN `max_questions` INT DEFAULT 0");
    } catch(Exception $ex) {}
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM exams");
        $stmt = $pdo->prepare("INSERT INTO exams (id, name, bank_soal_id, classes, token, prev_token, prev_token_expires_at, token_updated_at, status, start_time, end_time, duration, shuffle_questions, shuffle_options, max_questions, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($data as $e) {
            $classes = $e['classes'] ?? $e['class_ids'] ?? [];
            if (is_string($classes)) {
                $decoded = json_decode($classes, true);
                if (is_array($decoded)) {
                    $classes = $decoded;
                }
            }
            $classesJson = is_array($classes) ? json_encode(array_values(array_map('intval', $classes))) : '[]';

            $shuffleQ = isset($e['shuffle_questions']) ? (filter_var($e['shuffle_questions'], FILTER_VALIDATE_BOOLEAN) ? 1 : 0) : 1;
            $shuffleO = isset($e['shuffle_options']) ? (filter_var($e['shuffle_options'], FILTER_VALIDATE_BOOLEAN) ? 1 : 0) : 1;
            $maxQ = isset($e['max_questions']) ? (int)$e['max_questions'] : 0;

            $stmt->execute([
                (int)$e['id'],
                (string)$e['name'],
                (int)($e['bank_soal_id'] ?? $e['id']),
                $classesJson,
                (string)$e['token'],
                (string)($e['prev_token'] ?? null),
                isset($e['prev_token_expires_at']) ? (int)$e['prev_token_expires_at'] : null,
                isset($e['token_updated_at']) ? (int)$e['token_updated_at'] : null,
                (string)($e['status'] ?? 'aktif'),
                !empty($e['start_time']) ? date('Y-m-d H:i:s', strtotime($e['start_time'])) : null,
                !empty($e['end_time']) ? date('Y-m-d H:i:s', strtotime($e['end_time'])) : null,
                (int)($e['duration'] ?? 90),
                $shuffleQ,
                $shuffleO,
                $maxQ,
                !empty($e['created_at']) ? $e['created_at'] : date('Y-m-d H:i:s')
            ]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function delete_exam_data($exam_id) {
    $exam_id = (int)$exam_id;
    if ($exam_id <= 0) return;
    $pdo = get_db_connection();
    $stmt1 = $pdo->prepare("DELETE FROM exam_sessions WHERE exam_id = ?");
    $stmt1->execute([$exam_id]);
    $stmt2 = $pdo->prepare("DELETE FROM exam_results WHERE exam_id = ?");
    $stmt2->execute([$exam_id]);
    clean_orphan_exam_data();
}

function clean_orphan_exam_data() {
    $pdo = get_db_connection();
    try {
        $pdo->exec("DELETE FROM exam_sessions WHERE exam_id NOT IN (SELECT id FROM exams)");
        $pdo->exec("DELETE FROM exam_results WHERE exam_id NOT IN (SELECT id FROM exams)");
    } catch (Exception $e) {
        // Ignore if query fails
    }
}

// ==========================================
// BANK SOAL FUNCTIONS
// ==========================================
function get_bank_soal() {
    $pdo = get_db_connection();
    try {
        $pdo->exec("ALTER TABLE `bank_soal` ADD COLUMN `classes` TEXT NULL");
    } catch(Exception $ex) {}
    $stmt = $pdo->query("SELECT id, name, created_by, author_id, author_role, uploaded_by, classes, created_at FROM bank_soal ORDER BY id ASC");
    $rows = $stmt->fetchAll();
    $res = [];
    foreach ($rows as $b) {
        $res[] = [
            'id' => (int)$b['id'],
            'name' => $b['name'],
            'created_by' => $b['created_by'] ?? 'Administrator',
            'author_id' => (int)($b['author_id'] ?? 0),
            'author_role' => $b['author_role'] ?? 'admin',
            'uploaded_by' => $b['uploaded_by'] ?? 'Administrator',
            'classes' => $b['classes'] ?? '',
            'created_at' => $b['created_at'] ?? null
        ];
    }
    return $res;
}

function save_bank_soal($data) {
    $pdo = get_db_connection();
    try {
        $pdo->exec("ALTER TABLE `bank_soal` ADD COLUMN `classes` TEXT NULL");
    } catch(Exception $ex) {}
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM bank_soal");
        $stmt = $pdo->prepare("INSERT INTO bank_soal (id, name, created_by, author_id, author_role, uploaded_by, classes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($data as $b) {
            $stmt->execute([
                (int)$b['id'],
                (string)$b['name'],
                (string)($b['created_by'] ?? 'Administrator'),
                (int)($b['author_id'] ?? 0),
                (string)($b['author_role'] ?? 'admin'),
                (string)($b['uploaded_by'] ?? 'Administrator'),
                (string)($b['classes'] ?? ''),
                !empty($b['created_at']) ? $b['created_at'] : date('Y-m-d H:i:s')
            ]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ==========================================
// USERS / TEACHERS FUNCTIONS & ADMIN ROLES
// ==========================================

function get_admin_tasks_list() {
    return [
        'dashboard' => [
            'name' => 'Dashboard',
            'group' => 'Utama',
            'icon' => 'fas fa-tachometer-alt text-primary',
            'desc' => 'Melihat statistik ujian, siswa aktif, dan status server'
        ],
        'kelas' => [
            'name' => 'Data Kelas',
            'group' => 'Data Master',
            'icon' => 'fas fa-chalkboard text-info',
            'desc' => 'Menambah, mengedit, dan mengelola daftar kelas'
        ],
        'siswa' => [
            'name' => 'Data Siswa',
            'group' => 'Data Master',
            'icon' => 'fas fa-users text-success',
            'desc' => 'Kelola siswa, impor Excel, cetak daftar, blokir peserta'
        ],
        'guru' => [
            'name' => 'Data Guru',
            'group' => 'Data Master',
            'icon' => 'fas fa-chalkboard-teacher text-warning',
            'desc' => 'Kelola akun guru dan mata pelajaran yang diampu'
        ],
        'mata_pelajaran' => [
            'name' => 'Mata Pelajaran',
            'group' => 'Data Master',
            'icon' => 'fas fa-book text-secondary',
            'desc' => 'Kelola master daftar mata pelajaran'
        ],
        'jenis_ujian' => [
            'name' => 'Jenis Ujian',
            'group' => 'Data Master',
            'icon' => 'fas fa-tags text-purple',
            'desc' => 'Kelola jenis ujian (PH, PTS, PAS, PAT, US, Try Out)'
        ],
        'soal' => [
            'name' => 'Bank Soal',
            'group' => 'Manajemen Ujian',
            'icon' => 'fas fa-file-alt text-danger',
            'desc' => 'Kelola bank soal, edit butir soal, impor Word & Excel'
        ],
        'mapel' => [
            'name' => 'Jadwal Ujian & Token',
            'group' => 'Manajemen Ujian',
            'icon' => 'fas fa-calendar-alt text-primary',
            'desc' => 'Rilis jadwal ujian, durasi, sesi, dan token ujian'
        ],
        'cetak_kartu' => [
            'name' => 'Cetak Kartu Peserta',
            'group' => 'Manajemen Ujian',
            'icon' => 'fas fa-id-card text-info',
            'desc' => 'Generate & cetak kartu login ujian siswa'
        ],
        'status' => [
            'name' => 'Status Ujian & Nilai',
            'group' => 'Pelaksanaan',
            'icon' => 'fas fa-desktop text-success',
            'desc' => 'Monitoring peserta realtime, reset login, cetak & rekap nilai'
        ],
        'analisis' => [
            'name' => 'Analisis Soal',
            'group' => 'Pelaksanaan',
            'icon' => 'fas fa-chart-pie text-warning',
            'desc' => 'Statistik daya beda dan tingkat kesukaran soal'
        ],
        'pengaturan' => [
            'name' => 'Pengaturan & Kelola Admin',
            'group' => 'Sistem',
            'icon' => 'fas fa-cogs text-danger',
            'desc' => 'Pengaturan sekolah, token dinamis, backup DB, dan hak akses admin'
        ],
        'log' => [
            'name' => 'Log Pembaruan',
            'group' => 'Sistem',
            'icon' => 'fas fa-history text-secondary',
            'desc' => 'Catatan riwayat update dan versi CBT'
        ],
        'panduan' => [
            'name' => 'Petunjuk Penggunaan',
            'group' => 'Panduan',
            'icon' => 'fas fa-book-reader text-info',
            'desc' => 'Buku panduan pengoperasian sistem CBT'
        ]
    ];
}

function parse_admin_permissions($rawPerms) {
    if (empty($rawPerms) || $rawPerms === 'all') {
        return array_keys(get_admin_tasks_list());
    }
    if (is_array($rawPerms)) {
        return array_values($rawPerms);
    }
    $decoded = json_decode($rawPerms, true);
    if (is_array($decoded)) {
        return array_values($decoded);
    }
    $parts = array_filter(array_map('trim', explode(',', (string)$rawPerms)));
    return !empty($parts) ? array_values($parts) : array_keys(get_admin_tasks_list());
}

function admin_has_permission($taskKey, $user = null) {
    if (session_status() === PHP_SESSION_NONE) {
        @session_start();
    }
    $role = $user['role'] ?? ($_SESSION['user_role'] ?? 'admin');
    if ($role === 'guru') {
        $allowedGuru = ['dashboard', 'soal', 'status', 'analisis', 'panduan'];
        return in_array($taskKey, $allowedGuru);
    }
    if ($role !== 'admin') {
        return false;
    }
    
    $username = strtolower($user['username'] ?? ($_SESSION['username'] ?? ''));
    if ($username === 'admin') {
        return true;
    }
    
    $raw = $user['permissions'] ?? ($_SESSION['admin_permissions'] ?? 'all');
    if ($raw === 'all' || empty($raw)) {
        return true;
    }
    
    $perms = parse_admin_permissions($raw);
    return in_array($taskKey, $perms) || in_array('all', $perms);
}

function ensure_user_columns($pdo) {
    static $checkedUserCols = false;
    if (!$checkedUserCols) {
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN permissions TEXT NULL");
        } catch (Exception $e) {}
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN admin_role VARCHAR(100) DEFAULT 'Super Admin'");
        } catch (Exception $e) {}
        $checkedUserCols = true;
    }
}

function get_users() {
    $pdo = get_db_connection();
    ensure_user_columns($pdo);
    
    $stmt = $pdo->query("SELECT id, name, username, password, role, mapel, permissions, admin_role, created_at FROM users ORDER BY id ASC");
    $users = $stmt->fetchAll();
    foreach ($users as &$u) {
        $u['id'] = (int)$u['id'];
        $u['permissions'] = (string)($u['permissions'] ?? '');
        $u['admin_role'] = (string)($u['admin_role'] ?? (($u['role'] ?? '') === 'admin' ? 'Super Admin' : 'Guru'));
        if (($u['role'] ?? '') === 'admin' && empty($u['permissions'])) {
            $u['permissions'] = 'all';
        }
    }
    unset($u);

    // Pastikan akun admin utama tersedia jika belum ada
    $has_admin = false;
    foreach ($users as $u) {
        if (($u['role'] ?? '') === 'admin') {
            $has_admin = true;
            break;
        }
    }
    if (!$has_admin) {
        $max_id = count($users) > 0 ? max(array_column($users, 'id')) : 0;
        $admin = [
            'id' => $max_id + 1,
            'name' => 'Administrator',
            'username' => 'admin',
            'password' => 'Ryuna0106',
            'role' => 'admin',
            'mapel' => 'Semua',
            'permissions' => 'all',
            'admin_role' => 'Super Admin',
            'created_at' => date('Y-m-d H:i:s')
        ];
        $stmt = $pdo->prepare("INSERT INTO users (id, name, username, password, role, mapel, permissions, admin_role, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $admin['id'], 
            $admin['name'], 
            $admin['username'], 
            $admin['password'], 
            $admin['role'], 
            $admin['mapel'], 
            $admin['permissions'], 
            $admin['admin_role'], 
            $admin['created_at']
        ]);
        $users[] = $admin;
    }
    return $users;
}

function save_users($data) {
    $pdo = get_db_connection();
    ensure_user_columns($pdo);
    
    $pdo->beginTransaction();
    try {
        $pdo->exec("DELETE FROM users");
        $stmt = $pdo->prepare("INSERT INTO users (id, name, username, password, role, mapel, permissions, admin_role, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($data as $u) {
            $perms = $u['permissions'] ?? '';
            if (is_array($perms)) {
                $perms = json_encode(array_values($perms));
            } elseif (empty($perms) && ($u['role'] ?? '') === 'admin') {
                $perms = 'all';
            }
            
            $stmt->execute([
                (int)$u['id'],
                (string)$u['name'],
                (string)$u['username'],
                (string)$u['password'],
                (string)($u['role'] ?? 'guru'),
                (string)($u['mapel'] ?? 'Umum'),
                (string)$perms,
                (string)($u['admin_role'] ?? (($u['role'] ?? '') === 'admin' ? 'Super Admin' : 'Guru')),
                !empty($u['created_at']) ? $u['created_at'] : date('Y-m-d H:i:s')
            ]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ==========================================
// QUESTIONS DATABASE HELPER FUNCTIONS
// ==========================================

/**
 * Memangkas opsi kosong di bagian akhir pilihan ganda (misal guru membuat 4 opsi, opsi ke-5 kosong).
 */
function trim_trailing_empty_options($options) {
    if (!is_array($options)) return $options;
    while (count($options) > 2) {
        $last = end($options);
        $clean = trim(strip_tags((string)$last, '<img><audio><video>'));
        $clean = str_replace(['&nbsp;', '&#160;', "\xc2\xa0"], '', $clean);
        $clean = trim($clean);
        if ($clean === '' && strpos((string)$last, '<img') === false && strpos((string)$last, '<audio') === false && strpos((string)$last, '<video') === false) {
            array_pop($options);
        } else {
            break;
        }
    }
    return array_values($options);
}

function get_questions_json_file($bank_id) {
    $dir = __DIR__ . '/_backup_questions';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
        @file_put_contents($dir . '/.htaccess', "Require all denied\n");
    }
    return $dir . "/questions_{$bank_id}.json";
}

function get_questions_db($bank_id) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare("SELECT question_data FROM questions WHERE bank_soal_id = ? ORDER BY question_index ASC");
    $stmt->execute([(int)$bank_id]);
    $rows = $stmt->fetchAll();
    $questions = [];
    foreach ($rows as $r) {
        $q = json_decode($r['question_data'], true);
        if ($q !== null) {
            $questions[] = $q;
        }
    }
    // Fallback jika di MySQL belum ada tapi berkas JSON lokal tersedia
    if (empty($questions)) {
        $q_file = get_questions_json_file($bank_id);
        if (!file_exists($q_file)) {
            $q_file = __DIR__ . "/questions_{$bank_id}.json";
        }
        if (file_exists($q_file)) {
            $fileData = json_decode(file_get_contents($q_file), true);
            if (is_array($fileData) && !empty($fileData)) {
                $questions = $fileData;
                // Sinkronisasi otomatis ke MySQL
                try {
                    save_questions_db($bank_id, $questions);
                } catch (Exception $e) {}
            }
        }
    }
    
    // Otomatis bersihkan opsi kosong di akhir (misal opsi E kosong pada soal 4 opsi)
    foreach ($questions as &$q) {
        if (!empty($q['options']) && is_array($q['options']) && ($q['type'] ?? 'multiple_choice') !== 'matching') {
            $q['options'] = trim_trailing_empty_options($q['options']);
        }
    }
    unset($q);

    return $questions;
}

/**
 * Mengonversi data biner gambar (PNG, JPEG, GIF, BMP) menjadi WebP dengan kompresi optimal.
 * Mempertahankan transparansi (alpha channel) untuk PNG & GIF.
 * Secara otomatis meresize jika dimensi melebihi maxDimension (default: 1600px) untuk hemat memori.
 *
 * @param string $binaryData Data biner gambar mentah
 * @param int $quality Kualitas WebP (default: 80)
 * @param int $maxDimension Batas resolusi maksimum lebar/tinggi (default: 1600px, 0 untuk tanpa batas)
 * @return string Data biner WebP (atau biner asli jika gagal / sudah webp / GD tidak tersedia)
 */
function convert_image_binary_to_webp($binaryData, $quality = 80, $maxDimension = 1600) {
    if (empty($binaryData) || !function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
        return $binaryData;
    }

    // Cek apakah sudah berformat WebP (Header RIFF .... WEBP)
    if (strlen($binaryData) >= 12 && substr($binaryData, 0, 4) === 'RIFF' && substr($binaryData, 8, 4) === 'WEBP') {
        return $binaryData;
    }

    $img = @imagecreatefromstring($binaryData);
    if (!$img) {
        return $binaryData;
    }

    $origW = imagesx($img);
    $origH = imagesy($img);

    // Jika resolusi sangat besar (> maxDimension), resize proporsional agar hemat memori & loading cepat
    if ($maxDimension > 0 && ($origW > $maxDimension || $origH > $maxDimension) && function_exists('imagescale')) {
        if ($origW >= $origH) {
            $newW = $maxDimension;
            $newH = (int)round(($origH / $origW) * $newW);
        } else {
            $newH = $maxDimension;
            $newW = (int)round(($origW / $origH) * $newH);
        }
        $scaled = @imagescale($img, $newW, $newH);
        if ($scaled) {
            imagedestroy($img);
            $img = $scaled;
        }
    }

    // Pertahankan transparansi (alpha channel) untuk PNG / GIF
    imagealphablending($img, false);
    imagesavealpha($img, true);

    ob_start();
    $success = @imagewebp($img, null, $quality);
    $webpBinary = ob_get_clean();
    imagedestroy($img);

    if ($success && !empty($webpBinary)) {
        return $webpBinary;
    }

    return $binaryData;
}

/**
 * Menghasilkan ikon PWA standar (icon-192.png dan icon-512.png) dari gambar sumber.
 * Gambar diposisikan di tengah kanvas persegi transparan secara proporsional.
 *
 * @param string $sourcePath Path berkas gambar sumber
 * @param string $baseDir Direktori basis aplikasi (default __DIR__)
 * @return bool Berhasil atau tidak
 */
function generate_pwa_icons_from_source($sourcePath, $baseDir = __DIR__) {
    if (!file_exists($sourcePath)) {
        return false;
    }

    $dest192 = $baseDir . '/icon-192.png';
    $dest512 = $baseDir . '/icon-512.png';
    $default192 = $baseDir . '/icon-192.default.png';
    $default512 = $baseDir . '/icon-512.default.png';

    // Backup default icons jika belum ada
    if (!file_exists($default192) && file_exists($dest192)) {
        @copy($dest192, $default192);
    }
    if (!file_exists($default512) && file_exists($dest512)) {
        @copy($dest512, $default512);
    }

    $binary = @file_get_contents($sourcePath);
    if (empty($binary)) {
        return false;
    }

    // Jika GD tersedia, lakukan resize proporsional dengan kanvas transparan
    if (function_exists('imagecreatefromstring') && function_exists('imagecreatetruecolor') && function_exists('imagepng')) {
        $srcImg = @imagecreatefromstring($binary);
        if ($srcImg) {
            $origW = imagesx($srcImg);
            $origH = imagesy($srcImg);

            $sizes = [
                192 => $dest192,
                512 => $dest512
            ];

            foreach ($sizes as $targetSize => $targetFile) {
                $canvas = imagecreatetruecolor($targetSize, $targetSize);
                imagealphablending($canvas, false);
                imagesavealpha($canvas, true);
                $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
                imagefill($canvas, 0, 0, $transparent);
                imagealphablending($canvas, true);

                $ratio = min($targetSize / max(1, $origW), $targetSize / max(1, $origH));
                $newW = max(1, (int)round($origW * $ratio));
                $newH = max(1, (int)round($origH * $ratio));
                $dstX = (int)round(($targetSize - $newW) / 2);
                $dstY = (int)round(($targetSize - $newH) / 2);

                imagecopyresampled($canvas, $srcImg, $dstX, $dstY, 0, 0, $newW, $newH, $origW, $origH);
                imagealphablending($canvas, false);
                imagesavealpha($canvas, true);

                @imagepng($canvas, $targetFile, 9);
                imagedestroy($canvas);
            }

            imagedestroy($srcImg);
            return true;
        }
    }

    // Fallback jika GD tidak dapat memproses gambar
    @copy($sourcePath, $dest512);
    @copy($sourcePath, $dest192);
    return true;
}

/**
 * Mengembalikan ikon PWA ke berkas bawaan sistem jika tersedia.
 */
function reset_pwa_icons_to_default($baseDir = __DIR__) {
    $dest192 = $baseDir . '/icon-192.png';
    $dest512 = $baseDir . '/icon-512.png';
    $default192 = $baseDir . '/icon-192.default.png';
    $default512 = $baseDir . '/icon-512.default.png';

    $restored = false;
    if (file_exists($default192)) {
        @copy($default192, $dest192);
        $restored = true;
    }
    if (file_exists($default512)) {
        @copy($default512, $dest512);
        $restored = true;
    }
    return $restored;
}

/**
 * Memperbarui file manifest.json agar sinkron dengan nama sekolah dan ikon PWA terkini.
 */
function sync_pwa_manifest_json($schoolName = '', $schoolDesc = '', $baseDir = __DIR__) {
    $name = !empty($schoolName) ? trim($schoolName) : 'RyuExam CBT';
    $desc = !empty($schoolDesc) ? trim($schoolDesc) : 'Aplikasi Ujian Berbasis Komputer (CBT) Online';
    $shortName = mb_strimwidth($name, 0, 15, '');

    $manifest = [
        'name' => $name . ' - CBT Ujian Online',
        'short_name' => $shortName,
        'description' => $desc,
        'start_url' => 'index.php',
        'scope' => './',
        'display' => 'standalone',
        'background_color' => '#1F7FAB',
        'theme_color' => '#1F7FAB',
        'orientation' => 'portrait-primary',
        'lang' => 'id',
        'icons' => [
            [
                'src' => 'icon-192.png',
                'sizes' => '192x192',
                'type' => 'image/png',
                'purpose' => 'any'
            ],
            [
                'src' => 'icon-192.png',
                'sizes' => '192x192',
                'type' => 'image/png',
                'purpose' => 'maskable'
            ],
            [
                'src' => 'icon-512.png',
                'sizes' => '512x512',
                'type' => 'image/png',
                'purpose' => 'any'
            ],
            [
                'src' => 'icon-512.png',
                'sizes' => '512x512',
                'type' => 'image/png',
                'purpose' => 'maskable'
            ]
        ]
    ];

    $jsonStr = json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    @file_put_contents($baseDir . '/manifest.json', $jsonStr);
}

/**
 * Memindai tag <img> dalam string HTML dan mengonversi gambar data URI menjadi WebP.
 * Memperbaiki pula data:null;base64 atau mime yang keliru jika datanya WebP.
 *
 * @param string $html String HTML pertanyaan/opsi
 * @param int $quality Kualitas kompresi WebP
 * @param int &$convertedCount Counter jumlah gambar yang dikonversi
 * @return string HTML yang telah dioptimasi
 */
function optimize_html_images_to_webp($html, $quality = 80, &$convertedCount = 0) {
    if (empty($html) || !is_string($html)) return $html;

    @ini_set('pcre.backtrack_limit', '10000000');
    @ini_set('pcre.recursion_limit', '10000000');

    // Gunakan regex non-backtracking untuk mengekstrak tag <img> dan src tanpa risiko PREG_BACKTRACK_LIMIT_ERROR
    $result = preg_replace_callback('/<img\b([^>]*?)\bsrc=(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))([^>]*?)>/i', function($matches) use ($quality, &$convertedCount) {
        $prefix = $matches[1];
        $quote = '"';
        $src = '';
        if ($matches[2] !== '') {
            $quote = '"';
            $src = $matches[2];
        } elseif ($matches[3] !== '') {
            $quote = "'";
            $src = $matches[3];
        } elseif (isset($matches[4])) {
            $quote = '';
            $src = $matches[4];
        }
        $suffix = $matches[5];
        $srcTrim = trim($src);

        // Format data URI base64: data:image/xxx;base64,... atau data:null;base64,...
        if (substr($srcTrim, 0, 5) === 'data:') {
            $commaPos = strpos($srcTrim, ',');
            if ($commaPos !== false) {
                $meta = substr($srcTrim, 5, $commaPos - 5);
                $rawBase64 = substr($srcTrim, $commaPos + 1);

                // Cek jika encoding base64
                if (stripos($meta, ';base64') !== false) {
                    $mime = strtolower(trim(str_replace(';base64', '', $meta)));
                    
                    // Jika sudah WebP atau SVG vektor murni, biarkan apa adanya
                    if ($mime === 'image/webp' || $mime === 'image/svg+xml') {
                        return $matches[0];
                    }

                    $rawBase64Clean = str_replace([' ', "\r", "\n", "\t"], ['+', '', '', ''], $rawBase64);
                    $bin = base64_decode($rawBase64Clean);
                    if ($bin !== false && strlen($bin) > 0) {
                        // Periksa jika biner sebenarnya sudah WebP (magic bytes RIFF...WEBP)
                        if (strlen($bin) >= 12 && substr($bin, 0, 4) === 'RIFF' && substr($bin, 8, 4) === 'WEBP') {
                            $convertedCount++;
                            $newSrc = 'data:image/webp;base64,' . $rawBase64Clean;
                            return "<img{$prefix}src={$quote}{$newSrc}{$quote}{$suffix}>";
                        }

                        $webpBin = convert_image_binary_to_webp($bin, $quality);
                        if (!empty($webpBin)) {
                            $convertedCount++;
                            $newSrc = 'data:image/webp;base64,' . base64_encode($webpBin);
                            return "<img{$prefix}src={$quote}{$newSrc}{$quote}{$suffix}>";
                        }
                    }
                }
            }
        }

        return $matches[0];
    }, $html);

    // Keamanan mutlak: Jika regex mengembalikan null karena isu PCRE apa pun, jangan pernah me-return null! Kembalikan HTML asli.
    return ($result !== null) ? $result : $html;
}

/**
 * Mengoptimasi seluruh gambar di dalam butir-butir soal (soal, pilihan, pernyataan, premis) menjadi .webp.
 *
 * @param array &$questions Array butir soal
 * @param int $quality Kualitas kompresi WebP (default: 80)
 * @param int &$convertedCount Total gambar yang berhasil dikonversi
 * @return array Array butir soal yang telah teroptimasi
 */
function optimize_questions_images_to_webp(&$questions, $quality = 80, &$convertedCount = 0) {
    if (!is_array($questions)) return $questions;
    foreach ($questions as &$q) {
        if (!is_array($q)) continue;
        if (isset($q['question']) && is_string($q['question'])) {
            $opt = optimize_html_images_to_webp($q['question'], $quality, $convertedCount);
            if ($opt !== null) {
                $q['question'] = $opt;
            }
        }
        if (isset($q['text']) && is_string($q['text'])) {
            $opt = optimize_html_images_to_webp($q['text'], $quality, $convertedCount);
            if ($opt !== null) {
                $q['text'] = $opt;
            }
        }
        if (isset($q['options']) && is_array($q['options'])) {
            foreach ($q['options'] as &$opt) {
                if (is_string($opt)) {
                    $optRes = optimize_html_images_to_webp($opt, $quality, $convertedCount);
                    if ($optRes !== null) {
                        $opt = $optRes;
                    }
                }
            }
            unset($opt);
        }
        if (isset($q['statements']) && is_array($q['statements'])) {
            foreach ($q['statements'] as &$st) {
                if (is_array($st) && isset($st['text']) && is_string($st['text'])) {
                    $opt = optimize_html_images_to_webp($st['text'], $quality, $convertedCount);
                    if ($opt !== null) {
                        $st['text'] = $opt;
                    }
                } elseif (is_string($st)) {
                    $opt = optimize_html_images_to_webp($st, $quality, $convertedCount);
                    if ($opt !== null) {
                        $st = $opt;
                    }
                }
            }
            unset($st);
        }
        if (isset($q['premises']) && is_array($q['premises'])) {
            foreach ($q['premises'] as &$prem) {
                if (is_array($prem) && isset($prem['text']) && is_string($prem['text'])) {
                    $opt = optimize_html_images_to_webp($prem['text'], $quality, $convertedCount);
                    if ($opt !== null) {
                        $prem['text'] = $opt;
                    }
                } elseif (is_string($prem)) {
                    $opt = optimize_html_images_to_webp($prem, $quality, $convertedCount);
                    if ($opt !== null) {
                        $prem = $opt;
                    }
                }
            }
            unset($prem);
        }
    }
    unset($q);
    return $questions;
}

function save_questions_db($bank_id, $questions) {
    if (!empty($questions) && is_array($questions)) {
        foreach ($questions as &$q) {
            if (!empty($q['options']) && is_array($q['options']) && ($q['type'] ?? 'multiple_choice') !== 'matching') {
                $q['options'] = trim_trailing_empty_options($q['options']);
            }
        }
        unset($q);
        $questions = optimize_questions_images_to_webp($questions);
    }
    $pdo = get_db_connection();
    $pdo->beginTransaction();
    try {
        $stmtDel = $pdo->prepare("DELETE FROM questions WHERE bank_soal_id = ?");
        $stmtDel->execute([(int)$bank_id]);

        $stmtIns = $pdo->prepare("INSERT INTO questions (bank_soal_id, question_index, question_data) VALUES (?, ?, ?)");
        foreach ($questions as $idx => $q) {
            $stmtIns->execute([(int)$bank_id, (int)$idx, json_encode($q, JSON_UNESCAPED_UNICODE)]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }

    // Dual Live-Sync: Sinkronkan ke berkas lokal JSON di folder terproteksi
    try {
        $q_file = get_questions_json_file($bank_id);
        if (empty($questions)) {
            if (file_exists($q_file)) @unlink($q_file);
        } else {
            file_put_contents($q_file, json_encode(array_values($questions), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        $legacy_file = __DIR__ . "/questions_{$bank_id}.json";
        if (file_exists($legacy_file)) @unlink($legacy_file);
    } catch (Exception $e) {}
}

/**
 * Menambahkan soal baru ke bank soal TANPA menghapus soal yang sudah ada.
 * Soal baru ditambahkan setelah soal terakhir yang ada.
 */
function append_questions_db($bank_id, $new_questions) {
    if (!empty($new_questions) && is_array($new_questions)) {
        $new_questions = optimize_questions_images_to_webp($new_questions);
    }
    $pdo = get_db_connection();
    
    // Ambil soal yang sudah ada
    $existing = get_questions_db($bank_id);
    
    // Gabungkan: soal lama + soal baru
    $merged = array_merge($existing, $new_questions);
    
    // Simpan ulang dengan index yang benar
    $pdo->beginTransaction();
    try {
        $stmtDel = $pdo->prepare("DELETE FROM questions WHERE bank_soal_id = ?");
        $stmtDel->execute([(int)$bank_id]);

        $stmtIns = $pdo->prepare("INSERT INTO questions (bank_soal_id, question_index, question_data) VALUES (?, ?, ?)");
        foreach ($merged as $idx => $q) {
            $stmtIns->execute([(int)$bank_id, (int)$idx, json_encode($q, JSON_UNESCAPED_UNICODE)]);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }

    // Sync ke JSON di folder terproteksi
    try {
        $q_file = get_questions_json_file($bank_id);
        file_put_contents($q_file, json_encode(array_values($merged), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $legacy_file = __DIR__ . "/questions_{$bank_id}.json";
        if (file_exists($legacy_file)) @unlink($legacy_file);
    } catch (Exception $e) {}
    
    return count($existing); // return jumlah soal lama (untuk info)
}

function delete_questions_by_bank($bank_id) {
    $pdo = get_db_connection();
    $stmt = $pdo->prepare("DELETE FROM questions WHERE bank_soal_id = ?");
    $stmt->execute([(int)$bank_id]);
    $q_file = get_questions_json_file($bank_id);
    if (file_exists($q_file)) @unlink($q_file);
    $legacy_file = __DIR__ . "/questions_{$bank_id}.json";
    if (file_exists($legacy_file)) @unlink($legacy_file);
}

function clean_orphan_questions() {
    try {
        $pdo = get_db_connection();
        $pdo->exec("DELETE FROM questions WHERE bank_soal_id NOT IN (SELECT id FROM bank_soal)");
    } catch (Exception $e) {
        // Silently handle if table not created yet
    }
}

function get_question_counts() {
    $pdo = get_db_connection();
    $counts = [];
    try {
        $stmt = $pdo->query("SELECT bank_soal_id, COUNT(*) as cnt FROM questions GROUP BY bank_soal_id");
        while ($row = $stmt->fetch()) {
            $counts[(int)$row['bank_soal_id']] = (int)$row['cnt'];
        }
    } catch (Exception $e) {}
    return $counts;
}

// ==========================================
// SERVER-SIDE SCORING ENGINE
// ==========================================
function calculate_exam_score($bank_id, $student_answers) {
    static $bank_cache = [];
    $bId = (int)$bank_id;
    if (!isset($bank_cache[$bId])) {
        $bank_cache[$bId] = get_questions_db($bId);
    }
    $bank_questions = $bank_cache[$bId];
    if (empty($bank_questions)) {
        return 0;
    }

    $normalize_opt = function($val) {
        if ($val === null || $val === '') return null;
        $valStr = trim((string)$val);
        if (is_numeric($valStr)) {
            return (int)$valStr;
        }
        $upper = strtoupper($valStr);
        if (strlen($upper) === 1 && $upper >= 'A' && $upper <= 'Z') {
            return ord($upper) - 65;
        }
        return $valStr;
    };

    // Index jawaban siswa dari berbagai kemungkinan format (dengan originalId, teks soal, urutan array)
    $answers_by_id = [];
    $answers_by_qtext = [];
    $answers_by_seq = [];
    $answers_awarded_by_id = [];

    if (is_array($student_answers)) {
        $seq = 0;
        foreach ($student_answers as $k => $item) {
            $sel = null;
            $origId = null;
            $qText = null;
            $awardedPoints = null;

            if (is_array($item)) {
                $sel = $item['selected'] ?? ($item['selectedOption'] ?? null);
                if (isset($item['originalId'])) {
                    $origId = (int)$item['originalId'];
                }
                if (!empty($item['question'])) {
                    $qText = trim(strip_tags(html_entity_decode((string)$item['question'])));
                }
                if (isset($item['awarded_points'])) {
                    $awardedPoints = (float)$item['awarded_points'];
                }
            } else {
                $sel = $item;
                if (is_numeric($k)) {
                    $origId = (int)$k;
                }
            }

            if ($origId !== null) {
                $answers_by_id[$origId] = $sel;
                if ($awardedPoints !== null) {
                    $answers_awarded_by_id[$origId] = $awardedPoints;
                }
            }
            if ($qText !== null && $qText !== '') {
                $answers_by_qtext[$qText] = $sel;
            }
            $answers_by_seq[$seq] = $sel;
            $seq++;
        }
    }

    $total_score = 0;

    foreach ($bank_questions as $q_idx => $q) {
        $q_type = $q['type'] ?? 'multiple_choice';
        $points = isset($q['points']) ? (float)$q['points'] : 2.0;

        // Cari jawaban siswa: prioritas 1) originalId, 2) teks soal, 3) index urutan
        $selected = null;
        $clean_bank_qtext = !empty($q['question']) ? trim(strip_tags(html_entity_decode((string)$q['question']))) : '';

        if (array_key_exists($q_idx, $answers_by_id)) {
            $selected = $answers_by_id[$q_idx];
        } elseif ($clean_bank_qtext !== '' && array_key_exists($clean_bank_qtext, $answers_by_qtext)) {
            $selected = $answers_by_qtext[$clean_bank_qtext];
        } elseif (array_key_exists($q_idx, $answers_by_seq) && empty($answers_by_id)) {
            $selected = $answers_by_seq[$q_idx];
        }

        if ($q_type === 'essay') {
            // Esai dinilai manual oleh guru / admin: jika sudah ada nilai yang pernah diberikan, pertahankan
            if (isset($answers_awarded_by_id[$q_idx])) {
                $total_score += (float)$answers_awarded_by_id[$q_idx];
            }
            continue;
        }

        if ($selected === null || $selected === '' || $selected === []) {
            continue;
        }

        if ($q_type === 'complex_mc') {
            // Pilihan Ganda Kompleks standar ANBK
            $correct_raw = $q['answers'] ?? (isset($q['answer']) ? [$q['answer']] : []);
            if (!is_array($correct_raw)) {
                $correct_raw = [$correct_raw];
            }
            $correct_vals = array_map($normalize_opt, $correct_raw);
            $selected_raw = is_array($selected) ? $selected : [$selected];
            $selected_vals = array_map($normalize_opt, $selected_raw);

            if (!empty($correct_vals)) {
                $correct_count = count(array_intersect($selected_vals, $correct_vals));
                $wrong_count = count(array_diff($selected_vals, $correct_vals));
                $ratio = max(0, ($correct_count - $wrong_count) / count($correct_vals));
                $total_score += $ratio * $points;
            }
        } elseif ($q_type === 'true_false') {
            // Benar - Salah per baris pernyataan
            $statements = $q['statements'] ?? [];
            if (!empty($statements) && (is_array($selected) || is_object($selected))) {
                $points_per_statement = $points / count($statements);
                foreach ($statements as $s_idx => $stmt) {
                    $s_val = is_array($selected) ? ($selected[$s_idx] ?? null) : ($selected->$s_idx ?? null);
                    if ($s_val !== null) {
                        $student_ans = ($s_val === true || $s_val === 'true' || $s_val === 1 || $s_val === '1' || strtolower((string)$s_val) === 'b');
                        $stmt_ans = !empty($stmt['answer']) && ($stmt['answer'] === true || $stmt['answer'] === 'true' || $stmt['answer'] === 1 || $stmt['answer'] === '1' || strtolower((string)$stmt['answer']) === 'b');
                        if ($student_ans === $stmt_ans) {
                            $total_score += $points_per_statement;
                        }
                    }
                }
            }
        } elseif ($q_type === 'matching') {
            // Menjodohkan per pasangan
            $premises = $q['premises'] ?? [];
            $pairs = $q['pairs'] ?? [];
            if (!empty($premises) && !empty($pairs) && (is_array($selected) || is_object($selected))) {
                $points_per_match = $points / count($premises);
                foreach ($premises as $p_idx => $premise) {
                    $expected = is_array($pairs) ? ($pairs[$p_idx] ?? ($pairs[(string)$p_idx] ?? null)) : ($pairs->$p_idx ?? null);
                    $actual = is_array($selected) ? ($selected[$p_idx] ?? ($selected[(string)$p_idx] ?? null)) : ($selected->$p_idx ?? null);
                    if ($expected !== null && $actual !== null && (string)$actual === (string)$expected) {
                        $total_score += $points_per_match;
                    }
                }
            }
        } else {
            // Pilihan Ganda biasa
            $expected_opt = $normalize_opt($q['answer'] ?? null);
            $student_opt = $normalize_opt($selected);
            if ($expected_opt !== null && $student_opt !== null && $student_opt === $expected_opt) {
                $total_score += $points;
            }
        }
    }

    return round($total_score, 2);
}

/**
 * Menghitung jumlah benar dan salah (B/S) jawaban siswa terhadap bank soal
 */
function calculate_exam_bs_count($bank_questions, $student_answers) {
    if (empty($bank_questions) || !is_array($bank_questions)) {
        return [
            'correct_count' => 0,
            'wrong_count' => 0,
            'total' => 0,
            'bs' => '-'
        ];
    }

    $normalize_opt = function($val) {
        if ($val === null || $val === '') return null;
        $valStr = trim((string)$val);
        if (is_numeric($valStr)) {
            return (int)$valStr;
        }
        $upper = strtoupper($valStr);
        if (strlen($upper) === 1 && $upper >= 'A' && $upper <= 'Z') {
            return ord($upper) - 65;
        }
        return $valStr;
    };

    $answers_by_id = [];
    $answers_by_qtext = [];
    $answers_by_seq = [];
    $answers_awarded_by_id = [];

    if (is_array($student_answers)) {
        $seq = 0;
        foreach ($student_answers as $k => $item) {
            $sel = null;
            $origId = null;
            $qText = null;
            $awardedPoints = null;

            if (is_array($item)) {
                $sel = $item['selected'] ?? ($item['selectedOption'] ?? null);
                if (isset($item['originalId'])) {
                    $origId = (int)$item['originalId'];
                }
                if (!empty($item['question'])) {
                    $qText = trim(strip_tags(html_entity_decode((string)$item['question'])));
                }
                if (isset($item['awarded_points'])) {
                    $awardedPoints = (float)$item['awarded_points'];
                }
            } else {
                $sel = $item;
                if (is_numeric($k)) {
                    $origId = (int)$k;
                }
            }

            if ($origId !== null) {
                $answers_by_id[$origId] = $sel;
                if ($awardedPoints !== null) {
                    $answers_awarded_by_id[$origId] = $awardedPoints;
                }
            }
            if ($qText !== null && $qText !== '') {
                $answers_by_qtext[$qText] = $sel;
            }
            $answers_by_seq[$seq] = $sel;
            $seq++;
        }
    }

    $correct_count = 0;
    $total_q = count($bank_questions);

    foreach ($bank_questions as $q_idx => $q) {
        $q_type = $q['type'] ?? 'multiple_choice';
        $selected = null;
        $clean_bank_qtext = !empty($q['question']) ? trim(strip_tags(html_entity_decode((string)$q['question']))) : '';

        if (array_key_exists($q_idx, $answers_by_id)) {
            $selected = $answers_by_id[$q_idx];
        } elseif ($clean_bank_qtext !== '' && array_key_exists($clean_bank_qtext, $answers_by_qtext)) {
            $selected = $answers_by_qtext[$clean_bank_qtext];
        } elseif (array_key_exists($q_idx, $answers_by_seq) && empty($answers_by_id)) {
            $selected = $answers_by_seq[$q_idx];
        }

        $is_correct = false;
        if ($selected !== null && $selected !== '' && $selected !== []) {
            if ($q_type === 'complex_mc') {
                $correct_raw = $q['answers'] ?? (isset($q['answer']) ? [$q['answer']] : []);
                if (!is_array($correct_raw)) $correct_raw = [$correct_raw];
                $correct_vals = array_values(array_filter(array_map($normalize_opt, $correct_raw), function($v) { return $v !== null; }));
                $selected_raw = is_array($selected) ? $selected : [$selected];
                $selected_vals = array_values(array_filter(array_map($normalize_opt, $selected_raw), function($v) { return $v !== null; }));
                sort($correct_vals);
                sort($selected_vals);
                $is_correct = (!empty($correct_vals) && $selected_vals === $correct_vals);
            } elseif ($q_type === 'true_false') {
                $statements = $q['statements'] ?? [];
                if (!empty($statements) && (is_array($selected) || is_object($selected))) {
                    $allMatch = true;
                    foreach ($statements as $s_idx => $stmt) {
                        $s_val = is_array($selected) ? ($selected[$s_idx] ?? null) : ($selected->$s_idx ?? null);
                        if ($s_val !== null) {
                            $student_ans = ($s_val === true || $s_val === 'true' || $s_val === 1 || $s_val === '1' || strtolower((string)$s_val) === 'b');
                            $stmt_ans = !empty($stmt['answer']) && ($stmt['answer'] === true || $stmt['answer'] === 'true' || $stmt['answer'] === 1 || $stmt['answer'] === '1' || strtolower((string)$stmt['answer']) === 'b');
                            if ($student_ans !== $stmt_ans) {
                                $allMatch = false;
                                break;
                            }
                        } else {
                            $allMatch = false;
                            break;
                        }
                    }
                    $is_correct = $allMatch;
                }
            } elseif ($q_type === 'matching') {
                $premises = $q['premises'] ?? [];
                $pairs = $q['pairs'] ?? [];
                if (!empty($premises) && !empty($pairs) && (is_array($selected) || is_object($selected))) {
                    $allMatch = true;
                    foreach ($premises as $p_idx => $premise) {
                        $expected = is_array($pairs) ? ($pairs[$p_idx] ?? ($pairs[(string)$p_idx] ?? null)) : ($pairs->$p_idx ?? null);
                        $actual = is_array($selected) ? ($selected[$p_idx] ?? ($selected[(string)$p_idx] ?? null)) : ($selected->$p_idx ?? null);
                        if ($expected === null || $actual === null || (string)$actual !== (string)$expected) {
                            $allMatch = false;
                            break;
                        }
                    }
                    $is_correct = $allMatch;
                }
            } elseif ($q_type === 'essay') {
                if (isset($answers_awarded_by_id[$q_idx])) {
                    $is_correct = ((float)$answers_awarded_by_id[$q_idx] > 0);
                }
            } else {
                $expected_opt = $normalize_opt($q['answer'] ?? null);
                $student_opt = $normalize_opt($selected);
                $is_correct = ($expected_opt !== null && $student_opt !== null && $student_opt === $expected_opt);
            }
        }

        if ($is_correct) {
            $correct_count++;
        }
    }

    $wrong_count = max(0, $total_q - $correct_count);
    return [
        'correct_count' => $correct_count,
        'wrong_count' => $wrong_count,
        'total' => $total_q,
        'bs' => "{$correct_count}/{$wrong_count}"
    ];
}

// ==========================================
// AUTO-RECALCULATE EXAM SCORES ENGINE
// ==========================================
function recalculate_bank_results($bank_id) {
    $bank_id = (int)$bank_id;
    if ($bank_id <= 0) return 0;
    
    $exams = get_exams_raw();
    $targetExamIds = [];
    foreach ($exams as $e) {
        $bId = (int)($e['bank_soal_id'] ?? $e['id']);
        if ($bId === $bank_id) {
            $targetExamIds[] = (int)$e['id'];
        }
    }
    if (!in_array($bank_id, $targetExamIds)) {
        $targetExamIds[] = $bank_id;
    }
    
    $results = get_results();
    $updatedCount = 0;
    
    foreach ($results as &$r) {
        $exam_id = (int)($r['exam_id'] ?? 0);
        if (in_array($exam_id, $targetExamIds)) {
            $answers = is_string($r['answers']) ? json_decode($r['answers'], true) : $r['answers'];
            if (is_array($answers) && !empty($answers)) {
                $newScore = calculate_exam_score($bank_id, $answers);
                $r['score'] = $newScore;
                $updatedCount++;
            }
        }
    }
    unset($r);
    
    if ($updatedCount > 0) {
        save_results($results);
    }
    
    return $updatedCount;
}

function recalculate_exam_results($exam_id) {
    $exam_id = (int)$exam_id;
    if ($exam_id <= 0) return 0;
    
    $exams = get_exams_raw();
    $bank_id = $exam_id;
    foreach ($exams as $e) {
        if ((int)$e['id'] === $exam_id) {
            $bank_id = (int)($e['bank_soal_id'] ?? $e['id']);
            break;
        }
    }
    
    $results = get_results();
    $updatedCount = 0;
    
    foreach ($results as &$r) {
        if ((int)($r['exam_id'] ?? 0) === $exam_id) {
            $answers = is_string($r['answers']) ? json_decode($r['answers'], true) : $r['answers'];
            if (is_array($answers) && !empty($answers)) {
                $newScore = calculate_exam_score($bank_id, $answers);
                $r['score'] = $newScore;
                $updatedCount++;
            }
        }
    }
    unset($r);
    
    if ($updatedCount > 0) {
        save_results($results);
    }
    
    return $updatedCount;
}


// ==========================================
// MYSQL BACKUP & RESTORE ENGINE
// ==========================================
function export_mysql_database() {
    $pdo = get_db_connection();
    $db_name = defined('DB_NAME') ? DB_NAME : 'cbt_ujian';
    
    $out = "-- ========================================================\n";
    $out .= "-- CBT Online MySQL Database Dump\n";
    $out .= "-- Database: `" . $db_name . "`\n";
    $out .= "-- Waktu Pembuatan: " . date('Y-m-d H:i:s') . "\n";
    $out .= "-- ========================================================\n\n";
    $out .= "SET FOREIGN_KEY_CHECKS=0;\n";
    $out .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $out .= "SET time_zone = \"+07:00\";\n";
    $out .= "SET NAMES utf8mb4;\n\n";

    $tables = [];
    $stmt = $pdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'");
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        $tables[] = $row[0];
    }

    foreach ($tables as $table) {
        $out .= "-- --------------------------------------------------------\n";
        $out .= "-- Struktur tabel `" . $table . "`\n";
        $out .= "-- --------------------------------------------------------\n";
        $out .= "DROP TABLE IF EXISTS `" . $table . "`;\n";
        
        $createStmt = $pdo->query("SHOW CREATE TABLE `" . $table . "`")->fetch(PDO::FETCH_NUM);
        $out .= $createStmt[1] . ";\n\n";
        
        $dataStmt = $pdo->query("SELECT * FROM `" . $table . "`");
        $rows = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($rows)) {
            $out .= "-- Data untuk tabel `" . $table . "`\n";
            $columns = array_keys($rows[0]);
            $colList = '`' . implode('`, `', $columns) . '`';
            
            $chunks = array_chunk($rows, 100);
            foreach ($chunks as $chunk) {
                $valuesArr = [];
                foreach ($chunk as $r) {
                    $rowVals = [];
                    foreach ($columns as $col) {
                        $val = $r[$col];
                        if ($val === null) {
                            $rowVals[] = 'NULL';
                        } else {
                            $rowVals[] = $pdo->quote($val);
                        }
                    }
                    $valuesArr[] = "(" . implode(', ', $rowVals) . ")";
                }
                $out .= "INSERT INTO `" . $table . "` (" . $colList . ") VALUES\n" . implode(",\n", $valuesArr) . ";\n";
            }
            $out .= "\n";
        }
    }
    
    $out .= "SET FOREIGN_KEY_CHECKS=1;\n";
    $out .= "-- Selesai backup database CBT Online.\n";
    return $out;
}

function import_mysql_database($sql_content) {
    $pdo = get_db_connection();
    
    $sql_content = str_replace(["\r\n", "\r"], "\n", $sql_content);
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0;");
    
    $lines = explode("\n", $sql_content);
    $query = '';
    $in_multi_comment = false;
    $executed = 0;
    
    foreach ($lines as $line) {
        $trimmed = trim($line);
        if ($trimmed === '' || substr($trimmed, 0, 2) === '--' || substr($trimmed, 0, 1) === '#') {
            continue;
        }
        
        if (substr($trimmed, 0, 2) === '/*') {
            $in_multi_comment = true;
        }
        if ($in_multi_comment) {
            if (substr($trimmed, -2) === '*/' || strpos($trimmed, '*/') !== false) {
                $in_multi_comment = false;
            }
            continue;
        }
        
        $query .= $line . "\n";
        
        if (substr(rtrim($trimmed), -1) === ';') {
            try {
                $pdo->exec($query);
                $executed++;
            } catch (Exception $e) {
                // Lanjutkan jika ada query tertentu yang gagal non-fatal
            }
            $query = '';
        }
    }
    
    if (trim($query) !== '') {
        try {
            $pdo->exec($query);
            $executed++;
        } catch (Exception $e) {}
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1;");
    
    // Dual Live-Sync: Regenerasi file questions_{id}.json di folder terproteksi
    try {
        $bank_soal = get_bank_soal();
        foreach ($bank_soal as $b) {
            $b_id = (int)$b['id'];
            $q_data = get_questions_db($b_id);
            $q_file = get_questions_json_file($b_id);
            if (!empty($q_data)) {
                file_put_contents($q_file, json_encode(array_values($q_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
            $legacy_file = __DIR__ . "/questions_{$b_id}.json";
            if (file_exists($legacy_file)) @unlink($legacy_file);
        }
        clean_orphan_questions();
    } catch (Exception $e) {}
    
    return $executed;
}



