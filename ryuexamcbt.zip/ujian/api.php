<?php
// Kompresi output GZIP otomatis jika didukung oleh browser siswa (hemat bandwidth hingga 80%)
if (!ob_start("ob_gzhandler")) {
    ob_start();
}
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/database.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Lepas kunci sesi PHP (session_write_close) untuk semua aksi yang tidak menulis ke $_SESSION.
// Menulis ke $_SESSION hanya diperlukan pada update profil admin ('update_current_admin', 'edit_admin').
// Membebaskan kunci sesi secara instan mencegah request siswa (sync, submit, polling) saling blocking
// dan langsung membebaskan slot Entry Process (EP) di Cloud Hosting.
$session_write_actions = ['update_current_admin', 'edit_admin'];
if (!in_array($action, $session_write_actions, true)) {
    session_write_close();
}

if ($action === 'get_settings') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    $settings = get_settings();
    if (!isset($settings['require_all_answered'])) {
        $settings['require_all_answered'] = false;
    }
    if (!isset($settings['min_time_submit'])) {
        $settings['min_time_submit'] = 0;
    }
    if (!isset($settings['require_password'])) {
        $settings['require_password'] = true;
    }
    if (!isset($settings['prevent_multi_login'])) {
        $settings['prevent_multi_login'] = false;
    }
    if (!isset($settings['show_score'])) {
        $settings['show_score'] = true;
    }
    if (!isset($settings['max_violations'])) {
        $settings['max_violations'] = 3;
    }
    if (!isset($settings['violation_action'])) {
        $settings['violation_action'] = 'lockout';
    }
    if (!isset($settings['lockout_duration'])) {
        $settings['lockout_duration'] = 60;
    }
    if (!isset($settings['dynamic_token'])) {
        $settings['dynamic_token'] = false;
    }
    if (!isset($settings['token_interval_minutes'])) {
        $settings['token_interval_minutes'] = 15;
    }
    if (!isset($settings['disable_token'])) {
        $settings['disable_token'] = false;
    }
    if (!isset($settings['student_login_method'])) {
        $settings['student_login_method'] = 'name_select';
    }
    if (!isset($settings['sync_interval_seconds'])) {
        $settings['sync_interval_seconds'] = 60;
    }
    echo json_encode(['status' => 'success', 'data' => $settings]);
    exit;
}

if ($action === 'save_settings') {
    $require_all = isset($_POST['require_all_answered']) && $_POST['require_all_answered'] === 'true';
    $require_password = isset($_POST['require_password']) && $_POST['require_password'] === 'true';
    $prevent_multi = isset($_POST['prevent_multi_login']) && $_POST['prevent_multi_login'] === 'true';
    $show_score = isset($_POST['show_score']) && $_POST['show_score'] === 'true';
    $min_time = (int)($_POST['min_time_submit'] ?? 0);
    $max_violations = isset($_POST['max_violations']) ? (int)$_POST['max_violations'] : 3;
    $violation_action = in_array($_POST['violation_action'] ?? '', ['lockout', 'auto_submit']) ? $_POST['violation_action'] : 'lockout';
    $lockout_duration = isset($_POST['lockout_duration']) ? max(0, (int)$_POST['lockout_duration']) : 60;
    $dynamic_token = isset($_POST['dynamic_token']) && $_POST['dynamic_token'] === 'true';
    $dynamic_token_all_exams = isset($_POST['dynamic_token_all_exams']) && $_POST['dynamic_token_all_exams'] === 'true';
    $token_interval = isset($_POST['token_interval_minutes']) ? max(1, (int)($_POST['token_interval_minutes'])) : 15;
    $sync_interval = isset($_POST['sync_interval_seconds']) ? max(10, min(600, (int)$_POST['sync_interval_seconds'])) : 60;
    
    $settings = get_settings();
    $settings['require_all_answered'] = $require_all;
    $settings['require_password'] = $require_password;
    $settings['prevent_multi_login'] = $prevent_multi;
    $settings['show_score'] = $show_score;
    $settings['min_time_submit'] = $min_time;
    $settings['max_violations'] = $max_violations;
    $settings['violation_action'] = $violation_action;
    $settings['lockout_duration'] = $lockout_duration;
    $settings['dynamic_token'] = $dynamic_token;
    $settings['dynamic_token_all_exams'] = $dynamic_token_all_exams;
    $settings['token_interval_minutes'] = $token_interval;
    $settings['disable_token'] = isset($_POST['disable_token']) && $_POST['disable_token'] === 'true';
    $settings['sync_interval_seconds'] = $sync_interval;
    
    if (isset($_POST['student_login_method'])) {
        $method = trim($_POST['student_login_method']);
        $settings['student_login_method'] = in_array($method, ['name_select', 'username']) ? $method : 'name_select';
    }
    
    if (isset($_POST['school_name'])) {
        $settings['school_name'] = trim($_POST['school_name']);
    }

    if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] === UPLOAD_ERR_OK) {
        $allowed_logo = ['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif'];
        $ext_logo = strtolower(pathinfo($_FILES['school_logo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext_logo, $allowed_logo)) {
            // Hapus logo lama jika ada ekstensi berbeda
            foreach ($allowed_logo as $old_ext) {
                if (file_exists('logo.' . $old_ext)) {
                    @unlink('logo.' . $old_ext);
                }
            }
            $dest_logo = 'logo.' . $ext_logo;
            if (move_uploaded_file($_FILES['school_logo']['tmp_name'], $dest_logo)) {
                $settings['school_logo'] = $dest_logo;
            }
        }
    } else if (!empty($_POST['remove_school_logo']) && $_POST['remove_school_logo'] === 'true') {
        if (!empty($settings['school_logo']) && file_exists($settings['school_logo'])) {
            @unlink($settings['school_logo']);
        }
        $settings['school_logo'] = '';
    }

    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['ico', 'png', 'jpg', 'jpeg'];
        $ext = strtolower(pathinfo($_FILES['favicon']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $dest = 'favicon.' . $ext;
            if (move_uploaded_file($_FILES['favicon']['tmp_name'], $dest)) {
                $settings['favicon'] = $dest;
            }
        }
    }
    
    // Kelola Ikon PWA (Progressive Web App)
    if (isset($_FILES['pwa_icon']) && $_FILES['pwa_icon']['error'] === UPLOAD_ERR_OK) {
        $allowed_pwa = ['png', 'jpg', 'jpeg', 'webp', 'svg'];
        $ext_pwa = strtolower(pathinfo($_FILES['pwa_icon']['name'], PATHINFO_EXTENSION));
        if (in_array($ext_pwa, $allowed_pwa)) {
            if (function_exists('generate_pwa_icons_from_source')) {
                generate_pwa_icons_from_source($_FILES['pwa_icon']['tmp_name'], __DIR__);
                $settings['pwa_icon_custom'] = true;
                $settings['pwa_icon_updated'] = time();
            }
        }
    } elseif (!empty($_POST['action_pwa_icon'])) {
        $actPwa = trim($_POST['action_pwa_icon']);
        if ($actPwa === 'sync_logo') {
            $logoPath = !empty($settings['school_logo']) ? (__DIR__ . '/' . $settings['school_logo']) : '';
            if (!empty($logoPath) && file_exists($logoPath)) {
                if (function_exists('generate_pwa_icons_from_source')) {
                    generate_pwa_icons_from_source($logoPath, __DIR__);
                    $settings['pwa_icon_custom'] = true;
                    $settings['pwa_icon_updated'] = time();
                }
            }
        } elseif ($actPwa === 'reset_default') {
            if (function_exists('reset_pwa_icons_to_default')) {
                reset_pwa_icons_to_default(__DIR__);
                $settings['pwa_icon_custom'] = false;
                $settings['pwa_icon_updated'] = time();
            }
        }
    }

    // Selalu sinkronkan manifest.json agar sesuai dengan nama sekolah dan ikon PWA terkini
    if (function_exists('sync_pwa_manifest_json')) {
        sync_pwa_manifest_json($settings['school_name'] ?? '', $settings['school_description'] ?? '', __DIR__);
    }
    
    save_settings($settings);
    if ($dynamic_token) {
        check_and_rotate_dynamic_tokens();
    }
    
    echo json_encode(['status' => 'success', 'message' => 'Pengaturan berhasil disimpan']);
    exit;
}

if ($action === 'update_pwa_icon') {
    if (empty($_SESSION['admin_logged_in'])) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak. Silakan login sebagai admin.']);
        exit;
    }
    $settings = get_settings();
    $subAction = $_POST['sub_action'] ?? '';
    
    if (isset($_FILES['pwa_icon']) && $_FILES['pwa_icon']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['png', 'jpg', 'jpeg', 'webp', 'svg'];
        $ext = strtolower(pathinfo($_FILES['pwa_icon']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            echo json_encode(['status' => 'error', 'message' => 'Format file tidak didukung. Gunakan PNG, JPG, atau WebP.']);
            exit;
        }
        if (function_exists('generate_pwa_icons_from_source')) {
            generate_pwa_icons_from_source($_FILES['pwa_icon']['tmp_name'], __DIR__);
            $settings['pwa_icon_custom'] = true;
            $settings['pwa_icon_updated'] = time();
            save_settings($settings);
            sync_pwa_manifest_json($settings['school_name'] ?? '', $settings['school_description'] ?? '', __DIR__);
            echo json_encode(['status' => 'success', 'message' => 'Ikon PWA berhasil diperbarui.', 'version' => $settings['pwa_icon_updated']]);
            exit;
        }
    } elseif ($subAction === 'sync_logo') {
        $logoPath = !empty($settings['school_logo']) ? (__DIR__ . '/' . $settings['school_logo']) : '';
        if (empty($logoPath) || !file_exists($logoPath)) {
            echo json_encode(['status' => 'error', 'message' => 'Logo sekolah belum diunggah. Silakan unggah logo sekolah terlebih dahulu.']);
            exit;
        }
        if (function_exists('generate_pwa_icons_from_source')) {
            generate_pwa_icons_from_source($logoPath, __DIR__);
            $settings['pwa_icon_custom'] = true;
            $settings['pwa_icon_updated'] = time();
            save_settings($settings);
            sync_pwa_manifest_json($settings['school_name'] ?? '', $settings['school_description'] ?? '', __DIR__);
            echo json_encode(['status' => 'success', 'message' => 'Ikon PWA berhasil disinkronkan dari Logo Sekolah.', 'version' => $settings['pwa_icon_updated']]);
            exit;
        }
    } elseif ($subAction === 'reset_default') {
        if (function_exists('reset_pwa_icons_to_default')) {
            reset_pwa_icons_to_default(__DIR__);
            $settings['pwa_icon_custom'] = false;
            $settings['pwa_icon_updated'] = time();
            save_settings($settings);
            sync_pwa_manifest_json($settings['school_name'] ?? '', $settings['school_description'] ?? '', __DIR__);
            echo json_encode(['status' => 'success', 'message' => 'Ikon PWA berhasil dikembalikan ke default.', 'version' => $settings['pwa_icon_updated']]);
            exit;
        }
    }
    
    echo json_encode(['status' => 'error', 'message' => 'Tidak ada berkas atau aksi yang valid.']);
    exit;
}

if ($action === 'update_current_admin') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak.']);
        exit;
    }
    
    $name = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($name) || empty($username)) {
        echo json_encode(['status' => 'error', 'message' => 'Nama dan Username wajib diisi.']);
        exit;
    }
    
    $users = get_users();
    $current_username = $_SESSION['username'] ?? 'admin';
    $current_id = (int)($_SESSION['user_id'] ?? 0);
    
    // Check if username already used by another user
    foreach ($users as $u) {
        $u_id = (int)($u['id'] ?? 0);
        if ($u_id !== $current_id && strtolower($u['username'] ?? '') === strtolower($username)) {
            echo json_encode(['status' => 'error', 'message' => 'Username "' . htmlspecialchars($username) . '" sudah digunakan akun lain.']);
            exit;
        }
    }
    
    $found = false;
    foreach ($users as &$u) {
        $u_id = (int)($u['id'] ?? 0);
        if ($u_id === $current_id || strtolower($u['username'] ?? '') === strtolower($current_username)) {
            $u['name'] = $name;
            $u['username'] = $username;
            if (!empty($password)) {
                $u['password'] = password_hash($password, PASSWORD_BCRYPT);
            }
            $found = true;
            break;
        }
    }
    
    if (!$found) {
        echo json_encode(['status' => 'error', 'message' => 'Akun admin tidak ditemukan.']);
        exit;
    }
    
    save_users($users);
    $_SESSION['user_name'] = $name;
    $_SESSION['username'] = $username;
    
    echo json_encode(['status' => 'success', 'message' => 'Profil dan password admin berhasil diperbarui.']);
    exit;
}

if ($action === 'add_admin') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak.']);
        exit;
    }
    if (!admin_has_permission('pengaturan')) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak. Anda tidak memiliki izin kelola admin.']);
        exit;
    }
    
    $name = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $admin_role = trim($_POST['admin_role'] ?? 'Super Admin');
    
    // Parse permissions (array atau JSON string)
    $raw_perms = $_POST['permissions'] ?? [];
    if (is_string($raw_perms)) {
        $decoded = json_decode($raw_perms, true);
        $permissions = is_array($decoded) ? $decoded : explode(',', $raw_perms);
    } else {
        $permissions = (array)$raw_perms;
    }
    $permissions = array_values(array_filter(array_map('trim', $permissions)));
    
    if (empty($name) || empty($username) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Nama, Username, dan Password wajib diisi.']);
        exit;
    }
    
    $allTasks = array_keys(get_admin_tasks_list());
    if (empty($permissions)) {
        if ($admin_role === 'Super Admin') {
            $permissions = $allTasks;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Pilih minimal 1 tugas / hak akses dengan menceklis tugas yang tersedia.']);
            exit;
        }
    }
    
    $isAll = count(array_intersect($allTasks, $permissions)) === count($allTasks);
    $savedPerms = $isAll ? 'all' : json_encode($permissions);
    
    $users = get_users();
    foreach ($users as $u) {
        if (strtolower($u['username'] ?? '') === strtolower($username)) {
            echo json_encode(['status' => 'error', 'message' => 'Username "' . htmlspecialchars($username) . '" sudah digunakan.']);
            exit;
        }
    }
    
    $max_id = count($users) > 0 ? max(array_column($users, 'id')) : 0;
    $users[] = [
        'id' => $max_id + 1,
        'name' => $name,
        'username' => $username,
        'password' => password_hash($password, PASSWORD_BCRYPT),
        'role' => 'admin',
        'admin_role' => $admin_role ?: 'Admin',
        'permissions' => $savedPerms,
        'mapel' => 'Semua',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    save_users($users);
    echo json_encode(['status' => 'success', 'message' => 'Akun admin baru beserta hak akses tugas berhasil ditambahkan.']);
    exit;
}

if ($action === 'edit_admin') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak.']);
        exit;
    }
    if (!admin_has_permission('pengaturan')) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak. Anda tidak memiliki izin kelola admin.']);
        exit;
    }
    
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $admin_role = trim($_POST['admin_role'] ?? '');
    
    $raw_perms = $_POST['permissions'] ?? null;
    $permissions = null;
    if ($raw_perms !== null) {
        if (is_string($raw_perms)) {
            $decoded = json_decode($raw_perms, true);
            $permissions = is_array($decoded) ? $decoded : explode(',', $raw_perms);
        } else {
            $permissions = (array)$raw_perms;
        }
        $permissions = array_values(array_filter(array_map('trim', $permissions)));
    }
    
    if ($id <= 0 || empty($name) || empty($username)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap.']);
        exit;
    }
    
    $users = get_users();
    foreach ($users as $u) {
        if ((int)$u['id'] !== $id && strtolower($u['username'] ?? '') === strtolower($username)) {
            echo json_encode(['status' => 'error', 'message' => 'Username "' . htmlspecialchars($username) . '" sudah digunakan.']);
            exit;
        }
    }
    
    $allTasks = array_keys(get_admin_tasks_list());
    $found = false;
    $updatedPerms = 'all';
    
    foreach ($users as &$u) {
        if ((int)$u['id'] === $id) {
            $u['name'] = $name;
            $u['username'] = $username;
            if (!empty($password)) {
                $u['password'] = password_hash($password, PASSWORD_BCRYPT);
            }
            if (!empty($admin_role)) {
                $u['admin_role'] = $admin_role;
            }
            if ($permissions !== null) {
                // Jangan biarkan username 'admin' utama kehilangan izin pengaturan
                if (strtolower($u['username']) === 'admin' && !in_array('pengaturan', $permissions)) {
                    $permissions[] = 'pengaturan';
                }
                if (empty($permissions)) {
                    echo json_encode(['status' => 'error', 'message' => 'Pilih minimal 1 tugas / hak akses dengan menceklis tugas yang tersedia.']);
                    exit;
                }
                $isAll = count(array_intersect($allTasks, $permissions)) === count($allTasks);
                $u['permissions'] = $isAll ? 'all' : json_encode($permissions);
                $updatedPerms = $u['permissions'];
            } else {
                $updatedPerms = $u['permissions'] ?? 'all';
            }
            $found = true;
            break;
        }
    }
    unset($u);
    
    if (!$found) {
        echo json_encode(['status' => 'error', 'message' => 'Akun admin tidak ditemukan.']);
        exit;
    }
    
    save_users($users);
    
    if ((int)($_SESSION['user_id'] ?? 0) === $id) {
        $_SESSION['user_name'] = $name;
        $_SESSION['username'] = $username;
        if (!empty($admin_role)) {
            $_SESSION['admin_role'] = $admin_role;
        }
        $_SESSION['admin_permissions'] = $updatedPerms;
    }
    
    echo json_encode(['status' => 'success', 'message' => 'Data admin dan hak akses tugas berhasil diperbarui.']);
    exit;
}

if ($action === 'delete_admin') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak.']);
        exit;
    }
    if (!admin_has_permission('pengaturan')) {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak. Anda tidak memiliki izin kelola admin.']);
        exit;
    }
    
    $id = (int)($_POST['id'] ?? 0);
    $users = get_users();
    
    $current_id = (int)($_SESSION['user_id'] ?? 0);
    $current_username = strtolower($_SESSION['username'] ?? '');
    
    $target_user = null;
    foreach ($users as $u) {
        if ((int)$u['id'] === $id) {
            $target_user = $u;
            break;
        }
    }
    
    if (!$target_user) {
        echo json_encode(['status' => 'error', 'message' => 'Akun admin tidak ditemukan.']);
        exit;
    }
    
    if ($id === $current_id || strtolower($target_user['username'] ?? '') === $current_username) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak dapat menghapus akun admin yang sedang Anda gunakan untuk login.']);
        exit;
    }
    
    $admin_count = count(array_filter($users, fn($u) => ($u['role'] ?? '') === 'admin'));
    if ($admin_count <= 1) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak dapat menghapus admin terakhir. Minimal harus ada 1 admin aktif.']);
        exit;
    }
    
    $users = array_filter($users, fn($u) => (int)$u['id'] !== $id);
    save_users(array_values($users));
    
    echo json_encode(['status' => 'success', 'message' => 'Akun admin berhasil dihapus.']);
    exit;
}

if ($action === 'get_classes') {
    $classes = get_classes();
    // Sort classes by name
    usort($classes, function($a, $b) { return strcmp($a['name'], $b['name']); });
    echo json_encode(['status' => 'success', 'data' => $classes]);
    exit;
}

if ($action === 'get_students') {
    $class_id = isset($_GET['class_id']) && (int)$_GET['class_id'] > 0 ? (int)$_GET['class_id'] : null;
    $exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
    
    // Query siswa terfilter langsung di database
    $students = get_students($class_id);
    
    // Optimasi Memori O(1): Hanya ambil ID siswa yang sudah selesai
    // TANPA men-decode seluruh teks dan JSON answers_json dari riwayat database
    $pdo = get_db_connection();
    if ($exam_id > 0) {
        $stmtFin = $pdo->prepare("SELECT DISTINCT student_id FROM exam_results WHERE exam_id = ?");
        $stmtFin->execute([$exam_id]);
    } else {
        $stmtFin = $pdo->query("SELECT DISTINCT student_id FROM exam_results");
    }
    $finished_map = array_fill_keys($stmtFin->fetchAll(PDO::FETCH_COLUMN), true);
    
    $is_admin = !empty($_SESSION['admin_logged_in']);
    $return_students = [];
    foreach ($students as $s) {
        $s['has_finished'] = isset($finished_map[$s['id']]);
        $s['has_password'] = !empty($s['password']);
        if (!$is_admin) {
            unset($s['password']);
        }
        $return_students[] = $s;
    }
    
    usort($return_students, function($a, $b) { return strcmp($a['name'], $b['name']); });
    
    echo json_encode(['status' => 'success', 'data' => array_values($return_students)]);
    exit;
}

if ($action === 'import_students_batch') {
    $students_json = $_POST['students'] ?? '[]';
    $import_data = json_decode($students_json, true);
    
    if (!is_array($import_data) || empty($import_data)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid']);
        exit;
    }
    
    $students = get_students();
    $classes = get_classes();
    
    $new_student_id = count($students) > 0 ? max(array_column($students, 'id')) + 1 : 1;
    $new_class_id = count($classes) > 0 ? max(array_column($classes, 'id')) + 1 : 1;
    
    // Create map of existing classes (case-insensitive)
    $class_map = [];
    foreach ($classes as $c) {
        $class_map[strtolower($c['name'])] = $c['id'];
    }
    
    $added = 0;
    $classes_updated = false;
    
    foreach ($import_data as $row) {
        $name = trim($row['name'] ?? '');
        $class_name = trim($row['class_name'] ?? '');
        $password = trim($row['password'] ?? '');
        $username = trim($row['username'] ?? '');
        $ruang = trim($row['ruang'] ?? '');
        $no_peserta = trim($row['no_peserta'] ?? '');
        
        if (!empty($name) && !empty($class_name)) {
            $class_key = strtolower($class_name);
            
            if (!isset($class_map[$class_key])) {
                $classes[] = [
                    'id' => $new_class_id,
                    'name' => $class_name
                ];
                $class_map[$class_key] = $new_class_id;
                $new_class_id++;
                $classes_updated = true;
            }
            
            $curr_id = $new_student_id++;
            if (empty($username)) {
                $username = 'siswa' . $curr_id;
            }
            
            $students[] = [
                'id' => $curr_id,
                'username' => $username,
                'class_id' => $class_map[$class_key],
                'name' => $name,
                'password' => $password,
                'ruang' => $ruang,
                'no_peserta' => $no_peserta
            ];
            $added++;
        }
    }
    
    if ($classes_updated) {
        save_classes($classes);
    }
    
    save_students($students);
    echo json_encode(['status' => 'success', 'message' => "$added siswa berhasil diimpor!"]);
    exit;
}

if ($action === 'import_guru_batch') {
    if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in'] || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya administrator yang memiliki izin mengimpor akun guru.']);
        exit;
    }

    $gurus_json = $_POST['gurus'] ?? '[]';
    $import_data = json_decode($gurus_json, true);
    
    if (!is_array($import_data) || empty($import_data)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid atau kosong.']);
        exit;
    }

    $users = get_users();
    $new_user_id = count($users) > 0 ? max(array_column($users, 'id')) + 1 : 1;

    $existing_usernames = [];
    foreach ($users as $u) {
        $existing_usernames[strtolower($u['username'])] = true;
    }

    $added = 0;
    $skipped = 0;

    foreach ($import_data as $row) {
        $name = trim($row['name'] ?? '');
        $username = trim($row['username'] ?? '');
        $password = trim($row['password'] ?? '');
        $mapel = trim($row['mapel'] ?? '');

        if (empty($name) || empty($username)) {
            continue;
        }

        if (empty($password)) {
            $password = 'guru123';
        }

        $user_key = strtolower($username);
        if (isset($existing_usernames[$user_key])) {
            $skipped++;
            continue;
        }

        $users[] = [
            'id' => $new_user_id++,
            'name' => $name,
            'username' => $username,
            'password' => $password,
            'role' => 'guru',
            'mapel' => $mapel,
            'created_at' => date('Y-m-d H:i:s')
        ];
        $existing_usernames[$user_key] = true;
        $added++;
    }

    if ($added > 0) {
        save_users($users);
    }

    $msg = "$added akun guru berhasil diimpor!";
    if ($skipped > 0) {
        $msg .= " ($skipped akun dilewati karena username sudah terdaftar).";
    }

    echo json_encode([
        'status' => 'success',
        'message' => $msg,
        'added' => $added,
        'skipped' => $skipped
    ]);
    exit;
}

if ($action === 'bulk_delete_guru') {
    if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in'] || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya administrator yang memiliki izin menghapus akun guru.']);
        exit;
    }

    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];

    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada akun guru yang dipilih.']);
        exit;
    }

    $users = get_users();
    $initialCount = count($users);

    $users = array_filter($users, function($u) use ($ids) {
        return !in_array($u['id'], $ids);
    });

    $deletedCount = $initialCount - count($users);
    if ($deletedCount > 0) {
        save_users(array_values($users));
        echo json_encode([
            'status' => 'success',
            'message' => "$deletedCount akun guru terpilih berhasil dihapus.",
            'deleted_count' => $deletedCount
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Akun guru tidak ditemukan atau sudah dihapus.']);
    }
    exit;
}

if ($action === 'submit_test') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $answers_log = $_POST['answers'] ?? '[]';
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid student_id']);
        exit;
    }
    
    $pdo = get_db_connection();
    
    // Check if already finished for this specific exam
    $checkFinished = $pdo->prepare("SELECT id FROM exam_results WHERE student_id = ? AND exam_id = ? LIMIT 1");
    $checkFinished->execute([$student_id, $exam_id]);
    if ($checkFinished->fetchColumn()) {
        echo json_encode(['status' => 'error', 'message' => 'Anda sudah pernah mengumpulkan ujian ini!']);
        exit;
    }

    // Cari bank_soal_id yang berasosiasi dengan exam_id
    $exams = get_exams();
    $bank_id = $exam_id;
    foreach ($exams as $e) {
        if ((int)$e['id'] === $exam_id) {
            $bank_id = isset($e['bank_soal_id']) ? (int)$e['bank_soal_id'] : (int)$e['id'];
            break;
        }
    }

    $parsed_answers = is_string($answers_log) ? json_decode($answers_log, true) : $answers_log;
    if (!is_array($parsed_answers)) {
        $parsed_answers = [];
    }

    // Keamanan Arsitektur: Nilai dikalkulasi 100% di server dari bank soal asli
    $score = calculate_exam_score($bank_id, $parsed_answers);
    
    $violations = isset($_POST['violations']) ? (int)$_POST['violations'] : 0;
    $start_time = isset($_POST['start_time']) ? (int)$_POST['start_time'] : null;

    // Ambil start_time dan violations dari sesi siswa yang bersangkutan saja
    $stmtSess = $pdo->prepare("SELECT violations, start_time, state_json FROM exam_sessions WHERE student_id = ? AND (exam_id = ? OR exam_id = 0) LIMIT 1");
    $stmtSess->execute([$student_id, $exam_id]);
    $currSession = $stmtSess->fetch(PDO::FETCH_ASSOC);

    if ($currSession) {
        $violations = max($violations, (int)($currSession['violations'] ?? 0));
        if (!$start_time) {
            if (!empty($currSession['start_time'])) {
                $start_time = (int)$currSession['start_time'];
            } else if (!empty($currSession['state_json'])) {
                $sState = json_decode($currSession['state_json'], true);
                if (isset($sState['startTime'])) {
                    $start_time = (int)($sState['startTime'] / 1000);
                }
            }
        }
    }
    
    $now_ts = time();
    if (!$start_time || $start_time > $now_ts) {
        $start_time = $now_ts;
    }
    $duration_seconds = max(0, $now_ts - $start_time);
    
    $new_result = [
        'student_id' => $student_id,
        'exam_id' => $exam_id,
        'score' => $score,
        'violations' => $violations,
        'started_at' => date('Y-m-d H:i:s', $start_time),
        'submitted_at' => date('Y-m-d H:i:s', $now_ts),
        'duration_seconds' => $duration_seconds,
        'answers' => is_string($answers_log) ? $answers_log : json_encode($answers_log, JSON_UNESCAPED_UNICODE)
    ];
    
    // Simpan hasil ujian secara atomic O(1)
    save_single_result($new_result);

    // Hapus sesi aktif siswa ini secara atomic O(1)
    delete_student_session($student_id, $exam_id);

    echo json_encode(['status' => 'success', 'score' => $score, 'message' => 'Ujian berhasil disubmit!']);
    exit;
}

if ($action === 'reset_student') {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak: Akun guru tidak diizinkan mengeluarkan atau mereset siswa.']);
        exit;
    }
    $student_id = (int)($_POST['student_id'] ?? 0);
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid student_id']);
        exit;
    }
    
    $pdo = get_db_connection();
    
    // 1. Cek sesi aktif di exam_sessions (siswa sedang mengerjakan atau terkunci)
    $stmtSess = $pdo->prepare("SELECT * FROM exam_sessions WHERE student_id = ? " . ($exam_id > 0 ? "AND (exam_id = ? OR exam_id = 0)" : ""));
    if ($exam_id > 0) {
        $stmtSess->execute([$student_id, $exam_id]);
    } else {
        $stmtSess->execute([$student_id]);
    }
    $sess = $stmtSess->fetch(PDO::FETCH_ASSOC);
    
    if ($sess) {
        // Keluarkan siswa dari sesi ujian aktif:
        // Set is_reset = 1, is_locked = 0, unlocked_by_admin = 1.
        // PENTING: state_json TIDAK disentuh sama sekali agar seluruh jawaban siswa tetap 100% utuh!
        $upd = $pdo->prepare("
            UPDATE exam_sessions 
            SET is_reset = 1, is_locked = 0, unlocked_by_admin = 1, last_active = ? 
            WHERE id = ?
        ");
        $upd->execute([time(), $sess['id']]);
        
        echo json_encode([
            'status' => 'success', 
            'message' => 'Siswa berhasil dikeluarkan dari sesi ujian. Seluruh jawaban tersimpan aman.'
        ]);
        exit;
    }
    
    // 2. Jika tidak ada di exam_sessions, periksa apakah ada di exam_results (status Selesai)
    $stmtRes = $pdo->prepare("SELECT * FROM exam_results WHERE student_id = ? " . ($exam_id > 0 ? "AND (exam_id = ? OR exam_id = 0)" : "") . " ORDER BY id DESC LIMIT 1");
    if ($exam_id > 0) {
        $stmtRes->execute([$student_id, $exam_id]);
    } else {
        $stmtRes->execute([$student_id]);
    }
    $res = $stmtRes->fetch(PDO::FETCH_ASSOC);
    
    if ($res) {
        // Siswa berstatus Selesai: pulihkan jawaban ke exam_sessions dengan is_reset = 1
        // tanpa menghilangkan jawaban yang sudah pernah dikerjakan
        $target_exam_id = (int)$res['exam_id'];
        $answers = json_decode($res['answers_json'], true) ?: [];
        
        $exams = get_exams();
        $bank_id = $target_exam_id;
        $targetExam = null;
        foreach ($exams as $e) {
            if ((int)$e['id'] === $target_exam_id) {
                $bank_id = isset($e['bank_soal_id']) ? (int)$e['bank_soal_id'] : $target_exam_id;
                $targetExam = $e;
                break;
            }
        }
        
        $allQuestions = get_questions_db($bank_id);
        
        $savedAnswersMap = [];
        foreach ($answers as $idx => $ansItem) {
            $origId = isset($ansItem['originalId']) ? $ansItem['originalId'] : $idx;
            $savedAnswersMap[$origId] = $ansItem['selected'] ?? null;
        }
        
        $shuffledQuestions = [];
        if (is_array($allQuestions)) {
            foreach ($allQuestions as $qIdx => $qItem) {
                $selectedVal = $savedAnswersMap[$qIdx] ?? ($savedAnswersMap[(string)$qIdx] ?? null);
                $opts = [];
                if (!empty($qItem['options']) && is_array($qItem['options'])) {
                    foreach ($qItem['options'] as $oKey => $oVal) {
                        $opts[] = ['value' => $oKey, 'text' => $oVal];
                    }
                }
                $shuffledQuestions[] = [
                    'originalId' => $qIdx,
                    'question' => $qItem['question'] ?? '',
                    'type' => $qItem['type'] ?? 'multiple_choice',
                    'selectedOption' => $selectedVal,
                    'points' => $qItem['points'] ?? 1,
                    'options' => $opts,
                    'statements' => $qItem['statements'] ?? [],
                    'premises' => $qItem['premises'] ?? []
                ];
            }
        }
        
        $students = get_students();
        $studentName = '';
        $className = '';
        foreach ($students as $stu) {
            if ((int)$stu['id'] === $student_id) {
                $studentName = $stu['name'] ?? '';
                break;
            }
        }
        
        $durationMinutes = isset($targetExam['duration']) ? (int)$targetExam['duration'] : 60;
        $startTime = !empty($res['started_at']) ? strtotime($res['started_at']) : time();
        $endTime = time() + ($durationMinutes * 60);
        
        $restoredState = [
            'selectedExamId' => $target_exam_id,
            'selectedExam' => $targetExam,
            'selectedStudentId' => $student_id,
            'selectedStudentName' => $studentName,
            'selectedClassName' => $className,
            'startTime' => $startTime * 1000,
            'endTime' => $endTime * 1000,
            'shuffledQuestions' => $shuffledQuestions,
            'currentQuestionIndex' => 0,
            'violations' => (int)($res['violations'] ?? 0),
            'is_locked' => false
        ];
        
        $insSess = $pdo->prepare("
            INSERT INTO exam_sessions (student_id, exam_id, score, violations, is_locked, unlocked_by_admin, is_reset, is_forced_submit, start_time, last_active, state_json)
            VALUES (?, ?, ?, ?, 0, 1, 1, 0, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                exam_id = VALUES(exam_id),
                score = VALUES(score),
                violations = VALUES(violations),
                is_locked = 0,
                unlocked_by_admin = 1,
                is_reset = 1,
                is_forced_submit = 0,
                last_active = VALUES(last_active),
                state_json = VALUES(state_json)
        ");
        $insSess->execute([
            $student_id,
            $target_exam_id,
            (float)$res['score'],
            (int)$res['violations'],
            $startTime,
            time(),
            json_encode($restoredState, JSON_UNESCAPED_UNICODE)
        ]);
        
        $delRes = $pdo->prepare("DELETE FROM exam_results WHERE id = ?");
        $delRes->execute([$res['id']]);
        
        echo json_encode([
            'status' => 'success', 
            'message' => 'Status siswa berhasil dibuka kembali. Jawaban sebelumnya telah dipulihkan ke sesi ujian.'
        ]);
        exit;
    }
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Siswa belum memiliki sesi atau riwayat ujian.'
    ]);
    exit;
}

if ($action === 'block_student') {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak: Akun guru tidak diizinkan memblokir siswa.']);
        exit;
    }
    $student_id = (int)($_POST['student_id'] ?? 0);
    $block = isset($_POST['block']) ? (int)$_POST['block'] : 1;
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID siswa tidak valid']);
        exit;
    }
    
    $pdo = get_db_connection();
    try {
        $pdo->exec("ALTER TABLE students ADD COLUMN is_blocked TINYINT(1) NOT NULL DEFAULT 0");
    } catch (Exception $e) {}
    
    $upd = $pdo->prepare("UPDATE students SET is_blocked = ? WHERE id = ?");
    $upd->execute([$block ? 1 : 0, $student_id]);
    
    if ($block) {
        // Flag sesi agar sync_progress langsung memutus sesi seketika (force_logout)
        $pdo->prepare("UPDATE exam_sessions SET is_reset = 1, is_locked = 1 WHERE student_id = ?")->execute([$student_id]);
        echo json_encode([
            'status' => 'success', 
            'message' => 'Siswa berhasil diblokir. Sesi ujian siswa langsung diputus dan dikeluarkan.'
        ]);
    } else {
        $pdo->prepare("UPDATE exam_sessions SET is_locked = 0, is_reset = 1, unlocked_by_admin = 1 WHERE student_id = ?")->execute([$student_id]);
        echo json_encode([
            'status' => 'success', 
            'message' => 'Blokir siswa berhasil dibuka. Siswa dapat login kembali untuk mengerjakan ujian.'
        ]);
    }
    exit;
}

if ($action === 'bulk_block_students') {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak: Akun guru tidak diizinkan memblokir siswa.']);
        exit;
    }
    $raw_ids = $_POST['student_ids'] ?? [];
    $student_ids = is_string($raw_ids) ? json_decode($raw_ids, true) : $raw_ids;
    $block = isset($_POST['block']) ? (int)$_POST['block'] : 1;
    
    if (!is_array($student_ids) || empty($student_ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Pilih minimal satu siswa']);
        exit;
    }
    
    $pdo = get_db_connection();
    try {
        $pdo->exec("ALTER TABLE students ADD COLUMN is_blocked TINYINT(1) NOT NULL DEFAULT 0");
    } catch (Exception $e) {}
    
    $clean_ids = array_map('intval', $student_ids);
    $inClause = implode(',', array_fill(0, count($clean_ids), '?'));
    
    $stmt = $pdo->prepare("UPDATE students SET is_blocked = ? WHERE id IN ($inClause)");
    $stmt->execute(array_merge([$block ? 1 : 0], $clean_ids));
    
    if ($block) {
        $pdo->prepare("UPDATE exam_sessions SET is_reset = 1, is_locked = 1 WHERE student_id IN ($inClause)")->execute($clean_ids);
    } else {
        $pdo->prepare("UPDATE exam_sessions SET is_locked = 0, is_reset = 1, unlocked_by_admin = 1 WHERE student_id IN ($inClause)")->execute($clean_ids);
    }
    
    echo json_encode([
        'status' => 'success', 
        'message' => $block ? 'Siswa terpilih berhasil diblokir.' : 'Blokir siswa terpilih berhasil dibuka.'
    ]);
    exit;
}

if ($action === 'reset_all_exam_status') {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak: Akun guru tidak diizinkan mereset status ujian.']);
        exit;
    }
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID ujian tidak valid']);
        exit;
    }
    delete_exam_data($exam_id);
    echo json_encode(['status' => 'success', 'message' => 'Seluruh status peserta pada ujian ini berhasil direset ke Belum Mulai.']);
    exit;
}

if ($action === 'force_submit') {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak: Akun guru tidak diizinkan menyelesaikan ujian secara paksa.']);
        exit;
    }
    $student_id = (int)($_POST['student_id'] ?? 0);
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid student_id']);
        exit;
    }
    
    $sessions = get_sessions();
    $found_s = null;
    $remaining_sessions = [];
    foreach ($sessions as $s) {
        if ($s['student_id'] === $student_id) {
            $found_s = $s;
        } else {
            $remaining_sessions[] = $s;
        }
    }
    
    if ($found_s !== null) {
        // Generate results from the last known state
        $results = get_results();
        $new_id = count($results) > 0 ? max(array_column($results, 'id')) + 1 : 1;
        
        $answers_log = [];
        if (isset($found_s['state']) && isset($found_s['state']['shuffledQuestions'])) {
            $exam_id = $found_s['exam_id'] ?? 0;
            $exams = get_exams();
            $bank_soal_id = $exam_id;
            foreach ($exams as $e) {
                if ($e['id'] === $exam_id) {
                    $bank_soal_id = isset($e['bank_soal_id']) ? $e['bank_soal_id'] : $e['id'];
                    break;
                }
            }
            $bank_questions = get_questions_db($bank_soal_id);
            
            foreach ($found_s['state']['shuffledQuestions'] as $idx => $q) {
                $origId = $q['originalId'] ?? $idx;
                $origQ = isset($bank_questions[$origId]) ? $bank_questions[$origId] : null;
                $q_text = $origQ['question'] ?? ($q['question'] ?? '');
                $q_type = $origQ['type'] ?? ($q['type'] ?? 'multiple_choice');
                
                $answers_log[] = [
                    'originalId' => $origId,
                    'type' => $q_type,
                    'question' => $q_text,
                    'selected' => $q['selectedOption'] ?? null
                ];
            }
        }
        
        $calculated_score = calculate_exam_score($bank_soal_id ?? 0, $answers_log);

        $start_time = null;
        if (isset($found_s['start_time'])) {
            $start_time = (int)$found_s['start_time'];
        } else if (isset($found_s['state']['startTime'])) {
            $start_time = (int)($found_s['state']['startTime'] / 1000);
        }
        $now_ts = time();
        if (!$start_time || $start_time > $now_ts) {
            $start_time = $now_ts;
        }
        $duration_seconds = max(0, $now_ts - $start_time);

        $new_result = [
            'student_id' => $student_id,
            'exam_id' => $found_s['exam_id'] ?? 0,
            'score' => $calculated_score,
            'violations' => (int)($found_s['violations'] ?? 0),
            'started_at' => date('Y-m-d H:i:s', $start_time),
            'submitted_at' => date('Y-m-d H:i:s', $now_ts),
            'duration_seconds' => $duration_seconds,
            'answers' => json_encode($answers_log, JSON_UNESCAPED_UNICODE)
        ];
        
        save_single_result($new_result);
        
        // Tandai is_forced_submit = 1 secara spesifik tanpa menulis ulang seluruh tabel sesi
        $pdo = get_db_connection();
        $pdo->prepare("UPDATE exam_sessions SET is_forced_submit = 1 WHERE student_id = ?")->execute([$student_id]);
        
        echo json_encode(['status' => 'success', 'message' => 'Ujian siswa diselesaikan secara paksa.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Siswa tidak sedang mengerjakan ujian.']);
    }
    exit;
}

if ($action === 'sync_progress') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $score = (int)($_POST['score'] ?? 0);
    $state_json = $_POST['state_json'] ?? null;
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid student_id']);
        exit;
    }
    
    $pdo = get_db_connection();
    $stmt = $pdo->prepare("SELECT id, student_id, exam_id, score, violations, is_locked, unlocked_by_admin, is_reset, is_forced_submit, start_time, last_active, state_json FROM exam_sessions WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $s = $stmt->fetch();
    
    if (!$s) {
        echo json_encode(['status' => 'force_logout', 'message' => 'Sesi Anda telah direset oleh Admin. Anda telah dikeluarkan dari ujian.']);
        exit;
    }
    
    // Cek jika siswa diblokir oleh admin
    $chkBlocked = $pdo->prepare("SELECT is_blocked FROM students WHERE id = ?");
    $chkBlocked->execute([$student_id]);
    if ((int)$chkBlocked->fetchColumn() === 1) {
        echo json_encode(['status' => 'force_logout', 'message' => 'Akun Anda telah diblokir oleh Pengawas/Admin. Anda dikeluarkan dari ujian.']);
        exit;
    }
    
    if (!empty($s['is_forced_submit'])) {
        $pdo->prepare("DELETE FROM exam_sessions WHERE student_id = ?")->execute([$student_id]);
        echo json_encode(['status' => 'force_logout', 'message' => 'Ujian Anda telah diselesaikan paksa oleh Admin. Anda akan diarahkan ke halaman hasil.']);
        exit;
    }
    
    if (!empty($s['is_reset'])) {
        echo json_encode(['status' => 'force_logout', 'message' => 'Sesi Anda telah direset oleh Admin. Anda telah dikeluarkan dari ujian.']);
        exit;
    }
    
    if (!empty($s['unlocked_by_admin'])) {
        $pdo->prepare("UPDATE exam_sessions SET is_locked = 0, unlocked_by_admin = 0, violations = 0, last_active = ? WHERE student_id = ?")->execute([time(), $student_id]);
        echo json_encode(['status' => 'unlocked', 'message' => 'Ujian Anda telah dibuka kembali oleh Pengawas. Silakan lanjutkan ujian.']);
        exit;
    }
    
    $violations = isset($_POST['violations']) ? (int)$_POST['violations'] : (int)($s['violations'] ?? 0);
    $is_locked = isset($_POST['is_locked']) ? (($_POST['is_locked'] === 'true' || $_POST['is_locked'] === '1' || $_POST['is_locked'] === true) ? 1 : 0) : (!empty($s['is_locked']) ? 1 : 0);
    $now_ts = time();
    
    // Optimasi CPU: Simpan jawaban mentah (state_json) langsung tanpa melakukan kalkulasi skor berulang
    // Skor resmi akan dikalkulasi 100% akurat di server saat siswa menekan tombol "Submit / Kumpulkan Ujian"
    $score = (float)($s['score'] ?? 0);
    if ($state_json !== null) {
        $upd = $pdo->prepare("
            UPDATE exam_sessions 
            SET score = ?, exam_id = ?, violations = ?, is_locked = ?, is_reset = 0, last_active = ?, state_json = ?
            WHERE student_id = ?
        ");
        $upd->execute([$score, $exam_id, $violations, $is_locked, $now_ts, $state_json, $student_id]);
    } else {
        $upd = $pdo->prepare("
            UPDATE exam_sessions 
            SET score = ?, exam_id = ?, violations = ?, is_locked = ?, is_reset = 0, last_active = ?
            WHERE student_id = ?
        ");
        $upd->execute([$score, $exam_id, $violations, $is_locked, $now_ts, $student_id]);
    }
    
    $curr_settings = get_settings();
    echo json_encode([
        'status' => 'success',
        'settings' => [
            'require_all_answered' => !empty($curr_settings['require_all_answered']),
            'min_time_submit' => (int)($curr_settings['min_time_submit'] ?? 0),
            'show_score' => !empty($curr_settings['show_score']),
            'max_violations' => (int)($curr_settings['max_violations'] ?? 3),
            'violation_action' => $curr_settings['violation_action'] ?? 'lockout',
            'lockout_duration' => (int)($curr_settings['lockout_duration'] ?? 60),
            'sync_interval_seconds' => (int)($curr_settings['sync_interval_seconds'] ?? 60),
        ]
    ]);
    exit;
}

if ($action === 'report_violation') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $violations = (int)($_POST['violations'] ?? 1);
    $is_locked = isset($_POST['is_locked']) && ($_POST['is_locked'] === 'true' || $_POST['is_locked'] === '1');
    
    if ($student_id > 0) {
        $pdo = get_db_connection();
        if ($is_locked) {
            $stmt = $pdo->prepare("UPDATE exam_sessions SET violations = ?, is_locked = 1, last_active = ? WHERE student_id = ?");
            $stmt->execute([$violations, time(), $student_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE exam_sessions SET violations = ?, last_active = ? WHERE student_id = ?");
            $stmt->execute([$violations, time(), $student_id]);
        }
    }
    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'unlock_student') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID siswa tidak valid']);
        exit;
    }
    
    $pdo = get_db_connection();
    $stmt = $pdo->prepare("UPDATE exam_sessions SET is_locked = 0, violations = 0, unlocked_by_admin = 1, last_active = ? WHERE student_id = ?");
    $stmt->execute([time(), $student_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Ujian siswa berhasil dibuka kunci']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Sesi siswa aktif tidak ditemukan']);
    }
    exit;
}

if ($action === 'clear_lock') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    if ($student_id > 0) {
        $pdo = get_db_connection();
        $stmt = $pdo->prepare("UPDATE exam_sessions SET is_locked = 0, violations = 0, unlocked_by_admin = 0, last_active = ? WHERE student_id = ?");
        $stmt->execute([time(), $student_id]);
    }
    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'student_username_login') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    
    $settings = get_settings();
    
    if (empty($username)) {
        echo json_encode(['status' => 'error', 'message' => 'Username wajib diisi!']);
        exit;
    }
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Silakan pilih mata pelajaran / ujian!']);
        exit;
    }
    
    $pdo = get_db_connection();
    $stmtEx = $pdo->prepare("SELECT * FROM exams WHERE id = ? LIMIT 1");
    $stmtEx->execute([$exam_id]);
    $target_exam = $stmtEx->fetch(PDO::FETCH_ASSOC);
    
    if (!$target_exam) {
        echo json_encode(['status' => 'error', 'message' => 'Mata pelajaran / ujian tidak ditemukan!']);
        exit;
    }
    
    // Validasi status aktif ujian jika ada
    if (isset($target_exam['is_active']) && !$target_exam['is_active']) {
        echo json_encode(['status' => 'error', 'message' => 'Ujian ini sedang tidak aktif. Hubungi proktor / admin.']);
        exit;
    }
    
    // Cari siswa langsung via query database (O(1)) berdasarkan username atau fallback 'siswa'+id
    $stmtSt = $pdo->prepare("SELECT id, class_id, username, name, password, is_blocked, ruang, no_peserta FROM students WHERE LOWER(username) = LOWER(?) OR LOWER(CONCAT('siswa', id)) = LOWER(?) LIMIT 1");
    $stmtSt->execute([$username, $username]);
    $matched_student = $stmtSt->fetch(PDO::FETCH_ASSOC);
    
    if (!$matched_student) {
        echo json_encode(['status' => 'error', 'message' => 'Username tidak ditemukan. Periksa kembali username Anda!']);
        exit;
    }
    
    // Validasi apakah siswa diblokir oleh admin
    if (!empty($matched_student['is_blocked'])) {
        echo json_encode(['status' => 'error', 'message' => 'Akun Anda sedang diblokir oleh Pengawas/Admin. Anda tidak dapat mengikuti ujian.']);
        exit;
    }
    
    // Validasi Password Siswa Selalu Wajib
    if (empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Password peserta ujian wajib diisi!']);
        exit;
    }
    
    $is_valid_pw = !empty($matched_student['password']) && (password_verify($password, $matched_student['password']) || (trim($matched_student['password']) === $password));
    if (!$is_valid_pw) {
        echo json_encode(['status' => 'error', 'message' => 'Password salah! Periksa kembali huruf besar/kecil.']);
        exit;
    }
    
    // Validasi kelayakan kelas siswa
    $class_ids = $target_exam['class_ids'] ?? [];
    if (is_string($class_ids)) {
        $class_ids = json_decode($class_ids, true) ?: [];
    }
    if (!is_array($class_ids)) {
        $class_ids = (!empty($target_exam['class_id'])) ? [(int)$target_exam['class_id']] : [];
    }
    $class_ids = array_map('intval', $class_ids);
    if (!empty($class_ids) && !in_array((int)$matched_student['class_id'], $class_ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak terdaftar untuk mengikuti ujian ini (Kelas tidak sesuai).']);
        exit;
    }
    
    // Validasi apakah siswa sudah pernah menyelesaikan ujian ini (Direct O(1) indexed query)
    $pdo = get_db_connection();
    $chkFin = $pdo->prepare("SELECT id FROM exam_results WHERE student_id = ? AND exam_id = ? LIMIT 1");
    $chkFin->execute([$matched_student['id'], $exam_id]);
    if ($chkFin->fetchColumn()) {
        echo json_encode(['status' => 'error', 'message' => 'Anda sudah menyelesaikan ujian ini dan tidak dapat mengerjakan kembali.']);
        exit;
    }
    
    // Cek jadwal ujian jika ditentukan
    if (!empty($target_exam['start_time']) && !empty($target_exam['end_time'])) {
        $now = time();
        $start = strtotime($target_exam['start_time']);
        $end = strtotime($target_exam['end_time']);
        if ($now < $start) {
            echo json_encode(['status' => 'error', 'message' => 'Ujian belum dimulai. Waktu mulai: ' . date('d/m/Y H:i', $start)]);
            exit;
        }
        if ($now > $end) {
            echo json_encode(['status' => 'error', 'message' => 'Waktu pelaksanaan ujian telah berakhir.']);
            exit;
        }
    }
    
    // Ambil nama kelas langsung via SQL (O(1))
    $stmtCls = $pdo->prepare("SELECT name FROM classes WHERE id = ? LIMIT 1");
    $stmtCls->execute([(int)$matched_student['class_id']]);
    $class_name = $stmtCls->fetchColumn() ?: '-';
    
    // Ambil jumlah soal dari database
    $bank_id = isset($target_exam['bank_soal_id']) ? $target_exam['bank_soal_id'] : $target_exam['id'];
    $bank_q_count = count(get_questions_db($bank_id));
    $max_q = !empty($target_exam['max_questions']) ? (int)$target_exam['max_questions'] : 0;
    $questions_count = ($max_q > 0 && $max_q < $bank_q_count) ? $max_q : $bank_q_count;

    // Keamanan Arsitektur: Jangan kembalikan password siswa dan token ujian di response
    echo json_encode([
        'status' => 'success',
        'student' => [
            'id' => (int)$matched_student['id'],
            'username' => $matched_student['username'] ?? ('siswa' . $matched_student['id']),
            'name' => $matched_student['name'],
            'class_id' => (int)$matched_student['class_id'],
            'class_name' => $class_name
        ],
        'exam' => [
            'id' => (int)$target_exam['id'],
            'name' => $target_exam['name'],
            'duration' => $target_exam['duration'] ?? 90,
            'classes' => $target_exam['classes'] ?? $target_exam['class_ids'] ?? [],
            'class_ids' => $target_exam['class_ids'] ?? $target_exam['classes'] ?? [],
            'shuffle_questions' => !empty($target_exam['shuffle_questions']),
            'shuffle_options' => !empty($target_exam['shuffle_options']),
            'max_questions' => $max_q,
            'question_count' => $questions_count
        ],
        'require_token' => empty($settings['disable_token'])
    ]);
    exit;
}

if ($action === 'start_session') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $provided_token = strtoupper(trim($_POST['token'] ?? ''));
    $provided_password = trim($_POST['password'] ?? '');
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid student_id']);
        exit;
    }

    $settings = get_settings();
    $disable_token = !empty($settings['disable_token']);

    // Validasi Password Siswa Selalu Wajib
    if (empty($provided_password)) {
        echo json_encode(['status' => 'error', 'message' => 'Password peserta ujian wajib diisi!']);
        exit;
    }

    $pdo = get_db_connection();
    $stmtSt = $pdo->prepare("SELECT id, class_id, username, name, password, is_blocked FROM students WHERE id = ? LIMIT 1");
    $stmtSt->execute([$student_id]);
    $target_student = $stmtSt->fetch(PDO::FETCH_ASSOC);

    if (!$target_student) {
        echo json_encode(['status' => 'error', 'message' => 'Data peserta tidak ditemukan!']);
        exit;
    }

    // Validasi apakah siswa diblokir oleh admin
    if (!empty($target_student['is_blocked'])) {
        echo json_encode(['status' => 'error', 'message' => 'Akun Anda sedang diblokir oleh Pengawas/Admin. Anda tidak dapat mengikuti ujian.']);
        exit;
    }

    $is_valid_pw = !empty($target_student['password']) && (password_verify($provided_password, $target_student['password']) || ($target_student['password'] === $provided_password));
    if (!$is_valid_pw) {
        echo json_encode(['status' => 'error', 'message' => 'Password peserta salah! Periksa kembali huruf besar/kecil.']);
        exit;
    }

    // Validate token if not disabled
    if (!$disable_token) {
        if (!empty($provided_token)) {
            $stmtEx = $pdo->prepare("SELECT id, token, prev_token, prev_token_expires_at FROM exams WHERE id = ? LIMIT 1");
            $stmtEx->execute([$exam_id]);
            $target_exam = $stmtEx->fetch(PDO::FETCH_ASSOC);
            if ($target_exam) {
                $cur_token = strtoupper($target_exam['token'] ?? '');
                $prev_token = strtoupper($target_exam['prev_token'] ?? '');
                $prev_expires = (int)($target_exam['prev_token_expires_at'] ?? 0);
                $is_prev_valid = (!empty($prev_token) && time() <= $prev_expires && $provided_token === $prev_token);
                if ($provided_token !== $cur_token && !$is_prev_valid) {
                    echo json_encode(['status' => 'error', 'message' => 'Token ujian tidak valid atau telah berganti. Silakan masukkan token terbaru!']);
                    exit;
                }
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Token ujian wajib diisi!']);
            exit;
        }
    }
    
    $prevent_multi = $settings['prevent_multi_login'] ?? false;
    $stmtSess = $pdo->prepare("SELECT id, is_reset, state_json, last_active FROM exam_sessions WHERE student_id = ? AND exam_id = ? LIMIT 1");
    $stmtSess->execute([$student_id, $exam_id]);
    $currSess = $stmtSess->fetch(PDO::FETCH_ASSOC);
    
    $found = ($currSess !== false);
    $was_reset = false;
    $saved_state = null;
    
    if ($found) {
        if (!empty($currSess['is_reset'])) {
            $saved_state = !empty($currSess['state_json']) ? json_decode($currSess['state_json'], true) : null;
            $was_reset = true;
        }
    }
    
    if ($prevent_multi && $found && !$was_reset) {
        echo json_encode(['status' => 'error', 'message' => 'Siswa sedang mengerjakan ujian di perangkat lain (atau sesi masih aktif). Hubungi admin untuk mereset login.']);
        exit;
    }
    
    if ($found) {
        // Jika sesi dipulihkan setelah direset, pastikan timer endTime tidak kedaluwarsa jika jadwal ujian masih berjalan
        if ($was_reset && $saved_state !== null) {
            $exams = get_exams();
            foreach ($exams as $e) {
                if ((int)$e['id'] === $exam_id) {
                    $examEndTs = strtotime($e['end_time']);
                    if ($examEndTs > time() && (!isset($saved_state['endTime']) || (int)($saved_state['endTime'] / 1000) <= time())) {
                        $durMins = (int)($e['duration'] ?? 60);
                        $saved_state['endTime'] = min($examEndTs, time() + ($durMins * 60)) * 1000;
                    }
                    break;
                }
            }
            $stateJson = json_encode($saved_state, JSON_UNESCAPED_UNICODE);
            $pdo->prepare("UPDATE exam_sessions SET is_reset = 0, last_active = ?, state_json = ? WHERE id = ?")
                ->execute([time(), $stateJson, (int)$currSess['id']]);
        } else {
            $pdo->prepare("UPDATE exam_sessions SET is_reset = 0, last_active = ? WHERE id = ?")
                ->execute([time(), (int)$currSess['id']]);
        }
        
        if ($saved_state !== null) {
            echo json_encode(['status' => 'success', 'data' => $saved_state]);
        } else {
            echo json_encode(['status' => 'success']);
        }
        exit;
    }
    
    // Jika belum ada sesi, buat sesi baru (Atomic O(1) Insert)
    $stmtNew = $pdo->prepare("INSERT INTO exam_sessions (student_id, exam_id, score, start_time, last_active) VALUES (?, ?, 0, ?, ?)");
    $stmtNew->execute([$student_id, $exam_id, time(), time()]);
    
    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'reset_login') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    
    if ($student_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid student_id']);
        exit;
    }
    
    $pdo = get_db_connection();
    $stmtReset = $pdo->prepare("UPDATE exam_sessions SET is_reset = 1 WHERE student_id = ?");
    $stmtReset->execute([$student_id]);
    
    if ($stmtReset->rowCount() > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Sesi login berhasil direset.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Siswa tidak sedang login.']);
    }
    exit;
}

if ($action === 'get_live_status') {
    $exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
    
    $students = get_students();
    $classes = get_classes();
    $results = get_results($exam_id > 0 ? $exam_id : null);
    $sessions = get_sessions($exam_id > 0 ? $exam_id : null);
    $exams = get_exams();
    
    $classLookup = [];
    foreach ($classes as $c) { $classLookup[$c['id']] = $c['name']; }
    
    $examLookup = [];
    $allowed_classes = [];
    foreach ($exams as $e) { 
        $examLookup[$e['id']] = $e['name'];
        if ($exam_id !== 0 && $e['id'] == $exam_id) {
            $c_ids = $e['class_ids'] ?? null;
            if ($c_ids === null && isset($e['class_id'])) {
                $c_ids = $e['class_id'] == 0 ? [] : [$e['class_id']];
            } else if (!is_array($c_ids) && !empty($c_ids)) {
                $c_ids = json_decode($c_ids, true) ?: [];
            }
            $allowed_classes = $c_ids ?: [];
        }
    }
    
    // Total questions for exam
    $total_exam_questions = 0;
    if ($exam_id !== 0) {
        $target_exam = null;
        foreach ($exams as $e) {
            if ($e['id'] == $exam_id) {
                $target_exam = $e;
                break;
            }
        }
        $bank_id = isset($target_exam['bank_soal_id']) ? $target_exam['bank_soal_id'] : $exam_id;
        $dbQuestions = get_questions_db($bank_id);
        if (empty($dbQuestions) && $bank_id != $exam_id) {
            $dbQuestions = get_questions_db($exam_id);
        }
        $total_exam_questions = count($dbQuestions);
    }
    
    
    $examToBankMap = [];
    foreach ($exams as $e) {
        $examToBankMap[(int)$e['id']] = isset($e['bank_soal_id']) ? (int)$e['bank_soal_id'] : (int)$e['id'];
    }
    
    $resultsLookup = [];
    foreach ($results as $r) { 
        if ($exam_id === 0 || (isset($r['exam_id']) && (int)$r['exam_id'] === $exam_id)) {
            $resultsLookup[$r['student_id']] = $r; 
        }
    }
    
    $sessionsLookup = [];
    foreach ($sessions as $s) {
        if ($exam_id === 0 || (isset($s['exam_id']) && (int)$s['exam_id'] === $exam_id)) {
            $sessionsLookup[$s['student_id']] = $s;
        }
    }
    
    $statusData = [];
    foreach ($students as $student) {
        if ($exam_id !== 0 && !empty($allowed_classes) && !in_array($student['class_id'], $allowed_classes)) {
            continue; // Skip this student if they are not in the allowed classes for this exam
        }
        
        $sid = $student['id'];
        $className = $classLookup[$student['class_id']] ?? '-';
        
        $violations = 0;
        $is_locked = false;
        $is_reset = false;
        $progressText = '0/' . $total_exam_questions;
        $answeredCount = 0;
        $totalQ = $total_exam_questions;
        
        $startTimeFormatted = '-';
        $startTimeTs = 0;
        $endTimeFormatted = '-';
        $endTimeTs = 0;
        $durationFormatted = '-';
        $durationSeconds = 0;
        
        if (isset($resultsLookup[$sid])) {
            $status = 'Selesai';
            $score = $resultsLookup[$sid]['score'];
            $examName = $examLookup[$resultsLookup[$sid]['exam_id'] ?? 0] ?? '-';
            
            $r = $resultsLookup[$sid];
            $violations = (int)($r['violations'] ?? 0);
            if ($violations === 0 && isset($sessionsLookup[$sid])) {
                $violations = (int)($sessionsLookup[$sid]['violations'] ?? 0);
            }

            $sub_ts = !empty($r['submitted_at']) ? strtotime($r['submitted_at']) : 0;
            $start_ts = !empty($r['started_at']) ? strtotime($r['started_at']) : 0;
            if (!$start_ts && $sub_ts) {
                $start_ts = $sub_ts - (int)($r['duration_seconds'] ?? 600);
            }
            if ($start_ts > 0) {
                $startTimeTs = $start_ts;
                $startTimeFormatted = date('H:i:s', $start_ts);
            }
            if ($sub_ts > 0) {
                $endTimeTs = $sub_ts;
                $endTimeFormatted = date('H:i:s', $sub_ts);
            }
            if (isset($r['duration_seconds']) && (int)$r['duration_seconds'] > 0) {
                $durationSeconds = (int)$r['duration_seconds'];
            } else if ($sub_ts > 0 && $start_ts > 0 && $sub_ts >= $start_ts) {
                $durationSeconds = $sub_ts - $start_ts;
            }
            if ($durationSeconds > 0) {
                $dh = floor($durationSeconds / 3600);
                $dm = floor(($durationSeconds % 3600) / 60);
                $ds = $durationSeconds % 60;
                if ($dh > 0) {
                    $durationFormatted = "{$dh}j {$dm}m";
                } else if ($dm > 0) {
                    $durationFormatted = "{$dm}m {$ds}s";
                } else {
                    $durationFormatted = "{$ds}s";
                }
            }

            $ansList = is_string($r['answers']) ? json_decode($r['answers'], true) : ($r['answers'] ?? []);
            if (is_array($ansList) && !empty($ansList)) {
                $totalQ = count($ansList);
                foreach ($ansList as $ansItem) {
                    $sel = $ansItem['selected'] ?? null;
                    if ($sel !== null && $sel !== '' && $sel !== [] && $sel !== '{}') {
                        if (is_string($sel) && trim($sel) === '') continue;
                        if (is_array($sel) && empty($sel)) continue;
                        $answeredCount++;
                    }
                }
            } else {
                $answeredCount = $total_exam_questions;
            }
            $progressText = "{$answeredCount}/{$totalQ}";
        } else if (isset($sessionsLookup[$sid])) {
            $sess = $sessionsLookup[$sid];
            $violations = (int)($sess['violations'] ?? 0);
            $is_locked = !empty($sess['is_locked']);
            $is_reset = !empty($sess['is_reset']);
            $status = $is_reset ? 'Belum Mengerjakan' : ($is_locked ? 'Terkunci' : 'Sedang Mengerjakan');
            
            // Optimasi Tinggi: Gunakan skor yang sudah tersimpan di database exam_sessions
            // Hindari kalkulasi ulang seluruh butir bank soal pada setiap detik interval polling admin
            $score = (float)($sess['score'] ?? 0);
            $examName = $examLookup[$sess['exam_id'] ?? 0] ?? '-';
            
            $start_ts = isset($sess['start_time']) ? (int)$sess['start_time'] : (isset($sess['state']['startTime']) ? (int)($sess['state']['startTime'] / 1000) : 0);
            if (!$start_ts) {
                $start_ts = (int)($sess['last_active'] ?? time());
            }
            if ($start_ts > 0) {
                $startTimeTs = $start_ts;
                $startTimeFormatted = date('H:i:s', $start_ts);
                $durationSeconds = max(0, time() - $start_ts);
                $dh = floor($durationSeconds / 3600);
                $dm = floor(($durationSeconds % 3600) / 60);
                $ds = $durationSeconds % 60;
                if ($dh > 0) {
                    $durationFormatted = "{$dh}j {$dm}m";
                } else if ($dm > 0) {
                    $durationFormatted = "{$dm}m {$ds}s";
                } else {
                    $durationFormatted = "{$ds}s";
                }
            }
            $endTimeFormatted = '-';
            $endTimeTs = 0;

            $shuffledQ = $sess['state']['shuffledQuestions'] ?? [];
            if (is_array($shuffledQ) && !empty($shuffledQ)) {
                $totalQ = count($shuffledQ);
                foreach ($shuffledQ as $sq) {
                    $sel = $sq['selectedOption'] ?? null;
                    if ($sel !== null && $sel !== '' && $sel !== [] && $sel !== '{}') {
                        if (is_string($sel) && trim($sel) === '') continue;
                        if (is_array($sel) && empty($sel)) continue;
                        $answeredCount++;
                    }
                }
            }
            $progressText = "{$answeredCount}/{$totalQ}";
        } else {
            $status = 'Belum Mengerjakan';
            $score = 0;
            $examName = $examLookup[$exam_id] ?? '-';
            $progressText = "0/{$total_exam_questions}";
        }
        
        $statusData[] = [
            'id' => $sid,
            'name' => $student['name'],
            'username' => $student['username'] ?? '',
            'password' => $student['password'] ?? '',
            'class_name' => $className,
            'status' => $status,
            'score' => $score,
            'exam_name' => $examName,
            'violations' => $violations,
            'is_locked' => $is_locked,
            'is_blocked' => !empty($student['is_blocked']),
            'is_reset' => !empty($is_reset),
            'answered_count' => $answeredCount,
            'total_questions' => $totalQ,
            'progress' => $progressText,
            'start_time' => $startTimeFormatted,
            'start_time_ts' => $startTimeTs,
            'end_time' => $endTimeFormatted,
            'end_time_ts' => $endTimeTs,
            'duration' => $durationFormatted,
            'duration_seconds' => $durationSeconds
        ];
    }
    
    // Sort by class then name
    usort($statusData, function($a, $b) {
        $c = strcmp($a['class_name'], $b['class_name']);
        if ($c !== 0) return $c;
        return strcmp($a['name'], $b['name']);
    });
    
    $target_exam = null;
    foreach ($exams as $e) {
        if ($e['id'] == $exam_id) {
            $target_exam = $e;
            break;
        }
    }
    $settings = get_settings();
    $is_dynamic = !empty($settings['dynamic_token']);
    $interval_seconds = max(1, (int)($settings['token_interval_minutes'] ?? 15)) * 60;
    $now = time();
    $remaining = 0;
    $currentToken = $target_exam ? ($target_exam['token'] ?? '') : '';
    if ($target_exam && $is_dynamic) {
        $last_gen = isset($target_exam['token_updated_at']) ? (int)$target_exam['token_updated_at'] : $now;
        $elapsed = $now - $last_gen;
        $remaining = max(0, $interval_seconds - ($elapsed % $interval_seconds));
    }
    
    echo json_encode([
        'status' => 'success', 
        'data' => $statusData,
        'exam_token' => $currentToken,
        'is_dynamic' => $is_dynamic,
        'token_remaining_seconds' => $remaining,
        'interval_minutes' => (int)($settings['token_interval_minutes'] ?? 15)
    ]);
    exit;
}

if ($action === 'refresh_exam_token') {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        echo json_encode(['status' => 'error', 'message' => 'Akses ditolak: Akun guru tidak diizinkan merilis token ujian.']);
        exit;
    }
    $exam_id = (int)($_POST['exam_id'] ?? $_GET['exam_id'] ?? 0);
    $exams = get_exams_raw();
    $now = time();
    $newToken = '';
    $found = false;
    $settings = get_settings();
    $use_single_token = !empty($settings['dynamic_token_all_exams']);

    if ($use_single_token) {
        $newToken = generate_random_token(6);
        foreach ($exams as &$exam) {
            $found = true;
            if (!empty($exam['token'])) {
                $exam['prev_token'] = $exam['token'];
                $exam['prev_token_expires_at'] = $now + 120; // 2 min grace period
            }
            $exam['token'] = $newToken;
            $exam['token_updated_at'] = $now;
        }
        unset($exam);
    } else {
        foreach ($exams as &$exam) {
            if ($exam_id === 0 || $exam['id'] == $exam_id) {
                $found = true;
                if (!empty($exam['token'])) {
                    $exam['prev_token'] = $exam['token'];
                    $exam['prev_token_expires_at'] = $now + 120; // 2 min grace period
                }
                $exam['token'] = generate_random_token(6);
                $exam['token_updated_at'] = $now;
                if ($exam_id !== 0) {
                    $newToken = $exam['token'];
                }
            }
        }
        unset($exam);
    }

    if ($found) {
        save_exams($exams);
        $interval_seconds = max(1, (int)($settings['token_interval_minutes'] ?? 15)) * 60;
        echo json_encode([
            'status' => 'success',
            'message' => 'Token berhasil diperbarui secara acak!',
            'token' => $newToken,
            'remaining_seconds' => $interval_seconds
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Mata pelajaran / jadwal tidak ditemukan']);
    }
    exit;
}

if ($action === 'get_student_essay_answers') {
    $student_id = (int)($_GET['student_id'] ?? 0);
    $exam_id = (int)($_GET['exam_id'] ?? 0);
    
    $results = get_results();
    $studentResult = null;
    foreach ($results as $r) {
        if ($r['student_id'] === $student_id && (isset($r['exam_id']) && $r['exam_id'] == $exam_id)) {
            $studentResult = $r;
            break;
        }
    }
    
    if (!$studentResult || !isset($studentResult['answers'])) {
        echo json_encode(['status' => 'error', 'message' => 'Data jawaban tidak ditemukan (siswa mungkin belum selesai ujian)']);
        exit;
    }
    
    // Ambil data soal asli untuk mendapatkan maks point dan pertanyaan jika diperlukan
    $questionsData = get_questions_db($exam_id);
    
    $answers = is_string($studentResult['answers']) ? json_decode($studentResult['answers'], true) : $studentResult['answers'];
    if (!is_array($answers)) $answers = [];
    
    $essays = [];
    foreach ($answers as $ans) {
        if (isset($ans['type']) && $ans['type'] === 'essay') {
            $origId = $ans['originalId'];
            $qInfo = $questionsData[$origId] ?? [];
            $maxPoints = isset($qInfo['points']) ? (float)$qInfo['points'] : 2;
            
            $essays[] = [
                'originalId' => $origId,
                'question' => $ans['question'],
                'selected' => $ans['selected'],
                'points' => $maxPoints,
                'awarded_points' => isset($ans['awarded_points']) ? $ans['awarded_points'] : 0
            ];
        }
    }
    
    echo json_encode(['status' => 'success', 'data' => $essays]);
    exit;
}

if ($action === 'save_essay_points') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $points_data = json_decode($_POST['points_data'] ?? '[]', true);
    
    if ($student_id <= 0 || $exam_id <= 0 || !is_array($points_data)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid']);
        exit;
    }
    
    $results = get_results();
    $found = false;
    foreach ($results as &$r) {
        if ($r['student_id'] === $student_id && (isset($r['exam_id']) && $r['exam_id'] == $exam_id)) {
            $found = true;
            $totalPointsAdded = 0;
            
            $answers = is_string($r['answers']) ? json_decode($r['answers'], true) : $r['answers'];
            if (!is_array($answers)) $answers = [];
            
            // Re-calculate the score. First, deduct old awarded points, then add new ones
            foreach ($points_data as $pd) {
                $origId = (int)$pd['originalId'];
                $newPoints = (float)$pd['points'];
                
                foreach ($answers as &$ans) {
                    if (isset($ans['type']) && $ans['type'] === 'essay' && $ans['originalId'] === $origId) {
                        $oldPoints = isset($ans['awarded_points']) ? (float)$ans['awarded_points'] : 0;
                        $r['score'] = $r['score'] - $oldPoints + $newPoints;
                        $ans['awarded_points'] = $newPoints;
                        break;
                    }
                }
            }
            
            $r['answers'] = is_string($r['answers']) ? json_encode($answers) : $answers;
            break;
        }
    }
    
    if ($found) {
        save_results($results);
        echo json_encode(['status' => 'success', 'message' => 'Nilai esai berhasil disimpan']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Data hasil ujian tidak ditemukan']);
    }
    exit;
}

if ($action === 'get_all_results') {
    $exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
    
    $students = get_students();
    $classes = get_classes();
    $results = get_results();
    $sessions = get_sessions();
    $exams = get_exams();
    
    $classLookup = [];
    foreach ($classes as $c) { $classLookup[$c['id']] = $c['name']; }
    
    $examLookup = [];
    $allowed_classes_by_exam = [];
    foreach ($exams as $e) { 
        $examLookup[$e['id']] = $e['name'];
        $c_ids = $e['class_ids'] ?? null;
        if ($c_ids === null && isset($e['class_id'])) {
            $c_ids = $e['class_id'] == 0 ? [] : [$e['class_id']];
        } else if (!is_array($c_ids) && !empty($c_ids)) {
            $c_ids = json_decode($c_ids, true) ?: [];
        }
        $allowed_classes_by_exam[$e['id']] = $c_ids ?: [];
    }
    
    // Map existing results: [exam_id][student_id] => result
    $resultsMap = [];
    foreach ($results as $r) {
        $eid = (int)($r['exam_id'] ?? 0);
        $sid = (int)($r['student_id'] ?? 0);
        $resultsMap[$eid][$sid] = $r;
    }

    // Map active sessions: [exam_id][student_id] => session
    $sessionsMap = [];
    foreach ($sessions as $s) {
        $eid = (int)($s['exam_id'] ?? 0);
        $sid = (int)($s['student_id'] ?? 0);
        $sessionsMap[$eid][$sid] = $s;
    }
    
    $target_exams = [];
    if ($exam_id !== 0) {
        foreach ($exams as $e) {
            if ($e['id'] === $exam_id) { $target_exams[] = $e; break; }
        }
    } else {
        $target_exams = $exams;
    }
    
    $exportData = [];
    foreach ($target_exams as $target_e) {
        $eid = $target_e['id'];
        $eName = $target_e['name'];
        $allowed = $allowed_classes_by_exam[$eid] ?? [];
        
        foreach ($students as $student) {
            if (!empty($allowed) && !in_array($student['class_id'], $allowed)) {
                continue; // Skip student not in target classes for this exam
            }
            
            $sid = $student['id'];
            $className = $classLookup[$student['class_id']] ?? '-';
            
            $score = 0;
            if (isset($resultsMap[$eid][$sid])) {
                $score = (float)$resultsMap[$eid][$sid]['score'];
            } else if (isset($sessionsMap[$eid][$sid])) {
                $score = (float)($sessionsMap[$eid][$sid]['score'] ?? 0);
            }
            
            $exportData[] = [
                'Nama Siswa' => $student['name'],
                'Kelas' => $className,
                'Nilai' => $score
            ];
        }
    }
    
    usort($exportData, function($a, $b) {
        $c = strcmp($a['Kelas'], $b['Kelas']);
        if ($c !== 0) return $c;
        return strcmp($a['Nama Siswa'], $b['Nama Siswa']);
    });
    
    $finalData = [];
    $no = 1;
    foreach ($exportData as $row) {
        $finalData[] = [
            'No' => $no++,
            'Nama Siswa' => $row['Nama Siswa'],
            'Kelas' => $row['Kelas'],
            'Nilai' => $row['Nilai']
        ];
    }
    
    echo json_encode(['status' => 'success', 'data' => $finalData]);
    exit;
}

if ($action === 'get_exams') {
    $exams = get_exams();
    $settings = get_settings();
    $is_dynamic = !empty($settings['dynamic_token']);
    $interval_seconds = max(1, (int)($settings['token_interval_minutes'] ?? 15)) * 60;
    $now = time();
    $is_admin = !empty($_SESSION['admin_logged_in']);
    $active_exams = [];
    foreach ($exams as $e) {
        $start = strtotime($e['start_time']);
        $end = strtotime($e['end_time']);
        $status = $e['status'] ?? 'aktif';
        if ($start <= $now && $end >= $now && $status === 'aktif') {
            $last_gen = isset($e['token_updated_at']) ? (int)$e['token_updated_at'] : $now;
            $elapsed = $now - $last_gen;
            $remaining = max(0, $interval_seconds - ($elapsed % $interval_seconds));
            
            $e['is_dynamic'] = $is_dynamic;
            $e['token_remaining_seconds'] = $remaining;
            // Only provide prev_token if still within grace period
            if (isset($e['prev_token_expires_at']) && $now > $e['prev_token_expires_at']) {
                unset($e['prev_token']);
            }
            
            // Keamanan Arsitektur: Jangan bocorkan token ujian ke publik / browser siswa
            if (!$is_admin) {
                unset($e['token']);
                unset($e['prev_token']);
                unset($e['prev_token_expires_at']);
            }
            $active_exams[] = $e;
        }
    }
    echo json_encode(['status' => 'success', 'data' => $active_exams]);
    exit;
}

if ($action === 'verify_exam_token') {
    $exam_id = (int)($_POST['exam_id'] ?? $_GET['exam_id'] ?? 0);
    $token = strtoupper(trim($_POST['token'] ?? $_GET['token'] ?? ''));
    if ($exam_id <= 0 || empty($token)) {
        echo json_encode(['status' => 'error', 'valid' => false, 'message' => 'Token kosong atau ujian tidak valid']);
        exit;
    }
    $exams = get_exams();
    $target = null;
    foreach ($exams as $e) {
        if ((int)$e['id'] === $exam_id) {
            $target = $e;
            break;
        }
    }
    if (!$target) {
        echo json_encode(['status' => 'error', 'valid' => false, 'message' => 'Jadwal ujian tidak ditemukan']);
        exit;
    }
    $now = time();
    $cur_token = strtoupper($target['token'] ?? '');
    $prev_token = strtoupper($target['prev_token'] ?? '');
    $prev_expires = (int)($target['prev_token_expires_at'] ?? 0);
    $is_valid = ($token === $cur_token) || (!empty($prev_token) && $token === $prev_token && $now <= $prev_expires);
    echo json_encode(['status' => 'success', 'valid' => $is_valid]);
    exit;
}

function check_guru_bank_access($bank_soal_id) {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'guru') {
        $cur_user_id = $_SESSION['user_id'] ?? 0;
        $cur_user_name = $_SESSION['user_name'] ?? '';
        $bank_soal = get_bank_soal();
        foreach ($bank_soal as $b) {
            if ($b['id'] == $bank_soal_id) {
                return (isset($b['author_id']) && (int)$b['author_id'] === (int)$cur_user_id) ||
                       (isset($b['created_by']) && strcasecmp(trim($b['created_by']), trim($cur_user_name)) === 0);
            }
        }
        return false;
    }
    return true;
}

if ($action === 'add_bank_soal') {
    $name = trim($_POST['name'] ?? '');
    if (empty($name)) {
        echo json_encode(['status' => 'error', 'message' => 'Nama Bank Soal tidak boleh kosong']);
        exit;
    }
    
    $created_by = trim($_POST['created_by'] ?? '');
    $author_id = isset($_POST['author_id']) ? (int)$_POST['author_id'] : 0;
    $author_role = trim($_POST['author_role'] ?? 'admin');
    
    if (empty($created_by) && isset($_SESSION['user_name'])) {
        $created_by = $_SESSION['user_name'];
        $author_id = (int)($_SESSION['user_id'] ?? 0);
        $author_role = $_SESSION['user_role'] ?? 'admin';
    }
    if (empty($created_by)) {
        $created_by = 'Administrator';
    }

    // Bersihkan soal orphan yang tidak punya induk bank_soal
    clean_orphan_questions();

    $bank_soal = get_bank_soal();
    $maxBankId = count($bank_soal) > 0 ? max(array_column($bank_soal, 'id')) : 0;
    
    // Periksa juga ID maksimal di tabel questions agar tidak tumpang tindih
    $maxQId = 0;
    try {
        $pdo = get_db_connection();
        $stmtMax = $pdo->query("SELECT MAX(bank_soal_id) as max_id FROM questions");
        $maxQId = (int)($stmtMax->fetch()['max_id'] ?? 0);
    } catch (Exception $e) {}

    $new_id = max($maxBankId, $maxQId) + 1;

    // Pastikan bank soal baru bersih dari sisa soal lama
    delete_questions_by_bank($new_id);
    $q_file = "questions_{$new_id}.json";
    if (file_exists($q_file)) {
        @unlink($q_file);
    }

    $classes = trim($_POST['classes'] ?? '');
    $bank_soal[] = [
        'id' => $new_id,
        'name' => $name,
        'classes' => $classes,
        'created_by' => $created_by,
        'author_id' => $author_id,
        'author_role' => $author_role
    ];
    save_bank_soal($bank_soal);
    echo json_encode(['status' => 'success', 'message' => 'Bank Soal berhasil ditambahkan', 'new_id' => $new_id]);
    exit;
}

if ($action === 'delete_bank_soal') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        if (!check_guru_bank_access($id)) {
            echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin menghapus bank soal ini']);
            exit;
        }
        
        $bank_soal = get_bank_soal();
        $bank_soal = array_filter($bank_soal, function($b) use ($id) { return $b['id'] !== $id; });
        save_bank_soal(array_values($bank_soal));
        
        // Hapus soal dari database MySQL dan file JSON
        delete_questions_by_bank($id);
        $q_file = "questions_{$id}.json";
        if (file_exists($q_file)) {
            @unlink($q_file);
        }
    }
    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'bulk_delete_bank_soal') {
    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];

    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada bank soal yang dipilih']);
        exit;
    }

    $bank_soal = get_bank_soal();
    $deletedCount = 0;

    $bank_soal = array_filter($bank_soal, function($b) use ($ids, &$deletedCount) {
        if (in_array($b['id'], $ids)) {
            if (!check_guru_bank_access($b['id'])) {
                return true; // keep if no access
            }
            $deletedCount++;
            
            // Hapus soal dari database MySQL dan file JSON
            delete_questions_by_bank($b['id']);
            $q_file = "questions_{$b['id']}.json";
            if (file_exists($q_file)) {
                @unlink($q_file);
            }
            return false;
        }
        return true;
    });

    if ($deletedCount > 0) {
        save_bank_soal(array_values($bank_soal));
        echo json_encode([
            'status' => 'success',
            'message' => "$deletedCount bank soal terpilih berhasil dihapus.",
            'deleted_count' => $deletedCount
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada bank soal yang dapat dihapus atau izin tidak mencukupi']);
    }
    exit;
}

if ($action === 'edit_bank_soal_name') {
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $classes = trim($_POST['classes'] ?? '');
    if ($id <= 0 || empty($name)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid']);
        exit;
    }
    if (!check_guru_bank_access($id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }
    
    $bank_soal = get_bank_soal();
    foreach ($bank_soal as &$b) {
        if ($b['id'] === $id) {
            $b['name'] = $name;
            if (isset($_POST['classes'])) {
                $b['classes'] = $classes;
            }
            break;
        }
    }
    unset($b);
    save_bank_soal($bank_soal);
    echo json_encode(['status' => 'success', 'message' => 'Bank Soal berhasil diperbarui']);
    exit;
}

if ($action === 'add_exam') {
    $exam_name = trim($_POST['exam_name'] ?? '');
    $bank_soal_id = (int)($_POST['bank_soal_id'] ?? 0);
    $token = trim($_POST['token'] ?? '');
    $start_time = trim($_POST['start_time'] ?? '');
    $end_time = trim($_POST['end_time'] ?? '');
    $duration = (int)($_POST['duration'] ?? 90);
    $class_ids_raw = $_POST['class_ids'] ?? '[]';
    $class_ids = json_decode($class_ids_raw, true);
    if (!is_array($class_ids)) $class_ids = [];
    $class_ids = array_values(array_map('intval', $class_ids));
    
    $shuffle_questions = filter_var($_POST['shuffle_questions'] ?? true, FILTER_VALIDATE_BOOLEAN) ? 1 : 0;
    $shuffle_options = filter_var($_POST['shuffle_options'] ?? true, FILTER_VALIDATE_BOOLEAN) ? 1 : 0;
    $max_questions = max(0, (int)($_POST['max_questions'] ?? 0));
    $status = $_POST['status'] ?? 'aktif';
    
    if (empty($exam_name) || $bank_soal_id <= 0 || empty($token) || empty($start_time) || empty($end_time) || $duration <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Semua kolom jadwal harus diisi dengan benar, dan pastikan Bank Soal telah dipilih']);
        exit;
    }
    
    clean_orphan_exam_data();
    $pdo = get_db_connection();
    $maxDbId = (int)$pdo->query("SELECT GREATEST(
        COALESCE((SELECT MAX(id) FROM exams), 0),
        COALESCE((SELECT MAX(exam_id) FROM exam_sessions), 0),
        COALESCE((SELECT MAX(exam_id) FROM exam_results), 0)
    )")->fetchColumn();
    
    $exams = get_exams();
    $maxArrId = count($exams) > 0 ? max(array_column($exams, 'id')) : 0;
    $new_id = max($maxDbId, $maxArrId) + 1;
    
    // Pastikan tidak ada data sesi atau nilai yang tersisa untuk ID ini
    delete_exam_data($new_id);

    $exams[] = [
        'id' => $new_id,
        'name' => $exam_name,
        'bank_soal_id' => $bank_soal_id,
        'token' => strtoupper($token),
        'classes' => $class_ids,
        'class_ids' => $class_ids,
        'start_time' => $start_time,
        'end_time' => $end_time,
        'duration' => $duration,
        'shuffle_questions' => $shuffle_questions,
        'shuffle_options' => $shuffle_options,
        'max_questions' => $max_questions,
        'status' => $status
    ];
    save_exams($exams);
    
    echo json_encode(['status' => 'success', 'message' => 'Mata Pelajaran & Jadwal berhasil ditambahkan']);
    exit;
}

if ($action === 'edit_exam') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $exam_name = trim($_POST['exam_name'] ?? '');
    $bank_soal_id = (int)($_POST['bank_soal_id'] ?? 0);
    $token = trim($_POST['token'] ?? '');
    $start_time = trim($_POST['start_time'] ?? '');
    $end_time = trim($_POST['end_time'] ?? '');
    $duration = (int)($_POST['duration'] ?? 90);
    $class_ids_raw = $_POST['class_ids'] ?? '[]';
    $class_ids = json_decode($class_ids_raw, true);
    if (!is_array($class_ids)) $class_ids = [];
    $class_ids = array_values(array_map('intval', $class_ids));

    $shuffle_questions = filter_var($_POST['shuffle_questions'] ?? true, FILTER_VALIDATE_BOOLEAN) ? 1 : 0;
    $shuffle_options = filter_var($_POST['shuffle_options'] ?? true, FILTER_VALIDATE_BOOLEAN) ? 1 : 0;
    $max_questions = max(0, (int)($_POST['max_questions'] ?? 0));
    $status = $_POST['status'] ?? 'aktif';

    if ($exam_id <= 0 || empty($exam_name) || $bank_soal_id <= 0 || empty($token) || empty($start_time) || empty($end_time) || $duration <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Semua kolom jadwal harus diisi dengan benar, dan pastikan Bank Soal telah dipilih']);
        exit;
    }
    
    $exams = get_exams();
    foreach ($exams as &$e) {
        if ($e['id'] === $exam_id) {
            $e['name'] = $exam_name;
            $e['bank_soal_id'] = $bank_soal_id;
            $e['token'] = strtoupper($token);
            $e['classes'] = $class_ids;
            $e['class_ids'] = $class_ids;
            $e['start_time'] = $start_time;
            $e['end_time'] = $end_time;
            $e['duration'] = $duration;
            $e['shuffle_questions'] = $shuffle_questions;
            $e['shuffle_options'] = $shuffle_options;
            $e['max_questions'] = $max_questions;
            $e['status'] = $status;
            break;
        }
    }
    unset($e);
    save_exams($exams);
    
    echo json_encode(['status' => 'success', 'message' => 'Ujian dan Jadwal berhasil diperbarui']);
    exit;
}

if ($action === 'delete_exam') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    if ($exam_id > 0) {
        $exams = get_exams();
        $exams = array_filter($exams, function($e) use ($exam_id) { return $e['id'] !== $exam_id; });
        save_exams(array_values($exams));
        delete_exam_data($exam_id);
    }
    clean_orphan_exam_data();
    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'bulk_delete_exam') {
    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];

    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada mata pelajaran yang dipilih']);
        exit;
    }

    $exams = get_exams();
    $initial_count = count($exams);
    $exams = array_filter($exams, function($e) use ($ids) {
        return !in_array($e['id'], $ids);
    });
    $deleted_count = $initial_count - count($exams);

    if ($deleted_count > 0) {
        save_exams(array_values($exams));
        foreach ($ids as $del_id) {
            delete_exam_data((int)$del_id);
        }
        clean_orphan_exam_data();
        echo json_encode([
            'status' => 'success',
            'message' => "$deleted_count mata pelajaran berhasil dihapus",
            'deleted_count' => $deleted_count
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada mata pelajaran yang cocok untuk dihapus']);
    }
    exit;
}

if ($action === 'bulk_update_exam_status') {
    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];
    $new_status = strtolower(trim($_POST['status'] ?? ''));

    $valid_statuses = ['aktif', 'draft', 'selesai'];
    if (!in_array($new_status, $valid_statuses)) {
        echo json_encode(['status' => 'error', 'message' => 'Status tidak valid']);
        exit;
    }

    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada mata pelajaran yang dipilih']);
        exit;
    }

    $exams = get_exams();
    $updated_count = 0;
    foreach ($exams as &$e) {
        if (in_array($e['id'], $ids)) {
            $e['status'] = $new_status;
            $updated_count++;
        }
    }
    unset($e);

    if ($updated_count > 0) {
        save_exams($exams);
        echo json_encode([
            'status' => 'success',
            'message' => "$updated_count mata pelajaran berhasil diubah statusnya menjadi " . ucfirst($new_status),
            'updated_count' => $updated_count
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada mata pelajaran yang diperbarui']);
    }
    exit;
}

if ($action === 'get_questions') {
    if (isset($_GET['bank_soal_id']) && (int)$_GET['bank_soal_id'] > 0) {
        $bank_id = (int)$_GET['bank_soal_id'];
    } else {
        $id = (int)($_GET['exam_id'] ?? 1);
        
        // Coba cari sebagai Jadwal Ujian (Exam ID) via direct O(1) query
        $pdo = get_db_connection();
        $stmtEx = $pdo->prepare("SELECT bank_soal_id FROM exams WHERE id = ? LIMIT 1");
        $stmtEx->execute([$id]);
        $bankRow = $stmtEx->fetch(PDO::FETCH_ASSOC);
        $bank_id = ($bankRow && !empty($bankRow['bank_soal_id'])) ? (int)$bankRow['bank_soal_id'] : $id;
    }
    
    $questions = get_questions_db($bank_id);
    
    // Keamanan Arsitektur: Jika bukan admin/guru yang login, bersihkan seluruh kunci jawaban
    if (empty($_SESSION['admin_logged_in'])) {
        foreach ($questions as &$q) {
            unset($q['answer']);
            unset($q['answers']);
            unset($q['pairs']);
            unset($q['essay_answer']);
            unset($q['rubric']);
            if (!empty($q['statements']) && is_array($q['statements'])) {
                foreach ($q['statements'] as &$stmt) {
                    if (is_array($stmt)) {
                        unset($stmt['answer']);
                    }
                }
                unset($stmt);
            }
        }
        unset($q);
    }
    
    echo json_encode(['status' => 'success', 'data' => $questions]);
    exit;
}

/**
 * Membersihkan dan menerjemahkan karakter matematika dan simbol Yunani ke sintaks LaTeX standar.
 */
function docx_clean_math_text($text) {
    if ($text === '' || $text === null) return '';
    $text = str_replace(["\xc2\xa0", "\u{00A0}"], ' ', $text);

    $charMap = [
        '±' => ' \\pm ',
        '∓' => ' \\mp ',
        '×' => ' \\times ',
        '÷' => ' \\div ',
        '·' => ' \\cdot ',
        '∙' => ' \\bullet ',
        '≠' => ' \\neq ',
        '≤' => ' \\le ',
        '≥' => ' \\ge ',
        '≈' => ' \\approx ',
        '≡' => ' \\equiv ',
        '∼' => ' \\sim ',
        '∝' => ' \\propto ',
        '≪' => ' \\ll ',
        '≫' => ' \\gg ',
        '∞' => ' \\infty ',
        '°' => '^{\\circ}',
        '∂' => ' \\partial ',
        '∇' => ' \\nabla ',
        '∈' => ' \\in ',
        '∉' => ' \\notin ',
        '⊂' => ' \\subset ',
        '⊆' => ' \\subseteq ',
        '⊄' => ' \\nsubset ',
        '∪' => ' \\cup ',
        '∩' => ' \\cap ',
        '∅' => ' \\emptyset ',
        '→' => ' \\to ',
        '←' => ' \\leftarrow ',
        '⇒' => ' \\Rightarrow ',
        '⇔' => ' \\Leftrightarrow ',
        '↔' => ' \\leftrightarrow ',
        '∀' => ' \\forall ',
        '∃' => ' \\exists ',
        '…' => ' \\dots ',
        '⋯' => ' \\cdots ',
        '⋮' => ' \\vdots ',
        '⋱' => ' \\ddots ',
        // Greek lowercase
        'α' => '\\alpha ', 'β' => '\\beta ', 'γ' => '\\gamma ', 'δ' => '\\delta ',
        'ε' => '\\varepsilon ', 'ϵ' => '\\epsilon ', 'ζ' => '\\zeta ', 'η' => '\\eta ',
        'θ' => '\\theta ', 'ϑ' => '\\vartheta ', 'ι' => '\\iota ', 'κ' => '\\kappa ',
        'λ' => '\\lambda ', 'μ' => '\\mu ', 'ν' => '\\nu ', 'ξ' => '\\xi ',
        'π' => '\\pi ', 'ϖ' => '\\varpi ', 'ρ' => '\\rho ', 'ϱ' => '\\varrho ',
        'σ' => '\\sigma ', 'ς' => '\\varsigma ', 'τ' => '\\tau ', 'υ' => '\\upsilon ',
        'φ' => '\\varphi ', 'ϕ' => '\\phi ', 'χ' => '\\chi ', 'ψ' => '\\psi ', 'ω' => '\\omega ',
        // Greek uppercase
        'Γ' => '\\Gamma ', 'Δ' => '\\Delta ', 'Θ' => '\\Theta ', 'Λ' => '\\Lambda ',
        'Ξ' => '\\Xi ', 'Π' => '\\Pi ', 'Σ' => '\\Sigma ', 'Υ' => '\\Upsilon ',
        'Φ' => '\\Phi ', 'Ψ' => '\\Psi ', 'Ω' => '\\Omega '
    ];

    return strtr($text, $charMap);
}

/**
 * Mengonversi struktur persamaan Word Equation (OMML m:oMath / m:oMathPara) dan MathML menjadi sintaks LaTeX.
 */
function docx_omml_to_latex($node) {
    if (!$node) return '';
    
    if ($node->nodeType === XML_TEXT_NODE) {
        return docx_clean_math_text($node->nodeValue);
    }
    if ($node->nodeType !== XML_ELEMENT_NODE) {
        return '';
    }

    $tag = strtolower($node->localName ?: $node->nodeName);
    if (strpos($tag, ':') !== false) {
        $parts = explode(':', $tag);
        $tag = end($parts);
    }

    $getChildren = function($parent, $tags = []) {
        $res = [];
        if (!is_array($tags)) $tags = [$tags];
        $tags = array_map('strtolower', $tags);
        foreach ($parent->childNodes as $c) {
            if ($c->nodeType === XML_ELEMENT_NODE) {
                $cTag = strtolower($c->localName ?: $c->nodeName);
                if (strpos($cTag, ':') !== false) {
                    $cParts = explode(':', $cTag);
                    $cTag = end($cParts);
                }
                if (empty($tags) || in_array($cTag, $tags)) {
                    $res[] = $c;
                }
            }
        }
        return $res;
    };

    $getFirstChild = function($parent, $t) use ($getChildren) {
        $list = $getChildren($parent, [$t]);
        return !empty($list) ? $list[0] : null;
    };

    $getValAttr = function($parent, $attrName = 'val') {
        if (!$parent) return '';
        foreach ($parent->attributes as $a) {
            $aName = strtolower($a->localName ?: $a->nodeName);
            if ($aName === strtolower($attrName) || $aName === 'm:' . strtolower($attrName)) {
                return $a->value;
            }
        }
        return '';
    };

    $convertChildren = function($parent) {
        $out = '';
        foreach ($parent->childNodes as $child) {
            $out .= docx_omml_to_latex($child);
        }
        return $out;
    };

    // Wadah paragraf matematika (Display Math)
    if ($tag === 'omathpara') {
        $maths = $getChildren($node, ['omath']);
        if (!empty($maths)) {
            $parts = [];
            foreach ($maths as $m) {
                $p = trim(docx_omml_to_latex($m));
                if ($p !== '') $parts[] = $p;
            }
            return implode(' \quad ', $parts);
        }
        return $convertChildren($node);
    }

    if ($tag === 'omath' || $tag === 'math' || $tag === 'mrow' || $tag === 'mstyle') {
        return $convertChildren($node);
    }

    // Pecahan (Fraction)
    if ($tag === 'f') {
        $numNode = $getFirstChild($node, 'num');
        $denNode = $getFirstChild($node, 'den');
        $fPr = $getFirstChild($node, 'fpr');
        $fType = '';
        if ($fPr) {
            $typeNode = $getFirstChild($fPr, 'type');
            if ($typeNode) $fType = strtolower($getValAttr($typeNode, 'val'));
        }
        $numLatex = $numNode ? trim(docx_omml_to_latex($numNode)) : '';
        $denLatex = $denNode ? trim(docx_omml_to_latex($denNode)) : '';
        
        if ($fType === 'nobar') {
            return '\\binom{' . $numLatex . '}{' . $denLatex . '}';
        } elseif ($fType === 'skw' || $fType === 'lin') {
            return '{' . $numLatex . '}/{' . $denLatex . '}';
        } else {
            return '\\frac{' . $numLatex . '}{' . $denLatex . '}';
        }
    }
    if ($tag === 'mfrac') {
        $elChildren = $getChildren($node);
        $numLatex = isset($elChildren[0]) ? trim(docx_omml_to_latex($elChildren[0])) : '';
        $denLatex = isset($elChildren[1]) ? trim(docx_omml_to_latex($elChildren[1])) : '';
        return '\\frac{' . $numLatex . '}{' . $denLatex . '}';
    }

    // Akar (Radical / Root)
    if ($tag === 'rad') {
        $radPr = $getFirstChild($node, 'radpr');
        $degHide = false;
        if ($radPr) {
            $dhNode = $getFirstChild($radPr, 'deghide');
            if ($dhNode) {
                $val = strtolower($getValAttr($dhNode, 'val'));
                if ($val === '1' || $val === 'on' || $val === 'true') $degHide = true;
            }
        }
        $degNode = $getFirstChild($node, 'deg');
        $eNode = $getFirstChild($node, 'e');
        $degLatex = ($degNode && !$degHide) ? trim(docx_omml_to_latex($degNode)) : '';
        $eLatex = $eNode ? trim(docx_omml_to_latex($eNode)) : '';
        
        if (!empty($degLatex)) {
            return '\\sqrt[' . $degLatex . ']{' . $eLatex . '}';
        }
        return '\\sqrt{' . $eLatex . '}';
    }
    if ($tag === 'msqrt') {
        return '\\sqrt{' . trim($convertChildren($node)) . '}';
    }
    if ($tag === 'mroot') {
        $elChildren = $getChildren($node);
        $base = isset($elChildren[0]) ? trim(docx_omml_to_latex($elChildren[0])) : '';
        $deg = isset($elChildren[1]) ? trim(docx_omml_to_latex($elChildren[1])) : '';
        return '\\sqrt[' . $deg . ']{' . $base . '}';
    }

    // Pangkat & Indeks (Superscript, Subscript)
    if ($tag === 'ssup' || $tag === 'msup') {
        $eNode = ($tag === 'ssup') ? $getFirstChild($node, 'e') : ($getChildren($node)[0] ?? null);
        $supNode = ($tag === 'ssup') ? $getFirstChild($node, 'sup') : ($getChildren($node)[1] ?? null);
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        $supLatex = $supNode ? docx_omml_to_latex($supNode) : '';
        return '{' . $eLatex . '}^{' . $supLatex . '}';
    }
    if ($tag === 'ssub' || $tag === 'msub') {
        $eNode = ($tag === 'ssub') ? $getFirstChild($node, 'e') : ($getChildren($node)[0] ?? null);
        $subNode = ($tag === 'ssub') ? $getFirstChild($node, 'sub') : ($getChildren($node)[1] ?? null);
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        $subLatex = $subNode ? docx_omml_to_latex($subNode) : '';
        return '{' . $eLatex . '}_{' . $subLatex . '}';
    }
    if ($tag === 'ssubsup' || $tag === 'msubsup') {
        $eNode = ($tag === 'ssubsup') ? $getFirstChild($node, 'e') : ($getChildren($node)[0] ?? null);
        $subNode = ($tag === 'ssubsup') ? $getFirstChild($node, 'sub') : ($getChildren($node)[1] ?? null);
        $supNode = ($tag === 'ssubsup') ? $getFirstChild($node, 'sup') : ($getChildren($node)[2] ?? null);
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        $subLatex = $subNode ? docx_omml_to_latex($subNode) : '';
        $supLatex = $supNode ? docx_omml_to_latex($supNode) : '';
        return '{' . $eLatex . '}_{' . $subLatex . '}^{' . $supLatex . '}';
    }
    if ($tag === 'spre') {
        $eNode = $getFirstChild($node, 'e');
        $subNode = $getFirstChild($node, 'sub');
        $supNode = $getFirstChild($node, 'sup');
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        $subLatex = $subNode ? docx_omml_to_latex($subNode) : '';
        $supLatex = $supNode ? docx_omml_to_latex($supNode) : '';
        return '{}_{' . $subLatex . '}^{' . $supLatex . '}{' . $eLatex . '}';
    }

    // Kurung & Pembatas (Delimiters)
    if ($tag === 'd') {
        $dPr = $getFirstChild($node, 'dpr');
        $beg = '(';
        $end = ')';
        $sep = '|';
        if ($dPr) {
            $begNode = $getFirstChild($dPr, 'begchr');
            if ($begNode) $beg = $getValAttr($begNode, 'val');
            $endNode = $getFirstChild($dPr, 'endchr');
            if ($endNode) $end = $getValAttr($endNode, 'val');
            $sepNode = $getFirstChild($dPr, 'sepchr');
            if ($sepNode) $sep = $getValAttr($sepNode, 'val');
        }
        $mapDelim = function($ch, $isLeft = true) {
            if ($ch === '(') return $isLeft ? '\\left(' : '\\right(';
            if ($ch === ')') return $isLeft ? '\\left)' : '\\right)';
            if ($ch === '[') return $isLeft ? '\\left[' : '\\right[';
            if ($ch === ']') return $isLeft ? '\\left]' : '\\right]';
            if ($ch === '{') return $isLeft ? '\\left\\{' : '\\right\\{';
            if ($ch === '}') return $isLeft ? '\\left\\}' : '\\right\\}';
            if ($ch === '|') return $isLeft ? '\\left|' : '\\right|';
            if ($ch === '‖') return $isLeft ? '\\left\\|' : '\\right\\|';
            if ($ch === '⟨' || $ch === '〈') return $isLeft ? '\\left\\langle' : '\\right\\langle';
            if ($ch === '⟩' || $ch === '〉') return $isLeft ? '\\left\\rangle' : '\\right\\rangle';
            if ($ch === '⌊') return $isLeft ? '\\left\\lfloor' : '\\right\\lfloor';
            if ($ch === '⌋') return $isLeft ? '\\left\\rfloor' : '\\right\\rfloor';
            if ($ch === '⌈') return $isLeft ? '\\left\\lceil' : '\\right\\lceil';
            if ($ch === '⌉') return $isLeft ? '\\left\\rceil' : '\\right\\rceil';
            if ($ch === '' || $ch === null) return $isLeft ? '\\left.' : '\\right.';
            return ($isLeft ? '\\left' : '\\right') . $ch;
        };

        $eNodes = $getChildren($node, ['e']);
        $eParts = [];
        foreach ($eNodes as $en) {
            $eParts[] = docx_omml_to_latex($en);
        }
        $sepStr = ($sep !== '') ? (' ' . $sep . ' ') : ' ';
        $inner = implode($sepStr, $eParts);
        return $mapDelim($beg, true) . ' ' . $inner . ' ' . $mapDelim($end, false);
    }
    if ($tag === 'mfenced') {
        $open = $node->getAttribute('open') ?: '(';
        $close = $node->getAttribute('close') ?: ')';
        return '\\left' . $open . ' ' . $convertChildren($node) . ' \\right' . $close;
    }

    // Operator N-ary (Integral, Sum, Product)
    if ($tag === 'nary') {
        $naryPr = $getFirstChild($node, 'narypr');
        $chr = '∫';
        $subHide = false;
        $supHide = false;
        if ($naryPr) {
            $chrNode = $getFirstChild($naryPr, 'chr');
            if ($chrNode) $chr = $getValAttr($chrNode, 'val') ?: '∫';
            $shNode = $getFirstChild($naryPr, 'subhide');
            if ($shNode && in_array(strtolower($getValAttr($shNode, 'val')), ['1', 'on', 'true'])) $subHide = true;
            $sphNode = $getFirstChild($naryPr, 'suphide');
            if ($sphNode && in_array(strtolower($getValAttr($sphNode, 'val')), ['1', 'on', 'true'])) $supHide = true;
        }
        $opMap = [
            '∑' => '\\sum',
            '∫' => '\\int',
            '∬' => '\\iint',
            '∭' => '\\iiint',
            '∮' => '\\oint',
            '∏' => '\\prod',
            '∐' => '\\coprod',
            '⋃' => '\\bigcup',
            '⋂' => '\\bigcap',
            '⋁' => '\\bigvee',
            '⋀' => '\\bigwedge'
        ];
        $op = $opMap[$chr] ?? $chr;
        $subNode = $getFirstChild($node, 'sub');
        $supNode = $getFirstChild($node, 'sup');
        $eNode = $getFirstChild($node, 'e');

        $subLatex = ($subNode && !$subHide) ? '_{' . trim(docx_omml_to_latex($subNode)) . '}' : '';
        $supLatex = ($supNode && !$supHide) ? '^{' . trim(docx_omml_to_latex($supNode)) . '}' : '';
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';

        return $op . $subLatex . $supLatex . ' ' . $eLatex;
    }
    if ($tag === 'munderover') {
        $elChildren = $getChildren($node);
        $base = isset($elChildren[0]) ? docx_omml_to_latex($elChildren[0]) : '';
        $sub = isset($elChildren[1]) ? docx_omml_to_latex($elChildren[1]) : '';
        $sup = isset($elChildren[2]) ? docx_omml_to_latex($elChildren[2]) : '';
        return $base . '_{' . $sub . '}^{' . $sup . '}';
    }
    if ($tag === 'munder') {
        $elChildren = $getChildren($node);
        $base = isset($elChildren[0]) ? docx_omml_to_latex($elChildren[0]) : '';
        $sub = isset($elChildren[1]) ? docx_omml_to_latex($elChildren[1]) : '';
        return $base . '_{' . $sub . '}';
    }
    if ($tag === 'mover') {
        $elChildren = $getChildren($node);
        $base = isset($elChildren[0]) ? docx_omml_to_latex($elChildren[0]) : '';
        $sup = isset($elChildren[1]) ? docx_omml_to_latex($elChildren[1]) : '';
        return $base . '^{' . $sup . '}';
    }

    // Fungsi Matematika (sin, cos, tan, log, ln, lim, dsb)
    if ($tag === 'func') {
        $fNameNode = $getFirstChild($node, 'fname');
        $eNode = $getFirstChild($node, 'e');
        $fName = $fNameNode ? trim(docx_omml_to_latex($fNameNode)) : '';
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        
        $knownFuncs = ['sin', 'cos', 'tan', 'arcsin', 'arccos', 'arctan', 'sinh', 'cosh', 'tanh', 'sec', 'csc', 'cot', 'log', 'ln', 'lg', 'exp', 'lim', 'max', 'min', 'inf', 'sup', 'det', 'gcd', 'deg', 'dim', 'hom', 'ker'];
        if (in_array(strtolower($fName), $knownFuncs)) {
            $fName = '\\' . strtolower($fName);
        }
        return $fName . ' ' . $eLatex;
    }

    // Limit bawah / atas
    if ($tag === 'limlow') {
        $eNode = $getFirstChild($node, 'e');
        $limNode = $getFirstChild($node, 'lim');
        $eLatex = $eNode ? trim(docx_omml_to_latex($eNode)) : 'lim';
        $limLatex = $limNode ? trim(docx_omml_to_latex($limNode)) : '';
        if (strtolower($eLatex) === 'lim') {
            return '\\lim_{' . $limLatex . '} ';
        }
        return '{' . $eLatex . '}_{' . $limLatex . '} ';
    }
    if ($tag === 'limupp') {
        $eNode = $getFirstChild($node, 'e');
        $limNode = $getFirstChild($node, 'lim');
        $eLatex = $eNode ? trim(docx_omml_to_latex($eNode)) : '';
        $limLatex = $limNode ? trim(docx_omml_to_latex($limNode)) : '';
        return '{' . $eLatex . '}^{' . $limLatex . '} ';
    }

    // Garis Atas / Bawah / Kurung Kurawal Kelompok
    if ($tag === 'groupchr') {
        $gcPr = $getFirstChild($node, 'groupchrpr');
        $chr = '‾';
        $pos = 'top';
        if ($gcPr) {
            $chrNode = $getFirstChild($gcPr, 'chr');
            if ($chrNode) $chr = $getValAttr($chrNode, 'val') ?: '‾';
            $posNode = $getFirstChild($gcPr, 'pos');
            if ($posNode) $pos = strtolower($getValAttr($posNode, 'val')) ?: 'top';
        }
        $eNode = $getFirstChild($node, 'e');
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        if ($pos === 'bot' && ($chr === '⏟' || $chr === '}')) {
            return '\\underbrace{' . $eLatex . '}';
        } elseif ($pos === 'top' && ($chr === '⏞' || $chr === '{')) {
            return '\\overbrace{' . $eLatex . '}';
        } elseif ($pos === 'bot') {
            return '\\underline{' . $eLatex . '}';
        } else {
            return '\\overline{' . $eLatex . '}';
        }
    }

    // Aksentuasi (Topi, Vektor, Titik, Garis)
    if ($tag === 'acc') {
        $accPr = $getFirstChild($node, 'accpr');
        $chr = '^';
        if ($accPr) {
            $chrNode = $getFirstChild($accPr, 'chr');
            if ($chrNode) $chr = $getValAttr($chrNode, 'val') ?: '^';
        }
        $accMap = [
            '^' => '\\hat', 'ˆ' => '\\hat',
            '~' => '\\tilde', '˜' => '\\tilde',
            '¯' => '\\bar', '̄' => '\\bar', '-' => '\\bar',
            '.' => '\\dot', '̇' => '\\dot',
            '¨' => '\\ddot', '̈' => '\\ddot',
            '→' => '\\vec', '⃗' => '\\vec',
            'ˇ' => '\\check', '˘' => '\\breve',
            '´' => '\\acute', '`' => '\\grave'
        ];
        $cmd = $accMap[$chr] ?? '\\hat';
        $eNode = $getFirstChild($node, 'e');
        return $cmd . '{' . ($eNode ? docx_omml_to_latex($eNode) : '') . '}';
    }

    // Bar
    if ($tag === 'bar') {
        $barPr = $getFirstChild($node, 'barpr');
        $pos = 'top';
        if ($barPr) {
            $posNode = $getFirstChild($barPr, 'pos');
            if ($posNode) $pos = strtolower($getValAttr($posNode, 'val')) ?: 'top';
        }
        $eNode = $getFirstChild($node, 'e');
        $eLatex = $eNode ? docx_omml_to_latex($eNode) : '';
        return ($pos === 'bot') ? ('\\underline{' . $eLatex . '}') : ('\\overline{' . $eLatex . '}');
    }

    // Kotak (Box / BorderBox)
    if ($tag === 'borderbox') {
        $eNode = $getFirstChild($node, 'e');
        return '\\boxed{' . ($eNode ? docx_omml_to_latex($eNode) : '') . '}';
    }
    if ($tag === 'box') {
        $eNode = $getFirstChild($node, 'e');
        return $eNode ? docx_omml_to_latex($eNode) : $convertChildren($node);
    }

    // Matriks & Tabel Matematika
    if ($tag === 'm' || $tag === 'mtable') {
        $mrNodes = $getChildren($node, ['mr', 'mtr']);
        $rowLatexs = [];
        foreach ($mrNodes as $mr) {
            $colNodes = $getChildren($mr, ['e', 'mtd']);
            $colLatexs = [];
            foreach ($colNodes as $col) {
                $colLatexs[] = docx_omml_to_latex($col);
            }
            $rowLatexs[] = implode(' & ', $colLatexs);
        }
        return '\\begin{matrix} ' . implode(' \\\\ ', $rowLatexs) . ' \\end{matrix}';
    }
    if ($tag === 'eqarr') {
        $eNodes = $getChildren($node, ['e']);
        $lines = [];
        foreach ($eNodes as $en) {
            $lines[] = docx_omml_to_latex($en);
        }
        return '\\begin{aligned} ' . implode(' \\\\ ', $lines) . ' \\end{aligned}';
    }

    // Run teks matematika
    if ($tag === 'r') {
        $rPr = $getFirstChild($node, 'rpr');
        $isNormalText = false;
        if ($rPr) {
            if ($getFirstChild($rPr, 'nor') || $getFirstChild($rPr, 'lit')) {
                $isNormalText = true;
            }
        }
        $text = '';
        $tNodes = $getChildren($node, ['t']);
        foreach ($tNodes as $tn) {
            $text .= $tn->nodeValue;
        }
        if ($text === '') {
            $text = $convertChildren($node);
        }
        if ($isNormalText) {
            return '\\text{' . $text . '}';
        }
        return docx_clean_math_text($text);
    }

    // Teks & Simbol MathML
    if ($tag === 't' || $tag === 'mi' || $tag === 'mn' || $tag === 'mo') {
        return docx_clean_math_text($node->textContent);
    }
    if ($tag === 'mtext') {
        return '\\text{' . $node->textContent . '}';
    }

    // Fallback: konversi seluruh anak elemen
    return $convertChildren($node);
}

/**
 * Mengonversi elemen tabel OpenXML Word (<w:tbl>) menjadi tabel HTML responsif dengan border rapi.
 */
/**
 * Mengonversi elemen tabel OpenXML Word (<w:tbl>) menjadi tabel HTML responsif dengan border rapi.
 */
function docx_table_to_html($tblNode, $mediaMap = []) {
    if (!$tblNode) return '';

    $getValAttr = function($parent, $attrName = 'val') {
        if (!$parent) return '';
        foreach ($parent->attributes as $a) {
            $aName = strtolower($a->localName ?: $a->nodeName);
            if ($aName === strtolower($attrName) || $aName === 'w:' . strtolower($attrName)) {
                return $a->value;
            }
        }
        return '';
    };

    // Cari baris (tr), dukung tr langsung maupun di dalam w:sdt / w:sdtContent / w:tbody
    $getRows = function($parent) {
        $rows = [];
        $walkFind = function($n) use (&$walkFind, &$rows) {
            foreach ($n->childNodes as $c) {
                if ($c->nodeType === XML_ELEMENT_NODE) {
                    $cTag = strtolower($c->localName ?: $c->nodeName);
                    if (strpos($cTag, ':') !== false) $cTag = substr($cTag, strpos($cTag, ':') + 1);
                    if ($cTag === 'tr') {
                        $rows[] = $c;
                    } elseif (in_array($cTag, ['sdt', 'sdtcontent', 'tbody', 'customxml'])) {
                        $walkFind($c);
                    }
                }
            }
        };
        $walkFind($parent);
        return $rows;
    };

    // Cari sel (tc) di dalam suatu baris
    $getCells = function($row) {
        $cells = [];
        $walkFind = function($n) use (&$walkFind, &$cells) {
            foreach ($n->childNodes as $c) {
                if ($c->nodeType === XML_ELEMENT_NODE) {
                    $cTag = strtolower($c->localName ?: $c->nodeName);
                    if (strpos($cTag, ':') !== false) $cTag = substr($cTag, strpos($cTag, ':') + 1);
                    if ($cTag === 'tc') {
                        $cells[] = $c;
                    } elseif (in_array($cTag, ['sdt', 'sdtcontent', 'customxml'])) {
                        $walkFind($c);
                    }
                }
            }
        };
        $walkFind($row);
        return $cells;
    };

    $trNodes = $getRows($tblNode);
    if (empty($trNodes)) return '';

    $html = '<div class="table-responsive my-2 d-inline-block text-left" style="max-width: 100%;">';
    $html .= '<table class="table table-bordered table-sm text-center mb-0" style="width: auto; min-width: 220px; border-collapse: collapse; border: 1px solid #4a5568; background-color: #fff;">';
    $html .= '<tbody>';

    $isFirstRow = true;
    foreach ($trNodes as $tr) {
        $tcNodes = $getCells($tr);
        if (empty($tcNodes)) continue;

        $trPr = null;
        foreach ($tr->childNodes as $c) {
            if ($c->nodeType === XML_ELEMENT_NODE && in_array(strtolower($c->localName ?: $c->nodeName), ['trpr', 'w:trpr'])) {
                $trPr = $c;
                break;
            }
        }
        $isHeaderRow = false;
        if ($trPr) {
            foreach ($trPr->childNodes as $c) {
                if ($c->nodeType === XML_ELEMENT_NODE && in_array(strtolower($c->localName ?: $c->nodeName), ['tblheader', 'w:tblheader'])) {
                    $isHeaderRow = true;
                    break;
                }
            }
        }
        if ($isFirstRow && count($trNodes) > 1) {
            $isHeaderRow = true;
        }

        $html .= '<tr>';
        foreach ($tcNodes as $tc) {
            $tcPr = null;
            foreach ($tc->childNodes as $c) {
                if ($c->nodeType === XML_ELEMENT_NODE && in_array(strtolower($c->localName ?: $c->nodeName), ['tcpr', 'w:tcpr'])) {
                    $tcPr = $c;
                    break;
                }
            }

            $colspan = 1;
            $shdColor = '';
            if ($tcPr) {
                foreach ($tcPr->childNodes as $c) {
                    $cTag = strtolower($c->localName ?: $c->nodeName);
                    if (in_array($cTag, ['gridspan', 'w:gridspan'])) {
                        $spanVal = (int)$getValAttr($c, 'val');
                        if ($spanVal > 1) $colspan = $spanVal;
                    } elseif (in_array($cTag, ['shd', 'w:shd'])) {
                        $fill = $getValAttr($c, 'fill');
                        if ($fill && strtolower($fill) !== 'auto' && strtolower($fill) !== 'none') {
                            $shdColor = '#' . ltrim($fill, '#');
                        }
                    }
                }
            }

            $cellContent = extract_docx_node_content($tc, $mediaMap);

            $tag = $isHeaderRow ? 'th' : 'td';
            $attrs = ' style="border: 1px solid #4a5568; padding: 6px 12px; vertical-align: middle;';
            if ($isHeaderRow) {
                $bg = $shdColor ?: '#edf2f7';
                $attrs .= ' font-weight: bold; background-color: ' . $bg . ';';
            } elseif ($shdColor) {
                $attrs .= ' background-color: ' . $shdColor . ';';
            }
            $attrs .= '"';

            if ($colspan > 1) {
                $attrs .= ' colspan="' . $colspan . '"';
            }

            $html .= "<$tag$attrs>" . ($cellContent !== '' ? $cellContent : '&nbsp;') . "</$tag>";
        }
        $html .= '</tr>';
        $isFirstRow = false;
    }

    $html .= '</tbody></table></div>';
    return $html;
}

/**
 * Mengecek apakah suatu tabel Word OpenXML adalah tabel template butir soal CBT
 * (memiliki nomor soal pada kolom pertama dan opsi/kunci jawaban di baris berikutnya).
 * Dilengkapi pencegahan false-positive agar tabel data/stimulus tidak disangka sebagai template soal.
 */
function is_docx_template_table($tblNode) {
    if (!$tblNode) return false;
    $hasQNum = false;
    $hasKeyRow = false;
    $optionRows = 0;
    
    $rows = [];
    foreach ($tblNode->childNodes as $c) {
        if ($c->nodeType === XML_ELEMENT_NODE) {
            $trTag = strtolower($c->localName ?: $c->nodeName);
            if (strpos($trTag, ':') !== false) $trTag = substr($trTag, strpos($trTag, ':') + 1);
            if ($trTag === 'tr') $rows[] = $c;
        }
    }

    if (count($rows) < 2) return false;

    foreach ($rows as $tr) {
        $tcTexts = [];
        foreach ($tr->childNodes as $tc) {
            if ($tc->nodeType !== XML_ELEMENT_NODE) continue;
            $tcTag = strtolower($tc->localName ?: $tc->nodeName);
            if (strpos($tcTag, ':') !== false) $tcTag = substr($tcTag, strpos($tcTag, ':') + 1);
            if ($tcTag === 'tc') {
                $tcTexts[] = trim($tc->textContent);
            }
        }
        if (empty($tcTexts)) continue;

        $c0 = $tcTexts[0] ?? '';
        $c1 = $tcTexts[1] ?? '';
        $c2 = $tcTexts[2] ?? '';

        // Deteksi baris nomor soal (contoh: "1." atau "1" atau "Soal 1")
        if (preg_match('/^(?:soal\s*)?\d+[\.\)]?$/i', $c0)) {
            $hasQNum = true;
        }

        // Baris Kunci / Jawaban
        $rowText = strtoupper(implode(' ', $tcTexts));
        if (strpos($rowText, 'JAWABAN') !== false || strpos($rowText, 'KUNCI') !== false) {
            $hasKeyRow = true;
        }

        // Benar / Salah format
        if (strpos($rowText, 'PERNYATAAN') !== false || in_array(strtoupper($c1), ['BENAR','SALAH']) || in_array(strtoupper($c2), ['BENAR','SALAH'])) {
            $hasKeyRow = true;
        }

        // Baris opsi dalam template: kolom 0 kosong dan kolom 1 berisi label A-E
        if (empty($c0) && preg_match('/^[A-E][\.\)]?$/i', $c1)) {
            $optionRows++;
        }
        // Format 2 kolom: kolom 0 berisi label A-E dan kolom 1 berisi teks opsi
        elseif (count($tcTexts) === 2 && preg_match('/^[A-E][\.\)]?$/i', $c0)) {
            $optionRows++;
        }
    }

    // Tabel template CBT yang valid HARUS:
    // 1. Memiliki baris Kunci/Jawaban DAN (Nomor soal ATAU minimal 2 opsi), ATAU
    // 2. Memiliki nomor soal DAN minimal 3 baris opsi (A, B, C...)
    if ($hasKeyRow && ($hasQNum || $optionRows >= 2)) {
        return true;
    }
    if ($hasQNum && $optionRows >= 3) {
        return true;
    }

    return false;
}

/**
 * Mengekstrak teks, rumus Word Equation (OMML m:oMath -> LaTeX), tabel stimulus HTML, dan gambar dari node XML dokumen DOCX Word.
 * Gambar dari relationship diubah menjadi tag <img> dengan src WebP data URI.
 */
function extract_docx_node_content($node, $mediaMap = []) {
    if (!$node) return '';
    $text = '';
    $walk = function($n) use (&$walk, &$text, $mediaMap, $node) {
        if ($n->nodeType === XML_TEXT_NODE) {
            $text .= $n->nodeValue;
        } elseif ($n->nodeType === XML_ELEMENT_NODE) {
            $tag = strtolower($n->localName ?: $n->nodeName);
            if (strpos($tag, ':') !== false) {
                $parts = explode(':', $tag);
                $tag = end($parts);
            }

            // Dukungan penuh Word Equation (OMML) & MathML
            if ($tag === 'omathpara') {
                $latex = trim(docx_omml_to_latex($n));
                if ($latex !== '') {
                    $latex = preg_replace('/\s+/', ' ', $latex);
                    $text .= ' $$' . $latex . '$$ ';
                }
                return; // Jangan telusuri anak elemen lagi, sudah dikonversi
            } elseif ($tag === 'omath' || $tag === 'math') {
                $pTag = ($n->parentNode && $n->parentNode->nodeType === XML_ELEMENT_NODE)
                    ? strtolower($n->parentNode->localName ?: $n->parentNode->nodeName)
                    : '';
                if (strpos($pTag, ':') !== false) {
                    $pParts = explode(':', $pTag);
                    $pTag = end($pParts);
                }
                if ($pTag !== 'omathpara') {
                    $latex = trim(docx_omml_to_latex($n));
                    if ($latex !== '') {
                        $latex = preg_replace('/\s+/', ' ', $latex);
                        $text .= ' $' . $latex . '$ ';
                    }
                    return; // Jangan telusuri anak elemen lagi, sudah dikonversi
                }
            }

            // Tabel stimulus / tabel data di dalam sel soal
            if ($tag === 'tbl') {
                if ($n !== $node) {
                    $text .= ' ' . docx_table_to_html($n, $mediaMap) . ' ';
                    return; // Selesai, jangan telusuri anak w:tbl lagi karena sudah diekstrak menjadi tabel HTML
                }
            }

            if ($tag === 't') {
                $text .= $n->textContent;
                return; // Jangan telusuri anak w:t (text node) untuk mencegah duplikasi teks
            } elseif ($tag === 'br' || $tag === 'cr') {
                $text .= "<br>";
                return;
            } elseif ($tag === 'p') {
                if (!empty(trim($text)) && !preg_match('/<br\s*\/?>\s*$/i', $text)) {
                    $text .= "<br>";
                }
            } elseif ($tag === 'blip') { // <a:blip r:embed="rId4"/>
                $rId = '';
                foreach ($n->attributes as $attr) {
                    if (in_array(strtolower($attr->localName ?: $attr->nodeName), ['embed', 'r:embed'])) { $rId = $attr->value; break; }
                }
                if ($rId && isset($mediaMap[$rId])) {
                    $text .= ' <img src="' . $mediaMap[$rId] . '" style="max-width:100%; height:auto;"> ';
                }
            } elseif ($tag === 'imagedata') { // <v:imagedata r:id="rId4"/>
                $rId = '';
                foreach ($n->attributes as $attr) {
                    if (in_array(strtolower($attr->localName ?: $attr->nodeName), ['id', 'href', 'relid'])) { $rId = $attr->value; break; }
                }
                if ($rId && isset($mediaMap[$rId])) {
                    $text .= ' <img src="' . $mediaMap[$rId] . '" style="max-width:100%; height:auto;"> ';
                }
            }
            foreach ($n->childNodes as $child) {
                $walk($child);
            }
        }
    };
    $walk($node);
    return trim($text);
}

function parse_docx_xml_questions($xml, $mediaMap = []) {
    if (empty($xml)) return [];
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadXML($xml);
    libxml_clear_errors();

    $questions = [];
    $allTables = $dom->getElementsByTagName('tbl');
    $templateTables = [];
    foreach ($allTables as $tbl) {
        $pNode = $tbl->parentNode;
        $pTag = $pNode ? strtolower($pNode->localName ?: $pNode->nodeName) : '';
        if (strpos($pTag, ':') !== false) $pTag = substr($pTag, strpos($pTag, ':') + 1);
        // Template table harus berada di root body dan benar-benar memiliki struktur template soal
        if ($pTag === 'body' && is_docx_template_table($tbl)) {
            $templateTables[] = $tbl;
        }
    }

    if (!empty($templateTables)) {
        foreach ($templateTables as $tbl) {
            $rows = [];
            foreach ($tbl->childNodes as $c) {
                if ($c->nodeType === XML_ELEMENT_NODE) {
                    $cTag = strtolower($c->localName ?: $c->nodeName);
                    if (strpos($cTag, ':') !== false) $cTag = substr($cTag, strpos($cTag, ':') + 1);
                    if ($cTag === 'tr') $rows[] = $c;
                }
            }

            $qType = 'multiple_choice';
            $qText = '';
            $options = [];
            $answer = null;
            $premises = [];
            $matching_options = [];
            $pairs = [];
            $statements = [];
            $stimulusRows = [];

            $flushCurrent = function() use (&$questions, &$qType, &$qText, &$options, &$answer, &$premises, &$matching_options, &$pairs, &$statements, &$stimulusRows) {
                // Jika terdapat baris stimulus data tabel yang disisipkan sebelum opsi jawaban
                if (!empty($stimulusRows)) {
                    $tblHtml = '<div class="table-responsive my-2 d-inline-block text-left" style="max-width:100%;"><table class="table table-bordered table-sm text-center mb-0" style="width:auto; min-width:220px; border-collapse:collapse; border:1px solid #4a5568; background-color:#fff;"><tbody>';
                    $isFirst = true;
                    foreach ($stimulusRows as $sr) {
                        $tblHtml .= '<tr>';
                        foreach ($sr as $sc) {
                            $cellTag = $isFirst ? 'th' : 'td';
                            $cellStyle = ' style="border:1px solid #4a5568; padding:6px 12px; vertical-align:middle;' . ($isFirst ? ' font-weight:bold; background-color:#edf2f7;' : '') . '"';
                            $tblHtml .= "<$cellTag$cellStyle>" . ($sc !== '' ? $sc : '&nbsp;') . "</$cellTag>";
                        }
                        $tblHtml .= '</tr>';
                        $isFirst = false;
                    }
                    $tblHtml .= '</tbody></table></div>';
                    $qText .= '<br>' . $tblHtml;
                    $stimulusRows = [];
                }

                if (empty(trim($qText))) return;

                if ($qType === 'multiple_choice' && !empty($options)) {
                    $questions[] = [
                        'type' => 'multiple_choice',
                        'question' => $qText,
                        'options' => $options,
                        'answer' => $answer !== null ? $answer : 0,
                        'points' => 2.0
                    ];
                } elseif ($qType === 'complex_mc' && !empty($options)) {
                    $questions[] = [
                        'type' => 'complex_mc',
                        'question' => $qText,
                        'options' => $options,
                        'answers' => is_array($answer) ? $answer : [(int)$answer],
                        'points' => 2.0
                    ];
                } elseif ($qType === 'true_false' && !empty($statements)) {
                    $questions[] = [
                        'type' => 'true_false',
                        'question' => $qText,
                        'statements' => $statements,
                        'points' => 2.0
                    ];
                } elseif ($qType === 'matching' && !empty($premises)) {
                    $questions[] = [
                        'type' => 'matching',
                        'question' => $qText,
                        'premises' => $premises,
                        'options' => $matching_options,
                        'pairs' => $pairs,
                        'points' => 2.0
                    ];
                } elseif (empty($options) && empty($statements) && empty($premises)) {
                    $questions[] = [
                        'type' => 'essay',
                        'question' => $qText,
                        'points' => 2.0
                    ];
                }
            };

            foreach ($rows as $tr) {
                $cells = [];
                // Hanya ambil sel (tc) langsung dari baris ini, BUKAN getElementsByTagName('tc') yang tembus ke tabel anak/stimulus
                foreach ($tr->childNodes as $c) {
                    if ($c->nodeType === XML_ELEMENT_NODE) {
                        $cTag = strtolower($c->localName ?: $c->nodeName);
                        if (strpos($cTag, ':') !== false) $cTag = substr($cTag, strpos($cTag, ':') + 1);
                        if ($cTag === 'tc') {
                            $cells[] = extract_docx_node_content($c, $mediaMap);
                        }
                    }
                }
                if (empty($cells)) continue;

                $c0 = $cells[0] ?? '';
                if (preg_match('/^(?:soal\s*)?\d+[\.\)]?$/i', trim($c0))) {
                    // Jika qText sebelumnya ada isinya, simpan dulu sebelum menimpa (mendukung multi-soal 1 tabel)
                    $flushCurrent();

                    // Reset variabel untuk soal baru
                    $qType = 'multiple_choice';
                    $options = [];
                    $answer = null;
                    $premises = [];
                    $matching_options = [];
                    $pairs = [];
                    $statements = [];
                    $stimulusRows = [];
                    
                    // Ekstrak teks soal dari seluruh sel non-kosong pada baris pertanyaan (baik kolom 1, kolom 2, maupun merged)
                    $remainingCells = array_slice($cells, 1);
                    $nonEmpty = array_values(array_filter(array_map('trim', $remainingCells), function($v) { return $v !== ''; }));
                    if (count($nonEmpty) === 1) {
                        $qText = $nonEmpty[0];
                    } elseif (count($nonEmpty) > 1) {
                        $qText = implode(' ', $nonEmpty);
                    } else {
                        $qText = $cells[1] ?? ($cells[2] ?? $cells[0]);
                    }
                } elseif (count($cells) >= 3) {
                    $lbl = strtoupper(trim($cells[1]));
                    $val = trim($cells[2]);
                    
                    if (preg_match('/^[A-E][\.\)]?$/i', $lbl)) {
                        $options[] = $val;
                    } elseif (strpos($lbl, 'JAWAB') !== false || strpos($lbl, 'KUNCI') !== false) {
                        if (preg_match_all('/(?:(\d+)\s*[-=:–—]\s*([A-Z]))/iu', $val, $m)) {
                            $qType = 'matching';
                            for ($i = 0; $i < count($m[0]); $i++) {
                                $pairs[] = ['premise' => max(0, (int)$m[1][$i] - 1), 'option' => ord(strtoupper($m[2][$i])) - 65];
                            }
                        } elseif (preg_match_all('/[A-E]/i', $val, $matches)) {
                            if (count($matches[0]) > 1) {
                                $answer = array_map(function($a) { return ord(strtoupper($a)) - 65; }, $matches[0]);
                                $qType = 'complex_mc';
                            } else {
                                $answer = ord(strtoupper($matches[0][0])) - 65;
                            }
                        }
                    } elseif (strpos($lbl, 'PERNYATAAN') !== false || in_array(strtoupper($val), ['BENAR', 'SALAH', 'B', 'S', 'TRUE', 'FALSE'])) {
                        $qType = 'true_false';
                        $ans_val = strtoupper($val);
                        $is_true = in_array($ans_val, ['BENAR', 'B', 'TRUE']);
                        $statements[] = [
                            'text' => $cells[1],
                            'answer' => $is_true ? 'true' : 'false'
                        ];
                    } else {
                        // Jika belum ada opsi dan baris ini bukan kunci, simpan sebagai baris data tabel stimulus
                        if (empty($options) && strpos($lbl, 'JAWAB') === false && strpos($lbl, 'KUNCI') === false) {
                            $stimulusRows[] = array_slice($cells, 1);
                        } else {
                            if (!empty($lbl) && strpos($lbl, 'JAWAB') === false) {
                                $premises[] = $cells[1];
                                $qType = 'matching';
                            }
                            if (!empty($val)) $matching_options[] = $val;
                        }
                    }
                } elseif (count($cells) === 2) {
                    $lbl = strtoupper(trim($cells[0]));
                    $val = trim($cells[1]);
                    
                    if (preg_match('/^[A-E][\.\)]?$/i', $lbl)) {
                        $options[] = $val;
                    } elseif (strpos($lbl, 'JAWAB') !== false || strpos($lbl, 'KUNCI') !== false) {
                        if (preg_match_all('/(?:(\d+)\s*[-=:–—]\s*([A-Z]))/iu', $val, $m)) {
                            $qType = 'matching';
                            for ($i = 0; $i < count($m[0]); $i++) {
                                $pairs[] = ['premise' => max(0, (int)$m[1][$i] - 1), 'option' => ord(strtoupper($m[2][$i])) - 65];
                            }
                        } elseif (preg_match_all('/[A-E]/i', $val, $matches)) {
                            if (count($matches[0]) > 1) {
                                $answer = array_map(function($a) { return ord(strtoupper($a)) - 65; }, $matches[0]);
                                $qType = 'complex_mc';
                            } else {
                                $answer = ord(strtoupper($matches[0][0])) - 65;
                            }
                        }
                    } elseif (strpos($lbl, 'PERNYATAAN') !== false || in_array(strtoupper($val), ['BENAR', 'SALAH', 'B', 'S', 'TRUE', 'FALSE'])) {
                        $qType = 'true_false';
                        $ans_val = strtoupper($val);
                        $is_true = in_array($ans_val, ['BENAR', 'B', 'TRUE']);
                        $statements[] = [
                            'text' => $cells[0],
                            'answer' => $is_true ? 'true' : 'false'
                        ];
                    } else {
                        if (empty($options) && strpos($lbl, 'JAWAB') === false && strpos($lbl, 'KUNCI') === false) {
                            $stimulusRows[] = $cells;
                        } else {
                            if (!empty($lbl) && strpos($lbl, 'JAWAB') === false) {
                                $premises[] = $cells[0];
                                $qType = 'matching';
                            }
                            if (!empty($val)) $matching_options[] = $val;
                        }
                    }
                }
            }
            $flushCurrent();
        }
    }

    // Jika tidak menggunakan tabel template soal, parse alur dokumen paragraf & tabel stimulus di body
    if (empty($questions)) {
        $body = $dom->getElementsByTagName('body')->item(0);
        if ($body) {
            $currentQuestion = null;
            foreach ($body->childNodes as $node) {
                if ($node->nodeType !== XML_ELEMENT_NODE) continue;
                $tag = strtolower($node->localName ?: $node->nodeName);
                if (strpos($tag, ':') !== false) $tag = substr($tag, strpos($tag, ':') + 1);

                if ($tag === 'tbl') {
                    // Tabel stimulus di antara paragraf soal
                    $tableHtml = docx_table_to_html($node, $mediaMap);
                    if ($currentQuestion && empty($currentQuestion['options'])) {
                        $currentQuestion['question'] .= '<br>' . $tableHtml;
                    }
                } elseif ($tag === 'p') {
                    $txt = extract_docx_node_content($node, $mediaMap);
                    if (empty($txt)) continue;

                    if (preg_match('/^(?:soal\s*)?(\d+)[\.\)]\s*(.*)/si', $txt, $m)) {
                        if ($currentQuestion && !empty($currentQuestion['options'])) {
                            if ($currentQuestion['answer'] === null) $currentQuestion['answer'] = 0;
                            $questions[] = $currentQuestion;
                        }
                        $currentQuestion = [
                            'type' => 'multiple_choice',
                            'question' => trim($m[2]),
                            'options' => [],
                            'answer' => null,
                            'points' => 2.0
                        ];
                    } elseif ($currentQuestion) {
                        if (preg_match('/^([A-E])[\.\)]\s*(.*)/si', $txt, $m)) {
                            $currentQuestion['options'][] = trim($m[2]);
                        } elseif (preg_match('/(?:kunci|jawaban)\s*[:=]\s*([A-E])/i', $txt, $m)) {
                            $currentQuestion['answer'] = ord(strtoupper($m[1])) - 65;
                        } elseif (empty($currentQuestion['options'])) {
                            $currentQuestion['question'] .= '<br>' . $txt;
                        }
                    }
                }
            }
            if ($currentQuestion && !empty($currentQuestion['options'])) {
                if ($currentQuestion['answer'] === null) $currentQuestion['answer'] = 0;
                $questions[] = $currentQuestion;
            }
        }
    }

    return $questions;
}

function parse_html_doc_questions($html) {
    if (empty($html)) return [];

    // ── Pre-clean: strip MSO namespace tags that confuse the DOM parser ──────
    $html = preg_replace('/<\?xml[^>]*>/i', '', $html);
    
    // Remove VML blocks entirely to avoid duplicates and rely on standard <img> tags
    $html = preg_replace('/<!--\[if gte vml 1\]>.*?<!\[endif\]-->/is', '', $html);
    
    // Remove <![if !vml]> and <![endif]> wrappers but keep their contents (the standard <img> tag)
    $html = preg_replace('/<!\[if[^\]]*\]>/is', '', $html);
    $html = preg_replace('/<!\[endif\]>/is', '', $html);
    
    $html = preg_replace('/<o:[^>]*>.*?<\/o:[^>]*>/is', '', $html);
    $html = preg_replace('/<o:[^>]*\/>/i', '', $html);
    $html = preg_replace('/<w:[^>]*>.*?<\/w:[^>]*>/is', '', $html);
    $html = preg_replace('/<!--.*?-->/s', '', $html);

    libxml_use_internal_errors(true);
    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
    libxml_clear_errors();

    $questions = [];

    // ── Helper: get text of a single DOM node (non-recursive on table children) ──
    $getCellText = function($node) use ($dom) {
        $text = '';
        $walk = function($n) use (&$walk, &$text, $dom, $node) {
            if ($n->nodeType === XML_TEXT_NODE) {
                $text .= $n->nodeValue;
            } elseif ($n->nodeType === XML_ELEMENT_NODE) {
                $rawTag = strtolower($n->nodeName);
                $tag = (strpos($rawTag, ':') !== false) ? substr($rawTag, strpos($rawTag, ':') + 1) : $rawTag;
                if ($tag === 'omathpara') {
                    $latex = trim(docx_omml_to_latex($n));
                    if ($latex !== '') {
                        $latex = preg_replace('/[ \t]+/', ' ', $latex);
                        $text .= ' $$' . $latex . '$$ ';
                    }
                    return;
                } elseif ($tag === 'omath' || $tag === 'math') {
                    $latex = trim(docx_omml_to_latex($n));
                    if ($latex !== '') {
                        $latex = preg_replace('/[ \t]+/', ' ', $latex);
                        $text .= ' $' . $latex . '$ ';
                    }
                    return;
                }
                if ($tag === 'table') {
                    if ($n !== $node) {
                        $nestedHtml = $dom->saveHTML($n);
                        if (!preg_match('/class=[\'"][^\'"]*table/i', $nestedHtml)) {
                            $nestedHtml = preg_replace('/<table/i', '<table class="table table-bordered table-sm my-2 text-center" style="width:auto; margin:8px auto; border-collapse:collapse; border:1px solid #4a5568; background-color:#fff;"', $nestedHtml, 1);
                        }
                        $text .= ' <div class="table-responsive my-2 d-inline-block text-left" style="max-width:100%;">' . $nestedHtml . '</div> ';
                        return;
                    }
                }
                if ($tag === 'br' || $tag === 'p') $text .= ' ';
                if ($tag === 'img' || $tag === 'v:imagedata') {
                    $src = $n->getAttribute('src');
                    if ($src) {
                        $imgAttrs = 'src="' . htmlspecialchars($src) . '"';
                        
                        $width = $n->getAttribute('width');
                        $height = $n->getAttribute('height');
                        $style = $n->getAttribute('style') ?: '';
                        
                        $align = '';
                        $p = $n->parentNode;
                        while ($p && $p->nodeType === XML_ELEMENT_NODE) {
                            if (strtolower($p->nodeName) === 'v:shape' && !$style) {
                                $style = $p->getAttribute('style');
                            }
                            if ($p->getAttribute('align')) {
                                $align = strtolower($p->getAttribute('align'));
                            } elseif (stripos($p->getAttribute('style'), 'text-align') !== false) {
                                if (preg_match('/text-align\s*:\s*(left|center|right)/i', $p->getAttribute('style'), $m)) {
                                    $align = strtolower($m[1]);
                                }
                            }
                            $p = $p->parentNode;
                        }
                        
                        if ($width && !preg_match('/width\s*:/i', $style)) {
                            $w = is_numeric($width) ? $width . 'px' : $width;
                            $style = trim($style, '; ') . "; width: $w;";
                        }
                        if ($height && !preg_match('/height\s*:/i', $style)) {
                            $h = is_numeric($height) ? $height . 'px' : $height;
                            $style = trim($style, '; ') . "; height: $h;";
                        }
                        
                        if ($align === 'center') {
                            $style = trim($style, '; ') . "; display: block; margin: 0 auto;";
                        } elseif ($align === 'right') {
                            $style = trim($style, '; ') . "; float: right; margin-left: 10px;";
                        } elseif ($align === 'left') {
                            $style = trim($style, '; ') . "; float: left; margin-right: 10px;";
                        }
                        
                        $style = trim($style, '; ');
                        if ($style) {
                            $imgAttrs .= ' style="' . htmlspecialchars($style) . '"';
                        }
                        
                        $text .= "<img $imgAttrs>";
                    }
                }
                foreach ($n->childNodes as $child) $walk($child);
            }
        };
        $walk($node);
        return preg_replace('/\s+/', ' ', trim($text));
    };

    // ── Helper: flush current question state into $questions ────────────────
    $flush = function($qType, $qText, $options, $answer, $premises, $matching_options, $pairs, $statements) use (&$questions) {
        if (empty(trim($qText))) return;
        if ($qType === 'multiple_choice' && !empty($options)) {
            $questions[] = ['type'=>'multiple_choice','question'=>$qText,'options'=>$options,
                'answer'=>$answer !== null ? (int)$answer : 0,'points'=>2.0];
        } elseif ($qType === 'complex_mc' && !empty($options)) {
            $questions[] = ['type'=>'complex_mc','question'=>$qText,'options'=>$options,
                'answers'=>is_array($answer) ? $answer : [(int)$answer],'points'=>2.0];
        } elseif ($qType === 'true_false' && !empty($statements)) {
            $questions[] = ['type'=>'true_false','question'=>$qText,'statements'=>$statements,'points'=>2.0];
        } elseif ($qType === 'matching' && !empty($premises)) {
            $questions[] = ['type'=>'matching','question'=>$qText,'premises'=>$premises,
                'options'=>$matching_options,'pairs'=>$pairs,'points'=>2.0];
        } elseif (!empty($options)) {
            $questions[] = ['type'=>'multiple_choice','question'=>$qText,'options'=>$options,
                'answer'=>$answer !== null ? (int)$answer : 0,'points'=>2.0];
        } else {
            $questions[] = ['type'=>'essay','question'=>$qText,'points'=>2.0];
        }
    };

    // ── Helper: process a single row of cells ────────────────────────────────
    $processRow = function($cells, &$qType, &$qText, &$options, &$answer, &$premises, &$matching_options, &$pairs, &$statements) use ($flush, &$questions) {
        $c0 = trim($cells[0] ?? '');
        $numCells = count($cells);

        $c0clean = preg_replace('/[\s\xc2\xa0\x{00a0}]+/u', ' ', $c0);
        $c0clean = trim($c0clean);
        $c0TextOnly = trim(strip_tags($c0clean));
        $isNumRow = preg_match('/^(?:soal\s*)?\d+[\.\)]?$/i', $c0TextOnly) && $numCells >= 2;
        
        if (!$isNumRow && $numCells === 1 && preg_match('/^(?:soal\s*)?(\d+)[\.\)]\s+(.+)/si', $c0clean, $nm)) {
            if (!empty($qText)) {
                $flush($qType, $qText, $options, $answer, $premises, $matching_options, $pairs, $statements);
            }
            $qType = 'multiple_choice'; $options = []; $answer = null;
            $premises = []; $matching_options = []; $pairs = []; $statements = [];
            $qText = trim($nm[2]);
            return;
        }
        
        if ($isNumRow) {
            if (!empty($qText)) {
                $flush($qType, $qText, $options, $answer, $premises, $matching_options, $pairs, $statements);
            }
            $qType = 'multiple_choice'; $options = []; $answer = null;
            $premises = []; $matching_options = []; $pairs = []; $statements = [];
            
            $remainingCells = array_slice($cells, 1);
            $nonEmpty = array_values(array_filter(array_map('trim', $remainingCells), function($v) { return $v !== ''; }));
            if (count($nonEmpty) === 1) {
                $qText = $nonEmpty[0];
            } elseif (count($nonEmpty) > 1) {
                $qText = implode(' ', $nonEmpty);
            } else {
                $qText = trim($cells[1] ?? ($cells[2] ?? $cells[0]));
            }
            return;
        }

        $lbl = ''; $val = '';
        if ($numCells >= 3) {
            $lbl = strtoupper(trim($cells[1] ?? ''));
            $val = trim($cells[2] ?? '');
        } elseif ($numCells === 2) {
            $lbl = strtoupper(trim($cells[0] ?? ''));
            $val = trim($cells[1] ?? '');
        } elseif ($numCells === 1) {
            return;
        }

        $cleanLbl = trim(strip_tags($lbl));
        if (preg_match('/^[A-E][\.\)]?\s*$/i', $cleanLbl)) {
            $options[] = $val;
            return;
        }

        $cleanLbl = strtoupper(trim(strip_tags($lbl)));
        if (strpos($cleanLbl, 'JAWAB') !== false || strpos($cleanLbl, 'KUNCI') !== false) {
            $cleanVal = trim(strip_tags($val));
            if (preg_match_all('/(\d+)\s*[-=:–—]\s*([A-E])/iu', $cleanVal, $m)) {
                $qType = 'matching';
                for ($i = 0; $i < count($m[0]); $i++) {
                    $pairs[] = ['premise' => max(0,(int)$m[1][$i]-1), 'option' => ord(strtoupper($m[2][$i]))-65];
                }
            } elseif (preg_match_all('/[A-E]/i', $cleanVal, $matches)) {
                $letters = array_unique(array_map('strtoupper', $matches[0]));
                if (count($letters) > 1) {
                    $answer = array_values(array_map(function($a){return ord($a)-65;}, $letters));
                    $qType = 'complex_mc';
                } else {
                    $answer = ord($letters[0]) - 65;
                }
            }
            return;
        }

        $valUpper = strtoupper(trim(strip_tags($val)));
        if (strpos(strip_tags($lbl), 'PERNYATAAN') !== false || in_array($valUpper, ['BENAR','SALAH','B','S','TRUE','FALSE'])) {
            $qType = 'true_false';
            $is_true = in_array($valUpper, ['BENAR','B','TRUE']);
            $stmtText = ($numCells >= 3) ? trim($cells[1] ?? '') : trim($cells[0] ?? '');
            $statements[] = ['text' => $stmtText, 'answer' => $is_true ? 'true' : 'false'];
            return;
        }

        if (!empty($lbl) && strpos($lbl, 'JAWAB') === false && strpos($lbl, 'KUNCI') === false
            && strpos($lbl, 'TIPE') === false) {
            if (preg_match('/[A-Za-z]/', $lbl)) {
                $premiseText = ($numCells >= 3) ? trim($cells[1] ?? '') : trim($cells[0] ?? '');
                $premises[] = $premiseText;
                $qType = 'matching';
                if (!empty($val)) $matching_options[] = $val;
            }
        }
    };

    // ── Iterate tables ────────────────────────────────────────────────────────
    $tables = $dom->getElementsByTagName('table');
    if ($tables->length > 0) {
        $topLevelTables = [];
        foreach ($tables as $tbl) {
            $parent = $tbl->parentNode;
            $isNested = false;
            while ($parent && $parent->nodeName !== '#document') {
                if (strtolower($parent->nodeName) === 'table') { $isNested = true; break; }
                $parent = $parent->parentNode;
            }
            if (!$isNested) $topLevelTables[] = $tbl;
        }

        foreach ($topLevelTables as $table) {
            $qType = 'multiple_choice'; $qText = ''; $options = []; $answer = null;
            $premises = []; $matching_options = []; $pairs = []; $statements = [];

            $xpath = new DOMXPath($dom);
            $rows = $xpath->query('.//tr', $table);

            foreach ($rows as $tr) {
                $parent = $tr->parentNode;
                $inNestedTable = false;
                while ($parent && $parent !== $table) {
                    if (strtolower($parent->nodeName) === 'table') { $inNestedTable = true; break; }
                    $parent = $parent->parentNode;
                }
                if ($inNestedTable) continue;

                $cells = [];
                foreach ($tr->childNodes as $node) {
                    if (in_array(strtolower($node->nodeName), ['td','th'])) {
                        $cells[] = $getCellText($node);
                    }
                }
                if (empty($cells)) {
                    foreach ($tr->getElementsByTagName('td') as $td) {
                        if ($td->parentNode === $tr) {
                            $cells[] = $getCellText($td);
                        }
                    }
                }

                while (!empty($cells) && trim(end($cells)) === '') array_pop($cells);
                if (empty($cells)) continue;

                $processRow($cells, $qType, $qText, $options, $answer, $premises, $matching_options, $pairs, $statements);
            }

            if (!empty($qText)) {
                $flush($qType, $qText, $options, $answer, $premises, $matching_options, $pairs, $statements);
            }
        }
    }

    // ── Fallback: parse plain-text paragraphs and stimulus tables in body ─────
    if (empty($questions)) {
        $body = $dom->getElementsByTagName('body')->item(0);
        if ($body) {
            $currentQuestion = null;
            foreach ($body->childNodes as $node) {
                if ($node->nodeType !== XML_ELEMENT_NODE) continue;
                $rawTag = strtolower($node->nodeName);
                $tag = (strpos($rawTag, ':') !== false) ? substr($rawTag, strpos($rawTag, ':') + 1) : $rawTag;

                if ($tag === 'table') {
                    $tableHtml = $dom->saveHTML($node);
                    if (!preg_match('/class=[\'"][^\'"]*table/i', $tableHtml)) {
                        $tableHtml = preg_replace('/<table/i', '<table class="table table-bordered table-sm my-2 text-center" style="width:auto; margin:8px auto; border-collapse:collapse; border:1px solid #4a5568; background-color:#fff;"', $tableHtml, 1);
                    }
                    if ($currentQuestion && empty($currentQuestion['options'])) {
                        $currentQuestion['question'] .= '<br><div class="table-responsive my-2 d-inline-block text-left" style="max-width:100%;">' . $tableHtml . '</div>';
                    }
                } elseif ($tag === 'p' || $tag === 'div') {
                    $txt = trim($node->textContent);
                    if (empty($txt)) continue;

                    if (preg_match('/^(?:soal\s*)?(\d+)[\.\)]\s*(.*)/si', $txt, $m)) {
                        if ($currentQuestion && !empty($currentQuestion['options'])) {
                            if ($currentQuestion['answer'] === null) $currentQuestion['answer'] = 0;
                            $questions[] = $currentQuestion;
                        }
                        $currentQuestion = [
                            'type' => 'multiple_choice',
                            'question' => trim($m[2]),
                            'options' => [],
                            'answer' => null,
                            'points' => 2.0
                        ];
                    } elseif ($currentQuestion) {
                        if (preg_match('/^([A-E])[\.\)]\s*(.*)/si', $txt, $m)) {
                            $currentQuestion['options'][] = trim($m[2]);
                        } elseif (preg_match('/(?:kunci|jawaban)\s*[:=]\s*([A-E])/i', $txt, $m)) {
                            $currentQuestion['answer'] = ord(strtoupper($m[1])) - 65;
                        } elseif (empty($currentQuestion['options'])) {
                            $currentQuestion['question'] .= '<br>' . $txt;
                        }
                    }
                }
            }
            if ($currentQuestion && !empty($currentQuestion['options'])) {
                if ($currentQuestion['answer'] === null) $currentQuestion['answer'] = 0;
                $questions[] = $currentQuestion;
            }
        }
    }

    return $questions;
}

/**
 * Membaca dan mengekstrak seluruh bank soal beserta butir soal dan gambar dari berkas arsip ZIP.
 * Mendukung berkas ZIP tunggal (soal.json di root) maupun berkas ZIP paket massal (banyak subfolder bank soal).
 * Seluruh referensi gambar lokal di dalam ZIP dikonversi kembali ke base64 URI agar mandiri & portabel.
 */
function parse_all_banks_from_zip($zipFilePath) {
    if (!class_exists('ZipArchive')) {
        return [];
    }

    $zip = new ZipArchive();
    if ($zip->open($zipFilePath) !== true) {
        return [];
    }

    // 1. Temukan semua file JSON yang berpotensi menjadi data soal
    $jsonEntries = [];
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $entryName = $zip->getNameIndex($i);
        if (preg_match('/(^|\/)(soal|bank_soal|questions)\.json$/i', $entryName)) {
            $jsonEntries[] = $entryName;
        }
    }

    // Jika tidak ada nama standar, cari file .json apapun kecuali manifest, composer, package
    if (empty($jsonEntries)) {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entryName = $zip->getNameIndex($i);
            if (preg_match('/\.json$/i', $entryName) && !preg_match('/manifest|package|composer/i', $entryName)) {
                $jsonEntries[] = $entryName;
            }
        }
    }

    if (empty($jsonEntries)) {
        $zip->close();
        return [];
    }

    // Urutkan agar susunan bank konsisten
    sort($jsonEntries);

    $allBanks = [];

    foreach ($jsonEntries as $jsonFile) {
        $baseDir = dirname($jsonFile);
        if ($baseDir === '.' || $baseDir === '/' || $baseDir === '\\') {
            $baseDir = '';
        } else {
            $baseDir = rtrim(str_replace('\\', '/', $baseDir), '/') . '/';
        }

        $rawJson = $zip->getFromName($jsonFile);
        if ($rawJson === false) continue;
        $rawJson = preg_replace('/^\xEF\xBB\xBF/', '', $rawJson);
        $decoded = json_decode($rawJson, true);
        if (!is_array($decoded)) continue;

        $bankInfo = [];
        if (isset($decoded['bank_soal']) && is_array($decoded['bank_soal'])) {
            $bankInfo = $decoded['bank_soal'];
        } elseif (isset($decoded['bank_name'])) {
            $bankInfo = ['name' => $decoded['bank_name']];
        }

        $rawQuestions = [];
        if (isset($decoded['questions']) && is_array($decoded['questions'])) {
            $rawQuestions = $decoded['questions'];
        } elseif (isset($decoded['data']) && is_array($decoded['data'])) {
            $rawQuestions = $decoded['data'];
        } elseif (isset($decoded['soal']) && is_array($decoded['soal'])) {
            $rawQuestions = $decoded['soal'];
        } elseif (is_array($decoded) && isset($decoded[0]) && is_array($decoded[0])) {
            $rawQuestions = $decoded;
        }

        if (empty($rawQuestions)) continue;

        // Helper untuk mengubah path gambar lokal di ZIP kembali menjadi base64 URI
        $restoreImagesFromZip = function ($html) use ($zip, $baseDir) {
            if (empty($html) || !is_string($html)) return $html;

            return preg_replace_callback('/<img\b([^>]*?)\bsrc=(["\'])(.*?)\2([^>]*?)>/i', function ($matches) use ($zip, $baseDir) {
                $prefix = $matches[1];
                $quote = $matches[2];
                $src = trim($matches[3]);
                $suffix = $matches[4];

                if (preg_match('/^data:image\//i', $src) || preg_match('/^https?:\/\//i', $src)) {
                    return $matches[0];
                }

                $cleanSrc = ltrim($src, '/\\');
                $searchPaths = [
                    $src,
                    $cleanSrc,
                    $baseDir . $src,
                    $baseDir . $cleanSrc,
                    $baseDir . 'images/' . basename($src),
                    $baseDir . 'gambar/' . basename($src),
                    'images/' . basename($src),
                    'gambar/' . basename($src),
                    basename($src)
                ];

                $imgData = null;
                $matchedName = '';
                foreach ($searchPaths as $p) {
                    $p = str_replace('\\', '/', $p);
                    $data = $zip->getFromName($p);
                    if ($data !== false && strlen($data) > 0) {
                        $imgData = $data;
                        $matchedName = $p;
                        break;
                    }
                }

                if ($imgData === null) {
                    $base = strtolower(basename($src));
                    for ($k = 0; $k < $zip->numFiles; $k++) {
                        $entryName = $zip->getNameIndex($k);
                        if (strtolower(basename($entryName)) === $base) {
                            $imgData = $zip->getFromIndex($k);
                            $matchedName = $entryName;
                            break;
                        }
                    }
                }

                if ($imgData !== null && strlen($imgData) > 0) {
                    $ext = strtolower(pathinfo($matchedName, PATHINFO_EXTENSION));
                    if ($ext === 'svg') {
                        $mime = 'image/svg+xml';
                        $base64Uri = 'data:' . $mime . ';base64,' . base64_encode($imgData);
                    } else {
                        $webpBin = convert_image_binary_to_webp($imgData, 80);
                        $base64Uri = 'data:image/webp;base64,' . base64_encode($webpBin);
                    }
                    return "<img{$prefix}src={$quote}{$base64Uri}{$quote}{$suffix}>";
                }

                return $matches[0];
            }, $html);
        };

        $parsed = [];
        foreach ($rawQuestions as $item) {
            if (!is_array($item)) continue;

            $qText = $item['question'] ?? $item['text'] ?? $item['pertanyaan'] ?? '';
            if (empty(trim($qText))) continue;

            $qText = $restoreImagesFromZip($qText);
            $qType = $item['type'] ?? 'multiple_choice';
            $points = isset($item['points']) ? (float)$item['points'] : (isset($item['poin']) ? (float)$item['poin'] : 2.0);

            $normItem = [
                'type' => $qType,
                'question' => $qText,
                'points' => $points
            ];

            if ($qType === 'multiple_choice') {
                $options = $item['options'] ?? $item['pilihan'] ?? [];
                if (is_array($options)) {
                    foreach ($options as &$opt) {
                        if (is_string($opt)) $opt = $restoreImagesFromZip($opt);
                    }
                    unset($opt);
                }
                $ans = $item['answer'] ?? $item['jawaban'] ?? $item['kunci'] ?? 0;
                if (is_string($ans) && preg_match('/^[A-E]$/i', trim($ans))) {
                    $ans = ord(strtoupper(trim($ans))) - 65;
                } else {
                    $ans = (int)$ans;
                }
                $normItem['options'] = array_values((array)$options);
                $normItem['answer'] = $ans;
            } elseif ($qType === 'complex_mc') {
                $options = $item['options'] ?? $item['pilihan'] ?? [];
                if (is_array($options)) {
                    foreach ($options as &$opt) {
                        if (is_string($opt)) $opt = $restoreImagesFromZip($opt);
                    }
                    unset($opt);
                }
                $ans = $item['answers'] ?? $item['jawaban'] ?? $item['kunci'] ?? [];
                if (!is_array($ans)) $ans = [$ans];
                $normAns = [];
                foreach ($ans as $a) {
                    if (is_string($a) && preg_match('/^[A-E]$/i', trim($a))) {
                        $normAns[] = ord(strtoupper(trim($a))) - 65;
                    } else {
                        $normAns[] = (int)$a;
                    }
                }
                $normItem['options'] = array_values((array)$options);
                $normItem['answers'] = $normAns;
            } elseif ($qType === 'true_false') {
                $statements = $item['statements'] ?? $item['pernyataan'] ?? [];
                if (is_array($statements)) {
                    foreach ($statements as &$st) {
                        if (is_array($st) && isset($st['text'])) $st['text'] = $restoreImagesFromZip($st['text']);
                        elseif (is_string($st)) $st = $restoreImagesFromZip($st);
                    }
                    unset($st);
                }
                $normItem['statements'] = $statements;
            } elseif ($qType === 'matching') {
                $options = $item['options'] ?? [];
                $premises = $item['premises'] ?? [];
                if (is_array($premises)) {
                    foreach ($premises as &$prem) {
                        if (is_string($prem)) $prem = $restoreImagesFromZip($prem);
                        elseif (is_array($prem) && isset($prem['text'])) $prem['text'] = $restoreImagesFromZip($prem['text']);
                    }
                    unset($prem);
                }
                $normItem['options'] = $options;
                $normItem['premises'] = $premises;
                $normItem['pairs'] = $item['pairs'] ?? [];
            } else {
                $normItem['options'] = array_values((array)($item['options'] ?? []));
                $normItem['answer'] = (int)($item['answer'] ?? 0);
            }

            $parsed[] = $normItem;
        }

        $bName = $bankInfo['name'] ?? '';
        if (empty($bName)) {
            $folderName = trim($baseDir, '/\\');
            $folderName = preg_replace('/^bank_\d+_/i', '', $folderName);
            $folderName = str_replace('_', ' ', trim($folderName));
            $bName = !empty($folderName) ? $folderName : 'Bank Soal Impor ' . (count($allBanks) + 1);
        }

        $allBanks[] = [
            'name' => $bName,
            'info' => $bankInfo,
            'questions' => $parsed
        ];
    }

    $zip->close();
    return $allBanks;
}

/**
 * Backward compatibility: mengembalikan butir soal dari bank pertama di ZIP.
 */
function parse_questions_from_zip($zipFilePath, &$bankInfo = null) {
    $banks = parse_all_banks_from_zip($zipFilePath);
    if (empty($banks)) return [];
    $bankInfo = $banks[0]['info'] ?? ['name' => $banks[0]['name']];
    return $banks[0]['questions'] ?? [];
}

if ($action === 'backup_soal_zip' || $action === 'bulk_backup_soal_zip') {
    if (!class_exists('ZipArchive')) {
        echo json_encode(['status' => 'error', 'message' => 'Ekstensi ZipArchive PHP tidak tersedia di server']);
        exit;
    }

    $bankIds = [];
    if (isset($_GET['bank_ids']) || isset($_POST['bank_ids'])) {
        $rawIds = $_GET['bank_ids'] ?? $_POST['bank_ids'];
        if (is_array($rawIds)) {
            $bankIds = array_map('intval', $rawIds);
        } elseif (is_string($rawIds)) {
            $decoded = json_decode($rawIds, true);
            if (is_array($decoded)) {
                $bankIds = array_map('intval', $decoded);
            } else {
                $bankIds = array_filter(array_map('intval', explode(',', $rawIds)));
            }
        }
    } elseif (isset($_GET['all']) && $_GET['all'] == '1') {
        $allB = get_bank_soal();
        foreach ($allB as $b) {
            if (check_guru_bank_access((int)$b['id'])) {
                $bankIds[] = (int)$b['id'];
            }
        }
    } else {
        $singleId = (int)($_GET['bank_id'] ?? $_GET['exam_id'] ?? $_POST['bank_id'] ?? $_POST['exam_id'] ?? 0);
        if ($singleId > 0) $bankIds = [$singleId];
    }

    $bankIds = array_values(array_unique(array_filter($bankIds)));
    if (empty($bankIds)) {
        echo json_encode(['status' => 'error', 'message' => 'Pilih minimal satu bank soal untuk dibackup']);
        exit;
    }

    // Ambil daftar seluruh bank soal untuk referensi nama & metadata
    $allBanksList = get_bank_soal();
    $bankMap = [];
    foreach ($allBanksList as $b) {
        $bankMap[(int)$b['id']] = $b;
    }

    // JIKA HANYA 1 BANK SOAL & BUKAN FORCED BULK: Format ZIP Tunggal (soal.json di root + images/)
    if (count($bankIds) === 1 && !isset($_GET['bulk']) && !isset($_POST['bulk']) && $action !== 'bulk_backup_soal_zip') {
        $bank_id = $bankIds[0];
        if (!check_guru_bank_access($bank_id)) {
            echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki akses ke Bank Soal ini']);
            exit;
        }

        $bank = $bankMap[$bank_id] ?? null;
        $bankName = $bank ? $bank['name'] : "Bank_Soal_{$bank_id}";
        $questions = get_questions_db($bank_id);

        $zip = new ZipArchive();
        $safeName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $bankName);
        $safeName = trim(preg_replace('/_+/', '_', $safeName), '_');
        if (empty($safeName)) $safeName = "bank_soal_{$bank_id}";
        $zipFileName = 'backup_soal_' . $safeName . '_' . date('Ymd_His') . '.zip';
        $zipFilePath = sys_get_temp_dir() . '/' . uniqid('soal_backup_') . '.zip';

        if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            echo json_encode(['status' => 'error', 'message' => 'Gagal membuat file ZIP di server']);
            exit;
        }

        $imgCounter = 0;
        $extractImagesToZip = function ($html) use ($zip, &$imgCounter) {
            if (empty($html) || !is_string($html)) return $html;

            return preg_replace_callback('/<img\b([^>]*?)\bsrc=(["\'])(.*?)\2([^>]*?)>/i', function ($matches) use ($zip, &$imgCounter) {
                $prefix = $matches[1];
                $quote = $matches[2];
                $src = trim($matches[3]);
                $suffix = $matches[4];

                if (preg_match('/^data:image\/([a-zA-Z0-9\+\-]+);base64,(.+)$/is', $src, $m)) {
                    $ext = strtolower($m[1]);
                    if ($ext === 'jpeg') $ext = 'jpg';
                    elseif ($ext === 'svg+xml') $ext = 'svg';

                    $binary = base64_decode(str_replace(' ', '+', $m[2]));
                    if ($binary !== false) {
                        $imgCounter++;
                        $zipImgPath = "images/img_{$imgCounter}.{$ext}";
                        $zip->addFromString($zipImgPath, $binary);
                        return "<img{$prefix}src={$quote}{$zipImgPath}{$quote}{$suffix}>";
                    }
                } elseif (!preg_match('/^https?:\/\//i', $src)) {
                    $cleanSrc = ltrim($src, '/\\');
                    $localPath = __DIR__ . '/' . $cleanSrc;
                    if (file_exists($localPath) && is_file($localPath)) {
                        $binary = file_get_contents($localPath);
                        $ext = strtolower(pathinfo($localPath, PATHINFO_EXTENSION));
                        if (empty($ext)) $ext = 'png';
                        $imgCounter++;
                        $zipImgPath = "images/img_{$imgCounter}.{$ext}";
                        $zip->addFromString($zipImgPath, $binary);
                        return "<img{$prefix}src={$quote}{$zipImgPath}{$quote}{$suffix}>";
                    }
                }
                return $matches[0];
            }, $html);
        };

        $processedQuestions = [];
        foreach ($questions as $q) {
            $item = $q;
            if (isset($item['question'])) $item['question'] = $extractImagesToZip($item['question']);
            if (isset($item['options']) && is_array($item['options'])) {
                foreach ($item['options'] as &$opt) {
                    if (is_string($opt)) $opt = $extractImagesToZip($opt);
                }
                unset($opt);
            }
            if (isset($item['premises']) && is_array($item['premises'])) {
                foreach ($item['premises'] as &$prem) {
                    if (is_string($prem)) $prem = $extractImagesToZip($prem);
                    elseif (is_array($prem) && isset($prem['text'])) $prem['text'] = $extractImagesToZip($prem['text']);
                }
                unset($prem);
            }
            if (isset($item['statements']) && is_array($item['statements'])) {
                foreach ($item['statements'] as &$st) {
                    if (is_array($st) && isset($st['text'])) $st['text'] = $extractImagesToZip($st['text']);
                    elseif (is_string($st)) $st = $extractImagesToZip($st);
                }
                unset($st);
            }
            $processedQuestions[] = $item;
        }

        $backupPayload = [
            'app' => 'CBT_UJIAN',
            'type' => 'bank_soal_backup',
            'version' => '1.0',
            'exported_at' => date('Y-m-d H:i:s'),
            'bank_soal' => [
                'id' => $bank_id,
                'name' => $bankName,
                'created_by' => $bank['created_by'] ?? 'Administrator',
                'created_at' => $bank['created_at'] ?? date('Y-m-d H:i:s'),
            ],
            'total_questions' => count($processedQuestions),
            'total_images' => $imgCounter,
            'questions' => $processedQuestions
        ];

        $zip->addFromString('soal.json', json_encode($backupPayload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $zip->close();

        if (file_exists($zipFilePath)) {
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
            header('Content-Length: ' . filesize($zipFilePath));
            header('Pragma: no-cache');
            header('Expires: 0');
            readfile($zipFilePath);
            @unlink($zipFilePath);
            exit;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal menghasilkan berkas ZIP']);
            exit;
        }
    }

    // FORMAT MASSAL / BULK: Setiap bank soal ditempatkan dalam subfolder tersendiri
    $zip = new ZipArchive();
    $zipFileName = 'backup_massal_soal_' . count($bankIds) . 'bank_' . date('Ymd_His') . '.zip';
    $zipFilePath = sys_get_temp_dir() . '/' . uniqid('bulk_soal_backup_') . '.zip';

    if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal membuat file ZIP massal di server']);
        exit;
    }

    $manifestBanks = [];
    $totalAllQuestions = 0;
    $totalAllImages = 0;

    foreach ($bankIds as $bId) {
        if (!check_guru_bank_access($bId)) continue;
        $bInfo = $bankMap[$bId] ?? ['name' => "Bank_Soal_{$bId}", 'id' => $bId];
        $bName = $bInfo['name'] ?? "Bank_Soal_{$bId}";

        $safeFolder = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $bName);
        $safeFolder = trim(preg_replace('/_+/', '_', $safeFolder), '_');
        if (empty($safeFolder)) $safeFolder = "bank_{$bId}";
        $folderPrefix = "bank_{$bId}_{$safeFolder}/";

        $questions = get_questions_db($bId);
        $imgCounter = 0;

        $extractImagesToFolder = function ($html) use ($zip, $folderPrefix, &$imgCounter) {
            if (empty($html) || !is_string($html)) return $html;

            return preg_replace_callback('/<img\b([^>]*?)\bsrc=(["\'])(.*?)\2([^>]*?)>/i', function ($matches) use ($zip, $folderPrefix, &$imgCounter) {
                $prefix = $matches[1];
                $quote = $matches[2];
                $src = trim($matches[3]);
                $suffix = $matches[4];

                if (preg_match('/^data:image\/([a-zA-Z0-9\+\-]+);base64,(.+)$/is', $src, $m)) {
                    $ext = strtolower($m[1]);
                    if ($ext === 'jpeg') $ext = 'jpg';
                    elseif ($ext === 'svg+xml') $ext = 'svg';

                    $binary = base64_decode(str_replace(' ', '+', $m[2]));
                    if ($binary !== false) {
                        $imgCounter++;
                        $zipImgPath = "{$folderPrefix}images/img_{$imgCounter}.{$ext}";
                        $zip->addFromString($zipImgPath, $binary);
                        return "<img{$prefix}src={$quote}images/img_{$imgCounter}.{$ext}{$quote}{$suffix}>";
                    }
                } elseif (!preg_match('/^https?:\/\//i', $src)) {
                    $cleanSrc = ltrim($src, '/\\');
                    $localPath = __DIR__ . '/' . $cleanSrc;
                    if (file_exists($localPath) && is_file($localPath)) {
                        $binary = file_get_contents($localPath);
                        $ext = strtolower(pathinfo($localPath, PATHINFO_EXTENSION));
                        if (empty($ext)) $ext = 'png';
                        $imgCounter++;
                        $zipImgPath = "{$folderPrefix}images/img_{$imgCounter}.{$ext}";
                        $zip->addFromString($zipImgPath, $binary);
                        return "<img{$prefix}src={$quote}images/img_{$imgCounter}.{$ext}{$quote}{$suffix}>";
                    }
                }
                return $matches[0];
            }, $html);
        };

        $processedQuestions = [];
        foreach ($questions as $q) {
            $item = $q;
            if (isset($item['question'])) $item['question'] = $extractImagesToFolder($item['question']);
            if (isset($item['options']) && is_array($item['options'])) {
                foreach ($item['options'] as &$opt) {
                    if (is_string($opt)) $opt = $extractImagesToFolder($opt);
                }
                unset($opt);
            }
            if (isset($item['premises']) && is_array($item['premises'])) {
                foreach ($item['premises'] as &$prem) {
                    if (is_string($prem)) $prem = $extractImagesToFolder($prem);
                    elseif (is_array($prem) && isset($prem['text'])) $prem['text'] = $extractImagesToFolder($prem['text']);
                }
                unset($prem);
            }
            if (isset($item['statements']) && is_array($item['statements'])) {
                foreach ($item['statements'] as &$st) {
                    if (is_array($st) && isset($st['text'])) $st['text'] = $extractImagesToFolder($st['text']);
                    elseif (is_string($st)) $st = $extractImagesToFolder($st);
                }
                unset($st);
            }
            $processedQuestions[] = $item;
        }

        $bPayload = [
            'app' => 'CBT_UJIAN',
            'type' => 'bank_soal_backup',
            'version' => '1.0',
            'exported_at' => date('Y-m-d H:i:s'),
            'bank_soal' => [
                'id' => $bId,
                'name' => $bName,
                'created_by' => $bInfo['created_by'] ?? 'Administrator',
                'created_at' => $bInfo['created_at'] ?? date('Y-m-d H:i:s'),
            ],
            'total_questions' => count($processedQuestions),
            'total_images' => $imgCounter,
            'questions' => $processedQuestions
        ];

        $zip->addFromString("{$folderPrefix}soal.json", json_encode($bPayload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $manifestBanks[] = [
            'id' => $bId,
            'name' => $bName,
            'folder' => rtrim($folderPrefix, '/'),
            'question_count' => count($processedQuestions),
            'image_count' => $imgCounter
        ];

        $totalAllQuestions += count($processedQuestions);
        $totalAllImages += $imgCounter;
    }

    $manifest = [
        'app' => 'CBT_UJIAN',
        'type' => 'bulk_bank_soal_backup',
        'version' => '1.0',
        'exported_at' => date('Y-m-d H:i:s'),
        'total_banks' => count($manifestBanks),
        'total_questions' => $totalAllQuestions,
        'total_images' => $totalAllImages,
        'banks' => $manifestBanks
    ];

    $zip->addFromString('manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $zip->close();

    if (file_exists($zipFilePath)) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
        header('Content-Length: ' . filesize($zipFilePath));
        header('Pragma: no-cache');
        header('Expires: 0');
        readfile($zipFilePath);
        @unlink($zipFilePath);
        exit;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Gagal menghasilkan berkas ZIP massal']);
        exit;
    }
}

if ($action === 'import_bank_soal_zip') {
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        echo json_encode(['status' => 'error', 'message' => 'Sesi berakhir, silakan login kembali']);
        exit;
    }

    // Normalisasi file upload: dukung multiple files (files_zip[]) atau single file (file_zip)
    $uploadedZipList = [];
    if (isset($_FILES['files_zip']) && is_array($_FILES['files_zip']['name'])) {
        for ($k = 0; $k < count($_FILES['files_zip']['name']); $k++) {
            if ($_FILES['files_zip']['error'][$k] === UPLOAD_ERR_OK) {
                $uploadedZipList[] = [
                    'tmp_name' => $_FILES['files_zip']['tmp_name'][$k],
                    'name' => $_FILES['files_zip']['name'][$k]
                ];
            }
        }
    } elseif (isset($_FILES['files_zip']) && !is_array($_FILES['files_zip']['name']) && $_FILES['files_zip']['error'] === UPLOAD_ERR_OK) {
        $uploadedZipList[] = [
            'tmp_name' => $_FILES['files_zip']['tmp_name'],
            'name' => $_FILES['files_zip']['name']
        ];
    } elseif (isset($_FILES['file_zip']) && $_FILES['file_zip']['error'] === UPLOAD_ERR_OK) {
        $uploadedZipList[] = [
            'tmp_name' => $_FILES['file_zip']['tmp_name'],
            'name' => $_FILES['file_zip']['name']
        ];
    }

    if (empty($uploadedZipList)) {
        echo json_encode(['status' => 'error', 'message' => 'Pilih setidaknya satu berkas ZIP untuk diunggah']);
        exit;
    }

    // Kumpulkan seluruh bank soal dari semua berkas ZIP yang diunggah
    $allDiscoveredBanks = [];
    foreach ($uploadedZipList as $uZip) {
        $ext = strtolower(pathinfo($uZip['name'], PATHINFO_EXTENSION));
        if ($ext !== 'zip') continue;

        $banksInZip = parse_all_banks_from_zip($uZip['tmp_name']);
        foreach ($banksInZip as $b) {
            $allDiscoveredBanks[] = $b;
        }
    }

    if (empty($allDiscoveredBanks)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada data bank soal yang berhasil dibaca dari berkas ZIP yang diunggah. Pastikan file ZIP berisi soal.json dan folder gambar yang sesuai.']);
        exit;
    }

    $targetType = $_POST['target_type'] ?? 'new'; // 'new' atau 'existing'
    $importMode = $_POST['import_mode'] ?? 'append'; // 'append' atau 'replace'
    $creatorName = $_SESSION['user_name'] ?? 'Administrator';
    $creatorId = (int)($_SESSION['user_id'] ?? 0);
    $creatorRole = $_SESSION['user_role'] ?? 'admin';

    $importedCount = 0;
    $totalQuestionsImported = 0;
    $lastBankId = 0;
    $lastBankName = '';
    $importedNames = [];

    // Jika HANYA SATU bank soal ditemukan dan user memilih memasukkan ke bank eksisting
    if (count($allDiscoveredBanks) === 1 && $targetType === 'existing') {
        $bankItem = $allDiscoveredBanks[0];
        $targetBankId = (int)($_POST['existing_bank_id'] ?? 0);
        if ($targetBankId <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Pilih bank soal tujuan yang sudah ada']);
            exit;
        }
        if (!check_guru_bank_access($targetBankId)) {
            echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki akses ke Bank Soal ini']);
            exit;
        }

        $banksList = get_bank_soal();
        $targetBankName = "Bank Soal #{$targetBankId}";
        foreach ($banksList as $b) {
            if ((int)$b['id'] === $targetBankId) {
                $targetBankName = $b['name'];
                break;
            }
        }

        if ($importMode === 'replace') {
            save_questions_db($targetBankId, $bankItem['questions']);
            $cnt = count($bankItem['questions']);
            $msg = "Berhasil mengimpor $cnt butir soal ke \"{$targetBankName}\" (Mode: Timpa Semua).";
        } else {
            $existingCount = append_questions_db($targetBankId, $bankItem['questions']);
            $cnt = count($bankItem['questions']);
            $total = $existingCount + $cnt;
            $msg = "Berhasil menambahkan $cnt butir soal ke \"{$targetBankName}\". Total soal: $total.";
        }

        echo json_encode([
            'status' => 'success',
            'message' => $msg,
            'bank_id' => $targetBankId,
            'bank_name' => $targetBankName,
            'question_count' => count($bankItem['questions']),
            'total_banks' => 1
        ]);
        exit;
    }

    // IMPOR MASSAL / BANYAK BANK SOAL (atau single bank dengan target 'new')
    $pdo = get_db_connection();
    $customSingleName = trim($_POST['bank_name'] ?? '');

    foreach ($allDiscoveredBanks as $idx => $bItem) {
        $finalName = '';
        if (count($allDiscoveredBanks) === 1 && !empty($customSingleName)) {
            $finalName = $customSingleName;
        } elseif (!empty($bItem['name'])) {
            $finalName = $bItem['name'];
        } else {
            $finalName = 'Bank Soal Impor ' . ($idx + 1) . ' (' . date('d/m/Y H:i') . ')';
        }

        $stmt = $pdo->prepare("INSERT INTO bank_soal (name, created_by, author_id, author_role, created_at) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$finalName, $creatorName, $creatorId, $creatorRole, date('Y-m-d H:i:s')]);
        $newId = (int)$pdo->lastInsertId();

        save_questions_db($newId, $bItem['questions']);
        $importedCount++;
        $totalQuestionsImported += count($bItem['questions']);
        $lastBankId = $newId;
        $lastBankName = $finalName;
        $importedNames[] = $finalName;
    }

    $msg = count($allDiscoveredBanks) > 1
        ? "Berhasil mengimpor {$importedCount} Bank Soal dengan total {$totalQuestionsImported} butir soal beserta seluruh gambarnya!"
        : "Berhasil membuat Bank Soal \"{$lastBankName}\" dan mengimpor {$totalQuestionsImported} butir soal beserta gambarnya.";

    echo json_encode([
        'status' => 'success',
        'message' => $msg,
        'total_banks' => $importedCount,
        'bank_id' => $lastBankId,
        'bank_name' => $lastBankName,
        'question_count' => $totalQuestionsImported,
        'imported_names' => $importedNames
    ]);
    exit;
}

if ($action === 'upload_questions') {
    // Basic auth check
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Pilih bank soal terlebih dahulu']);
        exit;
    }

    if (!check_guru_bank_access($exam_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki akses ke Bank Soal ini']);
        exit;
    }

    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $errCode = $_FILES['file']['error'] ?? 'tidak ada berkas';
        echo json_encode(['status' => 'error', 'message' => 'Gagal mengunggah file (Kode error: ' . $errCode . ')']);
        exit;
    }

    $fileTmpPath = $_FILES['file']['tmp_name'];
    $fileName = $_FILES['file']['name'];
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    
    $parsed = [];

    if ($fileExtension === 'json') {
        $jsonString = file_get_contents($fileTmpPath);
        // Hapus BOM UTF-8 jika ada
        $jsonString = preg_replace('/^\xEF\xBB\xBF/', '', $jsonString);
        $jsonString = trim($jsonString);

        $decoded = json_decode($jsonString, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            // Toleransi & pemulihan otomatis unescaped LaTeX backslash (misal \frac, \sqrt, \alpha, \times, dll)
            // 1. Ganti \frac, \forall, dll agar tidak terinterpretasi sebagai formfeed JSON (\f)
            $fixCandidate = preg_replace('/(?<!\\\\)\\\\(frac|forall|flat|frown)/i', '\\\\\\\\$1', $jsonString);
            // 2. Ganti backslash tunggal yang bukan escape sequence JSON valid
            $fixCandidate = preg_replace_callback('/(?<!\\\\)\\\\(?!["\\\\\/bfnrtu]|u[0-9a-fA-F]{4})/', function($m) {
                return '\\\\';
            }, $fixCandidate);
            $decoded = json_decode($fixCandidate, true);
        }

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            echo json_encode(['status' => 'error', 'message' => 'Format file JSON tidak valid: ' . json_last_error_msg()]);
            exit;
        }

        // Buka pembungkus jika JSON berbentuk object seperti {"questions": [...]}, {"data": [...]}, {"soal": [...]}
        if (isset($decoded['questions']) && is_array($decoded['questions'])) {
            $decoded = $decoded['questions'];
        } elseif (isset($decoded['data']) && is_array($decoded['data'])) {
            $decoded = $decoded['data'];
        } elseif (isset($decoded['soal']) && is_array($decoded['soal'])) {
            $decoded = $decoded['soal'];
        }

        // Normalisasi format setiap butir soal
        foreach ($decoded as $item) {
            if (!is_array($item)) continue;
            
            $qText = $item['question'] ?? $item['text'] ?? $item['pertanyaan'] ?? '';
            if (empty(trim($qText))) continue;

            $qType = $item['type'] ?? 'multiple_choice';
            $points = isset($item['points']) ? (float)$item['points'] : (isset($item['poin']) ? (float)$item['poin'] : 2.0);

            $normItem = [
                'type' => $qType,
                'question' => $qText,
                'points' => $points
            ];

            if ($qType === 'multiple_choice') {
                $options = $item['options'] ?? $item['pilihan'] ?? [];
                $ans = $item['answer'] ?? $item['jawaban'] ?? $item['kunci'] ?? 0;
                if (is_string($ans) && preg_match('/^[A-E]$/i', trim($ans))) {
                    $ans = ord(strtoupper(trim($ans))) - 65;
                } else {
                    $ans = (int)$ans;
                }
                $normItem['options'] = array_values((array)$options);
                $normItem['answer'] = $ans;
            } elseif ($qType === 'complex_mc') {
                $options = $item['options'] ?? $item['pilihan'] ?? [];
                $ans = $item['answers'] ?? $item['jawaban'] ?? $item['kunci'] ?? [];
                if (!is_array($ans)) $ans = [$ans];
                $normAns = [];
                foreach ($ans as $a) {
                    if (is_string($a) && preg_match('/^[A-E]$/i', trim($a))) {
                        $normAns[] = ord(strtoupper(trim($a))) - 65;
                    } else {
                        $normAns[] = (int)$a;
                    }
                }
                $normItem['options'] = array_values((array)$options);
                $normItem['answers'] = $normAns;
            } elseif ($qType === 'true_false') {
                $normItem['statements'] = $item['statements'] ?? $item['pernyataan'] ?? [];
            } elseif ($qType === 'matching') {
                $normItem['options'] = $item['options'] ?? [];
                $normItem['premises'] = $item['premises'] ?? [];
                $normItem['pairs'] = $item['pairs'] ?? [];
            } else {
                $normItem['options'] = array_values((array)($item['options'] ?? []));
                $normItem['answer'] = (int)($item['answer'] ?? 0);
            }

            $parsed[] = $normItem;
        }

    } elseif ($fileExtension === 'docx') {
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($fileTmpPath) === true) {
                $mediaMap = [];
                $relsXml = $zip->getFromName('word/_rels/document.xml.rels');
                if ($relsXml) {
                    libxml_use_internal_errors(true);
                    $relDom = new DOMDocument();
                    $relDom->loadXML($relsXml);
                    libxml_clear_errors();
                    $relationships = $relDom->getElementsByTagName('Relationship');
                    foreach ($relationships as $rel) {
                        $rId = $rel->getAttribute('Id');
                        $target = $rel->getAttribute('Target');
                        $type = $rel->getAttribute('Type');
                        if (stripos($type, 'image') !== false || preg_match('/\.(png|jpe?g|gif|webp|bmp|svg)$/i', $target)) {
                            $cleanTarget = ltrim($target, '/');
                            $zipTarget = (stripos($cleanTarget, 'word/') === 0) ? $cleanTarget : ('word/' . $cleanTarget);
                            $rawBin = $zip->getFromName($zipTarget);
                            if ($rawBin !== false && strlen($rawBin) > 0) {
                                $ext = strtolower(pathinfo($cleanTarget, PATHINFO_EXTENSION));
                                if ($ext === 'svg') {
                                    $mediaMap[$rId] = 'data:image/svg+xml;base64,' . base64_encode($rawBin);
                                } else {
                                    $webpBin = convert_image_binary_to_webp($rawBin, 80);
                                    $mediaMap[$rId] = 'data:image/webp;base64,' . base64_encode($webpBin);
                                }
                            }
                        }
                    }
                }
                $xml = $zip->getFromName('word/document.xml');
                $zip->close();
                if ($xml) {
                    $parsed = parse_docx_xml_questions($xml, $mediaMap);
                }
            }
        }
        if (empty($parsed)) {
            echo json_encode(['status' => 'error', 'message' => 'Gagal membaca dokumen Word (.docx). Pastikan format tabel atau penomoran soal sesuai template.']);
            exit;
        }
    } elseif ($fileExtension === 'doc') {
        $docHtml = file_get_contents($fileTmpPath);
        if (substr($docHtml, 0, 2) === "\xff\xfe") {
            $docHtml = mb_convert_encoding(substr($docHtml, 2), 'UTF-8', 'UTF-16LE');
        } elseif (substr($docHtml, 0, 2) === "\xfe\xff") {
            $docHtml = mb_convert_encoding(substr($docHtml, 2), 'UTF-8', 'UTF-16BE');
        }
        // DEBUG: Save incoming file for inspection
        $debugPath = __DIR__ . '/debug_last_upload.doc';
        file_put_contents($debugPath, $docHtml);
        
        $parsed = parse_html_doc_questions($docHtml);
        
        // DEBUG LOG
        $debugLog = [
            'timestamp' => date('Y-m-d H:i:s'),
            'file_size' => strlen($docHtml),
            'file_name' => $fileName,
            'parsed_count' => count($parsed),
            'types' => array_count_values(array_column($parsed, 'type')),
        ];
        file_put_contents(__DIR__ . '/debug_upload_log.json', json_encode($debugLog, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        if (empty($parsed)) {
            echo json_encode(['status' => 'error', 'message' => 'Gagal membaca format dokumen Word (.doc). Pastikan format soal sesuai template.']);
            exit;
        }

    } elseif ($fileExtension === 'zip') {
        $zipBankInfo = [];
        $parsed = parse_questions_from_zip($fileTmpPath, $zipBankInfo);
        if (empty($parsed)) {
            echo json_encode(['status' => 'error', 'message' => 'Gagal membaca butir soal dari berkas ZIP. Pastikan file ZIP berisi soal.json dan folder gambar yang valid.']);
            exit;
        }

    } else {
        echo json_encode(['status' => 'error', 'message' => 'Format berkas tidak didukung. Harap gunakan format .json, .docx, .doc, atau .zip']);
        exit;
    }

    if (empty($parsed)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada butir soal yang berhasil diekstrak dari file']);
        exit;
    }

    // Simpan ke MySQL dan sync ke file lokal JSON
    // Mode: append (tambahkan) atau replace (timpa semua)
    $importMode = $_POST['import_mode'] ?? 'append';
    
    if ($importMode === 'replace') {
        save_questions_db($exam_id, $parsed);
        $recalculated = recalculate_bank_results($exam_id);
        $cnt = count($parsed);
        $msg = "Berhasil mengimpor $cnt butir soal (mode: Timpa Semua).";
        if ($recalculated > 0) {
            $msg .= " Nilai $recalculated siswa telah otomatis dihitung ulang!";
        }
    } else {
        // Default: append — tambahkan tanpa hapus soal lama
        $existingCount = append_questions_db($exam_id, $parsed);
        $recalculated = recalculate_bank_results($exam_id);
        $cnt = count($parsed);
        $total = $existingCount + $cnt;
        $msg = "Berhasil menambahkan $cnt butir soal baru. Total soal sekarang: $total.";
        if ($recalculated > 0) {
            $msg .= " Nilai $recalculated siswa telah otomatis dihitung ulang!";
        }
    }
    echo json_encode(['status' => 'success', 'message' => $msg]);
    exit;
}

if ($action === 'optimize_bank_images_webp') {
    $bank_id = (int)($_POST['bank_id'] ?? $_GET['bank_id'] ?? 0);
    if ($bank_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Bank Soal tidak valid']);
        exit;
    }
    if (!check_guru_bank_access($bank_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }

    $questions = get_questions_db($bank_id);
    if (empty($questions)) {
        echo json_encode(['status' => 'error', 'message' => 'Bank Soal tidak memiliki butir soal']);
        exit;
    }

    $convertedCount = 0;
    $questions = optimize_questions_images_to_webp($questions, 80, $convertedCount);
    save_questions_db($bank_id, $questions);

    $msg = "Optimasi gambar selesai! ";
    if ($convertedCount > 0) {
        $msg .= "Sebanyak {$convertedCount} gambar berhasil dikonversi ke format .webp sehingga bank soal kini jauh lebih ringan.";
    } else {
        $msg .= "Seluruh gambar pada bank soal ini sudah dalam format .webp berdaya kompresi optimal.";
    }

    echo json_encode([
        'status' => 'success',
        'message' => $msg,
        'converted_count' => $convertedCount
    ]);
    exit;
}

if ($action === 'delete_question_item') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $index = (int)($_POST['index'] ?? -1);
    
    if ($exam_id <= 0 || $index < 0) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid']);
        exit;
    }
    
    $data = get_questions_db($exam_id);
    if (isset($data[$index])) {
        array_splice($data, $index, 1);
        save_questions_db($exam_id, $data);
        recalculate_bank_results($exam_id);
        echo json_encode(['status' => 'success', 'message' => 'Soal berhasil dihapus']);
        exit;
    }
    echo json_encode(['status' => 'error', 'message' => 'Soal tidak ditemukan']);
    exit;
}

if ($action === 'delete_bulk_soal') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $indices_raw = $_POST['indices'] ?? '[]';
    $indices = json_decode($indices_raw, true) ?: [];

    if ($exam_id <= 0 || empty($indices)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid']);
        exit;
    }

    if (!check_guru_bank_access($exam_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }

    $data = get_questions_db($exam_id);
    if (!empty($data)) {
        rsort($indices); // Sort descending so removing items won't corrupt preceding indices
        $deleted = 0;
        foreach ($indices as $idx) {
            $idx = (int)$idx;
            if (isset($data[$idx])) {
                array_splice($data, $idx, 1);
                $deleted++;
            }
        }
        save_questions_db($exam_id, array_values($data));
        recalculate_bank_results($exam_id);
        echo json_encode(['status' => 'success', 'message' => "$deleted soal terpilih berhasil dihapus"]);
        exit;
    }
    echo json_encode(['status' => 'error', 'message' => 'Berkas soal tidak ditemukan']);
    exit;
}

if ($action === 'edit_question_item') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $index = (int)($_POST['index'] ?? -1);
    $type = $_POST['type'] ?? 'multiple_choice';
    $question_text = $_POST['question'] ?? '';
    $answer = (int)($_POST['answer'] ?? 0);
    
    if ($exam_id <= 0 || $index < 0 || empty(trim($question_text))) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
        exit;
    }

    if (!check_guru_bank_access($exam_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }
    
    // Process options array
    $options = [];
    $opt_idx = 0;
    while (isset($_POST["option_{$opt_idx}"])) {
        $options[] = $_POST["option_{$opt_idx}"];
        $opt_idx++;
    }
    if ($type === 'multiple_choice' || $type === 'complex_mc') {
        $options = trim_trailing_empty_options($options);
        if ($answer >= count($options)) {
            $answer = max(0, count($options) - 1);
        }
    }
    
    if (($type === 'multiple_choice' || $type === 'complex_mc') && count($options) < 2) {
        echo json_encode(['status' => 'error', 'message' => 'Minimal harus ada 2 pilihan jawaban']);
        exit;
    }

    // Process complex_mc answers
    $complex_answers = [];
    if ($type === 'complex_mc') {
        $ans_raw = $_POST['answers'] ?? '[]';
        $complex_answers = is_array($ans_raw) ? $ans_raw : (json_decode($ans_raw, true) ?: []);
        $complex_answers = array_map('intval', $complex_answers);
        if (empty($complex_answers)) {
            echo json_encode(['status' => 'error', 'message' => 'Pilih minimal 1 kunci jawaban benar']);
            exit;
        }
    }

    // Process true_false statements
    $statements = [];
    if ($type === 'true_false') {
        $stmts_raw = $_POST['statements'] ?? '[]';
        $statements = is_array($stmts_raw) ? $stmts_raw : (json_decode($stmts_raw, true) ?: []);
        if (empty($statements)) {
            echo json_encode(['status' => 'error', 'message' => 'Minimal harus ada 1 baris pernyataan']);
            exit;
        }
    }

    // Process matching premises, options, pairs
    $matching_options = [];
    $matching_premises = [];
    $matching_pairs = [];
    if ($type === 'matching') {
        $opts_raw = $_POST['options'] ?? '[]';
        $matching_options = is_array($opts_raw) ? $opts_raw : (json_decode($opts_raw, true) ?: []);
        $premises_raw = $_POST['premises'] ?? '[]';
        $matching_premises = is_array($premises_raw) ? $premises_raw : (json_decode($premises_raw, true) ?: []);
        $pairs_raw = $_POST['pairs'] ?? '{}';
        $matching_pairs = is_array($pairs_raw) ? $pairs_raw : (json_decode($pairs_raw, true) ?: []);
        if (count($matching_options) < 2 || count($matching_premises) < 1) {
            echo json_encode(['status' => 'error', 'message' => 'Soal menjodohkan harus memiliki minimal 2 opsi dan 1 baris pernyataan']);
            exit;
        }
    }
    
    $points = isset($_POST['points']) ? (float)$_POST['points'] : 2;
    
    $data = get_questions_db($exam_id);
    if (isset($data[$index])) {
        $data[$index] = [
            'type' => $type,
            'question' => $question_text,
            'points' => $points
        ];
        if ($type === 'multiple_choice') {
            $data[$index]['options'] = $options;
            $data[$index]['answer'] = $answer;
        } elseif ($type === 'complex_mc') {
            $data[$index]['options'] = $options;
            $data[$index]['answers'] = $complex_answers;
        } elseif ($type === 'true_false') {
            $data[$index]['statements'] = $statements;
        } elseif ($type === 'matching') {
            $data[$index]['options'] = $matching_options;
            $data[$index]['premises'] = $matching_premises;
            $data[$index]['pairs'] = $matching_pairs;
        }
        
        save_questions_db($exam_id, $data);
        $recalculated = recalculate_bank_results($exam_id);
        $msg = 'Soal berhasil diperbarui.';
        if ($recalculated > 0) {
            $msg .= " Kunci jawaban baru diterapkan & nilai {$recalculated} siswa otomatis dihitung ulang!";
        }
        echo json_encode(['status' => 'success', 'message' => $msg, 'recalculated' => $recalculated]);
        exit;
    }
    echo json_encode(['status' => 'error', 'message' => 'Soal tidak ditemukan']);
    exit;
}

if ($action === 'recalculate_scores') {
    $bank_id = (int)($_POST['bank_id'] ?? ($_GET['bank_id'] ?? 0));
    $exam_id = (int)($_POST['exam_id'] ?? ($_GET['exam_id'] ?? 0));
    
    if ($bank_id <= 0 && $exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID Bank Soal atau ID Ujian tidak valid']);
        exit;
    }
    
    if ($bank_id > 0) {
        if (!check_guru_bank_access($bank_id)) {
            echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengakses bank soal ini']);
            exit;
        }
        $count = recalculate_bank_results($bank_id);
    } else {
        $count = recalculate_exam_results($exam_id);
    }
    
    echo json_encode([
        'status' => 'success',
        'message' => "Berhasil menghitung ulang nilai siswa berdasarkan kunci jawaban terbaru ($count data nilai siswa diperbarui).",
        'updated_count' => $count
    ]);
    exit;
}

if ($action === 'auto_set_points') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID Bank Soal tidak valid']);
        exit;
    }
    if (!check_guru_bank_access($exam_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }
    $questions = get_questions_db($exam_id);
    $count = count($questions);
    if ($count === 0) {
        echo json_encode(['status' => 'error', 'message' => 'Bank soal masih kosong']);
        exit;
    }
    $pointPerQ = round(100 / $count, 2);
    foreach ($questions as &$q) {
        $q['points'] = $pointPerQ;
    }
    unset($q);
    save_questions_db($exam_id, $questions);
    $recalculated = recalculate_bank_results($exam_id);
    $msg = "Poin seluruh soal berhasil diset ke $pointPerQ (Total: 100).";
    if ($recalculated > 0) {
        $msg .= " Nilai $recalculated siswa telah otomatis dihitung ulang!";
    }
    echo json_encode(['status' => 'success', 'message' => $msg, 'recalculated' => $recalculated]);
    exit;
}

if ($action === 'import_kunci_jawaban') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $keys_raw = $_POST['keys_data'] ?? '[]';
    $auto_recalc = filter_var($_POST['auto_recalculate'] ?? true, FILTER_VALIDATE_BOOLEAN);

    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID Bank Soal tidak valid']);
        exit;
    }

    if (!check_guru_bank_access($exam_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }

    $keys_data = is_array($keys_raw) ? $keys_raw : (json_decode($keys_raw, true) ?: []);
    if (empty($keys_data)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada data kunci jawaban yang ditemukan pada file Excel']);
        exit;
    }

    $questions = get_questions_db($exam_id);
    if (empty($questions)) {
        echo json_encode(['status' => 'error', 'message' => 'Bank soal masih kosong. Silakan buat atau impor butir soal terlebih dahulu sebelum mengatur kunci jawaban.']);
        exit;
    }

    $normalize_opt = function($val) {
        if ($val === null || $val === '') return null;
        $valStr = trim((string)$val);
        if (is_numeric($valStr)) return (int)$valStr;
        $upper = strtoupper($valStr);
        if (strlen($upper) === 1 && $upper >= 'A' && $upper <= 'Z') {
            return ord($upper) - 65;
        }
        return $valStr;
    };

    $updated_count = 0;

    foreach ($keys_data as $row) {
        // Ambil No Soal (1-based index)
        $no_soal = null;
        foreach (['no_soal', 'no', 'nomor', 'No Soal', 'No', 'Nomor'] as $k) {
            if (isset($row[$k]) && is_numeric($row[$k])) {
                $no_soal = (int)$row[$k];
                break;
            }
        }
        if ($no_soal === null || $no_soal < 1) continue;

        $q_idx = $no_soal - 1;
        if (!isset($questions[$q_idx])) continue;

        $q = &$questions[$q_idx];
        $type = $q['type'] ?? 'multiple_choice';

        // Update poin jika diisi angka positif
        $point_val = null;
        foreach (['points', 'poin', 'bobot', 'Bobot Poin', 'Poin', 'Bobot'] as $pk) {
            if (isset($row[$pk]) && is_numeric($row[$pk])) {
                $point_val = (float)$row[$pk];
                break;
            }
        }
        if ($point_val !== null && $point_val > 0) {
            $q['points'] = round($point_val, 2);
        }

        // Ambil isi kunci jawaban
        $key_val = null;
        foreach (['kunci', 'kunci_jawaban', 'jawaban', 'Kunci Jawaban', 'Kunci', 'Jawaban', 'kunci_jawaban_benar'] as $kk) {
            if (isset($row[$kk]) && trim((string)$row[$kk]) !== '') {
                $key_val = trim((string)$row[$kk]);
                break;
            }
        }
        if ($key_val === null || $key_val === '') continue;

        $is_modified = false;

        if ($type === 'multiple_choice') {
            $optIdx = $normalize_opt($key_val);
            if ($optIdx !== null && is_int($optIdx)) {
                $q['answer'] = $optIdx;
                $is_modified = true;
            }
        } elseif ($type === 'complex_mc') {
            $parts = preg_split('/[,;\s]+/', $key_val, -1, PREG_SPLIT_NO_EMPTY);
            $parsed_answers = [];
            foreach ($parts as $p) {
                $idx = $normalize_opt($p);
                if ($idx !== null && is_int($idx) && !in_array($idx, $parsed_answers)) {
                    $parsed_answers[] = $idx;
                }
            }
            if (!empty($parsed_answers)) {
                sort($parsed_answers);
                $q['answers'] = $parsed_answers;
                $is_modified = true;
            }
        } elseif ($type === 'true_false') {
            $parts = preg_split('/[,;\-\s]+/', $key_val, -1, PREG_SPLIT_NO_EMPTY);
            if (!empty($q['statements']) && is_array($q['statements'])) {
                foreach ($q['statements'] as $s_idx => &$stmt) {
                    if (isset($parts[$s_idx])) {
                        $pVal = strtolower(trim($parts[$s_idx]));
                        $stmt['answer'] = ($pVal === 'b' || $pVal === 'benar' || $pVal === 'true' || $pVal === '1');
                    }
                }
                unset($stmt);
                $is_modified = true;
            }
        } elseif ($type === 'matching') {
            $parts = preg_split('/[,;\s]+/', $key_val, -1, PREG_SPLIT_NO_EMPTY);
            if (!empty($q['premises']) && is_array($q['premises'])) {
                $pairs = [];
                foreach ($q['premises'] as $p_idx => $premise) {
                    if (isset($parts[$p_idx])) {
                        $pVal = $parts[$p_idx];
                        if (strpos($pVal, '-') !== false) {
                            $splitP = explode('-', $pVal);
                            $pVal = end($splitP);
                        }
                        $targetOpt = $normalize_opt($pVal);
                        if ($targetOpt !== null && is_int($targetOpt)) {
                            $pairs[$p_idx] = $targetOpt;
                        }
                    }
                }
                if (!empty($pairs)) {
                    $q['pairs'] = $pairs;
                    $is_modified = true;
                }
            }
        }

        if ($is_modified) {
            $updated_count++;
        }
        unset($q);
    }

    if ($updated_count > 0) {
        save_questions_db($exam_id, $questions);
        
        $recalculated = 0;
        if ($auto_recalc) {
            $recalculated = recalculate_bank_results($exam_id);
        }

        $msg = "Kunci jawaban untuk $updated_count butir soal berhasil diperbarui!";
        if ($recalculated > 0) {
            $msg .= " Nilai $recalculated siswa telah otomatis dihitung ulang.";
        }

        echo json_encode([
            'status' => 'success',
            'message' => $msg,
            'updated_questions' => $updated_count,
            'updated_students' => $recalculated
        ]);
        exit;
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Tidak ada kunci jawaban yang cocok atau berhasil diperbarui dari berkas Excel. Pastikan format kolom nomor dan kunci sudah sesuai.'
        ]);
        exit;
    }
}
if ($action === 'delete_student') {
    $id = (int)($_POST['id'] ?? 0);
    $students = get_students();
    $initialCount = count($students);
    
    $students = array_filter($students, function($s) use ($id) {
        return $s['id'] != $id;
    });
    
    if (count($students) < $initialCount) {
        save_students(array_values($students));
        echo json_encode(['status' => 'success', 'message' => 'Siswa berhasil dihapus']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Siswa tidak ditemukan']);
    }
    exit;
}

if ($action === 'bulk_delete_students') {
    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];
    
    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada siswa yang dipilih']);
        exit;
    }
    
    $students = get_students();
    $initialCount = count($students);
    
    $students = array_filter($students, function($s) use ($ids) {
        return !in_array($s['id'], $ids);
    });
    
    if (count($students) < $initialCount) {
        save_students(array_values($students));
        echo json_encode(['status' => 'success', 'message' => 'Siswa terpilih berhasil dihapus']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Siswa tidak ditemukan']);
    }
    exit;
}

if ($action === 'bulk_reset_logins') {
    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];
    
    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada siswa yang dipilih']);
        exit;
    }
    
    $sessions = get_sessions();
    $found = false;
    foreach ($sessions as &$s) {
        if (in_array($s['student_id'], $ids)) {
            $s['is_reset'] = true;
            $found = true;
        }
    }
    
    if ($found) {
        save_sessions($sessions);
        echo json_encode(['status' => 'success', 'message' => 'Sesi login terpilih berhasil direset.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada sesi aktif yang ditemukan dari siswa terpilih.']);
    }
    exit;
}

if ($action === 'set_all_passwords') {
    $mode = trim($_POST['mode'] ?? 'same'); // 'same' or 'random'
    $scope = trim($_POST['scope'] ?? 'all'); // 'all' or 'selected'
    $pdo = get_db_connection();

    $targetIds = [];
    if ($scope === 'selected' && !empty($_POST['ids'])) {
        $rawIds = is_array($_POST['ids']) ? $_POST['ids'] : json_decode($_POST['ids'], true);
        if (is_array($rawIds)) {
            $targetIds = array_map('intval', $rawIds);
        }
    }

    if ($mode === 'random') {
        // Mode 2: Buat password random 6 karakter angka semua
        if (empty($targetIds)) {
            $targetIds = $pdo->query("SELECT id FROM students")->fetchAll(PDO::FETCH_COLUMN);
        }

        if (empty($targetIds)) {
            echo json_encode(['status' => 'error', 'message' => 'Tidak ada data siswa yang ditemukan']);
            exit;
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("UPDATE students SET password = ? WHERE id = ?");
            foreach ($targetIds as $sid) {
                $randPwd = sprintf('%06d', random_int(0, 999999));
                $stmt->execute([$randPwd, (int)$sid]);
            }
            $pdo->commit();
            $count = count($targetIds);
            $targetDesc = ($scope === 'selected') ? "{$count} siswa terpilih" : "semua siswa ({$count} siswa)";
            echo json_encode(['status' => 'success', 'message' => "Password random 6 angka berhasil digenerate untuk {$targetDesc}."]);
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['status' => 'error', 'message' => 'Gagal membuat password acak: ' . $e->getMessage()]);
            exit;
        }
    } else {
        // Mode 1: Buat password sama semua
        $password = trim($_POST['password'] ?? '');
        if (empty($password)) {
            echo json_encode(['status' => 'error', 'message' => 'Password tidak boleh kosong']);
            exit;
        }

        if (!empty($targetIds)) {
            $placeholders = implode(',', array_fill(0, count($targetIds), '?'));
            $params = array_merge([$password], $targetIds);
            $stmt = $pdo->prepare("UPDATE students SET password = ? WHERE id IN ($placeholders)");
            $stmt->execute($params);
            $count = count($targetIds);
            echo json_encode(['status' => 'success', 'message' => "Password berhasil diterapkan ke {$count} siswa terpilih."]);
            exit;
        } else {
            $stmt = $pdo->prepare("UPDATE students SET password = ?");
            $stmt->execute([$password]);
            echo json_encode(['status' => 'success', 'message' => 'Password berhasil diterapkan ke semua siswa.']);
            exit;
        }
    }
}

if ($action === 'delete_class') {
    $id = (int)($_POST['id'] ?? 0);
    $classes = get_classes();
    $initialCount = count($classes);
    
    $classes = array_filter($classes, function($c) use ($id) {
        return $c['id'] != $id;
    });
    
    if (count($classes) < $initialCount) {
        save_classes(array_values($classes));
        echo json_encode(['status' => 'success', 'message' => 'Kelas berhasil dihapus']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Kelas tidak ditemukan']);
    }
    exit;
}

if ($action === 'delete_mata_pelajaran') {
    if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in'] || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya administrator yang memiliki izin menghapus mata pelajaran.']);
        exit;
    }

    $id = (int)($_POST['id'] ?? 0);
    $pdo = get_db_connection();
    try {
        $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('mata_pelajaran_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
    } catch (Exception $e) {}

    $stmt = $pdo->prepare("DELETE FROM mata_pelajaran WHERE id = ?");
    $stmt->execute([$id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Mata pelajaran berhasil dihapus']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Mata pelajaran tidak ditemukan atau sudah dihapus']);
    }
    exit;
}

if ($action === 'bulk_delete_mata_pelajaran') {
    if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in'] || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya administrator yang memiliki izin menghapus mata pelajaran.']);
        exit;
    }

    $ids_raw = $_POST['ids'] ?? '[]';
    $ids = json_decode($ids_raw, true) ?: [];
    $ids = array_filter(array_map('intval', (array)$ids));

    if (empty($ids)) {
        echo json_encode(['status' => 'error', 'message' => 'Tidak ada mata pelajaran yang dipilih.']);
        exit;
    }

    $pdo = get_db_connection();
    try {
        $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES ('mata_pelajaran_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
    } catch (Exception $e) {}

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("DELETE FROM mata_pelajaran WHERE id IN ($placeholders)");
    $stmt->execute(array_values($ids));
    $deletedCount = $stmt->rowCount();

    if ($deletedCount > 0) {
        echo json_encode([
            'status' => 'success',
            'message' => "$deletedCount mata pelajaran terpilih berhasil dihapus.",
            'deleted_count' => $deletedCount
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Mata pelajaran tidak ditemukan atau sudah dihapus.']);
    }
    exit;
}

if ($action === 'import_mapel_batch') {
    if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in'] || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya administrator yang memiliki izin mengimpor mata pelajaran.']);
        exit;
    }

    $mapels_json = $_POST['mapels'] ?? '[]';
    $import_data = json_decode($mapels_json, true);

    if (!is_array($import_data) || empty($import_data)) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak valid atau kosong.']);
        exit;
    }

    $existing_list = get_mapel_list();
    $existing_names = [];
    $existing_codes = [];
    foreach ($existing_list as $m) {
        $existing_names[strtolower(trim($m['name']))] = true;
        if (!empty($m['code'])) {
            $existing_codes[strtoupper(trim($m['code']))] = true;
        }
    }

    $pdo = get_db_connection();
    $stmt = $pdo->prepare("INSERT INTO mata_pelajaran (code, name) VALUES (?, ?)");

    $added = 0;
    $skipped = 0;

    foreach ($import_data as $row) {
        $name = trim($row['name'] ?? '');
        $code = strtoupper(trim($row['code'] ?? ''));

        if (empty($name)) {
            continue;
        }

        // Jika kode kosong, generate dari nama
        if (empty($code)) {
            $words = preg_split('/\s+/', $name);
            if (count($words) >= 3) {
                $code = strtoupper(substr($words[0], 0, 1) . substr($words[1], 0, 1) . substr($words[2], 0, 1));
            } else {
                $clean = preg_replace('/[^a-zA-Z0-9]/', '', $name);
                $code = strtoupper(substr($clean, 0, 3));
            }
        }

        $name_key = strtolower($name);
        if (isset($existing_names[$name_key])) {
            $skipped++;
            continue;
        }

        try {
            $stmt->execute([$code, $name]);
            $existing_names[$name_key] = true;
            $existing_codes[$code] = true;
            $added++;
        } catch (Exception $e) {
            $skipped++;
        }
    }

    $msg = "Berhasil mengimpor {$added} mata pelajaran.";
    if ($skipped > 0) {
        $msg .= " ({$skipped} mata pelajaran dilewati karena sudah terdaftar).";
    }

    echo json_encode([
        'status' => 'success',
        'message' => $msg,
        'added' => $added,
        'skipped' => $skipped
    ]);
    exit;
}

if ($action === 'delete_jenis_ujian') {
    $id = (int)($_POST['id'] ?? 0);
    $jenis = get_jenis_ujian_list();
    $initialCount = count($jenis);
    
    $jenis = array_filter($jenis, function($j) use ($id) {
        return $j['id'] != $id;
    });
    
    if (count($jenis) < $initialCount) {
        save_jenis_ujian_list(array_values($jenis));
        echo json_encode(['status' => 'success', 'message' => 'Jenis ujian berhasil dihapus']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Jenis ujian tidak ditemukan']);
    }
    exit;
}

if ($action === 'add_question_item') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $type = $_POST['type'] ?? 'multiple_choice';
    $question_text = $_POST['question'] ?? '';
    $answer = (int)($_POST['answer'] ?? 0);
    
    if ($exam_id <= 0 || empty(trim($question_text))) {
        echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
        exit;
    }

    if (!check_guru_bank_access($exam_id)) {
        echo json_encode(['status' => 'error', 'message' => 'Anda tidak memiliki izin mengubah bank soal ini']);
        exit;
    }
    
    // Process options array
    $options = [];
    $opt_idx = 0;
    while (isset($_POST["option_{$opt_idx}"])) {
        $options[] = $_POST["option_{$opt_idx}"];
        $opt_idx++;
    }
    if ($type === 'multiple_choice' || $type === 'complex_mc') {
        $options = trim_trailing_empty_options($options);
        if ($answer >= count($options)) {
            $answer = max(0, count($options) - 1);
        }
    }
    
    if (($type === 'multiple_choice' || $type === 'complex_mc') && count($options) < 2) {
        echo json_encode(['status' => 'error', 'message' => 'Minimal harus ada 2 pilihan jawaban']);
        exit;
    }

    // Process complex_mc answers
    $complex_answers = [];
    if ($type === 'complex_mc') {
        $ans_raw = $_POST['answers'] ?? '[]';
        $complex_answers = is_array($ans_raw) ? $ans_raw : (json_decode($ans_raw, true) ?: []);
        $complex_answers = array_map('intval', $complex_answers);
        if (empty($complex_answers)) {
            echo json_encode(['status' => 'error', 'message' => 'Pilih minimal 1 kunci jawaban benar']);
            exit;
        }
    }

    // Process true_false statements
    $statements = [];
    if ($type === 'true_false') {
        $stmts_raw = $_POST['statements'] ?? '[]';
        $statements = is_array($stmts_raw) ? $stmts_raw : (json_decode($stmts_raw, true) ?: []);
        if (empty($statements)) {
            echo json_encode(['status' => 'error', 'message' => 'Minimal harus ada 1 baris pernyataan']);
            exit;
        }
    }

    // Process matching premises, options, pairs
    $matching_options = [];
    $matching_premises = [];
    $matching_pairs = [];
    if ($type === 'matching') {
        $opts_raw = $_POST['options'] ?? '[]';
        $matching_options = is_array($opts_raw) ? $opts_raw : (json_decode($opts_raw, true) ?: []);
        $premises_raw = $_POST['premises'] ?? '[]';
        $matching_premises = is_array($premises_raw) ? $premises_raw : (json_decode($premises_raw, true) ?: []);
        $pairs_raw = $_POST['pairs'] ?? '{}';
        $matching_pairs = is_array($pairs_raw) ? $pairs_raw : (json_decode($pairs_raw, true) ?: []);
        if (count($matching_options) < 2 || count($matching_premises) < 1) {
            echo json_encode(['status' => 'error', 'message' => 'Soal menjodohkan harus memiliki minimal 2 opsi dan 1 baris pernyataan']);
            exit;
        }
    }
    
    $points = isset($_POST['points']) ? (float)$_POST['points'] : 2;
    
    $data = get_questions_db($exam_id);
    
    $new_q = [
        'type' => $type,
        'question' => $question_text,
        'points' => $points
    ];
    if ($type === 'multiple_choice') {
        $new_q['options'] = $options;
        $new_q['answer'] = $answer;
    } elseif ($type === 'complex_mc') {
        $new_q['options'] = $options;
        $new_q['answers'] = $complex_answers;
    } elseif ($type === 'true_false') {
        $new_q['statements'] = $statements;
    } elseif ($type === 'matching') {
        $new_q['options'] = $matching_options;
        $new_q['premises'] = $matching_premises;
        $new_q['pairs'] = $matching_pairs;
    }
    
    $data[] = $new_q;
    
    save_questions_db($exam_id, $data);
    echo json_encode(['status' => 'success', 'message' => 'Soal berhasil ditambahkan']);
    exit;
}

if ($action === 'auto_set_points') {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $max_score = 100;
    
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Pilih mata pelajaran terlebih dahulu']);
        exit;
    }
    
    $data = get_questions_db($exam_id);
    if (!empty($data)) {
        $point_per_question = $max_score / count($data);
        foreach ($data as &$q) {
            $q['points'] = $point_per_question;
        }
        save_questions_db($exam_id, $data);
        echo json_encode(['status' => 'success', 'message' => 'Poin otomatis berhasil diset untuk semua soal']);
        exit;
    }
    echo json_encode(['status' => 'error', 'message' => 'Tidak ada soal untuk mata pelajaran ini']);
    exit;
}

if ($action === 'backup_database') {
    $pdo = get_db_connection();
    $tables = ['classes', 'students', 'users', 'bank_soal', 'questions', 'exams', 'exam_sessions', 'exam_results', 'settings'];
    
    $sqlDump = "-- CBT Ujian MySQL Backup\n";
    $sqlDump .= "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
    $sqlDump .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
    
    foreach ($tables as $t) {
        $createStmt = $pdo->query("SHOW CREATE TABLE `{$t}`")->fetch(PDO::FETCH_ASSOC);
        $sqlDump .= "DROP TABLE IF EXISTS `{$t}`;\n";
        $sqlDump .= $createStmt['Create Table'] . ";\n\n";
        
        $rows = $pdo->query("SELECT * FROM `{$t}`")->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($rows)) {
            $cols = array_keys($rows[0]);
            $colNames = implode('`, `', $cols);
            foreach ($rows as $row) {
                $vals = [];
                foreach ($row as $val) {
                    if ($val === null) {
                        $vals[] = "NULL";
                    } else {
                        $vals[] = $pdo->quote($val);
                    }
                }
                $sqlDump .= "INSERT INTO `{$t}` (`{$colNames}`) VALUES (" . implode(', ', $vals) . ");\n";
            }
            $sqlDump .= "\n";
        }
    }
    $sqlDump .= "SET FOREIGN_KEY_CHECKS=1;\n";
    
    $zip = new ZipArchive();
    $zipFileName = 'backup_cbt_mysql_' . date('Y-m-d_H-i-s') . '.zip';
    $zipFilePath = sys_get_temp_dir() . '/' . $zipFileName;
    
    if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal membuat file zip']);
        exit;
    }
    
    $zip->addFromString('backup_cbt.sql', $sqlDump);
    $zip->close();
    
    if (file_exists($zipFilePath)) {
        header('Content-Type: application/zip');
        header('Content-disposition: attachment; filename=' . $zipFileName);
        header('Content-Length: ' . filesize($zipFilePath));
        readfile($zipFilePath);
        unlink($zipFilePath);
        exit;
    }
    
    echo json_encode(['status' => 'error', 'message' => 'Gagal mengunduh file zip']);
    exit;
}

if ($action === 'restore_database') {
    if (!isset($_FILES['file_zip'])) {
        echo json_encode(['status' => 'error', 'message' => 'File tidak ditemukan']);
        exit;
    }
    
    $file = $_FILES['file_zip'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'Upload error']);
        exit;
    }
    
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    if (strtolower($ext) !== 'zip') {
        echo json_encode(['status' => 'error', 'message' => 'Format file harus .zip']);
        exit;
    }
    
    $zip = new ZipArchive();
    if ($zip->open($file['tmp_name']) === true) {
        $pdo = get_db_connection();
        $sqlContent = null;
        
        // Check for .sql file inside zip
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entryName = $zip->getNameIndex($i);
            if (preg_match('/\.sql$/i', $entryName)) {
                $sqlContent = $zip->getFromIndex($i);
                break;
            }
        }
        
        if ($sqlContent !== null) {
            try {
                $pdo->exec($sqlContent);
                $zip->close();
                echo json_encode(['status' => 'success', 'message' => 'Database MySQL berhasil direstore']);
                exit;
            } catch (Exception $e) {
                $zip->close();
                echo json_encode(['status' => 'error', 'message' => 'Gagal mengeksekusi SQL: ' . $e->getMessage()]);
                exit;
            }
        }
        
        // Fallback: Check if old JSON files exist in zip
        $hasJson = false;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entryName = $zip->getNameIndex($i);
            if (preg_match('/^(db_|questions_).*\.json$/i', basename($entryName))) {
                $hasJson = true;
                break;
            }
        }
        
        if ($hasJson) {
            $zip->extractTo(__DIR__);
            $zip->close();
            // Re-import to MySQL if migrator exists
            if (file_exists(__DIR__ . '/migrate_json_to_mysql.php')) {
                ob_start();
                include __DIR__ . '/migrate_json_to_mysql.php';
                ob_end_clean();
            }
            echo json_encode(['status' => 'success', 'message' => 'Database berhasil direstore dan disinkronkan ke MySQL']);
            exit;
        }
        
        $zip->close();
        echo json_encode(['status' => 'error', 'message' => 'Berkas backup zip tidak berisi data yang valid (.sql atau .json)']);
        exit;
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Gagal membaca file zip']);
    }
    exit;
}

if ($action === 'get_item_analysis') {
    $exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
    
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID ujian tidak valid']);
        exit;
    }
    
    $settings = function_exists('get_settings') ? get_settings() : [];
    $kkm = !empty($settings['passing_grade']) ? (float)$settings['passing_grade'] : 75;
    $schoolName = !empty($settings['school_name']) ? $settings['school_name'] : 'CBT ONLINE';
    
    $results = get_results($exam_id);
    $examResults = array_values(array_filter($results, function($r) use ($exam_id) {
        return (isset($r['exam_id']) && $r['exam_id'] == $exam_id);
    }));
    
    // Prioritaskan bank_soal_id dari data ujian
    $exams = get_exams();
    $targetExam = null;
    foreach ($exams as $e) {
        if ($e['id'] == $exam_id) {
            $targetExam = $e;
            break;
        }
    }
    
    $bank_soal_id = isset($targetExam['bank_soal_id']) ? $targetExam['bank_soal_id'] : $exam_id;
    $questionsData = get_questions_db($bank_soal_id);
    if (empty($questionsData) && $bank_soal_id != $exam_id) {
        $questionsData = get_questions_db($exam_id);
    }
    if (empty($questionsData)) {
        // Fallback: rekonstruksi data soal dari hasil ujian siswa jika file fisik tidak ada
        if (!empty($examResults)) {
            foreach ($examResults as $res) {
                $answers = isset($res['answers']) ? (is_string($res['answers']) ? json_decode($res['answers'], true) : $res['answers']) : [];
                if (is_array($answers)) {
                    foreach ($answers as $ans) {
                        $origId = $ans['originalId'] ?? null;
                        if ($origId !== null && !isset($questionsData[$origId])) {
                            $questionsData[$origId] = [
                                'question' => $ans['question'] ?? ('Soal #' . ($origId + 1)),
                                'type' => $ans['type'] ?? 'multiple_choice',
                                'points' => 2
                            ];
                        }
                    }
                }
            }
            ksort($questionsData);
        }
    }
    
    if (empty($questionsData)) {
        echo json_encode([
            'status' => 'success',
            'data' => [
                'total_students' => count($examResults),
                'exam_info' => [
                    'id' => $exam_id,
                    'name' => $targetExam['name'] ?? 'Ujian',
                    'token' => $targetExam['token'] ?? '-',
                    'school_name' => $schoolName,
                    'date' => date('d-m-Y'),
                    'total_questions' => 0,
                    'kkm' => $kkm
                ],
                'statistics' => [
                    'highest_score' => 0,
                    'lowest_score' => 0,
                    'average_score' => 0,
                    'standard_deviation' => 0,
                    'passed_count' => 0,
                    'failed_count' => 0,
                    'completeness_percent' => 0,
                    'difficulty_summary' => ['Mudah' => 0, 'Sedang' => 0, 'Sukar' => 0],
                    'recommendation_summary' => ['Diterima' => 0, 'Direvisi' => 0, 'Ditolak' => 0]
                ],
                'analysis' => [],
                'students' => []
            ]
        ]);
        exit;
    }
    
    $letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    $normalize_opt = function($val) {
        if ($val === null || $val === '') return null;
        $valStr = trim((string)$val);
        if (is_numeric($valStr)) {
            return (int)$valStr;
        }
        $upper = strtoupper($valStr);
        if (strlen($upper) === 1 && $upper >= 'A' && $upper <= 'Z') {
            return ord($upper) - 65;
        }
        return $valStr;
    };
    
    $questionsInfo = [];
    foreach ($questionsData as $idx => $q) {
        $type = $q['type'] ?? 'multiple_choice';
        $keyText = '-';
        if ($type === 'multiple_choice') {
            $ansIdx = $normalize_opt($q['answer'] ?? null);
            $keyText = ($ansIdx !== null && isset($letters[$ansIdx])) ? $letters[$ansIdx] : (string)($q['answer'] ?? '-');
        } else if ($type === 'complex_mc') {
            $cAnswers = $q['answers'] ?? (isset($q['answer']) ? [$q['answer']] : []);
            if (!is_array($cAnswers)) $cAnswers = [$cAnswers];
            $keyText = implode(', ', array_map(function($a) use ($letters, $normalize_opt) {
                $aIdx = $normalize_opt($a);
                return isset($letters[$aIdx]) ? $letters[$aIdx] : (string)$a;
            }, $cAnswers));
        } else if ($type === 'true_false') {
            $stmts = [];
            foreach (($q['statements'] ?? []) as $sidx => $st) {
                $stmts[] = ($sidx + 1) . ':' . (!empty($st['answer']) ? 'B' : 'S');
            }
            $keyText = implode(', ', $stmts);
        } else if ($type === 'matching') {
            $mPairs = [];
            foreach (($q['premises'] ?? []) as $pidx => $p) {
                $targetIdx = $q['pairs'][$pidx] ?? ($q['pairs'][(string)$pidx] ?? null);
                $letter = ($targetIdx !== null && isset($letters[(int)$targetIdx])) ? $letters[(int)$targetIdx] : '?';
                $mPairs[] = ($pidx + 1) . '→' . $letter;
            }
            $keyText = implode(', ', $mPairs);
        } else if ($type === 'essay') {
            $keyText = 'Esai';
        }

        $cleanQText = !empty($q['question']) ? trim(strip_tags((string)$q['question'])) : ('Soal #' . ($idx + 1));

        $questionsInfo[$idx] = [
            'originalId' => $idx,
            'question' => $q['question'] ?? ('Soal #' . ($idx + 1)),
            'question_clean' => $cleanQText,
            'type' => $type,
            'key' => $keyText,
            'max_points' => isset($q['points']) ? (float)$q['points'] : 2,
            'attempt_count' => 0,
            'correct_count' => 0,
            'wrong_count' => 0,
            'total_points_awarded' => 0,
            'options_count' => ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'E' => 0, 'Kosong' => 0]
        ];
    }
    
    $studentsList = get_students();
    $studentLookup = [];
    foreach ($studentsList as $st) {
        $studentLookup[$st['id']] = $st;
    }
    $classesList = get_classes();
    $classLookup = [];
    foreach ($classesList as $cl) {
        $classLookup[$cl['id']] = $cl['name'];
    }

    $studentAnalyses = [];
    foreach ($examResults as $res) {
        $sid = (int)$res['student_id'];
        $st = $studentLookup[$sid] ?? [];
        $stName = !empty($st['name']) ? $st['name'] : 'Siswa #' . $sid;
        $stNis = !empty($st['no_peserta']) ? $st['no_peserta'] : (!empty($st['username']) ? $st['username'] : 'ID-' . $sid);
        $stClass = !empty($st['class_id']) && isset($classLookup[$st['class_id']]) ? $classLookup[$st['class_id']] : '-';
        
        $answers = isset($res['answers']) ? (is_string($res['answers']) ? json_decode($res['answers'], true) : $res['answers']) : [];
        if (!is_array($answers)) $answers = [];

        $studentResponses = [];
        $seq = 0;
        foreach ($answers as $k => $item) {
            $origId = null;
            $sel = null;
            $awarded = null;
            if (is_array($item)) {
                $origId = isset($item['originalId']) ? (int)$item['originalId'] : (is_numeric($k) ? (int)$k : $seq);
                $sel = $item['selected'] ?? ($item['selectedOption'] ?? null);
                if (isset($item['awarded_points'])) $awarded = (float)$item['awarded_points'];
            } else {
                $origId = is_numeric($k) ? (int)$k : $seq;
                $sel = $item;
            }
            $studentResponses[$origId] = [
                'selected' => $sel,
                'awarded_points' => $awarded
            ];
            $seq++;
        }

        $sCorrectCount = 0;
        $sWrongCount = 0;
        $itemDetails = [];

        foreach ($questionsData as $idx => $q) {
            $qType = $q['type'] ?? 'multiple_choice';
            $maxPts = isset($q['points']) ? (float)$q['points'] : 2;
            $resp = $studentResponses[$idx] ?? null;
            $sel = $resp ? $resp['selected'] : null;
            $awarded = $resp ? $resp['awarded_points'] : null;

            $isAttempted = ($resp !== null && $sel !== null && $sel !== '');
            $isCorrect = false;
            $awardedScore = 0;
            $ansLabel = '-';

            if ($isAttempted) {
                $questionsInfo[$idx]['attempt_count']++;
            }

            if ($qType === 'multiple_choice') {
                $expectedNorm = $normalize_opt($q['answer'] ?? null);
                $selNorm = $normalize_opt($sel);
                if ($selNorm !== null && isset($letters[$selNorm])) {
                    $ansLabel = $letters[$selNorm];
                    if (isset($questionsInfo[$idx]['options_count'][$ansLabel])) {
                        $questionsInfo[$idx]['options_count'][$ansLabel]++;
                    }
                } else if ($selNorm !== null) {
                    $ansLabel = (string)$selNorm;
                } else {
                    $questionsInfo[$idx]['options_count']['Kosong']++;
                }

                if ($expectedNorm !== null && $selNorm !== null && $selNorm === $expectedNorm) {
                    $isCorrect = true;
                    $awardedScore = $maxPts;
                }
            } else if ($qType === 'complex_mc') {
                $correct_raw = $q['answers'] ?? (isset($q['answer']) ? [$q['answer']] : []);
                if (!is_array($correct_raw)) $correct_raw = [$correct_raw];
                $correct_vals = array_values(array_filter(array_map($normalize_opt, $correct_raw), function($v) { return $v !== null; }));
                $selected_raw = is_array($sel) ? $sel : [$sel];
                $selected_vals = array_values(array_filter(array_map($normalize_opt, $selected_raw), function($v) { return $v !== null; }));
                sort($correct_vals);
                sort($selected_vals);
                
                $ansLabel = implode(', ', array_map(function($a) use ($letters) { return isset($letters[$a]) ? $letters[$a] : (string)$a; }, $selected_vals));
                if (empty($ansLabel)) $ansLabel = '-';

                if (!empty($correct_vals) && $selected_vals === $correct_vals) {
                    $isCorrect = true;
                    $awardedScore = $maxPts;
                }
            } else if ($qType === 'true_false') {
                $statements = $q['statements'] ?? [];
                if (!empty($statements) && (is_array($sel) || is_object($sel))) {
                    $allMatch = true;
                    $tfArr = [];
                    foreach ($statements as $s_idx => $stmt) {
                        $s_val = is_array($sel) ? ($sel[$s_idx] ?? null) : ($sel->$s_idx ?? null);
                        $tfArr[] = ($s_idx + 1) . ':' . ($s_val === true || $s_val === 'true' || $s_val === 1 || $s_val === '1' ? 'B' : 'S');
                        $student_ans = ($s_val === true || $s_val === 'true' || $s_val === 1 || $s_val === '1' || strtolower((string)$s_val) === 'b');
                        $stmt_ans = !empty($stmt['answer']) && ($stmt['answer'] === true || $stmt['answer'] === 'true' || $stmt['answer'] === 1 || $stmt['answer'] === '1' || strtolower((string)$stmt['answer']) === 'b');
                        if ($student_ans !== $stmt_ans) {
                            $allMatch = false;
                        }
                    }
                    $ansLabel = implode(', ', $tfArr);
                    if ($allMatch) {
                        $isCorrect = true;
                        $awardedScore = $maxPts;
                    }
                }
            } else if ($qType === 'matching') {
                $premises = $q['premises'] ?? [];
                $pairs = $q['pairs'] ?? [];
                if (!empty($premises) && !empty($pairs) && (is_array($sel) || is_object($sel))) {
                    $allMatch = true;
                    $mArr = [];
                    foreach ($premises as $p_idx => $premise) {
                        $expected = is_array($pairs) ? ($pairs[$p_idx] ?? ($pairs[(string)$p_idx] ?? null)) : ($pairs->$p_idx ?? null);
                        $actual = is_array($sel) ? ($sel[$p_idx] ?? ($sel[(string)$p_idx] ?? null)) : ($sel->$p_idx ?? null);
                        $oLetter = ($actual !== null && isset($letters[(int)$actual])) ? $letters[(int)$actual] : (string)$actual;
                        $mArr[] = ((int)$p_idx + 1) . '→' . $oLetter;
                        if ($expected === null || $actual === null || (string)$actual !== (string)$expected) {
                            $allMatch = false;
                        }
                    }
                    $ansLabel = implode(', ', $mArr);
                    if ($allMatch) {
                        $isCorrect = true;
                        $awardedScore = $maxPts;
                    }
                }
            } else if ($qType === 'essay') {
                $awardedScore = ($awarded !== null && is_numeric($awarded)) ? (float)$awarded : 0;
                $isCorrect = ($awardedScore > 0);
                $questionsInfo[$idx]['total_points_awarded'] += $awardedScore;
                $ansLabel = strip_tags((string)$sel);
                if (mb_strlen($ansLabel) > 50) $ansLabel = mb_substr($ansLabel, 0, 50) . '...';
                if ($ansLabel === '') $ansLabel = '-';
            }

            if ($isCorrect) {
                $questionsInfo[$idx]['correct_count']++;
                $sCorrectCount++;
            } else {
                $questionsInfo[$idx]['wrong_count']++;
                $sWrongCount++;
            }

            $itemDetails[$idx] = [
                'score' => $awardedScore,
                'is_correct' => $isCorrect,
                'answer' => $ansLabel
            ];
        }

        $studentScore = (float)$res['score'];
        $studentAnalyses[] = [
            'id' => $sid,
            'name' => $stName,
            'nis' => $stNis,
            'class_name' => $stClass,
            'score' => $studentScore,
            'correct_count' => $sCorrectCount,
            'wrong_count' => $sWrongCount,
            'is_passed' => ($studentScore >= $kkm),
            'items' => $itemDetails
        ];
    }

    // Urutkan siswa dari nilai tertinggi ke terendah
    usort($studentAnalyses, function($a, $b) {
        if ($b['score'] != $a['score']) {
            return ($b['score'] > $a['score']) ? 1 : -1;
        }
        return ($b['correct_count'] <=> $a['correct_count']);
    });

    $totalStudents = count($studentAnalyses);
    $nUpper = 0;
    $nLower = 0;
    $upperStudents = [];
    $lowerStudents = [];

    if ($totalStudents >= 2) {
        if ($totalStudents <= 30) {
            $nUpper = (int)ceil($totalStudents / 2);
            $nLower = (int)floor($totalStudents / 2);
        } else {
            $nUpper = max(1, (int)round($totalStudents * 0.27));
            $nLower = max(1, (int)round($totalStudents * 0.27));
        }
        $upperStudents = array_slice($studentAnalyses, 0, $nUpper);
        $lowerStudents = array_slice($studentAnalyses, $totalStudents - $nLower, $nLower);
    }

    $finalAnalysis = [];
    $countMudah = 0; $countSedang = 0; $countSukar = 0;
    $countDiterima = 0; $countRevisi = 0; $countDitolak = 0;

    foreach ($questionsInfo as $idx => $item) {
        $qType = $item['type'];
        $maxPts = $item['max_points'] > 0 ? $item['max_points'] : 1;
        $attemptCount = $item['attempt_count'];
        $correctCount = $item['correct_count'];
        $item['wrong_count'] = max(0, $totalStudents - $correctCount);

        // Tingkat Kesukaran (P)
        if ($totalStudents > 0) {
            if ($qType === 'essay') {
                $avgPts = $attemptCount > 0 ? ($item['total_points_awarded'] / $attemptCount) : 0;
                $item['avg_points_awarded'] = round($avgPts, 2);
                $p = $avgPts / $maxPts;
            } else {
                $p = $correctCount / $totalStudents;
                $item['avg_points_awarded'] = round($p * $maxPts, 2);
            }
        } else {
            $p = 0;
            $item['avg_points_awarded'] = 0;
        }

        $p = max(0, min(1, $p));
        $item['difficulty_index'] = round($p, 3);
        $item['correct_percentage'] = round($p * 100, 2);

        if ($totalStudents > 0) {
            if ($p < 0.30) {
                $item['difficulty_level'] = 'Sukar';
                $countSukar++;
            } else if ($p <= 0.70) {
                $item['difficulty_level'] = 'Sedang';
                $countSedang++;
            } else {
                $item['difficulty_level'] = 'Mudah';
                $countMudah++;
            }
        } else {
            $item['difficulty_level'] = 'Belum Dikerjakan';
        }

        // Daya Pembeda (DP)
        $upperCorrect = 0;
        $lowerCorrect = 0;
        $upperPoints = 0;
        $lowerPoints = 0;

        if ($nUpper > 0) {
            foreach ($upperStudents as $ust) {
                $resp = $ust['items'][$idx] ?? null;
                if ($resp && !empty($resp['is_correct'])) $upperCorrect++;
                if ($resp && isset($resp['score'])) $upperPoints += (float)$resp['score'];
            }
        }

        if ($nLower > 0) {
            foreach ($lowerStudents as $lst) {
                $resp = $lst['items'][$idx] ?? null;
                if ($resp && !empty($resp['is_correct'])) $lowerCorrect++;
                if ($resp && isset($resp['score'])) $lowerPoints += (float)$resp['score'];
            }
        }

        $item['upper_correct_count'] = $upperCorrect;
        $item['lower_correct_count'] = $lowerCorrect;

        if ($nUpper > 0 && $nLower > 0) {
            if ($qType === 'essay') {
                $pA = ($upperPoints / ($nUpper * $maxPts));
                $pB = ($lowerPoints / ($nLower * $maxPts));
            } else {
                $pA = $upperCorrect / $nUpper;
                $pB = $lowerCorrect / $nLower;
            }
            $dp = round($pA - $pB, 3);
            $item['discrimination_index'] = $dp;

            if ($dp >= 0.40) {
                $item['discrimination_level'] = 'Sangat Baik';
                $item['recommendation'] = 'Diterima';
                $countDiterima++;
            } else if ($dp >= 0.30) {
                $item['discrimination_level'] = 'Baik';
                $item['recommendation'] = 'Diterima';
                $countDiterima++;
            } else if ($dp >= 0.20) {
                $item['discrimination_level'] = 'Cukup';
                $item['recommendation'] = 'Direvisi';
                $countRevisi++;
            } else if ($dp >= 0.0) {
                $item['discrimination_level'] = 'Jelek';
                $item['recommendation'] = 'Ditolak';
                $countDitolak++;
            } else {
                $item['discrimination_level'] = 'Sangat Jelek';
                $item['recommendation'] = 'Ditolak';
                $countDitolak++;
            }
        } else {
            $item['discrimination_index'] = 0;
            $item['discrimination_level'] = 'Data Kurang';
            $item['recommendation'] = 'Belum Ditentukan';
        }

        $finalAnalysis[] = $item;
    }

    $scores = array_column($studentAnalyses, 'score');
    $maxScore = !empty($scores) ? max($scores) : 0;
    $minScore = !empty($scores) ? min($scores) : 0;
    $avgScore = !empty($scores) ? round(array_sum($scores) / count($scores), 2) : 0;
    
    $stdDev = 0;
    if (count($scores) > 1) {
        $variance = 0;
        foreach ($scores as $sc) {
            $variance += pow($sc - $avgScore, 2);
        }
        $stdDev = round(sqrt($variance / count($scores)), 2);
    }
    
    $passedCount = count(array_filter($studentAnalyses, function($s) use ($kkm) { return $s['score'] >= $kkm; }));
    $failedCount = $totalStudents - $passedCount;
    $completeness = $totalStudents > 0 ? round(($passedCount / $totalStudents) * 100, 2) : 0;

    echo json_encode([
        'status' => 'success',
        'data' => [
            'total_students' => $totalStudents,
            'exam_info' => [
                'id' => $exam_id,
                'name' => $targetExam['name'] ?? 'Ujian',
                'token' => $targetExam['token'] ?? '-',
                'school_name' => $schoolName,
                'date' => !empty($targetExam['start_time']) ? date('d-m-Y', strtotime($targetExam['start_time'])) : date('d-m-Y'),
                'total_questions' => count($finalAnalysis),
                'kkm' => $kkm,
                'upper_count' => $nUpper,
                'lower_count' => $nLower
            ],
            'statistics' => [
                'highest_score' => $maxScore,
                'lowest_score' => $minScore,
                'average_score' => $avgScore,
                'standard_deviation' => $stdDev,
                'passed_count' => $passedCount,
                'failed_count' => $failedCount,
                'completeness_percent' => $completeness,
                'difficulty_summary' => [
                    'Mudah' => $countMudah,
                    'Sedang' => $countSedang,
                    'Sukar' => $countSukar
                ],
                'recommendation_summary' => [
                    'Diterima' => $countDiterima,
                    'Direvisi' => $countRevisi,
                    'Ditolak' => $countDitolak
                ]
            ],
            'analysis' => $finalAnalysis,
            'students' => $studentAnalyses
        ]
    ]);
    exit;
}

if ($action === 'get_all_answers_data') {
    $exam_id = (int)($_GET['exam_id'] ?? 0);
    if ($exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'ID Ujian tidak valid']);
        exit;
    }
    
    $exams = get_exams();
    $examName = 'Ujian';
    $targetExam = null;
    foreach ($exams as $e) {
        if ($e['id'] === $exam_id) {
            $examName = $e['name'];
            $targetExam = $e;
            break;
        }
    }
    
    if (!$targetExam) {
        echo json_encode(['status' => 'error', 'message' => 'Ujian tidak ditemukan']);
        exit;
    }
    
    $allowed_classes = $targetExam['class_ids'] ?? null;
    if ($allowed_classes === null && isset($targetExam['class_id'])) {
        $allowed_classes = $targetExam['class_id'] == 0 ? [] : [$targetExam['class_id']];
    } else if (!is_array($allowed_classes) && !empty($allowed_classes)) {
        $allowed_classes = json_decode($allowed_classes, true) ?: [];
    }
    $allowed_classes = $allowed_classes ?: [];
    
    // Load questions
    $bank_soal_id = isset($targetExam['bank_soal_id']) ? $targetExam['bank_soal_id'] : $targetExam['id'];
    $questions = get_questions_db($bank_soal_id);
    if (empty($questions) && $bank_soal_id != $exam_id) {
        $questions = get_questions_db($exam_id);
    }
    
    $letters = ['A', 'B', 'C', 'D', 'E'];
    $questionsInfo = [];
    foreach ($questions as $idx => $q) {
        $type = $q['type'] ?? 'multiple_choice';
        $keyText = '-';
        if ($type === 'multiple_choice' && isset($q['answer'])) {
            $keyText = $letters[(int)$q['answer']] ?? (string)$q['answer'];
        } else if ($type === 'complex_mc' && isset($q['answers'])) {
            $keyText = implode(', ', array_map(function($a) use ($letters) { return $letters[(int)$a] ?? (string)$a; }, (array)$q['answers']));
        } else if ($type === 'true_false' && isset($q['statements'])) {
            $stmts = [];
            foreach ($q['statements'] as $sidx => $st) {
                $stmts[] = ($sidx + 1) . ':' . ($st['answer'] ? 'B' : 'S');
            }
            $keyText = implode(', ', $stmts);
        } else if ($type === 'matching' && isset($q['premises'])) {
            $mPairs = [];
            foreach ($q['premises'] as $pidx => $p) {
                $targetIdx = $q['pairs'][$pidx] ?? ($q['pairs'][(string)$pidx] ?? null);
                $letter = ($targetIdx !== null && isset($letters[(int)$targetIdx])) ? $letters[(int)$targetIdx] : '?';
                $mPairs[] = ($pidx + 1) . '→' . $letter;
            }
            $keyText = implode(', ', $mPairs);
        } else if ($type === 'essay') {
            $keyText = 'Esai';
        }
        $questionsInfo[] = [
            'index' => $idx,
            'type' => $type,
            'key' => $keyText
        ];
    }
    
    $students = get_students();
    $classes = get_classes();
    $classLookup = [];
    foreach ($classes as $c) { $classLookup[$c['id']] = $c['name']; }
    
    $results = get_results();
    $resultsMap = [];
    foreach ($results as $r) {
        if (isset($r['exam_id']) && $r['exam_id'] == $exam_id) {
            $resultsMap[$r['student_id']] = $r;
        }
    }
    
    $sessions = get_sessions();
    $sessionsMap = [];
    foreach ($sessions as $s) {
        if (isset($s['exam_id']) && $s['exam_id'] == $exam_id) {
            $sessionsMap[$s['student_id']] = $s;
        }
    }
    
    $studentRows = [];
    foreach ($students as $student) {
        if (!empty($allowed_classes) && !in_array($student['class_id'], $allowed_classes)) {
            continue;
        }
        
        $sid = $student['id'];
        $className = $classLookup[$student['class_id']] ?? '-';
        
        $status = 'Belum Mengerjakan';
        $score = 0;
        $studentAnsMap = [];
        $correct_count = 0;
        $wrong_count = 0;
        $bs = '-';
        
        if (isset($resultsMap[$sid])) {
            $r = $resultsMap[$sid];
            $status = 'Selesai';
            $score = (float)$r['score'];
            $ansList = is_string($r['answers']) ? json_decode($r['answers'], true) : $r['answers'];
            if (is_array($ansList)) {
                $bsData = calculate_exam_bs_count($questions, $ansList);
                $correct_count = $bsData['correct_count'];
                $wrong_count = $bsData['wrong_count'];
                $bs = $bsData['bs'];

                foreach ($ansList as $k => $item) {
                    $qIdx = $item['originalId'] ?? (is_numeric($k) ? (int)$k : null);
                    if ($qIdx !== null) {
                        $qType = $item['type'] ?? 'multiple_choice';
                        $sel = $item['selected'] ?? null;
                        if ($qType === 'multiple_choice') {
                            $studentAnsMap[$qIdx] = ($sel !== null && $sel !== '') ? ($letters[(int)$sel] ?? (string)$sel) : '-';
                        } else if ($qType === 'complex_mc') {
                            if (is_array($sel)) {
                                $studentAnsMap[$qIdx] = implode(', ', array_map(function($a) use ($letters) { return $letters[(int)$a] ?? (string)$a; }, $sel));
                            } else {
                                $studentAnsMap[$qIdx] = '-';
                            }
                        } else if ($qType === 'true_false') {
                            if (is_array($sel)) {
                                $tfArr = [];
                                foreach ($sel as $tIdx => $tVal) {
                                    $tfArr[] = ($tIdx + 1) . ':' . ($tVal === true || $tVal === 'true' ? 'B' : 'S');
                                }
                                $studentAnsMap[$qIdx] = implode(', ', $tfArr);
                            } else {
                                $studentAnsMap[$qIdx] = '-';
                            }
                        } else if ($qType === 'matching') {
                            if (is_array($sel) || is_object($sel)) {
                                $mArr = [];
                                foreach ((array)$sel as $pIdx => $oIdx) {
                                    $oLetter = isset($letters[(int)$oIdx]) ? $letters[(int)$oIdx] : (string)$oIdx;
                                    $mArr[] = ((int)$pIdx + 1) . '→' . $oLetter;
                                }
                                $studentAnsMap[$qIdx] = !empty($mArr) ? implode(', ', $mArr) : '-';
                            } else {
                                $studentAnsMap[$qIdx] = '-';
                            }
                        } else {
                            $studentAnsMap[$qIdx] = strip_tags((string)$sel);
                        }
                    }
                }
            }
        } else if (isset($sessionsMap[$sid])) {
            $sess = $sessionsMap[$sid];
            $status = !empty($sess['is_locked']) ? 'Terkunci' : 'Sedang Mengerjakan';
            $score = (float)($sess['score'] ?? 0);
            $rawSessAns = $sess['answers'] ?? ($sess['state']['answers'] ?? ($sess['state']['shuffledQuestions'] ?? []));
            if (is_string($rawSessAns)) $rawSessAns = json_decode($rawSessAns, true) ?: [];
            if (is_array($rawSessAns) && !empty($rawSessAns)) {
                $bsData = calculate_exam_bs_count($questions, $rawSessAns);
                $correct_count = $bsData['correct_count'];
                $wrong_count = $bsData['wrong_count'];
                $bs = $bsData['bs'];
            }
            $sessAnswers = $sess['answers'] ?? [];
            if (is_string($sessAnswers)) $sessAnswers = json_decode($sessAnswers, true) ?: [];
            if (is_array($sessAnswers)) {
                foreach ($sessAnswers as $qIdx => $sel) {
                    $studentAnsMap[$qIdx] = ($sel !== null && $sel !== '') ? ($letters[(int)$sel] ?? (string)$sel) : '-';
                }
            }
        }
        
        $studentRows[] = [
            'id' => $sid,
            'name' => $student['name'],
            'class_name' => $className,
            'status' => $status,
            'score' => $score,
            'correct_count' => $correct_count,
            'wrong_count' => $wrong_count,
            'bs' => $bs,
            'answers' => $studentAnsMap
        ];
    }
    
    usort($studentRows, function($a, $b) {
        $c = strcmp($a['class_name'], $b['class_name']);
        if ($c !== 0) return $c;
        return strcmp($a['name'], $b['name']);
    });
    
    echo json_encode([
        'status' => 'success',
        'exam_name' => $examName,
        'questions' => $questionsInfo,
        'students' => $studentRows
    ]);
    exit;
}

if ($action === 'get_student_answers_data') {
    $student_id = (int)($_GET['student_id'] ?? 0);
    $exam_id = (int)($_GET['exam_id'] ?? 0);
    
    if ($student_id <= 0 || $exam_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Parameter tidak valid']);
        exit;
    }
    
    $students = get_students();
    $studentName = 'Unknown';
    $className = '-';
    $classes = get_classes();
    $classLookup = [];
    foreach ($classes as $c) { $classLookup[$c['id']] = $c['name']; }
    foreach ($students as $s) {
        if ($s['id'] == $student_id) {
            $studentName = $s['name'];
            $className = $classLookup[$s['class_id']] ?? '-';
            break;
        }
    }
    
    $exams = get_exams();
    $examName = 'Ujian';
    $targetExam = null;
    foreach ($exams as $e) {
        if ($e['id'] == $exam_id) {
            $examName = $e['name'];
            $targetExam = $e;
            break;
        }
    }
    
    // Load question bank for rich details (options text, etc.)
    $bank_soal_id = isset($targetExam['bank_soal_id']) ? $targetExam['bank_soal_id'] : $exam_id;
    $questionBank = get_questions_db($bank_soal_id);
    if (empty($questionBank) && $bank_soal_id != $exam_id) {
        $questionBank = get_questions_db($exam_id);
    }
    
    $results = get_results();
    $studentResult = null;
    foreach ($results as $r) {
        if ($r['student_id'] == $student_id && (isset($r['exam_id']) && $r['exam_id'] == $exam_id)) {
            $studentResult = $r;
            break;
        }
    }
    
    $letters = ['A', 'B', 'C', 'D', 'E'];
    $answersList = [];
    $score = 0;
    $status = 'Belum Mengerjakan';
    $bs = '-';
    $correct_count = 0;
    $wrong_count = 0;
    
    if ($studentResult) {
        $score = (float)$studentResult['score'];
        $status = 'Selesai';
        $rawAnswers = is_string($studentResult['answers']) ? json_decode($studentResult['answers'], true) : $studentResult['answers'];
        if (!is_array($rawAnswers)) $rawAnswers = [];
        $bsCalc = calculate_exam_bs_count($questionBank, $rawAnswers);
        $correct_count = $bsCalc['correct_count'];
        $wrong_count = $bsCalc['wrong_count'];
        $bs = $bsCalc['bs'];
        
        foreach ($rawAnswers as $idx => $ans) {
            $origId = $ans['originalId'] ?? $idx;
            $origQ = isset($questionBank[$origId]) ? $questionBank[$origId] : null;
            
            $q = !empty($ans['question']) ? $ans['question'] : ($origQ['question'] ?? 'Soal #' . ($idx + 1));
            $q = strip_tags($q);
            $type = $ans['type'] ?? ($origQ['type'] ?? 'multiple_choice');
            $userAns = '-';
            
            if ($type === 'essay') {
                $userAns = strip_tags((string)($ans['selected'] ?? '-'));
            } else if ($type === 'complex_mc') {
                $sel = $ans['selected'] ?? [];
                if (is_array($sel)) {
                    $userAns = implode(', ', array_map(function($a) use ($letters) { return $letters[(int)$a] ?? (string)$a; }, $sel));
                }
            } else if ($type === 'true_false') {
                $sel = $ans['selected'] ?? [];
                if (is_array($sel)) {
                    $tfArr = [];
                    foreach ($sel as $tIdx => $tVal) {
                        $tfArr[] = ($tIdx + 1) . ':' . ($tVal === true || $tVal === 'true' ? 'B' : 'S');
                    }
                    $userAns = implode(', ', $tfArr);
                }
            } else if ($type === 'matching') {
                $sel = $ans['selected'] ?? [];
                if (is_array($sel) || is_object($sel)) {
                    $mArr = [];
                    foreach ((array)$sel as $pIdx => $oIdx) {
                        $oLetter = isset($letters[(int)$oIdx]) ? $letters[(int)$oIdx] : (string)$oIdx;
                        $mArr[] = ((int)$pIdx + 1) . '→' . $oLetter;
                    }
                    $userAns = !empty($mArr) ? implode(', ', $mArr) : '-';
                }
            } else {
                $sel = $ans['selected'] ?? null;
                if ($sel !== null && $sel !== '') {
                    $userAns = $letters[(int)$sel] ?? (string)$sel;
                    $opts = $ans['options'] ?? ($origQ['options'] ?? null);
                    if ($opts && isset($opts[(int)$sel]['text'])) {
                        $userAns .= '. ' . strip_tags($opts[(int)$sel]['text']);
                    }
                }
            }
            
            $answersList[] = [
                'no' => $idx + 1,
                'question' => $q,
                'type' => $type === 'essay' ? 'Esai' : ($type === 'complex_mc' ? 'PG Kompleks' : ($type === 'true_false' ? 'Benar/Salah' : ($type === 'matching' ? 'Menjodohkan' : 'Pilihan Ganda'))),
                'answer' => $userAns
            ];
        }
    } else {
        // Fallback to sessions if student hasn't submitted or is currently taking exam
        $sessions = get_sessions();
        foreach ($sessions as $s) {
            if ($s['student_id'] == $student_id && (isset($s['exam_id']) && $s['exam_id'] == $exam_id)) {
                $status = !empty($s['is_locked']) ? 'Terkunci' : 'Sedang Mengerjakan';
                $score = (float)($s['score'] ?? 0);
                
                $sessQuestions = $s['state']['shuffledQuestions'] ?? [];
                if (!empty($sessQuestions)) {
                    foreach ($sessQuestions as $idx => $sq) {
                        $origId = $sq['originalId'] ?? $idx;
                        $origQ = isset($questionBank[$origId]) ? $questionBank[$origId] : null;
                        $qText = $origQ['question'] ?? ($sq['question'] ?? "Soal #" . ($idx + 1));
                        $qType = $origQ['type'] ?? ($sq['type'] ?? 'multiple_choice');
                        $sel = $sq['selectedOption'] ?? null;
                        $userAns = '-';
                        
                        if ($qType === 'essay') {
                            $userAns = strip_tags((string)($sel ?? '-'));
                        } else if ($qType === 'complex_mc') {
                            if (is_array($sel)) {
                                $userAns = implode(', ', array_map(function($a) use ($letters) { return $letters[(int)$a] ?? (string)$a; }, $sel));
                            }
                        } else if ($qType === 'true_false') {
                            if (is_array($sel)) {
                                $tfArr = [];
                                foreach ($sel as $tIdx => $tVal) {
                                    $tfArr[] = ($tIdx + 1) . ':' . ($tVal === true || $tVal === 'true' ? 'B' : 'S');
                                }
                                $userAns = implode(', ', $tfArr);
                            }
                        } else if ($qType === 'matching') {
                            if (is_array($sel) || is_object($sel)) {
                                $mArr = [];
                                foreach ((array)$sel as $pIdx => $oIdx) {
                                    $oLetter = isset($letters[(int)$oIdx]) ? $letters[(int)$oIdx] : (string)$oIdx;
                                    $mArr[] = ((int)$pIdx + 1) . '→' . $oLetter;
                                }
                                $userAns = !empty($mArr) ? implode(', ', $mArr) : '-';
                            }
                        } else {
                            if ($sel !== null && $sel !== '') {
                                $userAns = $letters[(int)$sel] ?? (string)$sel;
                                $opts = $origQ['options'] ?? ($sq['options'] ?? null);
                                if ($opts && isset($opts[(int)$sel]['text'])) {
                                    $userAns .= '. ' . strip_tags($opts[(int)$sel]['text']);
                                }
                            }
                        }
                        
                        $answersList[] = [
                            'no' => $idx + 1,
                            'question' => strip_tags($qText),
                            'type' => $qType === 'essay' ? 'Esai' : ($qType === 'complex_mc' ? 'PG Kompleks' : ($qType === 'true_false' ? 'Benar/Salah' : ($qType === 'matching' ? 'Menjodohkan' : 'Pilihan Ganda'))),
                            'answer' => $userAns
                        ];
                    }
                    $studentResult = true;
                }
                break;
            }
        }
    }
    
    if (!$studentResult && empty($answersList)) {
        echo json_encode(['status' => 'error', 'message' => 'Data jawaban siswa belum tersedia (siswa belum mulai ujian atau belum ada jawaban).']);
        exit;
    }
    
    echo json_encode([
        'status' => 'success',
        'student_name' => $studentName,
        'class_name' => $className,
        'exam_name' => $examName,
        'score' => $score,
        'student_status' => $status,
        'bs' => $bs,
        'correct_count' => $correct_count,
        'wrong_count' => $wrong_count,
        'answers' => $answersList
    ]);
    exit;
}

if ($action === 'download_student_answers_excel') {
    $student_id = (int)($_GET['student_id'] ?? 0);
    $exam_id = (int)($_GET['exam_id'] ?? 0);
    
    if ($student_id <= 0 || $exam_id <= 0) {
        die('Invalid parameters');
    }
    
    $students = get_students();
    $studentName = 'Unknown';
    $className = '';
    $classes = get_classes();
    $classLookup = [];
    foreach ($classes as $c) {
        $classLookup[$c['id']] = $c['name'];
    }
    foreach ($students as $s) {
        if ($s['id'] === $student_id) {
            $studentName = $s['name'];
            $className = $classLookup[$s['class_id']] ?? '';
            break;
        }
    }
    
    $results = get_results();
    $studentResult = null;
    foreach ($results as $r) {
        if ($r['student_id'] === $student_id && (isset($r['exam_id']) && $r['exam_id'] == $exam_id)) {
            $studentResult = $r;
            break;
        }
    }
    
    if (!$studentResult) {
        die('Data jawaban siswa tidak ditemukan.');
    }
    
    $answers = is_string($studentResult['answers']) ? json_decode($studentResult['answers'], true) : $studentResult['answers'];
    if (!is_array($answers)) $answers = [];
    
    $filename = "Jawaban_{$studentName}_{$className}.xls";
    // Bersihkan nama file
    $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $filename);
    
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Pragma: no-cache");
    header("Expires: 0");
    
    echo '<table border="1">';
    echo '<tr><th colspan="4" style="text-align:center; font-size:16px;"><b>Data Jawaban Siswa</b></th></tr>';
    echo "<tr><td colspan=\"2\"><b>Nama Siswa</b></td><td colspan=\"2\">{$studentName}</td></tr>";
    echo "<tr><td colspan=\"2\"><b>Kelas</b></td><td colspan=\"2\">{$className}</td></tr>";
    echo "<tr><td colspan=\"2\"><b>Total Skor</b></td><td colspan=\"2\">{$studentResult['score']}</td></tr>";
    echo '<tr><td colspan="4"></td></tr>';
    
    echo '<tr>';
    echo '<th>No</th>';
    echo '<th>Soal</th>';
    echo '<th>Tipe</th>';
    echo '<th>Jawaban Siswa</th>';
    echo '</tr>';
    
    foreach ($answers as $idx => $ans) {
        $no = $idx + 1;
        $q = strip_tags($ans['question']);
        $type = isset($ans['type']) && $ans['type'] === 'essay' ? 'Esai' : 'Pilihan Ganda';
        
        $userAnswer = '';
        if ($type === 'Esai') {
            $userAnswer = strip_tags($ans['selected'] ?? '');
        } else {
            // Jika pilihan ganda, selected berisi nilai option
            if (isset($ans['options'])) {
                foreach ($ans['options'] as $opt) {
                    if ((string)$opt['value'] === (string)($ans['selected'] ?? '')) {
                        // Kita tidak simpan teks jawaban di answers, kecuali kita parse questions_x.json
                        // Sebaiknya tampilkan nomor opsi atau value saja, atau jika ada "text", tampilkan
                        $userAnswer = isset($opt['text']) ? strip_tags($opt['text']) : "Opsi: " . $opt['value'];
                        break;
                    }
                }
            }
            if ($userAnswer === '') $userAnswer = (string)($ans['selected'] ?? '');
        }
        
        echo '<tr>';
        echo '<td>' . $no . '</td>';
        echo '<td>' . htmlspecialchars($q) . '</td>';
        echo '<td>' . $type . '</td>';
        echo '<td>' . htmlspecialchars($userAnswer) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    exit;
}

if ($action === 'download_all_answers_excel') {
    $exam_id = (int)($_GET['exam_id'] ?? 0);
    
    if ($exam_id <= 0) {
        die('Invalid exam_id');
    }
    
    $students = get_students();
    $classes = get_classes();
    $classLookup = [];
    foreach ($classes as $c) {
        $classLookup[$c['id']] = $c['name'];
    }
    
    $studentLookup = [];
    foreach ($students as $s) {
        $studentLookup[$s['id']] = [
            'name' => $s['name'],
            'className' => $classLookup[$s['class_id']] ?? ''
        ];
    }
    
    $exams = get_exams();
    $examName = "Ujian";
    $targetExam = null;
    foreach ($exams as $e) {
        if ($e['id'] == $exam_id) {
            $examName = $e['name'];
            $targetExam = $e;
            break;
        }
    }
    
    $allowed_classes = $targetExam['class_ids'] ?? null;
    if ($allowed_classes === null && isset($targetExam['class_id'])) {
        $allowed_classes = $targetExam['class_id'] == 0 ? [] : [$targetExam['class_id']];
    } else if (!is_array($allowed_classes) && !empty($allowed_classes)) {
        $allowed_classes = json_decode($allowed_classes, true) ?: [];
    }
    $allowed_classes = $allowed_classes ?: [];

    $results = get_results();
    $resultsMap = [];
    foreach ($results as $r) {
        if (isset($r['exam_id']) && $r['exam_id'] == $exam_id) {
            $resultsMap[$r['student_id']] = $r;
        }
    }

    $sessions = get_sessions();
    $sessionsMap = [];
    foreach ($sessions as $s) {
        if (isset($s['exam_id']) && $s['exam_id'] == $exam_id) {
            $sessionsMap[$s['student_id']] = $s;
        }
    }
    
    // Ambil data soal untuk menentukan urutan dan tipe (PG vs Esai)
    $bank_soal_id = $exam_id;
    foreach ($exams as $e) {
        if ($e['id'] == $exam_id) {
            $bank_soal_id = isset($e['bank_soal_id']) ? $e['bank_soal_id'] : $e['id'];
            break;
        }
    }
    $questionsData = get_questions_db($bank_soal_id);
    if (empty($questionsData) && $bank_soal_id != $exam_id) {
        $questionsData = get_questions_db($exam_id);
    }
    
    $pg_keys = [];
    $essay_keys = [];
    foreach ($questionsData as $idx => $q) {
        $type = isset($q['type']) ? $q['type'] : 'multiple_choice';
        if ($type === 'essay') {
            $essay_keys[] = $idx;
        } else {
            $pg_keys[] = $idx;
        }
    }
    
    $filename = "Semua_Jawaban_{$examName}.xls";
    $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $filename);
    
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Pragma: no-cache");
    header("Expires: 0");
    
    echo '<table border="1">';
    echo '<tr><th colspan="' . (3 + count($pg_keys) + count($essay_keys)) . '" style="text-align:center; font-size:16px;"><b>Data Seluruh Jawaban Siswa</b></th></tr>';
    echo "<tr><td colspan=\"3\"><b>Mata Pelajaran</b></td><td colspan=\"" . (count($pg_keys) + count($essay_keys)) . "\">{$examName}</td></tr>";
    
    echo '<tr>';
    echo '<th rowspan="3" style="vertical-align:middle;">Nama Siswa</th>';
    echo '<th rowspan="3" style="vertical-align:middle;">Kelas</th>';
    echo '<th rowspan="3" style="vertical-align:middle;">Total Skor</th>';
    
    if (count($pg_keys) > 0) {
        echo '<th colspan="' . count($pg_keys) . '" style="text-align:center;">Pilihan Ganda</th>';
    }
    if (count($essay_keys) > 0) {
        echo '<th colspan="' . count($essay_keys) . '" style="text-align:center;">Esai</th>';
    }
    echo '</tr>';
    
    echo '<tr>';
    foreach ($pg_keys as $k => $origId) {
        echo '<th style="text-align:center;">' . ($k + 1) . '</th>';
    }
    foreach ($essay_keys as $k => $origId) {
        echo '<th style="text-align:center;">' . ($k + 1) . '</th>';
    }
    echo '</tr>';
    
    $letters = ['A', 'B', 'C', 'D', 'E'];
    $pgCorrect = [];
    
    echo '<tr>';
    foreach ($pg_keys as $k => $origId) {
        $q = $questionsData[$origId];
        $correctAns = '-';
        if (isset($q['answer'])) {
            $ansIdx = (int)$q['answer'];
            $correctAns = $letters[$ansIdx] ?? '-';
            $pgCorrect[$origId] = $ansIdx;
        }
        echo '<th style="text-align:center; background-color:#ffffcc;">Kunci: ' . $correctAns . '</th>';
    }
    foreach ($essay_keys as $k => $origId) {
        echo '<th style="text-align:center; background-color:#ffffcc;">Esai</th>';
    }
    echo '</tr>';
    
    // Sort students by class and name
    $targetStudents = [];
    foreach ($students as $student) {
        if (!empty($allowed_classes) && !in_array($student['class_id'], $allowed_classes)) {
            continue;
        }
        $targetStudents[] = $student;
    }
    usort($targetStudents, function($a, $b) use ($classLookup) {
        $cA = $classLookup[$a['class_id']] ?? '';
        $cB = $classLookup[$b['class_id']] ?? '';
        $c = strcmp($cA, $cB);
        if ($c !== 0) return $c;
        return strcmp($a['name'], $b['name']);
    });
    
    foreach ($targetStudents as $student) {
        $sid = $student['id'];
        $sName = $student['name'];
        $sClass = $classLookup[$student['class_id']] ?? '';
        $score = 0;
        $ansMap = [];
        
        if (isset($resultsMap[$sid])) {
            $res = $resultsMap[$sid];
            $score = $res['score'];
            $answers = is_string($res['answers']) ? json_decode($res['answers'], true) : $res['answers'];
            if (!is_array($answers)) $answers = [];
            foreach ($answers as $ans) {
                if (isset($ans['originalId'])) {
                    $ansMap[$ans['originalId']] = $ans['selected'];
                }
            }
        } else if (isset($sessionsMap[$sid])) {
            $sess = $sessionsMap[$sid];
            $score = $sess['score'] ?? 0;
            $sessAns = $sess['answers'] ?? [];
            if (is_string($sessAns)) $sessAns = json_decode($sessAns, true) ?: [];
            if (is_array($sessAns)) {
                foreach ($sessAns as $qIdx => $sel) {
                    $ansMap[$qIdx] = $sel;
                }
            }
        }
        
        echo '<tr>';
        echo "<td>{$sName}</td>";
        echo "<td>{$sClass}</td>";
        echo "<td>" . (isset($resultsMap[$sid]) ? $score : "{$score} (Belum Selesai)") . "</td>";
        
        // Jawaban PG
        foreach ($pg_keys as $origId) {
            if (isset($ansMap[$origId]) && $ansMap[$origId] !== null && $ansMap[$origId] !== '') {
                $selIndex = (int)$ansMap[$origId];
                $ansStr = $letters[$selIndex] ?? '-';
                
                $color = '';
                if (isset($pgCorrect[$origId])) {
                    if ($selIndex === $pgCorrect[$origId]) {
                        $color = 'background-color:#c8e6c9; color:#155724; font-weight:bold;'; // Hijau
                    } else {
                        $color = 'background-color:#ffcdd2; color:#721c24; font-weight:bold;'; // Merah
                    }
                }
                
                echo "<td style=\"text-align:center; {$color}\">" . $ansStr . "</td>";
            } else {
                echo "<td style=\"text-align:center;\">-</td>";
            }
        }
        
        // Jawaban Esai
        foreach ($essay_keys as $origId) {
            if (isset($ansMap[$origId]) && $ansMap[$origId] !== null && $ansMap[$origId] !== '') {
                echo "<td>" . htmlspecialchars(strip_tags((string)$ansMap[$origId])) . "</td>";
            } else {
                echo "<td>-</td>";
            }
        }
        echo '</tr>';
    }
    echo '</table>';
    exit;
}

if ($action === 'backup_database_mysql' || $action === 'backup_database') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya Administrator yang memiliki akses unduh backup database']);
        exit;
    }

    $sqlDump = export_mysql_database();
    $filename = 'backup_cbt_mysql_' . date('Y-m-d_His') . '.sql';

    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($sqlDump));
    header('Pragma: no-cache');
    header('Expires: 0');
    echo $sqlDump;
    exit;
}

if ($action === 'restore_database_mysql' || $action === 'restore_database') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya Administrator yang memiliki izin restore database']);
        exit;
    }

    $fileField = isset($_FILES['sql_file']) ? 'sql_file' : (isset($_FILES['file_backup']) ? 'file_backup' : null);
    if (!$fileField || empty($_FILES[$fileField]['tmp_name']) || $_FILES[$fileField]['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'message' => 'File backup tidak ditemukan atau gagal diunggah']);
        exit;
    }

    $file = $_FILES[$fileField];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'sql') {
        echo json_encode(['status' => 'error', 'message' => 'Format file tidak didukung! Harap unggah file database MySQL dengan format .sql']);
        exit;
    }

    $sqlContent = file_get_contents($file['tmp_name']);
    if (empty($sqlContent)) {
        echo json_encode(['status' => 'error', 'message' => 'File .sql kosong atau tidak dapat dibaca']);
        exit;
    }

    try {
        $executedQueries = import_mysql_database($sqlContent);
        echo json_encode([
            'status' => 'success',
            'message' => "Database MySQL berhasil direstore ($executedQueries instruksi SQL dijalankan). Dual Live-Sync telah diperbarui."
        ]);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Gagal restore database: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'purge_database_data') {
    if (empty($_SESSION['admin_logged_in']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
        echo json_encode(['status' => 'error', 'message' => 'Hanya Administrator yang berwenang menghapus data database']);
        exit;
    }

    $targets = $_POST['targets'] ?? [];
    if (is_string($targets)) {
        $targets = json_decode($targets, true) ?: [];
    }

    if (!is_array($targets) || empty($targets)) {
        echo json_encode(['status' => 'error', 'message' => 'Pilih minimal satu kategori data yang ingin dihapus']);
        exit;
    }

    $pdo = get_db_connection();
    $pdo->beginTransaction();
    $messages = [];

    try {
        // 1. Hasil Ujian
        if (in_array('results', $targets)) {
            $pdo->exec("DELETE FROM exam_results");
            $messages[] = 'Hasil & Nilai Ujian';
        }

        // 2. Sesi Ujian Aktif
        if (in_array('sessions', $targets)) {
            $pdo->exec("DELETE FROM exam_sessions");
            $messages[] = 'Sesi Ujian Aktif';
        }

        // 3. Jadwal Ujian / Mapel
        if (in_array('exams', $targets)) {
            $pdo->exec("DELETE FROM exams");
            $messages[] = 'Jadwal Ujian';
        }

        // 4. Bank Soal & Butir Soal
        if (in_array('questions', $targets)) {
            $pdo->exec("DELETE FROM questions");
            $pdo->exec("DELETE FROM bank_soal");
            
            // Hapus semua file cache questions_{id}.json
            $jsonFiles = glob(__DIR__ . '/questions_*.json');
            if (!empty($jsonFiles)) {
                foreach ($jsonFiles as $f) {
                    if (file_exists($f)) @unlink($f);
                }
            }
            $messages[] = 'Bank Soal & Butir Soal';
        }

        // 5. Data Siswa
        if (in_array('students', $targets)) {
            $pdo->exec("DELETE FROM students");
            $messages[] = 'Data Siswa';
        }

        // 6. Data Kelas
        if (in_array('classes', $targets)) {
            $pdo->exec("DELETE FROM classes");
            $messages[] = 'Data Kelas';
        }

        // 7. Akun Guru
        if (in_array('gurus', $targets)) {
            $pdo->exec("DELETE FROM users WHERE role = 'guru'");
            $messages[] = 'Akun Guru';
        }

        $pdo->commit();

        echo json_encode([
            'status' => 'success',
            'message' => 'Berhasil menghapus: ' . implode(', ', $messages) . '.',
            'purged' => $targets
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus data: ' . $e->getMessage()]);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
?>
