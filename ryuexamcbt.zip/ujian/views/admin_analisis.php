<?php
// views/admin_analisis.php
$settings = function_exists('get_settings') ? get_settings() : [];
$schoolName = !empty($settings['school_name']) ? $settings['school_name'] : 'CBT ONLINE';
?>

<div id="section-analisis" class="content-section">
    <!-- Card Seleksi Ujian -->
    <div class="card card-outline card-info mb-4 shadow-sm border-0" style="border-radius: 8px;">
        <div class="card-body">
            <h5 class="mb-3 font-weight-bold text-dark">
                <i class="fas fa-microscope text-info mr-2"></i>Analisis Butir Soal & Kualitas Tes
            </h5>
            <p class="text-muted small mb-3">
                Pilih mata pelajaran / jadwal ujian untuk melihat analisis statistik psikometri butir soal (Tingkat Kesukaran $P$, Daya Pembeda $DP$, Rekomendasi Butir, Sebaran Pengecoh, dan Matriks Siswa) serta ekspor format standar evaluasi ke Excel (.xlsx).
            </p>
            <div class="form-group row mb-0 align-items-center">
                <label class="col-sm-2 col-form-label font-weight-bold text-secondary">Mata Pelajaran / Jadwal:</label>
                <div class="col-sm-6">
                    <select id="analisis_exam_select" class="form-control select2bs4" style="border-radius: 6px;">
                        <option value="">-- Pilih Mata Pelajaran --</option>
                        <?php foreach ($exams as $e): ?>
                            <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['name']) ?> (Token: <?= htmlspecialchars($e['token']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-sm-2">
                    <button class="btn btn-info btn-block shadow-sm font-weight-bold" onclick="loadAnalisis()" style="border-radius: 6px;">
                        <i class="fas fa-chart-line mr-1"></i> Analisis
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Container Hasil Analisis -->
    <div id="analisis-result-container" class="card card-outline card-primary shadow-sm border-0" style="display: none; border-radius: 8px;">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap py-2" style="gap: 10px;">
            <div class="d-flex align-items-center">
                <h4 class="card-title font-weight-bold text-dark mb-0 mr-3">
                    <i class="fas fa-chart-bar text-primary mr-2"></i>Hasil Analisis Butir Soal
                </h4>
                <span class="badge badge-primary px-3 py-2 mr-2" id="analisis_exam_badge" style="font-size: 0.85rem; border-radius: 6px;">-</span>
                <span class="badge badge-success px-3 py-2" id="analisis_total_student" style="font-size: 0.85rem; border-radius: 6px;">Total Peserta: 0</span>
            </div>
            <div class="card-tools d-flex align-items-center">
                <button class="btn btn-success btn-sm font-weight-bold shadow-sm px-3 py-2" id="btn_export_analisis" onclick="exportAnalisisExcel()" style="border-radius: 6px;" title="Unduh format standar Analisis Butir Soal (.xlsx)">
                    <i class="fas fa-file-excel mr-1"></i> Ekspor Excel (.xlsx)
                </button>
            </div>
        </div>

        <div class="card-body">
            <!-- Stat Cards Row -->
            <div class="row mb-4" id="analisis-stat-cards" style="display: none;">
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="p-3 bg-light rounded border border-light h-100 shadow-none">
                        <div class="text-uppercase text-muted font-weight-bold" style="font-size: 0.75rem;">Total Peserta & Soal</div>
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <h4 class="font-weight-bold mb-0 text-dark" id="stat_students_count">0</h4>
                            <span class="badge badge-secondary px-2 py-1" id="stat_questions_count">0 Soal</span>
                        </div>
                        <div class="small text-muted mt-1" id="stat_class_info">Ujian CBT Selesai</div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="p-3 bg-light rounded border border-light h-100 shadow-none">
                        <div class="text-uppercase text-muted font-weight-bold" style="font-size: 0.75rem;">Rata-rata & Ketuntasan</div>
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <h4 class="font-weight-bold mb-0 text-info" id="stat_avg_score">0.0</h4>
                            <span class="badge badge-info px-2 py-1" id="stat_completeness">0% Tuntas</span>
                        </div>
                        <div class="small text-muted mt-1" id="stat_kkm_info">Standar KKM: 75</div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="p-3 bg-light rounded border border-light h-100 shadow-none">
                        <div class="text-uppercase text-muted font-weight-bold" style="font-size: 0.75rem;">Sebaran Tingkat Kesukaran</div>
                        <div class="d-flex justify-content-between align-items-center mt-2" style="gap: 4px;">
                            <span class="badge badge-success px-2 py-1" id="stat_mudah_badge">Mudah: 0</span>
                            <span class="badge badge-warning px-2 py-1" id="stat_sedang_badge">Sedang: 0</span>
                            <span class="badge badge-danger px-2 py-1" id="stat_sukar_badge">Sukar: 0</span>
                        </div>
                        <div class="small text-muted mt-1">Klasifikasi Indeks Kesukaran $P$</div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="p-3 bg-light rounded border border-light h-100 shadow-none">
                        <div class="text-uppercase text-muted font-weight-bold" style="font-size: 0.75rem;">Status Kualitas Butir Soal</div>
                        <div class="d-flex justify-content-between align-items-center mt-2" style="gap: 4px;">
                            <span class="badge badge-success px-2 py-1" id="stat_diterima_badge">Diterima: 0</span>
                            <span class="badge badge-warning px-2 py-1" id="stat_revisi_badge">Revisi: 0</span>
                            <span class="badge badge-danger px-2 py-1" id="stat_ditolak_badge">Ditolak: 0</span>
                        </div>
                        <div class="small text-muted mt-1">Daya Pembeda & Psikometri</div>
                    </div>
                </div>
            </div>

            <!-- Nav Tabs -->
            <ul class="nav nav-pills mb-3" id="analisisTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active font-weight-bold" id="tab-rekap-link" data-toggle="pill" href="#tab-rekap" role="tab">
                        <i class="fas fa-list-ol mr-1"></i> Rekap Analisis Butir Soal
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" id="tab-matriks-link" data-toggle="pill" href="#tab-matriks" role="tab">
                        <i class="fas fa-th mr-1"></i> Matriks Jawaban Siswa
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" id="tab-distribusi-link" data-toggle="pill" href="#tab-distribusi" role="tab">
                        <i class="fas fa-chart-pie mr-1"></i> Sebaran Pilihan (Distraktor)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" id="tab-statistik-link" data-toggle="pill" href="#tab-statistik" role="tab">
                        <i class="fas fa-info-circle mr-1"></i> Statistik & Ketuntasan
                    </a>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="analisisTabContent">
                <!-- TAB 1: REKAP ANALISIS BUTIR SOAL -->
                <div class="tab-pane fade show active" id="tab-rekap" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover mb-0">
                            <thead class="thead-light">
                                <tr class="text-center align-middle">
                                    <th style="width: 50px;">No</th>
                                    <th>Soal</th>
                                    <th style="width: 110px;">Bentuk</th>
                                    <th style="width: 80px;">Kunci</th>
                                    <th style="width: 140px;">Benar / Menjawab</th>
                                    <th style="width: 140px;">Tingkat Kesukaran</th>
                                    <th style="width: 140px;">Daya Pembeda</th>
                                    <th style="width: 120px;">Rekomendasi</th>
                                </tr>
                            </thead>
                            <tbody id="analisis-tbody">
                                <tr><td colspan="8" class="text-center py-4 text-muted">Silakan pilih mata pelajaran dan klik Analisis.</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- TAB 2: MATRIKS JAWABAN SISWA -->
                <div class="tab-pane fade" id="tab-matriks" role="tabpanel">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="small text-muted font-weight-bold">
                            <i class="fas fa-check text-success mr-1"></i> Skor 1 = Benar, <i class="fas fa-times text-danger mr-1"></i> Skor 0 = Salah / Kosong
                        </span>
                        <span class="badge badge-light border" id="matriks_student_count">0 Siswa</span>
                    </div>
                    <div class="table-responsive" style="max-height: 520px; overflow-y: auto;">
                        <table class="table table-bordered table-sm text-center mb-0" id="matriks-table" style="font-size: 0.85rem;">
                            <thead class="thead-dark sticky-top" id="matriks-thead">
                                <tr><th>Memuat matriks...</th></tr>
                            </thead>
                            <tbody id="matriks-tbody">
                                <tr><td class="text-muted py-3">Belum ada data.</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- TAB 3: SEBARAN PILIHAN JAWABAN (DISTRAKTOR) -->
                <div class="tab-pane fade" id="tab-distribusi" role="tabpanel">
                    <p class="text-muted small mb-2">
                        Distribusi jumlah siswa yang memilih masing-masing opsi pilihan ganda. Kunci jawaban ditandai dengan tanda centang hijau (<i class="fas fa-check-circle text-success"></i>).
                    </p>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover mb-0 text-center">
                            <thead class="thead-light">
                                <tr>
                                    <th style="width: 60px;">No</th>
                                    <th>Soal</th>
                                    <th style="width: 80px;">Kunci</th>
                                    <th style="width: 80px;">Opsi A</th>
                                    <th style="width: 80px;">Opsi B</th>
                                    <th style="width: 80px;">Opsi C</th>
                                    <th style="width: 80px;">Opsi D</th>
                                    <th style="width: 80px;">Opsi E</th>
                                    <th style="width: 90px;">Kosong</th>
                                    <th style="width: 120px;">Total Peserta</th>
                                </tr>
                            </thead>
                            <tbody id="distribusi-tbody">
                                <tr><td colspan="10" class="text-center py-4 text-muted">Belum ada data.</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- TAB 4: STATISTIK & KETUNTASAN -->
                <div class="tab-pane fade" id="tab-statistik" role="tabpanel">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="card card-outline card-secondary h-100 shadow-none border">
                                <div class="card-header py-2">
                                    <h6 class="font-weight-bold mb-0 text-dark"><i class="fas fa-calculator mr-1 text-primary"></i> Parameter & Statistik Nilai</h6>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-sm table-striped mb-0">
                                        <tbody>
                                            <tr><td class="font-weight-bold pl-3" style="width: 50%;">Jumlah Peserta Selesai</td><td id="stat_detail_peserta">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Jumlah Butir Soal</td><td id="stat_detail_soal">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Kriteria Ketuntasan (KKM)</td><td id="stat_detail_kkm">75</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Nilai Tertinggi (Max)</td><td class="text-success font-weight-bold" id="stat_detail_max">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Nilai Terendah (Min)</td><td class="text-danger font-weight-bold" id="stat_detail_min">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Nilai Rata-rata (Mean)</td><td class="text-primary font-weight-bold" id="stat_detail_mean">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Standar Deviasi (Simpangan Baku)</td><td id="stat_detail_std">-</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="card card-outline card-secondary h-100 shadow-none border">
                                <div class="card-header py-2">
                                    <h6 class="font-weight-bold mb-0 text-dark"><i class="fas fa-graduation-cap mr-1 text-success"></i> Ketuntasan Belajar Siswa</h6>
                                </div>
                                <div class="card-body p-0">
                                    <table class="table table-sm table-striped mb-0">
                                        <tbody>
                                            <tr><td class="font-weight-bold pl-3" style="width: 50%;">Siswa Tuntas (&ge; KKM)</td><td class="text-success font-weight-bold" id="stat_detail_tuntas">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Siswa Remedial (&lt; KKM)</td><td class="text-danger font-weight-bold" id="stat_detail_remedial">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Persentase Ketuntasan Klasikal</td><td class="font-weight-bold" id="stat_detail_persen_tuntas">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Status Ketuntasan Klasikal</td><td id="stat_detail_status_klasikal">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Kelompok Atas (Upper Group)</td><td id="stat_detail_upper_group">-</td></tr>
                                            <tr><td class="font-weight-bold pl-3">Kelompok Bawah (Lower Group)</td><td id="stat_detail_lower_group">-</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // State global data analisis
    let currentAnalysisData = null;
    const globalSchoolName = <?= json_encode($schoolName) ?>;

    async function loadAnalisis() {
        const examSelect = document.getElementById('analisis_exam_select');
        const examId = examSelect.value;
        if (!examId) {
            Swal.fire('Oops', 'Pilih mata pelajaran terlebih dahulu', 'warning');
            return;
        }
        
        const container = document.getElementById('analisis-result-container');
        const tbody = document.getElementById('analisis-tbody');
        const totalStudentSpan = document.getElementById('analisis_total_student');
        const examBadge = document.getElementById('analisis_exam_badge');
        const statCards = document.getElementById('analisis-stat-cards');
        
        container.style.display = 'block';
        statCards.style.display = 'none';
        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4"><i class="fas fa-spinner fa-spin mr-2 text-primary"></i> Mengolah data psikometri & analisis butir soal...</td></tr>';
        totalStudentSpan.textContent = 'Memuat...';
        examBadge.textContent = examSelect.options[examSelect.selectedIndex].text.split('(Token:')[0].trim();
        
        try {
            const res = await fetch(`api.php?action=get_item_analysis&exam_id=${examId}`);
            const text = await res.text();
            let json;
            try {
                json = JSON.parse(text);
            } catch (err) {
                console.error("Non-JSON API response:", text);
                tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger py-4">Gagal memproses data server: ${text.replace(/<[^>]*>?/gm, '').substring(0, 150)}</td></tr>`;
                totalStudentSpan.textContent = 'Error';
                return;
            }
            
            if (json.status === 'success') {
                const data = json.data;
                currentAnalysisData = data;
                totalStudentSpan.textContent = `Total Peserta Selesai: ${data.total_students}`;
                
                if (!data.analysis || data.analysis.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted font-italic">Tidak ada butir soal atau belum ada siswa yang menyelesaikan ujian ini.</td></tr>';
                    return;
                }
                
                // Tampilkan Stat Cards
                statCards.style.display = 'flex';
                const stats = data.statistics || {};
                const info = data.exam_info || {};
                
                document.getElementById('stat_students_count').textContent = data.total_students;
                document.getElementById('stat_questions_count').textContent = `${data.analysis.length} Soal`;
                document.getElementById('stat_avg_score').textContent = stats.average_score !== undefined ? Number(stats.average_score).toFixed(1) : '0';
                document.getElementById('stat_completeness').textContent = `${stats.completeness_percent || 0}% Tuntas`;
                document.getElementById('stat_kkm_info').textContent = `Standar KKM: ${info.kkm || 75}`;
                
                const diffSum = stats.difficulty_summary || {};
                document.getElementById('stat_mudah_badge').textContent = `Mudah: ${diffSum['Mudah'] || 0}`;
                document.getElementById('stat_sedang_badge').textContent = `Sedang: ${diffSum['Sedang'] || 0}`;
                document.getElementById('stat_sukar_badge').textContent = `Sukar: ${diffSum['Sukar'] || 0}`;
                
                const recSum = stats.recommendation_summary || {};
                document.getElementById('stat_diterima_badge').textContent = `Diterima: ${recSum['Diterima'] || 0}`;
                document.getElementById('stat_revisi_badge').textContent = `Revisi: ${recSum['Direvisi'] || 0}`;
                document.getElementById('stat_ditolak_badge').textContent = `Ditolak: ${recSum['Ditolak'] || 0}`;

                // Detail Tab Statistik
                document.getElementById('stat_detail_peserta').textContent = `${data.total_students} Orang`;
                document.getElementById('stat_detail_soal').textContent = `${data.analysis.length} Butir`;
                document.getElementById('stat_detail_kkm').textContent = info.kkm || 75;
                document.getElementById('stat_detail_max').textContent = stats.highest_score || 0;
                document.getElementById('stat_detail_min').textContent = stats.lowest_score || 0;
                document.getElementById('stat_detail_mean').textContent = stats.average_score || 0;
                document.getElementById('stat_detail_std').textContent = stats.standard_deviation || 0;
                
                document.getElementById('stat_detail_tuntas').textContent = `${stats.passed_count || 0} Siswa`;
                document.getElementById('stat_detail_remedial').textContent = `${stats.failed_count || 0} Siswa`;
                document.getElementById('stat_detail_persen_tuntas').textContent = `${stats.completeness_percent || 0}%`;
                
                const isKlasikalTercapai = (stats.completeness_percent || 0) >= 85;
                document.getElementById('stat_detail_status_klasikal').innerHTML = isKlasikalTercapai 
                    ? '<span class="badge badge-success px-2 py-1"><i class="fas fa-check mr-1"></i> Tercapai (&ge; 85%)</span>'
                    : '<span class="badge badge-warning px-2 py-1"><i class="fas fa-exclamation-triangle mr-1"></i> Belum Tercapai (&lt; 85%)</span>';
                
                document.getElementById('stat_detail_upper_group').textContent = `${info.upper_count || 0} Siswa Tertinggi`;
                document.getElementById('stat_detail_lower_group').textContent = `${info.lower_count || 0} Siswa Terendah`;

                // Render TAB 1: Rekap Analisis Butir Soal
                let htmlRekap = '';
                data.analysis.forEach((item, index) => {
                    // Kesukaran
                    let diffBadge = 'badge-secondary';
                    if (item.difficulty_level === 'Mudah') diffBadge = 'badge-success';
                    else if (item.difficulty_level === 'Sedang') diffBadge = 'badge-warning';
                    else if (item.difficulty_level === 'Sukar') diffBadge = 'badge-danger';
                    
                    // Daya Pembeda
                    let dpBadge = 'badge-secondary';
                    if (item.discrimination_level === 'Sangat Baik' || item.discrimination_level === 'Baik') dpBadge = 'badge-success';
                    else if (item.discrimination_level === 'Cukup') dpBadge = 'badge-warning';
                    else if (item.discrimination_level === 'Jelek' || item.discrimination_level === 'Sangat Jelek') dpBadge = 'badge-danger';

                    // Rekomendasi
                    let recBadge = 'badge-secondary';
                    if (item.recommendation === 'Diterima') recBadge = 'badge-success';
                    else if (item.recommendation === 'Direvisi') recBadge = 'badge-warning';
                    else if (item.recommendation === 'Ditolak') recBadge = 'badge-danger';

                    let typeLabel = 'Pilihan Ganda';
                    if (item.type === 'complex_mc') typeLabel = 'PG Kompleks';
                    else if (item.type === 'true_false') typeLabel = 'Benar / Salah';
                    else if (item.type === 'matching') typeLabel = 'Menjodohkan';
                    else if (item.type === 'essay') typeLabel = 'Esai';

                    const qText = item.question ? String(item.question).replace(/(<([^>]+)>)/gi, "").substring(0, 95) + (String(item.question).length > 95 ? '...' : '') : '-';
                    const statText = item.type === 'essay' 
                        ? `Rata: ${(item.avg_points_awarded || 0).toFixed(1)} / ${item.max_points}`
                        : `${item.correct_count} dari ${item.attempt_count} (${item.correct_percentage}%)`;

                    const dpText = item.discrimination_index !== undefined ? Number(item.discrimination_index).toFixed(3) : '-';
                    const diffText = item.difficulty_index !== undefined ? Number(item.difficulty_index).toFixed(3) : '-';

                    htmlRekap += `
                        <tr>
                            <td class="text-center align-middle font-weight-bold">${index + 1}</td>
                            <td class="align-middle" style="max-width: 320px;">
                                <div class="font-weight-normal text-dark">${qText}</div>
                            </td>
                            <td class="text-center align-middle">
                                <span class="badge badge-light border text-muted" style="font-size: 0.8rem; padding: 4px 7px;">${typeLabel}</span>
                            </td>
                            <td class="text-center align-middle">
                                <span class="badge badge-info px-2 py-1" style="font-size: 0.85rem;">${item.key || '-'}</span>
                            </td>
                            <td class="text-center align-middle font-weight-bold" style="font-size: 0.85rem;">
                                ${statText}
                            </td>
                            <td class="text-center align-middle">
                                <span class="badge ${diffBadge} px-2 py-1" style="font-size: 0.8rem;">
                                    ${diffText} (${item.difficulty_level || '-'})
                                </span>
                            </td>
                            <td class="text-center align-middle">
                                <span class="badge ${dpBadge} px-2 py-1" style="font-size: 0.8rem;">
                                    ${dpText} (${item.discrimination_level || '-'})
                                </span>
                            </td>
                            <td class="text-center align-middle">
                                <span class="badge ${recBadge} px-2 py-1 font-weight-bold" style="font-size: 0.85rem;">
                                    ${item.recommendation || '-'}
                                </span>
                            </td>
                        </tr>
                    `;
                });
                tbody.innerHTML = htmlRekap;

                // Render TAB 2: Matriks Jawaban Siswa
                renderMatriksSiswa(data);

                // Render TAB 3: Sebaran Pilihan Jawaban
                renderDistribusiPilihan(data);

            } else {
                tbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-danger font-weight-bold">Gagal: ${json.message}</td></tr>`;
            }
        } catch (e) {
            console.error("Load analisis error:", e);
            tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-danger font-weight-bold">Terjadi kesalahan jaringan atau server tidak merespons.</td></tr>';
        }
    }

    function renderMatriksSiswa(data) {
        const thead = document.getElementById('matriks-thead');
        const tbody = document.getElementById('matriks-tbody');
        const students = data.students || [];
        const analysis = data.analysis || [];
        const info = data.exam_info || {};
        const kkm = info.kkm || 75;

        document.getElementById('matriks_student_count').textContent = `${students.length} Siswa Mengerjakan`;

        if (students.length === 0) {
            thead.innerHTML = '<tr><th>No</th><th>Nama Siswa</th><th>Kelas</th><th>Status</th></tr>';
            tbody.innerHTML = '<tr><td colspan="4" class="text-center py-3 text-muted">Belum ada siswa yang menyelesaikan ujian ini.</td></tr>';
            return;
        }

        // Header Matriks
        let thHtml = '<tr><th style="width: 45px;">No</th><th style="min-width: 170px;" class="text-left">Nama Siswa</th><th style="min-width: 90px;">Kelas</th>';
        analysis.forEach((q, i) => {
            thHtml += `<th style="width: 38px;" title="Soal ${i + 1} (Kunci: ${q.key})">S${i + 1}</th>`;
        });
        thHtml += '<th style="width: 55px;" class="bg-success text-white">B</th>';
        thHtml += '<th style="width: 55px;" class="bg-danger text-white">S</th>';
        thHtml += '<th style="width: 65px;" class="bg-primary text-white">Nilai</th>';
        thHtml += '<th style="width: 90px;">Status</th></tr>';

        // Baris Kunci Jawaban
        let keyRowHtml = '<tr class="bg-light font-weight-bold"><td colspan="3" class="text-right pr-2">KUNCI JAWABAN:</td>';
        analysis.forEach((q) => {
            keyRowHtml += `<td class="text-primary font-weight-bold">${q.key || '-'}</td>`;
        });
        keyRowHtml += '<td colspan="4"></td></tr>';

        thead.innerHTML = thHtml + keyRowHtml;

        // Baris Data Siswa
        let bodyHtml = '';
        students.forEach((s, sIdx) => {
            const isPassed = s.score >= kkm;
            bodyHtml += `<tr>
                <td>${sIdx + 1}</td>
                <td class="text-left font-weight-bold text-dark">${s.name}</td>
                <td><span class="badge badge-light border">${s.class_name || '-'}</span></td>
            `;

            analysis.forEach((q) => {
                const item = s.items && s.items[q.originalId] ? s.items[q.originalId] : null;
                if (!item) {
                    bodyHtml += '<td class="text-muted bg-light">-</td>';
                } else if (item.is_correct) {
                    bodyHtml += '<td style="background-color: #E2EFDA; color: #276A3C; font-weight: bold;" title="Benar (1)">1</td>';
                } else {
                    bodyHtml += '<td style="background-color: #FCE4D6; color: #C65911; font-weight: bold;" title="Salah (0)">0</td>';
                }
            });

            bodyHtml += `
                <td class="font-weight-bold text-success">${s.correct_count || 0}</td>
                <td class="font-weight-bold text-danger">${s.wrong_count || 0}</td>
                <td class="font-weight-bold text-primary" style="font-size: 0.95rem;">${s.score}</td>
                <td>
                    <span class="badge ${isPassed ? 'badge-success' : 'badge-danger'} px-2 py-1 font-weight-bold">
                        ${isPassed ? 'Tuntas' : 'Remedial'}
                    </span>
                </td>
            </tr>`;
        });

        // Baris Total Benar & Tingkat Kesukaran Bawah
        let sumCorrectHtml = '<tr class="bg-light font-weight-bold"><td colspan="3" class="text-right pr-2">Total Siswa Benar:</td>';
        analysis.forEach((q) => {
            sumCorrectHtml += `<td class="text-success">${q.correct_count}</td>`;
        });
        sumCorrectHtml += '<td colspan="4"></td></tr>';

        let diffRowHtml = '<tr class="bg-light font-weight-bold"><td colspan="3" class="text-right pr-2">Tingkat Kesukaran (P):</td>';
        analysis.forEach((q) => {
            diffRowHtml += `<td>${q.difficulty_index !== undefined ? Number(q.difficulty_index).toFixed(2) : '-'}</td>`;
        });
        diffRowHtml += '<td colspan="4"></td></tr>';

        tbody.innerHTML = bodyHtml + sumCorrectHtml + diffRowHtml;
    }

    function renderDistribusiPilihan(data) {
        const tbody = document.getElementById('distribusi-tbody');
        const analysis = data.analysis || [];

        if (analysis.length === 0) {
            tbody.innerHTML = '<tr><td colspan="10" class="text-center py-3 text-muted">Belum ada data.</td></tr>';
            return;
        }

        let html = '';
        analysis.forEach((q, idx) => {
            const opts = q.options_count || { A: 0, B: 0, C: 0, D: 0, E: 0, Kosong: 0 };
            const qKey = String(q.key || '').trim().toUpperCase();
            const cleanQ = q.question_clean ? q.question_clean.substring(0, 85) + (q.question_clean.length > 85 ? '...' : '') : `Soal #${idx + 1}`;

            const renderOptCell = (optLetter) => {
                const count = opts[optLetter] || 0;
                const isKey = qKey === optLetter;
                if (isKey) {
                    return `<td style="background-color: #E2EFDA; color: #276A3C; font-weight: bold;">
                        ${count} <i class="fas fa-check-circle text-success ml-1" title="Kunci Jawaban"></i>
                    </td>`;
                }
                return `<td>${count}</td>`;
            };

            html += `<tr>
                <td class="font-weight-bold">${idx + 1}</td>
                <td class="text-left">${cleanQ}</td>
                <td class="font-weight-bold text-primary">${q.key || '-'}</td>
                ${renderOptCell('A')}
                ${renderOptCell('B')}
                ${renderOptCell('C')}
                ${renderOptCell('D')}
                ${renderOptCell('E')}
                <td class="text-muted">${opts.Kosong || 0}</td>
                <td class="font-weight-bold text-dark">${data.total_students}</td>
            </tr>`;
        });

        tbody.innerHTML = html;
    }

    /**
     * EKSPOR EXCEL FORMAT STANDAR ANALISIS BUTIR SOAL INDONESIA (.XLSX)
     * Menggunakan pustaka xlsx-js-style untuk styling sel, border, warna, dan multi-sheet
     */
    function exportAnalisisExcel() {
        if (!currentAnalysisData || !currentAnalysisData.analysis || currentAnalysisData.analysis.length === 0) {
            Swal.fire('Informasi', 'Belum ada data analisis untuk diekspor. Silakan pilih mata pelajaran dan jalankan Analisis terlebih dahulu.', 'info');
            return;
        }

        if (typeof XLSX === 'undefined') {
            Swal.fire('Error', 'Pustaka Excel (SheetJS / xlsx-js-style) belum termuat. Silakan muat ulang halaman.', 'error');
            return;
        }

        const data = currentAnalysisData;
        const examInfo = data.exam_info || {};
        const stats = data.statistics || {};
        const analysis = data.analysis || [];
        const students = data.students || [];

        Swal.fire({
            title: 'Menyiapkan Berkas Excel...',
            html: '<i class="fas fa-spinner fa-spin fa-2x text-success mb-2"></i><br>Sedang menyusun lembar standar Analisis Butir Soal...',
            showConfirmButton: false,
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        setTimeout(() => {
            try {
                // Definisi Styles Border & Palet Warna Standar Kemendikbud / Evaluasi Pembelajaran
                const borderThin = {
                    top: { style: 'thin', color: { rgb: 'D0D7DE' } },
                    bottom: { style: 'thin', color: { rgb: 'D0D7DE' } },
                    left: { style: 'thin', color: { rgb: 'D0D7DE' } },
                    right: { style: 'thin', color: { rgb: 'D0D7DE' } }
                };
                const borderDark = {
                    top: { style: 'thin', color: { rgb: '000000' } },
                    bottom: { style: 'thin', color: { rgb: '000000' } },
                    left: { style: 'thin', color: { rgb: '000000' } },
                    right: { style: 'thin', color: { rgb: '000000' } }
                };

                const styleTitle = {
                    font: { name: 'Calibri', sz: 14, bold: true, color: { rgb: '1F497D' } },
                    alignment: { vertical: 'center', horizontal: 'center' }
                };
                const styleSubtitle = {
                    font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '333333' } },
                    alignment: { vertical: 'center', horizontal: 'center' }
                };
                const styleMetaLabel = {
                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left' }
                };
                const styleMetaVal = {
                    font: { name: 'Calibri', sz: 10, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left' }
                };

                const styleHeaderDark = {
                    fill: { fgColor: { rgb: '1F497D' } },
                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: 'FFFFFF' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderDark
                };
                const styleHeaderSub = {
                    fill: { fgColor: { rgb: 'D9E1F2' } },
                    font: { name: 'Calibri', sz: 9, bold: true, color: { rgb: '1F497D' } },
                    alignment: { vertical: 'center', horizontal: 'center', wrapText: true },
                    border: borderDark
                };
                const styleKeyRow = {
                    fill: { fgColor: { rgb: 'FFF2CC' } },
                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '7F6000' } },
                    alignment: { vertical: 'center', horizontal: 'center' },
                    border: borderDark
                };

                const styleCellCenter = {
                    font: { name: 'Calibri', sz: 10, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'center' },
                    border: borderThin
                };
                const styleCellLeft = {
                    font: { name: 'Calibri', sz: 10, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'left', wrapText: true },
                    border: borderThin
                };
                const styleCellNumber = {
                    font: { name: 'Calibri', sz: 10, color: { rgb: '000000' } },
                    alignment: { vertical: 'center', horizontal: 'right' },
                    border: borderThin
                };

                // Badge Styles
                const styleGreen = {
                    fill: { fgColor: { rgb: 'E2EFDA' } },
                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '375623' } },
                    alignment: { vertical: 'center', horizontal: 'center' },
                    border: borderThin
                };
                const styleYellow = {
                    fill: { fgColor: { rgb: 'FFF2CC' } },
                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '7F6000' } },
                    alignment: { vertical: 'center', horizontal: 'center' },
                    border: borderThin
                };
                const styleRed = {
                    fill: { fgColor: { rgb: 'FCE4D6' } },
                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: 'C65911' } },
                    alignment: { vertical: 'center', horizontal: 'center' },
                    border: borderThin
                };

                const workbook = XLSX.utils.book_new();

                /* =========================================================================
                 * SHEET 1: REKAP ANALISIS KUALITAS BUTIR SOAL
                 * ========================================================================= */
                const s1Data = [];
                s1Data.push(['LAPORAN ANALISIS BUTIR SOAL (ITEM ANALYSIS REPORT)']);
                s1Data.push([examInfo.school_name || globalSchoolName]);
                s1Data.push([]);
                s1Data.push(['Mata Pelajaran / Ujian:', examInfo.name || 'Ujian', '', 'Tanggal Ujian:', examInfo.date || '-']);
                s1Data.push(['Token Ujian:', examInfo.token || '-', '', 'Jumlah Butir Soal:', `${analysis.length} Butir`]);
                s1Data.push(['Jumlah Peserta Selesai:', `${data.total_students} Orang`, '', 'Standar Kelulusan (KKM):', examInfo.kkm || 75]);
                s1Data.push(['Nilai Rata-rata Kelas:', stats.average_score || 0, '', 'Ketuntasan Klasikal:', `${stats.completeness_percent || 0}%`]);
                s1Data.push([]);

                // Header Baris 1 & 2
                const headerRow1 = [
                    'No',
                    'Butir Pertanyaan',
                    'Bentuk Soal',
                    'Kunci',
                    'Bobot',
                    'Jml Menjawab',
                    'Benar (B)',
                    'Salah (S)',
                    'Sebaran Pilihan Siswa (Distraktor)', '', '', '', '',
                    'Tingkat Kesukaran (P)', '',
                    'Daya Pembeda (DP)', '', '', '',
                    'Status / Rekomendasi'
                ];
                const headerRow2 = [
                    '', '', '', '', '', '', '', '',
                    'A', 'B', 'C', 'D', 'E',
                    'Indeks (P)', 'Kategori',
                    'Kel. Atas (BA)', 'Kel. Bawah (BB)', 'Indeks (D)', 'Kategori',
                    ''
                ];

                s1Data.push(headerRow1);
                s1Data.push(headerRow2);

                const s1TableStartRow = 9; // baris ke-10 (0-indexed 9)

                analysis.forEach((q, idx) => {
                    const opts = q.options_count || { A: 0, B: 0, C: 0, D: 0, E: 0 };
                    let typeLabel = 'Pilihan Ganda';
                    if (q.type === 'complex_mc') typeLabel = 'PG Kompleks';
                    else if (q.type === 'true_false') typeLabel = 'Benar / Salah';
                    else if (q.type === 'matching') typeLabel = 'Menjodohkan';
                    else if (q.type === 'essay') typeLabel = 'Esai';

                    const cleanQ = q.question_clean || `Soal #${idx + 1}`;
                    s1Data.push([
                        idx + 1,
                        cleanQ,
                        typeLabel,
                        q.key || '-',
                        q.max_points || 2,
                        q.attempt_count || 0,
                        q.correct_count || 0,
                        q.wrong_count || 0,
                        opts.A || 0,
                        opts.B || 0,
                        opts.C || 0,
                        opts.D || 0,
                        opts.E || 0,
                        q.difficulty_index !== undefined ? Number(q.difficulty_index) : 0,
                        q.difficulty_level || '-',
                        q.upper_correct_count || 0,
                        q.lower_correct_count || 0,
                        q.discrimination_index !== undefined ? Number(q.discrimination_index) : 0,
                        q.discrimination_level || '-',
                        q.recommendation || '-'
                    ]);
                });

                // Tambahkan Ringkasan di Bawah Tabel
                s1Data.push([]);
                s1Data.push(['RINGKASAN TINGKAT KESUKARAN SOAL', '', '', '', '', '', '', '', 'RINGKASAN REKOMENDASI BUTIR SOAL']);
                s1Data.push(['- Soal Mudah (P > 0.70):', `${stats.difficulty_summary?.Mudah || 0} Soal`, '', '', '', '', '', '', '- Diterima / Baik (DP >= 0.30):', `${stats.recommendation_summary?.Diterima || 0} Soal`]);
                s1Data.push(['- Soal Sedang (0.30 <= P <= 0.70):', `${stats.difficulty_summary?.Sedang || 0} Soal`, '', '', '', '', '', '', '- Perlu Revisi (0.20 <= DP < 0.30):', `${stats.recommendation_summary?.Direvisi || 0} Soal`]);
                s1Data.push(['- Soal Sukar (P < 0.30):', `${stats.difficulty_summary?.Sukar || 0} Soal`, '', '', '', '', '', '', '- Ditolak / Dibuang (DP < 0.20):', `${stats.recommendation_summary?.Ditolak || 0} Soal`]);

                const ws1 = XLSX.utils.aoa_to_sheet(s1Data);

                // Merges Sheet 1
                ws1['!merges'] = [
                    { s: { r: 0, c: 0 }, e: { r: 0, c: 19 } }, // Judul
                    { s: { r: 1, c: 0 }, e: { r: 1, c: 19 } }, // Subjudul
                    // Header Merges
                    { s: { r: s1TableStartRow, c: 0 }, e: { r: s1TableStartRow + 1, c: 0 } }, // No
                    { s: { r: s1TableStartRow, c: 1 }, e: { r: s1TableStartRow + 1, c: 1 } }, // Soal
                    { s: { r: s1TableStartRow, c: 2 }, e: { r: s1TableStartRow + 1, c: 2 } }, // Bentuk
                    { s: { r: s1TableStartRow, c: 3 }, e: { r: s1TableStartRow + 1, c: 3 } }, // Kunci
                    { s: { r: s1TableStartRow, c: 4 }, e: { r: s1TableStartRow + 1, c: 4 } }, // Bobot
                    { s: { r: s1TableStartRow, c: 5 }, e: { r: s1TableStartRow + 1, c: 5 } }, // Menjawab
                    { s: { r: s1TableStartRow, c: 6 }, e: { r: s1TableStartRow + 1, c: 6 } }, // Benar
                    { s: { r: s1TableStartRow, c: 7 }, e: { r: s1TableStartRow + 1, c: 7 } }, // Salah
                    { s: { r: s1TableStartRow, c: 8 }, e: { r: s1TableStartRow, c: 12 } },     // Sebaran Pilihan (A-E)
                    { s: { r: s1TableStartRow, c: 13 }, e: { r: s1TableStartRow, c: 14 } },   // Tingkat Kesukaran
                    { s: { r: s1TableStartRow, c: 15 }, e: { r: s1TableStartRow, c: 18 } },   // Daya Pembeda
                    { s: { r: s1TableStartRow, c: 19 }, e: { r: s1TableStartRow + 1, c: 19 } } // Rekomendasi
                ];

                // Column Widths Sheet 1
                ws1['!cols'] = [
                    { wch: 6 },  // No
                    { wch: 45 }, // Soal
                    { wch: 15 }, // Bentuk
                    { wch: 12 }, // Kunci
                    { wch: 8 },  // Bobot
                    { wch: 13 }, // Menjawab
                    { wch: 11 }, // Benar
                    { wch: 11 }, // Salah
                    { wch: 7 },  // A
                    { wch: 7 },  // B
                    { wch: 7 },  // C
                    { wch: 7 },  // D
                    { wch: 7 },  // E
                    { wch: 13 }, // P
                    { wch: 13 }, // Kategori P
                    { wch: 14 }, // BA
                    { wch: 14 }, // BB
                    { wch: 13 }, // D
                    { wch: 14 }, // Kategori D
                    { wch: 16 }  // Rekomendasi
                ];

                // Apply Styles Sheet 1
                const totalRows1 = s1Data.length;
                for (let R = 0; R < totalRows1; R++) {
                    for (let C = 0; C < 20; C++) {
                        const cellAddr = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!ws1[cellAddr]) continue;

                        if (R === 0) {
                            ws1[cellAddr].s = styleTitle;
                        } else if (R === 1) {
                            ws1[cellAddr].s = styleSubtitle;
                        } else if (R >= 3 && R <= 6) {
                            if (C === 0 || C === 3) ws1[cellAddr].s = styleMetaLabel;
                            else if (C === 1 || C === 4) ws1[cellAddr].s = styleMetaVal;
                        } else if (R === s1TableStartRow) {
                            ws1[cellAddr].s = styleHeaderDark;
                        } else if (R === s1TableStartRow + 1) {
                            ws1[cellAddr].s = (C >= 8 && C <= 18) ? styleHeaderSub : styleHeaderDark;
                        } else if (R >= s1TableStartRow + 2 && R < s1TableStartRow + 2 + analysis.length) {
                            // Baris Data Soal
                            if (C === 0) ws1[cellAddr].s = styleCellCenter;
                            else if (C === 1) ws1[cellAddr].s = styleCellLeft;
                            else if (C === 2 || C === 3) ws1[cellAddr].s = styleCellCenter;
                            else if (C >= 4 && C <= 12) ws1[cellAddr].s = styleCellCenter;
                            else if (C === 13) {
                                ws1[cellAddr].s = styleCellNumber;
                                ws1[cellAddr].z = '0.000';
                            } else if (C === 14) {
                                const val = ws1[cellAddr].v;
                                if (val === 'Mudah') ws1[cellAddr].s = styleGreen;
                                else if (val === 'Sedang') ws1[cellAddr].s = styleYellow;
                                else if (val === 'Sukar') ws1[cellAddr].s = styleRed;
                                else ws1[cellAddr].s = styleCellCenter;
                            } else if (C >= 15 && C <= 16) {
                                ws1[cellAddr].s = styleCellCenter;
                            } else if (C === 17) {
                                ws1[cellAddr].s = styleCellNumber;
                                ws1[cellAddr].z = '0.000';
                            } else if (C === 18) {
                                const val = ws1[cellAddr].v;
                                if (val === 'Sangat Baik' || val === 'Baik') ws1[cellAddr].s = styleGreen;
                                else if (val === 'Cukup') ws1[cellAddr].s = styleYellow;
                                else if (val === 'Jelek' || val === 'Sangat Jelek') ws1[cellAddr].s = styleRed;
                                else ws1[cellAddr].s = styleCellCenter;
                            } else if (C === 19) {
                                const val = ws1[cellAddr].v;
                                if (val === 'Diterima') ws1[cellAddr].s = styleGreen;
                                else if (val === 'Direvisi') ws1[cellAddr].s = styleYellow;
                                else if (val === 'Ditolak') ws1[cellAddr].s = styleRed;
                                else ws1[cellAddr].s = styleCellCenter;
                            }
                        }
                    }
                }

                XLSX.utils.book_append_sheet(workbook, ws1, "Analisis Kualitas Soal");

                /* =========================================================================
                 * SHEET 2: MATRIKS SKOR SISWA PER BUTIR SOAL
                 * ========================================================================= */
                const s2Data = [];
                s2Data.push(['MATRIKS SKOR JAWABAN SISWA PER BUTIR SOAL']);
                s2Data.push([`${examInfo.name || 'Ujian'} - ${examInfo.school_name || globalSchoolName}`]);
                s2Data.push([]);

                // Header Matriks
                const s2Header = ['No', 'No. Peserta / NIS', 'Nama Siswa', 'Kelas'];
                analysis.forEach((q, i) => {
                    s2Header.push(`S${i + 1}`);
                });
                s2Header.push('Benar (B)', 'Salah (S)', 'Total Skor', 'Nilai (0-100)', 'Ketuntasan');
                s2Data.push(s2Header);

                // Baris Kunci
                const s2KeyRow = ['', '', 'KUNCI JAWABAN', ''];
                analysis.forEach((q) => {
                    s2KeyRow.push(q.key || '-');
                });
                s2KeyRow.push('', '', '', '', '');
                s2Data.push(s2KeyRow);

                const s2TableStartRow = 3;

                // Baris Siswa
                students.forEach((s, sIdx) => {
                    const isPassed = s.score >= (examInfo.kkm || 75);
                    const row = [
                        sIdx + 1,
                        s.nis || '-',
                        s.name || '-',
                        s.class_name || '-'
                    ];
                    analysis.forEach((q) => {
                        const item = s.items && s.items[q.originalId] ? s.items[q.originalId] : null;
                        if (!item) row.push(0);
                        else row.push(item.is_correct ? 1 : 0);
                    });
                    row.push(
                        s.correct_count || 0,
                        s.wrong_count || 0,
                        s.score || 0,
                        s.score || 0,
                        isPassed ? 'Tuntas' : 'Remedial'
                    );
                    s2Data.push(row);
                });

                // Baris Footer Total Benar & Tingkat Kesukaran
                const s2SumRow = ['', '', 'JUMLAH SISWA BENAR (B)', ''];
                analysis.forEach((q) => {
                    s2SumRow.push(q.correct_count || 0);
                });
                s2SumRow.push('', '', '', '', '');
                s2Data.push(s2SumRow);

                const s2DiffRow = ['', '', 'TINGKAT KESUKARAN (P)', ''];
                analysis.forEach((q) => {
                    s2DiffRow.push(q.difficulty_index !== undefined ? Number(q.difficulty_index) : 0);
                });
                s2DiffRow.push('', '', '', '', '');
                s2Data.push(s2DiffRow);

                const ws2 = XLSX.utils.aoa_to_sheet(s2Data);

                // Col widths Sheet 2
                const s2Cols = [
                    { wch: 6 },  // No
                    { wch: 18 }, // NIS
                    { wch: 32 }, // Nama
                    { wch: 14 }  // Kelas
                ];
                analysis.forEach(() => {
                    s2Cols.push({ wch: 7 }); // Tiap soal
                });
                s2Cols.push(
                    { wch: 10 }, // Benar
                    { wch: 10 }, // Salah
                    { wch: 12 }, // Total Skor
                    { wch: 14 }, // Nilai
                    { wch: 14 }  // Ketuntasan
                );
                ws2['!cols'] = s2Cols;

                // Merges Sheet 2
                const totalCols2 = s2Header.length;
                ws2['!merges'] = [
                    { s: { r: 0, c: 0 }, e: { r: 0, c: totalCols2 - 1 } },
                    { s: { r: 1, c: 0 }, e: { r: 1, c: totalCols2 - 1 } },
                    { s: { r: 4, c: 0 }, e: { r: 4, c: 3 } }, // Merge Kunci Jawaban
                    { s: { r: 5 + students.length, c: 0 }, e: { r: 5 + students.length, c: 3 } }, // Merge Total Benar
                    { s: { r: 6 + students.length, c: 0 }, e: { r: 6 + students.length, c: 3 } }  // Merge Tingkat Kesukaran
                ];

                // Styles Sheet 2
                const totalRows2 = s2Data.length;
                for (let R = 0; R < totalRows2; R++) {
                    for (let C = 0; C < totalCols2; C++) {
                        const cellAddr = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!ws2[cellAddr]) continue;

                        if (R === 0) ws2[cellAddr].s = styleTitle;
                        else if (R === 1) ws2[cellAddr].s = styleSubtitle;
                        else if (R === s2TableStartRow) {
                            ws2[cellAddr].s = styleHeaderDark;
                        } else if (R === s2TableStartRow + 1) {
                            ws2[cellAddr].s = styleKeyRow;
                        } else if (R >= s2TableStartRow + 2 && R < s2TableStartRow + 2 + students.length) {
                            // Baris Siswa
                            if (C === 0) ws2[cellAddr].s = styleCellCenter;
                            else if (C === 1) ws2[cellAddr].s = styleCellCenter;
                            else if (C === 2) ws2[cellAddr].s = styleCellLeft;
                            else if (C === 3) ws2[cellAddr].s = styleCellCenter;
                            else if (C >= 4 && C < 4 + analysis.length) {
                                const val = ws2[cellAddr].v;
                                ws2[cellAddr].s = (val === 1) ? styleGreen : styleRed;
                            } else if (C === 4 + analysis.length || C === 4 + analysis.length + 1) {
                                ws2[cellAddr].s = styleCellCenter;
                            } else if (C === 4 + analysis.length + 2 || C === 4 + analysis.length + 3) {
                                ws2[cellAddr].s = {
                                    font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '1F497D' } },
                                    alignment: { vertical: 'center', horizontal: 'center' },
                                    border: borderThin
                                };
                            } else if (C === 4 + analysis.length + 4) {
                                const isPassed = ws2[cellAddr].v === 'Tuntas';
                                ws2[cellAddr].s = isPassed ? styleGreen : styleRed;
                            }
                        } else if (R >= s2TableStartRow + 2 + students.length) {
                            // Footer rows
                            ws2[cellAddr].s = {
                                fill: { fgColor: { rgb: 'D9E1F2' } },
                                font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '1F497D' } },
                                alignment: { vertical: 'center', horizontal: 'center' },
                                border: borderDark
                            };
                        }
                    }
                }

                XLSX.utils.book_append_sheet(workbook, ws2, "Matriks Skor Siswa");

                /* =========================================================================
                 * SHEET 3: DISTRIBUSI PILIHAN JAWABAN SISWA (SEBARAN DISTRAKTOR RIIL)
                 * ========================================================================= */
                const s3Data = [];
                s3Data.push(['DISTRIBUSI PILIHAN JAWABAN RIIL SISWA PER BUTIR SOAL']);
                s3Data.push([`${examInfo.name || 'Ujian'} - ${examInfo.school_name || globalSchoolName}`]);
                s3Data.push([]);

                const s3Header = ['No', 'No. Peserta / NIS', 'Nama Siswa', 'Kelas'];
                analysis.forEach((q, i) => {
                    s3Header.push(`S${i + 1}`);
                });
                s3Data.push(s3Header);

                const s3KeyRow = ['', '', 'KUNCI JAWABAN', ''];
                analysis.forEach((q) => {
                    s3KeyRow.push(q.key || '-');
                });
                s3Data.push(s3KeyRow);

                students.forEach((s, sIdx) => {
                    const row = [
                        sIdx + 1,
                        s.nis || '-',
                        s.name || '-',
                        s.class_name || '-'
                    ];
                    analysis.forEach((q) => {
                        const item = s.items && s.items[q.originalId] ? s.items[q.originalId] : null;
                        row.push(item ? (item.answer || '-') : '-');
                    });
                    s3Data.push(row);
                });

                const ws3 = XLSX.utils.aoa_to_sheet(s3Data);
                const s3Cols = [
                    { wch: 6 },  { wch: 18 }, { wch: 32 }, { wch: 14 }
                ];
                analysis.forEach(() => { s3Cols.push({ wch: 7 }); });
                ws3['!cols'] = s3Cols;

                const totalCols3 = s3Header.length;
                ws3['!merges'] = [
                    { s: { r: 0, c: 0 }, e: { r: 0, c: totalCols3 - 1 } },
                    { s: { r: 1, c: 0 }, e: { r: 1, c: totalCols3 - 1 } },
                    { s: { r: 4, c: 0 }, e: { r: 4, c: 3 } }
                ];

                const totalRows3 = s3Data.length;
                for (let R = 0; R < totalRows3; R++) {
                    for (let C = 0; C < totalCols3; C++) {
                        const cellAddr = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!ws3[cellAddr]) continue;

                        if (R === 0) ws3[cellAddr].s = styleTitle;
                        else if (R === 1) ws3[cellAddr].s = styleSubtitle;
                        else if (R === 3) ws3[cellAddr].s = styleHeaderDark;
                        else if (R === 4) ws3[cellAddr].s = styleKeyRow;
                        else if (R >= 5) {
                            if (C === 0) ws3[cellAddr].s = styleCellCenter;
                            else if (C === 1) ws3[cellAddr].s = styleCellCenter;
                            else if (C === 2) ws3[cellAddr].s = styleCellLeft;
                            else if (C === 3) ws3[cellAddr].s = styleCellCenter;
                            else {
                                const qIdx = C - 4;
                                const studentIdx = R - 5;
                                const student = students[studentIdx];
                                const question = analysis[qIdx];
                                const item = student && student.items ? student.items[question.originalId] : null;
                                if (item && item.is_correct) {
                                    ws3[cellAddr].s = styleGreen;
                                } else if (item && item.answer !== '-') {
                                    ws3[cellAddr].s = styleRed;
                                } else {
                                    ws3[cellAddr].s = styleCellCenter;
                                }
                            }
                        }
                    }
                }

                XLSX.utils.book_append_sheet(workbook, ws3, "Distribusi Pilihan Siswa");

                /* =========================================================================
                 * SHEET 4: REKAPITULASI & STATISTIK KETUNTASAN
                 * ========================================================================= */
                const s4Data = [];
                s4Data.push(['REKAPITULASI HASIL EVALUASI & KETUNTASAN BELAJAR']);
                s4Data.push([examInfo.school_name || globalSchoolName]);
                s4Data.push([]);
                s4Data.push(['I. IDENTITAS EVALUASI']);
                s4Data.push(['Mata Pelajaran / Nama Ujian', ':', examInfo.name || '-']);
                s4Data.push(['Token Ujian', ':', examInfo.token || '-']);
                s4Data.push(['Tanggal Pelaksanaan', ':', examInfo.date || '-']);
                s4Data.push(['Jumlah Butir Soal', ':', `${analysis.length} Butir`]);
                s4Data.push(['Kriteria Ketuntasan Minimal (KKM)', ':', examInfo.kkm || 75]);
                s4Data.push([]);
                s4Data.push(['II. STATISTIK HASIL UJIAN']);
                s4Data.push(['Jumlah Peserta Terdaftar & Selesai', ':', `${data.total_students} Siswa`]);
                s4Data.push(['Nilai Tertinggi (Maximum Score)', ':', stats.highest_score || 0]);
                s4Data.push(['Nilai Terendah (Minimum Score)', ':', stats.lowest_score || 0]);
                s4Data.push(['Nilai Rata-rata Kelas (Mean)', ':', stats.average_score || 0]);
                s4Data.push(['Standar Deviasi (Simpangan Baku)', ':', stats.standard_deviation || 0]);
                s4Data.push([]);
                s4Data.push(['III. ANALISIS KETUNTASAN KLASIKAL']);
                s4Data.push(['Jumlah Siswa Tuntas (>= KKM)', ':', `${stats.passed_count || 0} Siswa`]);
                s4Data.push(['Jumlah Siswa Remedial (< KKM)', ':', `${stats.failed_count || 0} Siswa`]);
                s4Data.push(['Persentase Ketuntasan Klasikal', ':', `${stats.completeness_percent || 0}%`]);
                const isTuntasKlasikal = (stats.completeness_percent || 0) >= 85;
                s4Data.push(['Kesimpulan Ketuntasan Belajar', ':', isTuntasKlasikal ? 'TUNTAS SECARA KLASIKAL (>= 85%)' : 'BELUM TUNTAS SECARA KLASIKAL (< 85%)']);
                s4Data.push([]);
                s4Data.push(['IV. PENGESAHAN LAPORAN']);
                s4Data.push([]);
                s4Data.push(['', 'Mengetahui,', '', '', '', 'Guru Mata Pelajaran,']);
                s4Data.push(['', 'Kepala Sekolah', '', '', '', '']);
                s4Data.push([]);
                s4Data.push([]);
                s4Data.push([]);
                s4Data.push(['', '( .................................................. )', '', '', '', '( .................................................. )']);
                s4Data.push(['', 'NIP. .............................................', '', '', '', 'NIP. .............................................']);

                const ws4 = XLSX.utils.aoa_to_sheet(s4Data);
                ws4['!cols'] = [
                    { wch: 38 },
                    { wch: 4 },
                    { wch: 35 },
                    { wch: 10 },
                    { wch: 10 },
                    { wch: 35 }
                ];

                ws4['!merges'] = [
                    { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } },
                    { s: { r: 1, c: 0 }, e: { r: 1, c: 5 } },
                    { s: { r: 3, c: 0 }, e: { r: 3, c: 2 } },
                    { s: { r: 10, c: 0 }, e: { r: 10, c: 2 } },
                    { s: { r: 17, c: 0 }, e: { r: 17, c: 2 } },
                    { s: { r: 23, c: 0 }, e: { r: 23, c: 2 } }
                ];

                for (let R = 0; R < s4Data.length; R++) {
                    for (let C = 0; C < 6; C++) {
                        const cellAddr = XLSX.utils.encode_cell({ r: R, c: C });
                        if (!ws4[cellAddr]) continue;
                        if (R === 0) ws4[cellAddr].s = styleTitle;
                        else if (R === 1) ws4[cellAddr].s = styleSubtitle;
                        else if (R === 3 || R === 10 || R === 17 || R === 23) {
                            ws4[cellAddr].s = {
                                font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '1F497D' } },
                                alignment: { vertical: 'center', horizontal: 'left' }
                            };
                        } else if (C === 0 && R < 23) {
                            ws4[cellAddr].s = styleMetaLabel;
                        } else if (C === 2 && R < 23) {
                            ws4[cellAddr].s = {
                                font: { name: 'Calibri', sz: 10, bold: true, color: { rgb: '000000' } },
                                alignment: { vertical: 'center', horizontal: 'left' }
                            };
                        }
                    }
                }

                XLSX.utils.book_append_sheet(workbook, ws4, "Statistik & Ketuntasan");

                // Download File Excel
                const cleanExam = (examInfo.name || 'Ujian').replace(/[^a-zA-Z0-9_-]/g, '_');
                const dateStr = new Date().toISOString().split('T')[0];
                const fileName = `Analisis_Butir_Soal_${cleanExam}_${dateStr}.xlsx`;

                XLSX.writeFile(workbook, fileName, { compression: true });
                Swal.close();

                Swal.fire({
                    title: 'Berhasil Diekspor!',
                    text: `Berkas Excel format standar analisis butir soal telah berhasil diunduh (${fileName}).`,
                    icon: 'success',
                    confirmButtonColor: '#28a745'
                });
            } catch (err) {
                console.error("Export Excel error:", err);
                Swal.fire('Gagal Mengekspor', 'Terjadi kesalahan teknis saat membuat berkas Excel: ' + (err.message || err), 'error');
            }
        }, 300);
    }
</script>
