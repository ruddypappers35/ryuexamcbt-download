<!-- SECTION: DASHBOARD -->
<div id="section-dashboard" class="content-section">
    <?php if (($user_role ?? 'admin') === 'guru'): ?>
    <div class="alert alert-info border-0 shadow-sm mb-4">
        <h5><i class="fas fa-chalkboard-teacher mr-2"></i> Selamat Datang, <?= htmlspecialchars($user_name ?? 'Bapak/Ibu Guru') ?>!</h5>
        <p class="mb-0">Anda masuk dengan peran <strong>Guru</strong>. Anda memiliki akses untuk mengunggah dan mengelola naskah pada menu <strong><a href="?page=soal" class="text-white font-weight-bold text-underline">Bank Soal</a></strong> serta memantau progres dan nilai siswa pada menu <strong><a href="?page=status" class="text-white font-weight-bold text-underline">Status Ujian</a></strong>.</p>
    </div>
    <?php endif; ?>

    <?php
    $totalGuru = isset($teachersCount) ? $teachersCount : count(array_filter(get_users(), function($u) { return ($u['role'] ?? 'guru') === 'guru'; }));
    $totalBankSoal = isset($bankSoalCount) ? $bankSoalCount : count($bank_soal ?? []);
    $totalUjianAktif = isset($activeExamsCount) ? $activeExamsCount : count(array_filter($exams ?? [], function($e) { return ($e['status'] ?? 'aktif') === 'aktif'; }));
    ?>

    <style>
    /* Desain Kartu Statistik Dashboard (Sesuai Referensi Gambar) */
    .stat-card-custom {
        position: relative;
        overflow: hidden;
        border-radius: 6px;
        padding: 20px 24px;
        color: #ffffff;
        min-height: 142px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: flex-end;
        text-align: right;
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.06);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .stat-card-custom:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    }
    .stat-card-bg-icon {
        position: absolute;
        left: -4px;
        bottom: -10px;
        font-size: 8rem;
        color: rgba(255, 255, 255, 0.18);
        pointer-events: none;
        user-select: none;
        line-height: 0.9;
        z-index: 1;
    }
    .stat-card-content {
        position: relative;
        z-index: 2;
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
    }
    .stat-card-value {
        font-size: 3.2rem;
        font-weight: 200;
        line-height: 1;
        letter-spacing: -1px;
        color: #ffffff;
        margin-bottom: 8px;
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .stat-card-title {
        font-size: 1.05rem;
        font-weight: 400;
        color: #ffffff;
        line-height: 1.25;
        margin-bottom: 3px;
    }
    .stat-card-subtitle {
        font-size: 0.88rem;
        color: rgba(255, 255, 255, 0.88);
        font-weight: 300;
        line-height: 1.25;
    }

    /* 4 Warna Tema Sesuai Gambar Referensi */
    .stat-card-teal {
        background-color: #48b5a3;
    }
    .stat-card-purple {
        background-color: #8371a3;
    }
    .stat-card-blue {
        background-color: #5499c7;
    }
    .stat-card-lavender {
        background-color: #8c7aa8;
    }
    </style>

    <!-- Info boxes / Stat Cards Modern -->
    <div class="row mb-2">
        <!-- 1. Jumlah Siswa (Teal) -->
        <div class="col-12 col-sm-6 col-md-3 mb-3">
            <div class="stat-card-custom stat-card-teal">
                <i class="fas fa-user-graduate stat-card-bg-icon"></i>
                <div class="stat-card-content">
                    <div class="stat-card-value"><?= $studentsCount ?></div>
                    <div class="stat-card-title">Jumlah Siswa</div>
                    <div class="stat-card-subtitle">Total Peserta Terdaftar</div>
                </div>
            </div>
        </div>

        <!-- 2. Jumlah Guru (Purple) -->
        <div class="col-12 col-sm-6 col-md-3 mb-3">
            <div class="stat-card-custom stat-card-purple">
                <i class="fas fa-chalkboard-teacher stat-card-bg-icon"></i>
                <div class="stat-card-content">
                    <div class="stat-card-value"><?= $totalGuru ?></div>
                    <div class="stat-card-title">Jumlah Guru</div>
                    <div class="stat-card-subtitle">Tenaga Pendidik &amp; Admin</div>
                </div>
            </div>
        </div>

        <!-- 3. Total Bank Soal (Blue) -->
        <div class="col-12 col-sm-6 col-md-3 mb-3">
            <div class="stat-card-custom stat-card-blue">
                <i class="fas fa-file-alt stat-card-bg-icon"></i>
                <div class="stat-card-content">
                    <div class="stat-card-value"><?= $totalBankSoal ?></div>
                    <div class="stat-card-title">Total Bank Soal</div>
                    <div class="stat-card-subtitle">Naskah Ujian Terdaftar</div>
                </div>
            </div>
        </div>

        <!-- 4. Total Ujian Aktif (Lavender) -->
        <div class="col-12 col-sm-6 col-md-3 mb-3">
            <div class="stat-card-custom stat-card-lavender">
                <i class="fas fa-calendar-check stat-card-bg-icon"></i>
                <div class="stat-card-content">
                    <div class="stat-card-value"><?= $totalUjianAktif ?></div>
                    <div class="stat-card-title">Total Ujian Aktif</div>
                    <div class="stat-card-subtitle">Bulan <?= [ 'January'=>'Januari', 'February'=>'Februari', 'March'=>'Maret', 'April'=>'April', 'May'=>'Mei', 'June'=>'Juni', 'July'=>'Juli', 'August'=>'Agustus', 'September'=>'September', 'October'=>'Oktober', 'November'=>'November', 'December'=>'Desember' ][date('F')] ?? date('F') ?></div>
                </div>
            </div>
        </div>
    </div>

    <?php
    $http_proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? 80) == 443 ? "https://" : "http://";
    $http_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script_dir = rtrim(dirname($_SERVER['PHP_SELF'] ?? $_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
    $cbt_login_url = $http_proto . $http_host . ($script_dir !== '' && $script_dir !== '/' ? $script_dir : '') . '/';
    $school_name_text = !empty($settings['school_name']) ? $settings['school_name'] : 'CBT UJIAN ONLINE';

    $classesMap = [];
    if (!empty($classes)) {
        foreach ($classes as $cls) {
            $classesMap[$cls['id']] = $cls['name'];
        }
    }

    $now_ts = time();
    $today_ymd = date('Y-m-d');
    $daysIndo = ['Sunday'=>'Minggu', 'Monday'=>'Senin', 'Tuesday'=>'Selasa', 'Wednesday'=>'Rabu', 'Thursday'=>'Kamis', 'Friday'=>'Jumat', 'Saturday'=>'Sabtu'];
    $monthsIndo = [1=>'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

    $dashboardExamItems = [];
    $countOngoing = 0;
    $countToday = 0;
    $countActive = 0;

    foreach (($exams ?? []) as $e) {
        $sTs = !empty($e['start_time']) ? strtotime($e['start_time']) : 0;
        $eTs = !empty($e['end_time']) ? strtotime($e['end_time']) : 0;
        $status = $e['status'] ?? 'aktif';

        // Jangan tampilkan jika sudah selesai atau sudah lewat tanggal/waktunya
        if ($status === 'selesai') {
            continue;
        }
        if ($eTs > 0 && $eTs < $now_ts) {
            continue;
        }
        if ($eTs == 0 && $sTs > 0) {
            $effectiveEnd = $sTs + (($e['duration'] ?? 90) * 60);
            if ($effectiveEnd < $now_ts) {
                continue;
            }
        }

        $isOngoing = ($sTs <= $now_ts && $eTs >= $now_ts && $status === 'aktif');
        $isToday = ($sTs > 0 && date('Y-m-d', $sTs) === $today_ymd);
        $isActive = ($status === 'aktif');

        if ($isOngoing) $countOngoing++;
        if ($isToday) $countToday++;
        if ($isActive) $countActive++;

        $cNames = [];
        $class_ids = $e['class_ids'] ?? $e['classes'] ?? [];
        if (is_string($class_ids)) {
            $class_ids = json_decode($class_ids, true) ?: [];
        }
        if (empty($class_ids)) {
            $cNamesStr = 'Semua Kelas';
        } else {
            foreach ($class_ids as $cid) {
                if (isset($classesMap[$cid])) {
                    $cNames[] = $classesMap[$cid];
                }
            }
            $cNamesStr = !empty($cNames) ? implode(', ', $cNames) : 'Semua Kelas';
        }

        $dayStr = $sTs ? ($daysIndo[date('l', $sTs)] ?? date('l', $sTs)) : '-';
        $mStr = $sTs ? ($monthsIndo[(int)date('n', $sTs)] ?? date('M', $sTs)) : '-';
        $dateIndoFormatted = $sTs ? ($dayStr . ', ' . date('d', $sTs) . ' ' . $mStr . ' ' . date('Y', $sTs)) : '-';
        $timeRangeFormatted = ($sTs ? date('H:i', $sTs) : '-') . ' - ' . ($eTs ? date('H:i', $eTs) : '-');

        $dashboardExamItems[] = [
            'id' => (int)$e['id'],
            'name' => $e['name'],
            'token' => $e['token'] ?? '',
            'classes' => $cNamesStr,
            'duration' => (int)($e['duration'] ?? 90),
            'start_time' => $e['start_time'],
            'end_time' => $e['end_time'],
            'start_ts' => $sTs,
            'end_ts' => $eTs,
            'status' => $status,
            'is_ongoing' => $isOngoing,
            'is_today' => $isToday,
            'is_active' => $isActive,
            'date_formatted' => $dateIndoFormatted,
            'time_range' => $timeRangeFormatted,
            'question_count' => (int)($e['question_count'] ?? 0)
        ];
    }

    // Urutkan jadwal: Yang sedang berlangsung paling atas, lalu jadwal terdekat berikutnya
    usort($dashboardExamItems, function($a, $b) {
        if ($a['is_ongoing'] !== $b['is_ongoing']) {
            return $a['is_ongoing'] ? -1 : 1;
        }
        if ($a['start_ts'] !== $b['start_ts']) {
            return $a['start_ts'] - $b['start_ts'];
        }
        return strcmp($a['name'], $b['name']);
    });
    ?>

    <style>
    /* Styling Token & Ikon Copy */
    .token-badge-clean {
        font-family: 'SFMono-Regular', Menlo, Monaco, Consolas, 'Liberation Mono', monospace;
        font-size: 0.95rem;
        font-weight: 700;
        letter-spacing: 1.5px;
        background-color: #ffc107;
        color: #212529;
        padding: 4px 8px;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        transition: transform 0.15s ease;
    }
    .token-badge-clean:hover {
        transform: scale(1.04);
    }
    .btn-copy-wa-icon {
        color: #28a745;
        font-size: 0.88rem;
        padding: 2px 4px;
        line-height: 1;
        vertical-align: middle;
        font-weight: 300;
        opacity: 0.85;
        transition: transform 0.15s ease, opacity 0.15s ease, color 0.15s ease;
        text-decoration: none !important;
    }
    .btn-copy-wa-icon:hover {
        color: #1e7e34;
        opacity: 1;
        transform: scale(1.15);
    }
    .token-dynamic-icon {
        color: #17a2b8;
        font-size: 0.82rem;
        vertical-align: middle;
        font-weight: 300;
        opacity: 0.85;
        display: inline-block;
        transition: transform 0.15s ease, opacity 0.15s ease;
    }
    .token-dynamic-icon:hover {
        opacity: 1;
        transform: scale(1.15);
    }
    #btn-bulk-share-wa {
        display: none;
        align-items: center;
        justify-content: center;
        gap: 6px;
        background-color: #25d366;
        border-color: #20ba59;
        color: #ffffff !important;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 6px;
        line-height: 1.4;
        transition: all 0.2s ease;
    }
    #btn-bulk-share-wa:hover {
        background-color: #20ba59;
        border-color: #1aa04c;
        color: #ffffff !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 10px rgba(37, 211, 102, 0.35) !important;
    }
    #btn-bulk-share-wa .wa-btn-icon,
    #btn-bulk-share-wa i {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 17px;
        height: 17px;
        font-size: 1.05rem;
        line-height: 1;
        flex-shrink: 0;
        vertical-align: middle;
    }
    #table-dashboard-exams thead th {
        text-align: center !important;
        vertical-align: middle !important;
    }
    </style>

    <!-- Card Daftar Token Ujian -->
    <div class="card card-outline card-primary shadow-sm mb-4">
        <div class="card-header py-3">
            <div class="d-flex flex-wrap justify-content-between align-items-center">
                <h3 class="card-title font-weight-bold mb-2 mb-md-0" style="font-size: 1.1rem;">
                    Daftar Token Ujian per Mata Pelajaran
                </h3>
                <div class="card-tools d-flex align-items-center">
                    <button type="button" class="btn btn-sm btn-success mr-2 font-weight-bold shadow-sm" id="btn-bulk-share-wa" onclick="bulkShareSelectedTokensWhatsApp()" style="display: none;">
                        <svg class="wa-btn-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" style="vertical-align: middle; margin-right: 3px;">
                            <path d="M13.601 2.326A7.85 7.85 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.9 7.9 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.9 7.9 0 0 0 13.6 2.326zM7.994 14.521a6.6 6.6 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.56 6.56 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592m3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.017-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.73.73 0 0 0-.529.247c-.182.198-.691.677-.691 1.654s.707 1.929.806 2.062c.099.133 1.39 2.123 3.37 2.977.471.203.839.324 1.126.417.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232"/>
                        </svg>
                        <span>Bagikan&nbsp;<span id="selected-exams-count">0</span>&nbsp;Token Terpilih</span>
                    </button>
                    <div class="input-group input-group-sm" style="width: 240px;">
                        <input type="text" id="searchDashboardMapel" class="form-control" placeholder="Cari mapel / token..." oninput="filterDashboardExamTable()">
                        <div class="input-group-append">
                            <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body p-0 table-responsive">
            <table class="table table-striped table-hover table-bordered mb-0" id="table-dashboard-exams">
                <thead>
                    <tr class="text-center align-middle">
                        <th style="width: 40px" class="text-center align-middle">
                            <input type="checkbox" id="check-all-dashboard-exams" onchange="toggleSelectAllDashboardExams(this)" title="Pilih Semua">
                        </th>
                        <th style="width: 50px" class="text-center align-middle">No</th>
                        <th class="text-center align-middle">Mata Pelajaran</th>
                        <th class="text-center align-middle">Kelas</th>
                        <th style="width: 170px" class="text-center align-middle">Token</th>
                        <th class="text-center align-middle">Waktu Mulai</th>
                        <th class="text-center align-middle">Waktu Selesai</th>
                        <th style="width: 100px" class="text-center align-middle">Durasi</th>
                        <th style="width: 110px" class="text-center align-middle">Status</th>
                        <th style="width: 70px" class="text-center align-middle">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbody-dashboard-exams">
                    <?php if (empty($dashboardExamItems)): ?>
                    <tr id="row-empty-dashboard-exams">
                        <td colspan="10" class="text-center py-4 text-muted">
                            <i class="far fa-calendar-check fa-2x mb-2 text-secondary d-block"></i>
                            Tidak ada jadwal ujian aktif atau mendatang saat ini.
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($dashboardExamItems as $i => $item): 
                            $searchContent = strtolower($item['name'] . ' ' . $item['token'] . ' ' . $item['classes'] . ' ' . $item['status']);
                        ?>
                        <tr class="exam-item-row" data-search="<?= htmlspecialchars($searchContent) ?>">
                            <td class="text-center align-middle">
                                <input type="checkbox" class="cb-dashboard-exam" value="<?= $item['id'] ?>" onchange="updateDashboardBulkSelection()">
                            </td>
                            <td class="text-center align-middle font-weight-bold text-muted exam-num-col"><?= $i + 1 ?></td>
                            <td class="align-middle">
                                <strong><?= htmlspecialchars($item['name']) ?></strong>
                            </td>
                            <td class="align-middle">
                                <span class="badge badge-light border text-secondary" style="font-size: 0.85rem;">
                                    <?= htmlspecialchars($item['classes']) ?>
                                </span>
                            </td>
                            <td class="text-center align-middle text-nowrap">
                                <span class="token-badge-clean" 
                                      onclick="copySingleToken('<?= htmlspecialchars(addslashes($item['token'])) ?>', this)" 
                                      title="Klik untuk salin kode token saja">
                                    <?= htmlspecialchars($item['token']) ?>
                                </span>
                                <button type="button" class="btn btn-link btn-copy-wa-icon" 
                                        onclick="copyExamWhatsApp(<?= $item['id'] ?>, this)" 
                                        title="Salin info token ujian untuk di-paste ke grup WhatsApp">
                                    <i class="far fa-copy"></i>
                                </button>
                                <?php if (!empty($settings['dynamic_token'])): ?>
                                    <span class="token-dynamic-icon ml-1" title="Token Dinamis (berganti otomatis)"><i class="fas fa-bolt"></i></span>
                                <?php endif; ?>
                            </td>
                            <td class="align-middle"><?= date('d/m/Y H:i', $item['start_ts']) ?></td>
                            <td class="align-middle"><?= date('d/m/Y H:i', $item['end_ts']) ?></td>
                            <td class="text-center align-middle"><?= $item['duration'] ?> Menit</td>
                            <td class="text-center align-middle">
                                <?php 
                                $status = $item['status'] ?? 'aktif'; 
                                $badgeClass = 'badge-success';
                                if ($status == 'draft') $badgeClass = 'badge-secondary';
                                else if ($status == 'selesai') $badgeClass = 'badge-info';
                                ?>
                                <span class="badge <?= $badgeClass ?> font-weight-normal" style="font-size: 0.85rem; padding: 5px 10px; font-weight: 400;"><?= ucfirst($status) ?></span>
                            </td>
                            <td class="text-center align-middle">
                                <a href="admin.php?page=status&live_exam_id=<?= $item['id'] ?>&live_exam_name=<?= urlencode($item['name']) ?>&live_exam_token=<?= urlencode($item['token']) ?>" 
                                   class="btn btn-info btn-sm" title="Lihat Status Peserta">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <tr id="row-no-filter-match" style="display: none;">
                            <td colspan="10" class="text-center py-3 text-muted">
                                Tidak ada mata pelajaran ujian yang cocok dengan pencarian.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Script Dashboard Token & Copy WhatsApp -->
<script>
const dashboardExamData = <?= json_encode($dashboardExamItems) ?>;
const cbtLoginUrlGlobal = (<?= json_encode($cbt_login_url) ?> || '').replace(/\/index\.php$/i, '/');
const schoolNameGlobal = <?= json_encode($school_name_text) ?>;

// Clipboard helper
function copyTextToClipboard(text, onSuccess) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(function() {
            if (onSuccess) onSuccess();
        }).catch(function() {
            fallbackClipboardCopy(text, onSuccess);
        });
    } else {
        fallbackClipboardCopy(text, onSuccess);
    }
}

function fallbackClipboardCopy(text, onSuccess) {
    var textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.top = "-9999px";
    textArea.style.left = "-9999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
        var ok = document.execCommand('copy');
        if (ok && onSuccess) onSuccess();
    } catch (e) {}
    document.body.removeChild(textArea);
}

// 1. Salin Kode Token Saja (klik badge token)
function copySingleToken(token, el) {
    copyTextToClipboard(token, function() {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: 'Token ' + token + ' Berhasil Disalin!',
                showConfirmButton: false,
                timer: 1800,
                timerProgressBar: true
            });
        }
    });
}

// 2. Salin Format WhatsApp Siap Paste ke Grup (klik ikon copy)
function copyExamWhatsApp(examId, btn) {
    var item = dashboardExamData.find(function(e) { return e.id === examId; });
    if (!item) return;

    var qCountStr = (item.question_count && item.question_count > 0) ? item.question_count + " Soal" : "-";
    var text = "*INFORMASI TOKEN UJIAN*\n";
    if (schoolNameGlobal) {
        text += "*" + schoolNameGlobal + "*\n";
    }
    text += "━━━━━━━━━━━━━━━━━━━━━\n";
    var dateInfo = (item.date_formatted && item.date_formatted !== '-') ? " (" + item.date_formatted + ")" : "";
    text += "*" + item.name + "*" + dateInfo + "\n";
    text += "Kelas        : *" + item.classes + "*\n";
    text += "Token        : *" + item.token + "*\n";
    text += "Waktu        : " + item.time_range + " WIB\n";
    text += "Jml. Soal    : " + qCountStr + "\n";
    text += "━━━━━━━━━━━━━━━━━━━━━\n";
    text += "*Link Login CBT:*\n" + cbtLoginUrlGlobal + "\n\n";
    text += "*Petunjuk Pengawas / Guru:*\n";
    text += "1. Pastikan siswa telah hadir di ruangan dan terhubung ke jaringan internet.\n";
    text += "2. Bagikan Token ujian di atas kepada siswa tepat saat waktu ujian dimulai.\n";
    text += "3. Awasi ketertiban ujian dan pastikan siswa tetap berada di aplikasi/halaman ujian.\n";
    text += "4. Jika ada siswa yang mengalami kendala perangkat atau terlogout, silakan menghubungi proktor ujian.\n";
    text += "5. Ingatkan siswa untuk memeriksa kembali jawaban dan menekan tombol 'Selesai' sebelum waktu habis.\n\n";
    text += "*Petunjuk Siswa:*\n";
    text += "1. Buka tautan CBT di atas melalui Google Chrome / browser.\n";
    text += "2. Masuk menggunakan Username dan Password Anda.\n";
    text += "3. Masukkan Token: *" + item.token + "* (HURUF BESAR).\n";
    text += "4. Kerjakan ujian dengan jujur, tertib, dan teliti.\n\n";
    text += "_Semoga sukses dan lancar!_";

    copyTextToClipboard(text, function() {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: 'Format WhatsApp Berhasil Disalin!',
                text: 'Tinggal paste di grup WA siswa/guru.',
                showConfirmButton: false,
                timer: 2500,
                timerProgressBar: true
            });
        }
        if (btn) {
            var icon = btn.querySelector('i');
            if (icon) {
                var origClass = icon.className;
                icon.className = 'fas fa-check text-success';
                setTimeout(function() {
                    icon.className = origClass;
                }, 1800);
            }
        }
    });
}

// 3. Selection Checkbox Bulk Share
function toggleSelectAllDashboardExams(masterCb) {
    var isChecked = masterCb.checked;
    var rows = document.querySelectorAll('.exam-item-row');
    rows.forEach(function(row) {
        if (row.style.display !== 'none') {
            var cb = row.querySelector('.cb-dashboard-exam');
            if (cb) cb.checked = isChecked;
        }
    });
    updateDashboardBulkSelection();
}

function updateDashboardBulkSelection() {
    var checkedBoxes = document.querySelectorAll('.cb-dashboard-exam:checked');
    var count = checkedBoxes.length;
    var btn = document.getElementById('btn-bulk-share-wa');
    var countSpan = document.getElementById('selected-exams-count');
    var masterCb = document.getElementById('check-all-dashboard-exams');

    if (countSpan) countSpan.textContent = count;
    if (btn) {
        btn.style.display = count > 0 ? 'inline-flex' : 'none';
    }

    var visibleRows = Array.from(document.querySelectorAll('.exam-item-row')).filter(function(r) {
        return r.style.display !== 'none';
    });
    var visibleChecked = visibleRows.filter(function(r) {
        var cb = r.querySelector('.cb-dashboard-exam');
        return cb && cb.checked;
    });

    if (masterCb) {
        masterCb.checked = visibleRows.length > 0 && visibleChecked.length === visibleRows.length;
        masterCb.indeterminate = visibleChecked.length > 0 && visibleChecked.length < visibleRows.length;
    }
}

// 4. Bulk Share WhatsApp untuk Mapel Terpilih Saja
function bulkShareSelectedTokensWhatsApp() {
    var checkedBoxes = document.querySelectorAll('.cb-dashboard-exam:checked');
    if (checkedBoxes.length === 0) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'warning',
                title: 'Pilih Mapel',
                text: 'Centang minimal satu mata pelajaran untuk dibagikan tokennya.',
                confirmButtonColor: '#3085d6'
            });
        }
        return;
    }

    var selectedIds = Array.from(checkedBoxes).map(function(cb) {
        return parseInt(cb.value, 10);
    });

    var selectedList = dashboardExamData.filter(function(item) {
        return selectedIds.indexOf(item.id) !== -1;
    });

    if (selectedList.length === 0) return;

    var text = "*DAFTAR TOKEN UJIAN*\n";
    if (schoolNameGlobal) {
        text += "*" + schoolNameGlobal + "*\n";
    }
    text += "━━━━━━━━━━━━━━━━━━━━━\n\n";

    selectedList.forEach(function(item, idx) {
        var qCountStr = (item.question_count && item.question_count > 0) ? item.question_count + " Soal" : "-";
        var dateInfo = (item.date_formatted && item.date_formatted !== '-') ? " (" + item.date_formatted + ")" : "";
        text += (idx + 1) + ". *" + item.name + "*" + dateInfo + "\n";
        text += "   Kelas        : *" + item.classes + "*\n";
        text += "   Token        : *" + item.token + "*\n";
        text += "   Waktu        : " + item.time_range + " WIB\n";
        text += "   Jml. Soal    : " + qCountStr + "\n\n";
    });

    text += "━━━━━━━━━━━━━━━━━━━━━\n";
    text += "*Link Login CBT:*\n" + cbtLoginUrlGlobal + "\n\n";
    text += "*Petunjuk Pengawas / Guru:*\n";
    text += "1. Pastikan siswa telah hadir di ruangan dan terhubung ke jaringan internet.\n";
    text += "2. Bagikan Token ujian di atas kepada siswa tepat saat waktu ujian dimulai.\n";
    text += "3. Awasi ketertiban ujian dan pastikan siswa tetap berada di aplikasi/halaman ujian.\n";
    text += "4. Jika ada siswa yang mengalami kendala perangkat atau terlogout, silakan menghubungi proktor ujian.\n";
    text += "5. Ingatkan siswa untuk memeriksa kembali jawaban dan menekan tombol 'Selesai' sebelum waktu habis.\n\n";
    text += "*Petunjuk Siswa:*\n";
    text += "1. Buka tautan CBT di atas melalui Google Chrome / browser.\n";
    text += "2. Masuk menggunakan Username dan Password masing-masing.\n";
    text += "3. Masukkan Token ujian dengan HURUF BESAR sesuai mata pelajaran.\n";
    text += "4. Kerjakan ujian dengan jujur, tertib, dan teliti.\n\n";
    text += "_Semoga sukses dan lancar!_";

    copyTextToClipboard(text, function() {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'success',
                title: selectedList.length + ' Token Ujian Disalin!',
                html: 'Pesan list <b>' + selectedList.length + ' mata pelajaran</b> dan token berhasil disalin.<br>Tinggal <b>Paste (Ctrl + V)</b> di WhatsApp grup siswa atau guru.',
                showCancelButton: true,
                confirmButtonText: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" style="vertical-align: -2px; margin-right: 5px;"><path d="M13.601 2.326A7.85 7.85 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.9 7.9 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.9 7.9 0 0 0 13.6 2.326zM7.994 14.521a6.6 6.6 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.56 6.56 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592m3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.017-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.73.73 0 0 0-.529.247c-.182.198-.691.677-.691 1.654s.707 1.929.806 2.062c.099.133 1.39 2.123 3.37 2.977.471.203.839.324 1.126.417.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232"/></svg> Buka WhatsApp',
                cancelButtonText: 'Tutup',
                confirmButtonColor: '#25D366',
                cancelButtonColor: '#6c757d'
            }).then(function(result) {
                if (result.isConfirmed) {
                    var waUrl = "https://api.whatsapp.com/send?text=" + encodeURIComponent(text);
                    window.open(waUrl, '_blank');
                }
            });
        }
    });
}

// 5. Search realtime
function filterDashboardExamTable() {
    var query = (document.getElementById('searchDashboardMapel').value || '').trim().toLowerCase();
    var rows = document.querySelectorAll('.exam-item-row');
    var visibleCount = 0;

    rows.forEach(function(row) {
        var searchData = row.getAttribute('data-search') || '';
        var match = !query || searchData.indexOf(query) !== -1;
        if (match) {
            row.style.display = '';
            visibleCount++;
            var numCol = row.querySelector('.exam-num-col');
            if (numCol) numCol.textContent = visibleCount;
        } else {
            row.style.display = 'none';
        }
    });

    var noMatchRow = document.getElementById('row-no-filter-match');
    if (noMatchRow) {
        noMatchRow.style.display = (visibleCount === 0 && rows.length > 0) ? '' : 'none';
    }
    updateDashboardBulkSelection();
}
</script>

