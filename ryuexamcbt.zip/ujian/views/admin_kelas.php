<div id="section-kelas" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Daftar Kelas</h3>
            <button class="btn btn-primary btn-sm ml-auto" data-toggle="modal" data-target="#modalAddKelas">
                <i class="fas fa-plus mr-1"></i> Tambah Kelas
            </button>
        </div>
        <div class="card-body p-0">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 50px">ID</th>
                        <th>Nama Kelas</th>
                        <th style="width: 120px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($classes as $c): ?>
                    <tr>
                        <td><?= $c['id'] ?></td>
                        <td><?= htmlspecialchars($c['name']) ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editClass(<?= $c['id'] ?>, '<?= htmlspecialchars(addslashes($c['name'])) ?>')"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-danger btn-sm" onclick="deleteClass(<?= $c['id'] ?>)"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($classes)): ?>
                        <tr><td colspan="3" class="text-center">Belum ada kelas</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Add Kelas -->
    <div class="modal fade" id="modalAddKelas" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Kelas</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label>Nama Kelas</label>
                            <input type="text" name="class_name" class="form-control" placeholder="Contoh: IX.6" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="add_class" class="btn btn-primary">Simpan Kelas</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Kelas -->
    <div class="modal fade" id="modalEditKelas" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit_class_id" id="edit_class_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Kelas</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label>Nama Kelas</label>
                            <input type="text" name="class_name" id="edit_class_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="edit_class" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function editClass(id, name) {
    document.getElementById('edit_class_id').value = id;
    document.getElementById('edit_class_name').value = name;
    $('#modalEditKelas').modal('show');
}

async function deleteClass(id) {
    const result = await Swal.fire({
        title: 'Konfirmasi',
        text: 'Yakin ingin menghapus kelas ini? Siswa yang ada di kelas ini mungkin akan kehilangan referensi data kelasnya.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    });

    if (result.isConfirmed) {
        const formData = new FormData();
        formData.append('action', 'delete_class');
        formData.append('id', id);
        
        try {
            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.status === 'success') {
                Swal.fire({
                    title: 'Berhasil!',
                    text: 'Kelas berhasil dihapus.',
                    icon: 'success',
                    timer: 1000,
                    showConfirmButton: false
                }).then(() => {
                    window.location.reload();
                });
            } else {
                Swal.fire('Gagal', res.message, 'error');
            }
        } catch (error) {
            console.error(error);
            Swal.fire('Gagal', 'Gagal menghubungi server.', 'error');
        }
    }
}
</script>
