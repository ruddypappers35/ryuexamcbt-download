<?php $settings = get_settings(); ?>
<div id="section-status" class="content-section">
    <!-- EXAM LIST SECTION -->
    <div id="status-exam-list" class="card card-outline card-primary">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
            <div class="d-flex align-items-center flex-wrap" style="gap: 10px;">
                <h3 class="card-title font-weight-bold mb-0">Daftar Mata Pelajaran (Status Ujian)</h3>
                <button id="btn-bulk-download-status" type="button" onclick="bulkDownloadStatusExcel()" class="btn btn-success btn-sm" style="display: none;" title="Unduh nilai mata pelajaran yang dicentang">
                    <i class="fas fa-file-archive mr-1"></i> Unduh Nilai Terpilih (<span id="selected-status-count">0</span>) (.zip)
                </button>
            </div>
            <div class="card-tools">
                <div class="input-group input-group-sm" style="width: 250px;">
                    <input type="text" id="exam-list-search" class="form-control" placeholder="Cari mata pelajaran..." onkeyup="filterExamList()">
                    <div class="input-group-append">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body table-responsive p-0">
            <table class="table table-striped table-hover text-nowrap table-bordered mb-0">
                <thead>
                    <tr>
                        <th style="width: 40px" class="text-center">
                            <input type="checkbox" id="cb-all-status-exam" onchange="toggleAllStatusExam(this)" title="Pilih Semua">
                        </th>
                        <th style="width: 50px" class="text-center">No</th>
                        <th onclick="sortExamList(2)" style="cursor:pointer">Mata Pelajaran <i class="fas fa-sort text-muted ml-1"></i></th>
                        <th onclick="sortExamList(3)" style="cursor:pointer" class="text-center">Token <i class="fas fa-sort text-muted ml-1"></i></th>
                        <th onclick="sortExamList(4)" style="cursor:pointer">Waktu Ujian <i class="fas fa-sort text-muted ml-1"></i></th>
                        <th onclick="sortExamList(5)" style="cursor:pointer" class="text-center">Durasi <i class="fas fa-sort text-muted ml-1"></i></th>
                        <th onclick="sortExamList(6)" style="cursor:pointer" class="text-center">Jumlah Soal <i class="fas fa-sort text-muted ml-1"></i></th>
                        <th onclick="sortExamList(7)" style="cursor:pointer; width: 120px;" class="text-center">Status <i class="fas fa-sort text-muted ml-1"></i></th>
                        <th style="width: 100px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($exams as $i => $e): ?>
                    <tr>
                        <td class="text-center align-middle">
                            <input type="checkbox" class="cb-status-exam" value="<?= $e['id'] ?>" data-name="<?= htmlspecialchars($e['name']) ?>" onchange="toggleStatusExamSelection(this)">
                        </td>
                        <td class="text-center align-middle"><?= $i + 1 ?></td>
                        <td class="align-middle exam-name-cell"><strong><?= htmlspecialchars($e['name']) ?></strong></td>
                        <td class="text-center align-middle">
                            <span class="badge badge-warning" style="font-size:0.9em; letter-spacing:1px;"><?= htmlspecialchars($e['token']) ?></span>
                            <?php if (!empty($settings['dynamic_token'])): 
                                $allExamsTitle = !empty($settings['dynamic_token_all_exams']) ? ' (1 Token untuk Semua Ujian)' : '';
                            ?>
                                <i class="fas fa-bolt text-info ml-1" style="font-size: 0.8rem; vertical-align: middle; cursor: help;" title="Token Dinamis<?= $allExamsTitle ?> (berganti setiap <?= (int)($settings['token_interval_minutes'] ?? 15) ?> mnt)"></i>
                            <?php endif; ?>
                        </td>
                        <td class="align-middle"><?= date('d/m/Y H:i', strtotime($e['start_time'])) ?> s/d <?= date('d/m/Y H:i', strtotime($e['end_time'])) ?></td>
                        <td class="text-center align-middle"><?= $e['duration'] ?> Menit</td>
                        <td class="text-center align-middle"><?= $e['question_count'] ?> Soal</td>
                        <td class="text-center align-middle">
                            <?php 
                            $status = $e['status'] ?? 'aktif'; 
                            $badgeClass = 'badge-success';
                            if ($status == 'draft') $badgeClass = 'badge-secondary';
                            else if ($status == 'selesai') $badgeClass = 'badge-info';
                            ?>
                            <span class="badge <?= $badgeClass ?> font-weight-normal" style="font-size: 0.85rem; padding: 5px 10px; font-weight: 400;"><?= ucfirst($status) ?></span>
                        </td>
                        <td class="text-center align-middle text-nowrap">
                            <a href="admin.php?page=status&live_exam_id=<?= $e['id'] ?>&live_exam_name=<?= urlencode($e['name']) ?>&live_exam_token=<?= urlencode($e['token']) ?>" target="_blank" class="btn btn-info btn-sm mr-1" title="Lihat Status Realtime">
                                <i class="fas fa-eye"></i>
                            </a>
                            <button onclick="downloadExcel(<?= $e['id'] ?>, '<?= htmlspecialchars(addslashes($e['name'])) ?>')" class="btn btn-success btn-sm" title="Unduh Rekap Nilai (.xlsx)">
                                <i class="fas fa-download"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($exams)): ?>
                        <tr><td colspan="9" class="text-center py-3">Belum ada mata pelajaran</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- REALTIME STATUS SECTION -->
    <div id="status-live-view" style="display: none;">
        <style>
        /* Styling Modern Tab Filter Status Siswa */
        #status-tabs {
            border-bottom: 2px solid #e9ecef !important;
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            padding: 8px 12px 0 12px !important;
            margin-bottom: 0 !important;
            background-color: #ffffff;
        }
        #status-tabs .nav-item {
            margin-bottom: -2px; /* Overlap baseline border */
        }
        #status-tabs .nav-link {
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            color: #6c757d;
            padding: 8px 16px;
            border: none !important;
            border-bottom: 3px solid transparent !important;
            background: transparent !important;
            border-radius: 0 !important;
            display: inline-flex;
            align-items: center;
            transition: all 0.2s ease-in-out;
            text-decoration: none !important;
        }
        #status-tabs .nav-link:hover {
            color: #007bff;
            background-color: rgba(0, 123, 255, 0.04) !important;
            border-bottom-color: rgba(0, 123, 255, 0.35) !important;
        }
        #status-tabs .nav-link.active {
            color: #007bff !important;
            font-weight: 700 !important;
            background-color: transparent !important;
            border-bottom: 3px solid #007bff !important; /* Aksen warna biru di bawah tab aktif */
        }
        #status-tabs .nav-link .badge {
            font-size: 0.76rem;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 12px;
        }
        </style>
        <div class="card card-outline card-danger">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap py-2" style="gap: 8px;">
                <div class="d-flex align-items-center flex-wrap" style="gap: 10px;">
                    <h3 class="card-title font-weight-bold mb-0 d-flex align-items-center">
                        <i class="fas fa-user-graduate text-danger mr-2" title="Status Siswa"></i><span id="live-exam-title" class="text-dark"></span>
                    </h3>
                    <div class="d-inline-flex align-items-center bg-light border rounded px-2 py-1" style="font-size: 0.85rem;" title="Token Ujian">
                        <span class="text-muted mr-1 font-weight-bold" style="font-size: 0.72rem; letter-spacing: 0.5px;">TOKEN:</span>
                        <span id="live-exam-token" class="font-weight-bold text-dark mr-1" style="letter-spacing: 2px; font-size: 0.95rem; font-family: monospace;">-</span>
                        <?php if (($user_role ?? 'admin') === 'admin'): ?>
                        <button type="button" onclick="refreshExamTokenNow()" class="btn btn-outline-secondary btn-xs p-0 px-1 border-0" title="Acak / Rilis Token Baru">
                            <i class="fas fa-random text-primary" style="font-size: 0.8rem;"></i>
                        </button>
                        <?php endif; ?>
                        <span id="token-dynamic-info" class="text-muted ml-2" style="display: none; font-size: 0.75rem;">
                            <i class="fas fa-clock text-warning"></i> <strong id="token-countdown-display">--:--</strong>
                        </span>
                    </div>
                </div>
                <div class="card-tools d-flex align-items-center flex-wrap m-0" style="gap: 8px;">
                    <button type="button" onclick="refreshStatusManual()" class="btn btn-outline-primary btn-sm" id="btn-refresh-status" title="Segarkan data siswa">
                        <i class="fas fa-sync-alt mr-1"></i> Refresh
                    </button>
                    <span id="last-updated-time" class="badge badge-light border text-muted" style="font-size: 0.78rem; font-weight: normal;"></span>
                    <div class="input-group input-group-sm" style="width: 180px;">
                        <input type="text" id="live-search-input" class="form-control" placeholder="Cari siswa..." onkeyup="filterLiveSearch()">
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                    </div>
                    <select id="live-status-per-page" class="form-control form-control-sm" style="width: 125px;" onchange="changePerPage()">
                        <option value="10">10 / hal</option>
                        <option value="50">50 / hal</option>
                        <option value="100">100 / hal</option>
                        <option value="-1">Tampilkan Semua</option>
                    </select>
                </div>
            </div>
            <div class="card-body p-0" style="overflow-x: auto;">
                <ul class="nav custom-status-tabs" id="status-tabs">
                    <li class="nav-item"><a class="nav-link active" href="#" onclick="filterStatusTab('Semua', event, this)">Semua <span id="tab-count-semua" class="badge badge-secondary ml-1">0</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="filterStatusTab('Belum Mengerjakan', event, this)">Belum Mulai <span id="tab-count-belum" class="badge badge-secondary ml-1">0</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="filterStatusTab('Sedang Mengerjakan', event, this)">Mengerjakan <span id="tab-count-mengerjakan" class="badge badge-warning ml-1">0</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="filterStatusTab('Terkunci', event, this)"><i class="fas fa-lock mr-1 text-danger"></i>Terkunci <span id="tab-count-terkunci" class="badge badge-danger ml-1">0</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="filterStatusTab('Diblokir', event, this)"><i class="fas fa-ban mr-1 text-danger"></i>Diblokir <span id="tab-count-diblokir" class="badge badge-danger ml-1">0</span></a></li>
                    <li class="nav-item"><a class="nav-link" href="#" onclick="filterStatusTab('Selesai', event, this)">Selesai <span id="tab-count-selesai" class="badge badge-success ml-1">0</span></a></li>
                </ul>
                <div class="px-3 py-2 border-bottom bg-light d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
                    <div class="d-flex align-items-center flex-wrap my-1" style="gap: 6px;">
                        <?php if (($user_role ?? 'admin') === 'admin'): ?>
                        <button onclick="bulkUnlock()" class="btn btn-info btn-sm" title="Buka Kunci Terpilih"><i class="fas fa-unlock-alt"></i></button>
                        <button onclick="bulkReset()" class="btn btn-warning btn-sm" title="Keluarkan Siswa Terpilih (Jawaban Tetap Aman)"><i class="fas fa-undo"></i></button>
                        <button onclick="bulkForceSubmit()" class="btn btn-success btn-sm" title="Selesai Terpilih"><i class="fas fa-check-double"></i></button>
                        <button onclick="bulkBlock(1)" class="btn btn-outline-danger btn-sm" title="Blokir Siswa Terpilih (Keluarkan & Larang Ujian)"><i class="fas fa-ban"></i></button>
                        <button onclick="bulkBlock(0)" class="btn btn-outline-secondary btn-sm" title="Buka Blokir Siswa Terpilih"><i class="fas fa-user-check"></i></button>
                        <button onclick="resetAllExamStatus()" class="btn btn-outline-danger btn-sm" title="Reset Status Ujian Ini (Kosongkan data pengerjaan & nilai jadwal ini)"><i class="fas fa-trash-restore"></i></button>
                        <button onclick="recalculateLiveExamScores()" class="btn btn-outline-primary btn-sm" title="Hitung Ulang Nilai (Berdasarkan kunci jawaban terbaru)"><i class="fas fa-calculator"></i></button>
                        <?php endif; ?>
                    </div>
                    <div class="my-1">
                        <button onclick="downloadAllAnswersExcel()" class="btn btn-primary btn-sm"><i class="fas fa-file-excel mr-1"></i> Unduh Jawaban</button>
                    </div>
                </div>
                <table class="table table-striped table-hover mb-0" id="live-status-table" style="vertical-align: middle;">
                    <thead class="thead-light">
                        <tr>
                            <?php if (($user_role ?? 'admin') === 'admin'): ?>
                            <th style="width: 40px;" class="text-center align-middle"><input type="checkbox" id="cb-all-status" onchange="toggleAllStatus()"></th>
                            <?php endif; ?>
                            <th style="width: 50px;" class="text-center align-middle">No</th>
                            <th onclick="setSort('name')" style="cursor:pointer" class="align-middle">Nama Siswa <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('class_name')" style="cursor:pointer; width: 90px;" class="text-center align-middle">Kelas <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('answered_count')" style="cursor:pointer; width: 95px;" class="text-center align-middle">Prgs <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('status')" style="cursor:pointer; width: 140px;" class="text-center align-middle">Status <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('start_time_ts')" style="cursor:pointer; width: 90px;" class="text-center align-middle">Mulai <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('end_time_ts')" style="cursor:pointer; width: 90px;" class="text-center align-middle">Selesai <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('duration_seconds')" style="cursor:pointer; width: 95px;" class="text-center align-middle">Lama <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th onclick="setSort('score')" style="cursor:pointer; width: 80px;" class="text-center align-middle">Skor <i class="fas fa-sort text-muted ml-1"></i></th>
                            <th style="width: 140px;" class="text-center align-middle">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="live-status-tbody">
                        <tr><td colspan="11" class="text-center">Memuat data...</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right" id="live-status-pagination">
                </ul>
                <div id="live-status-info" class="float-left mt-1 text-muted" style="font-size: 0.9em;">
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (isset($_GET['live_exam_id'])): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Buka status ujian secara otomatis di tab baru
        let checkExist = setInterval(function() {
            if (typeof openLiveStatus === 'function') {
                openLiveStatus(
                    <?= (int)$_GET['live_exam_id'] ?>, 
                    <?= json_encode((string)($_GET['live_exam_name'] ?? '')) ?>, 
                    <?= json_encode((string)($_GET['live_exam_token'] ?? '')) ?>
                );
                clearInterval(checkExist);
            }
        }, 50);
    });
</script>
<?php endif; ?>

<!-- Modal Koreksi Esai -->
<div class="modal fade" id="modalKoreksiEsai" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Koreksi Jawaban Esai Siswa</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="koreksi_student_id">
                <input type="hidden" id="koreksi_exam_id">
                
                <div class="row mb-3 pb-3 border-bottom">
                    <div class="col-md-6">
                        <strong>Siswa:</strong> <span id="koreksi_student_name"></span>
                    </div>
                    <div class="col-md-6 text-right">
                        <strong>Skor Sementara:</strong> <span id="koreksi_current_score" class="badge badge-info">0</span>
                    </div>
                </div>
                
                <div id="koreksi_list_container">
                    <div class="text-center">Memuat jawaban esai...</div>
                </div>
                
                <div class="alert alert-info mt-3 mb-0" id="koreksi_no_essay" style="display: none;">
                    Tidak ada soal esai untuk dikoreksi pada mata pelajaran ini.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <button type="button" class="btn btn-primary" onclick="submitKoreksiEsai()">Simpan Penilaian</button>
            </div>
        </div>
    </div>
</div>
