<?php
$jenis_ujian_list = get_jenis_ujian_list();
?>
<div id="section-jenis-ujian" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
            <div class="d-flex align-items-center flex-wrap" style="gap: 10px;">
                <h3 class="card-title font-weight-bold mb-0">Daftar Jenis Ujian</h3>
            </div>
            <div class="card-tools d-flex align-items-center flex-wrap ml-auto" style="gap: 8px;">
                <div class="input-group input-group-sm" style="width: 220px;">
                    <input type="text" id="search-jenis" class="form-control" placeholder="Cari jenis ujian..." onkeyup="filterJenisTable()">
                    <div class="input-group-append">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalAddJenis">
                    <i class="fas fa-plus mr-1"></i> Tambah Jenis Ujian
                </button>
            </div>
        </div>
        <div class="card-body p-0 table-responsive">
            <table class="table table-striped table-hover mb-0" id="table-jenis">
                <thead>
                    <tr>
                        <th style="width: 50px" class="text-center">No</th>
                        <th style="width: 150px">Kode Jenis</th>
                        <th>Nama Jenis Ujian</th>
                        <th style="width: 120px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbody-jenis">
                    <?php if (empty($jenis_ujian_list)): ?>
                    <tr id="row-empty-jenis"><td colspan="4" class="text-center py-3 text-muted">Belum ada data jenis ujian</td></tr>
                    <?php else: ?>
                    <?php foreach ($jenis_ujian_list as $i => $j): ?>
                    <tr class="jenis-row">
                        <td class="text-center align-middle"><?= $i + 1 ?></td>
                        <td class="align-middle font-weight-bold jenis-code"><?= htmlspecialchars($j['code']) ?></td>
                        <td class="align-middle jenis-name"><?= htmlspecialchars($j['name']) ?></td>
                        <td class="text-center align-middle text-nowrap">
                            <button class="btn btn-warning btn-sm" title="Edit" onclick="editJenis(<?= $j['id'] ?>, '<?= htmlspecialchars(addslashes($j['code'])) ?>', '<?= htmlspecialchars(addslashes($j['name'])) ?>')"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-danger btn-sm" title="Hapus" onclick="deleteJenis(<?= $j['id'] ?>, '<?= htmlspecialchars(addslashes($j['name'])) ?>')"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Jenis Ujian -->
    <div class="modal fade" id="modalAddJenis" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold">Tambah Jenis Ujian</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Kode Jenis Ujian <span class="text-danger">*</span></label>
                            <input type="text" name="jenis_code" class="form-control" placeholder="Contoh: PTS, PAS, PAT, US, PH" style="text-transform: uppercase;" required>
                            <small class="text-muted">Singkatan jenis ujian (maksimal 20 karakter).</small>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Nama Jenis Ujian <span class="text-danger">*</span></label>
                            <input type="text" name="jenis_name" class="form-control" placeholder="Contoh: Penilaian Tengah Semester" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="add_jenis_ujian" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Simpan Jenis Ujian</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Jenis Ujian -->
    <div class="modal fade" id="modalEditJenis" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit_jenis_id" id="edit_jenis_id">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold">Edit Jenis Ujian</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Kode Jenis Ujian <span class="text-danger">*</span></label>
                            <input type="text" name="jenis_code" id="edit_jenis_code" class="form-control" style="text-transform: uppercase;" required>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Nama Jenis Ujian <span class="text-danger">*</span></label>
                            <input type="text" name="jenis_name" id="edit_jenis_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="edit_jenis_ujian" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function editJenis(id, code, name) {
    document.getElementById('edit_jenis_id').value = id;
    document.getElementById('edit_jenis_code').value = code;
    document.getElementById('edit_jenis_name').value = name;
    $('#modalEditJenis').modal('show');
}

async function deleteJenis(id, name) {
    const result = await Swal.fire({
        title: 'Hapus Jenis Ujian?',
        text: `Yakin ingin menghapus jenis ujian "${name}"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33'
    });

    if (result.isConfirmed) {
        const formData = new FormData();
        formData.append('action', 'delete_jenis_ujian');
        formData.append('id', id);

        try {
            const response = await fetch('api.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            if (data.status === 'success') {
                Swal.fire('Berhasil!', data.message, 'success').then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Gagal!', data.message, 'error');
            }
        } catch (error) {
            Swal.fire('Error!', 'Terjadi kesalahan sistem.', 'error');
        }
    }
}

function filterJenisTable() {
    const query = document.getElementById('search-jenis').value.toLowerCase();
    const rows = document.querySelectorAll('.jenis-row');
    rows.forEach(r => {
        const code = r.querySelector('.jenis-code') ? r.querySelector('.jenis-code').textContent.toLowerCase() : '';
        const name = r.querySelector('.jenis-name') ? r.querySelector('.jenis-name').textContent.toLowerCase() : '';
        if (code.includes(query) || name.includes(query)) {
            r.style.display = '';
        } else {
            r.style.display = 'none';
        }
    });
}
</script>
