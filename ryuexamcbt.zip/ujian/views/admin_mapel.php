<!-- Modal Edit Exam -->
<div class="modal fade" id="modalEditExam" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="form-edit-exam" onsubmit="submitEditExam(event)">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title font-weight-bold">Edit Jadwal Ujian</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="edit_exam_id">
                    
                    <!-- 1. Sumber Bank Soal -->
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Pilih Bank Soal <span class="text-danger">*</span></label>
                        <select id="edit_bank_soal_id" class="form-control" required onchange="onSelectBankSoalChange('edit', true)">
                            <option value="" disabled selected>-- Pilih Bank Soal --</option>
                            <?php foreach ($bank_soal as $b): ?>
                                <option value="<?= $b['id'] ?>"
                                    data-name="<?= htmlspecialchars($b['name']) ?>"
                                    data-count="<?= (int)($b['question_count'] ?? 0) ?>"
                                    data-classes="<?= htmlspecialchars($b['classes'] ?? '') ?>">
                                    <?= htmlspecialchars($b['name']) ?> (<?= (int)($b['question_count'] ?? 0) ?> Soal)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- 2. Nama Ujian -->
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Nama Ujian <span class="text-danger">*</span></label>
                        <input type="text" id="edit_exam_name" class="form-control font-weight-bold" required>
                    </div>

                    <!-- 3. Pilih Kelas -->
                    <div class="form-group mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="font-weight-bold mb-0">Pilih Kelas</label>
                            <small>
                                <a href="javascript:void(0)" onclick="$('.edit-exam-class-cb').prop('checked', true);" class="mr-2">Pilih Semua</a>
                                <a href="javascript:void(0)" onclick="$('.edit-exam-class-cb').prop('checked', false);" class="text-muted">Kosongkan (Semua)</a>
                            </small>
                        </div>
                        <div class="border p-2 rounded bg-light" style="max-height: 140px; overflow-y: auto;">
                            <div class="row">
                                <?php foreach ($classes as $c): ?>
                                    <div class="col-md-3 col-6">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input edit-exam-class-cb" id="edit_class_<?= $c['id'] ?>" value="<?= $c['id'] ?>" data-name="<?= htmlspecialchars($c['name']) ?>">
                                            <label class="custom-control-label font-weight-normal text-dark" for="edit_class_<?= $c['id'] ?>" style="cursor: pointer;"><?= htmlspecialchars($c['name']) ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- 4. Jumlah Soal Ditampilkan -->
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Jumlah Soal Ditampilkan</label>
                        <div class="input-group">
                            <input type="number" id="edit_exam_max_questions" class="form-control" min="1" placeholder="Semua soal di bank">
                            <div class="input-group-append">
                                <span class="input-group-text bg-white" id="edit_exam_total_badge">dari bank soal</span>
                            </div>
                        </div>
                        <small class="text-muted">Kosongkan atau isi sesuai total jika ingin menampilkan semua soal. Ubah jika ingin membatasi jumlah soal yang tampil ke siswa.</small>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Token Ujian <span class="text-danger">*</span></label>
                                <input type="text" id="edit_exam_token" class="form-control" style="text-transform: uppercase;" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Status Ujian</label>
                                <select id="edit_exam_status" class="form-control">
                                    <option value="aktif">Aktif</option>
                                    <option value="draft">Draft</option>
                                    <option value="selesai">Selesai</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Waktu Mulai <span class="text-danger">*</span></label>
                                <input type="datetime-local" id="edit_exam_start" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Waktu Berakhir <span class="text-danger">*</span></label>
                                <input type="datetime-local" id="edit_exam_end" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Durasi (Menit) <span class="text-danger">*</span></label>
                                <input type="number" id="edit_exam_duration" class="form-control" min="1" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mt-4 pt-1">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="edit_exam_shuffle_q">
                                    <label class="custom-control-label" for="edit_exam_shuffle_q">Acak Soal</label>
                                </div>
                                <div class="custom-control custom-switch mt-1">
                                    <input type="checkbox" class="custom-control-input" id="edit_exam_shuffle_o">
                                    <label class="custom-control-label" for="edit_exam_shuffle_o">Acak Opsi</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary font-weight-bold">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Add Exam -->
<div class="modal fade" id="modalAddExam" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="form-add-exam" onsubmit="addExam(event)">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title font-weight-bold">Tambah Jadwal Ujian</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- 1. Pilih Bank Soal -->
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Pilih Bank Soal <span class="text-danger">*</span></label>
                        <select id="add_bank_soal_id" class="form-control" required onchange="onSelectBankSoalChange('add', true)">
                            <option value="" disabled selected>-- Pilih Bank Soal --</option>
                            <?php foreach ($bank_soal as $b): ?>
                                <option value="<?= $b['id'] ?>"
                                    data-name="<?= htmlspecialchars($b['name']) ?>"
                                    data-count="<?= (int)($b['question_count'] ?? 0) ?>"
                                    data-classes="<?= htmlspecialchars($b['classes'] ?? '') ?>">
                                    <?= htmlspecialchars($b['name']) ?> (<?= (int)($b['question_count'] ?? 0) ?> Soal)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Pilih bank soal yang akan digunakan. Nama ujian, kelas, dan jumlah soal akan terisi otomatis.</small>
                    </div>

                    <!-- 2. Nama Ujian (Auto terisi) -->
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Nama Ujian <span class="text-danger">*</span></label>
                        <input type="text" id="add_exam_name" class="form-control font-weight-bold" placeholder="Contoh: PAS INFORMATIKA" required>
                        <small class="text-muted">Otomatis terisi saat bank soal dipilih (format: <code>JENIS MAPEL</code>). Tetap dapat diedit manual.</small>
                    </div>

                    <!-- 3. Pilih Kelas (Auto terceklis dari data kelas bank soal) -->
                    <div class="form-group mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="font-weight-bold mb-0">Pilih Kelas</label>
                            <small>
                                <a href="javascript:void(0)" onclick="$('.add-exam-class-cb').prop('checked', true);" class="mr-2">Pilih Semua</a>
                                <a href="javascript:void(0)" onclick="$('.add-exam-class-cb').prop('checked', false);" class="text-muted">Kosongkan (Semua)</a>
                            </small>
                        </div>
                        <div class="border p-2 rounded bg-light" style="max-height: 140px; overflow-y: auto;">
                            <div class="row">
                                <?php foreach ($classes as $c): ?>
                                    <div class="col-md-3 col-6">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input add-exam-class-cb" id="add_class_<?= $c['id'] ?>" value="<?= $c['id'] ?>" data-name="<?= htmlspecialchars($c['name']) ?>">
                                            <label class="custom-control-label font-weight-normal text-dark" for="add_class_<?= $c['id'] ?>" style="cursor: pointer;"><?= htmlspecialchars($c['name']) ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <small class="text-muted">Centang kelas peserta ujian. Terceklis otomatis berdasarkan kelas pada bank soal.</small>
                    </div>

                    <!-- 4. Jumlah Soal (Auto terisi & bisa diedit untuk soal yang ditampilkan) -->
                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Jumlah Soal Ditampilkan</label>
                        <div class="input-group">
                            <input type="number" id="add_exam_max_questions" class="form-control" min="1" placeholder="Jumlah soal yang akan dikerjakan siswa">
                            <div class="input-group-append">
                                <span class="input-group-text bg-white" id="add_exam_total_badge">dari 0 soal di bank</span>
                            </div>
                        </div>
                        <small class="text-muted">Auto terisi dengan total soal di bank. Ubah angka ini jika ingin hanya menampilkan sebagian soal secara acak/urut ke siswa.</small>
                    </div>

                    <!-- Row Token & Status -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Token Ujian <span class="text-danger">*</span></label>
                                <input type="text" id="add_exam_token" class="form-control" placeholder="Contoh: MATH24" style="text-transform: uppercase;" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Status Ujian</label>
                                <select id="add_exam_status" class="form-control">
                                    <option value="aktif" selected>Aktif</option>
                                    <option value="draft">Draft</option>
                                    <option value="selesai">Selesai</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Row Waktu & Durasi & Acak -->
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Waktu Mulai <span class="text-danger">*</span></label>
                                <input type="datetime-local" id="add_exam_start" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Waktu Berakhir <span class="text-danger">*</span></label>
                                <input type="datetime-local" id="add_exam_end" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Durasi (Menit) <span class="text-danger">*</span></label>
                                <input type="number" id="add_exam_duration" class="form-control" min="1" value="90" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mt-4 pt-1">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="add_exam_shuffle_q" checked>
                                    <label class="custom-control-label" for="add_exam_shuffle_q">Acak Soal</label>
                                </div>
                                <div class="custom-control custom-switch mt-1">
                                    <input type="checkbox" class="custom-control-input" id="add_exam_shuffle_o" checked>
                                    <label class="custom-control-label" for="add_exam_shuffle_o">Acak Opsi</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary font-weight-bold">Simpan Jadwal Ujian</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="section-mapel" class="content-section">
    <?php
    $countAll = count($exams ?? []);
    $countAktif = 0;
    $countSelesai = 0;
    $countDraft = 0;
    foreach (($exams ?? []) as $e) {
        $st = strtolower($e['status'] ?? 'aktif');
        if ($st === 'aktif') $countAktif++;
        elseif ($st === 'selesai') $countSelesai++;
        elseif ($st === 'draft' || $st === 'draf') $countDraft++;
    }
    ?>
    <div class="card card-outline card-info mt-4">
        <div class="card-header pb-0 border-bottom-0">
            <div class="d-flex justify-content-between align-items-center flex-wrap mb-2">
                <h3 class="card-title font-weight-bold mb-1 mb-md-0" style="font-size: 1.1rem;">
                    Daftar Mata Pelajaran & Token
                </h3>
                <div class="d-flex align-items-center flex-wrap" style="gap: 6px; margin-top: 6px;">
                    <input type="text" id="search-exam" class="form-control form-control-sm" placeholder="Cari mapel / kelas..." style="width: 200px; display: inline-block;" oninput="filterExamTable()">
                    
                    <!-- Bulk Action Controls -->
                    <div id="bulk-exam-actions" class="d-inline-flex align-items-center" style="display: none !important;">
                        <!-- Bulk Status Dropdown -->
                        <div class="btn-group mr-1">
                            <button type="button" class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-toggle-on mr-1"></i> Ubah Status (<span class="selected-exam-count">0</span>)
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item text-success" href="javascript:void(0)" onclick="bulkUpdateExamStatus('aktif')">
                                    <i class="fas fa-check-circle mr-2"></i> Set <strong>Aktif</strong>
                                </a>
                                <a class="dropdown-item text-secondary" href="javascript:void(0)" onclick="bulkUpdateExamStatus('draft')">
                                    <i class="fas fa-file-alt mr-2"></i> Set <strong>Draft</strong>
                                </a>
                                <a class="dropdown-item text-info" href="javascript:void(0)" onclick="bulkUpdateExamStatus('selesai')">
                                    <i class="fas fa-flag-checkered mr-2"></i> Set <strong>Selesai</strong>
                                </a>
                            </div>
                        </div>

                        <!-- Bulk Delete Button -->
                        <button id="btn-bulk-delete-exam" class="btn btn-danger btn-sm" onclick="bulkDeleteExam()">
                            <i class="fas fa-trash mr-1"></i> Hapus Terpilih (<span class="selected-exam-count">0</span>)
                        </button>
                    </div>

                    <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalAddExam">
                        <i class="fas fa-plus mr-1"></i> Tambah Jadwal
                    </button>
                </div>
            </div>

            <!-- Filter Tabs Status & Tampilkan Selector -->
            <div class="d-flex justify-content-between align-items-center flex-wrap" style="border-bottom: 2px solid #e9ecef; margin-bottom: 16px;">
                <ul class="nav custom-exam-tabs" id="exam-status-tabs" style="border-bottom: none; margin-bottom: 0;">
                    <li class="nav-item">
                        <a class="nav-link active" href="javascript:void(0)" onclick="filterExamTab('all', this)">
                            Semua Ujian <span class="badge badge-tab" id="tab-count-all"><?= $countAll ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="filterExamTab('aktif', this)">
                            Aktif <span class="badge badge-tab" id="tab-count-aktif"><?= $countAktif ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="filterExamTab('selesai', this)">
                            Selesai <span class="badge badge-tab" id="tab-count-selesai"><?= $countSelesai ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="filterExamTab('draft', this)">
                            Draf <span class="badge badge-tab" id="tab-count-draft"><?= $countDraft ?></span>
                        </a>
                    </li>
                </ul>

                <!-- Tampilkan 10, 20, 50, Semua di sebelah ujung kanan -->
                <div class="d-inline-flex align-items-center my-1 ml-auto" style="gap: 6px;">
                    <label for="exam-page-size" class="mb-0 text-muted" style="font-size: 0.85rem; font-weight: 500; white-space: nowrap;">
                        Tampilkan:
                    </label>
                    <select id="exam-page-size" class="form-control form-control-sm custom-select custom-select-sm" style="width: auto; min-width: 90px; height: 32px; font-size: 0.85rem;" onchange="changeExamPageSize(this.value)">
                        <option value="10" selected>10</option>
                        <option value="20">20</option>
                        <option value="50">50</option>
                        <option value="all">Semua</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="card-body p-0 table-responsive">
            <table class="table table-striped table-bordered mb-0" id="table-exam">
                <thead>
                    <tr class="text-center align-middle">
                        <th style="width: 40px" class="text-center align-middle"><input type="checkbox" id="cb-all-exam" onchange="toggleAllExam(this)" title="Pilih Semua"></th>
                        <th style="width: 55px" class="text-center align-middle sortable-th" onclick="sortMapelTable(1)" title="Urutkan No">No <i class="fas fa-sort text-muted ml-1" id="sort-icon-1"></i></th>
                        <th class="text-center align-middle sortable-th" onclick="sortMapelTable(2)" title="Urutkan Mata Pelajaran">Nama Mata Pelajaran <i class="fas fa-sort text-muted ml-1" id="sort-icon-2"></i></th>
                        <th class="text-center align-middle sortable-th" onclick="sortMapelTable(3)" title="Urutkan Bank Soal">Bank Soal <i class="fas fa-sort text-muted ml-1" id="sort-icon-3"></i></th>
                        <th class="text-center align-middle sortable-th" onclick="sortMapelTable(4)" title="Urutkan Kelas">Kelas <i class="fas fa-sort text-muted ml-1" id="sort-icon-4"></i></th>
                        <th class="text-center align-middle sortable-th" onclick="sortMapelTable(5)" title="Urutkan Tanggal & Waktu">Tanggal & Waktu <i class="fas fa-sort text-muted ml-1" id="sort-icon-5"></i></th>
                        <th class="text-center align-middle sortable-th" onclick="sortMapelTable(6)" title="Urutkan Jml Soal">Jml Soal <i class="fas fa-sort text-muted ml-1" id="sort-icon-6"></i></th>
                        <th style="width: 115px" class="text-center align-middle sortable-th" onclick="sortMapelTable(7)" title="Urutkan Pengacakan">Acak Soal/Opsi <i class="fas fa-sort text-muted ml-1" id="sort-icon-7"></i></th>
                        <th style="width: 120px" class="text-center align-middle sortable-th" onclick="sortMapelTable(8)" title="Urutkan Token">Token <i class="fas fa-sort text-muted ml-1" id="sort-icon-8"></i></th>
                        <th style="width: 100px" class="text-center align-middle sortable-th" onclick="sortMapelTable(9)" title="Urutkan Status">Status <i class="fas fa-sort text-muted ml-1" id="sort-icon-9"></i></th>
                        <th style="width: 150px" class="text-center align-middle">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbody-exam">
                    <?php if (empty($exams)): ?>
                        <tr id="row-empty-exam"><td colspan="11" class="text-center py-3">Belum ada mata pelajaran</td></tr>
                    <?php else: ?>
                    <?php foreach ($exams as $i => $e): ?>
                    <tr class="exam-row" data-exam-id="<?= $e['id'] ?>" data-exam-name="<?= strtolower(htmlspecialchars($e['name'])) ?>" data-exam-status="<?= strtolower($e['status'] ?? 'aktif') ?>">
                        <td class="text-center align-middle"><input type="checkbox" class="cb-exam" value="<?= $e['id'] ?>" onchange="toggleExamSelection(this)"></td>
                        <td class="text-center align-middle exam-no-col" data-val="<?= $i + 1 ?>"><?= $i + 1 ?></td>
                        <td class="align-middle" data-val="<?= htmlspecialchars(strtolower($e['name'])) ?>">
                            <strong style="font-size: 0.85rem;"><?= htmlspecialchars($e['name']) ?></strong>
                        </td>
                        <?php
                        $bankName = '-';
                        $bankId = $e['bank_soal_id'] ?? $e['id'];
                        foreach ($bank_soal as $b) {
                            if ($b['id'] == $bankId) {
                                $bankName = $b['name'];
                                break;
                            }
                        }
                        ?>
                        <td class="text-center align-middle" data-val="<?= htmlspecialchars(strtolower($bankName)) ?>">
                            <a href="?page=soal&open_bank_id=<?= $bankId ?>&open_bank_name=<?= urlencode($bankName) ?>" class="text-primary font-weight-normal" style="font-size: 0.88rem;" title="Klik untuk preview soal">
                                <?= htmlspecialchars($bankName) ?>
                            </a>
                        </td>
                        <?php
                        $cNames = [];
                        $class_ids = $e['class_ids'] ?? $e['classes'] ?? null;
                        if ($class_ids === null && isset($e['class_id'])) {
                            $class_ids = $e['class_id'] == 0 ? [] : [$e['class_id']];
                        } else if (!is_array($class_ids) && !empty($class_ids)) {
                            $class_ids = json_decode($class_ids, true) ?: [];
                        }
                        if (empty($class_ids)) {
                            $cNames[] = 'Semua Kelas';
                        } else {
                            foreach ($classes as $c) {
                                if (in_array($c['id'], $class_ids)) {
                                    $cNames[] = $c['name'];
                                }
                            }
                        }
                        $cNamesStr = implode(', ', $cNames);
                        ?>
                        <td class="align-middle" data-val="<?= htmlspecialchars(strtolower($cNamesStr)) ?>">
                            <span style="font-size: 0.85rem;"><?= htmlspecialchars($cNamesStr) ?></span>
                        </td>
                        <td class="align-middle text-nowrap" data-val="<?= strtotime($e['start_time'] ?? 'now') ?>">
                            <small class="text-muted d-block" style="font-size: 0.82rem;">
                                <i class="far fa-clock mr-1"></i> <?= date('d/m/Y H:i', strtotime($e['start_time'] ?? 'now')) ?> - <?= date('d/m/Y H:i', strtotime($e['end_time'] ?? 'now')) ?>
                            </small>
                            <small class="text-muted d-block mt-1" style="font-size: 0.8rem;">
                                <i class="fas fa-hourglass-half mr-1 text-muted"></i> <?= $e['duration'] ?? 90 ?> Menit
                            </small>
                        </td>
                        <?php 
                        $totalBankQ = (int)($e['question_count'] ?? 0);
                        $maxQ = !empty($e['max_questions']) ? (int)$e['max_questions'] : 0;
                        $displayQ = ($maxQ > 0) ? $maxQ : $totalBankQ;
                        ?>
                        <td class="text-center align-middle" style="font-size: 0.88rem;" data-val="<?= $displayQ ?>">
                            <?php 
                            if ($maxQ > 0 && $maxQ < $totalBankQ) {
                                echo "<strong>{$maxQ}</strong> <small class='text-muted' style='font-size: 0.78rem;'>/{$totalBankQ}</small>";
                            } else {
                                echo $totalBankQ;
                            }
                            ?>
                        </td>
                        <!-- Kolom Baru: Acak Soal & Opsi -->
                        <td class="text-center align-middle" data-val="<?= (!empty($e['shuffle_questions']) ? 2 : 0) + (!empty($e['shuffle_options']) ? 1 : 0) ?>">
                            <div class="d-inline-flex flex-column" style="gap: 2px; font-size: 0.74rem; text-align: left;">
                                <div class="d-flex align-items-center justify-content-between" style="width: 58px;" title="Pengacakan Soal: <?= !empty($e['shuffle_questions']) ? 'Aktif' : 'Nonaktif' ?>">
                                    <span class="text-muted" style="font-weight: 500;">Soal:</span>
                                    <span><?= !empty($e['shuffle_questions']) ? '<i class="fas fa-check text-success" style="font-size: 0.7rem;"></i>' : '<i class="fas fa-times text-danger" style="font-size: 0.7rem;"></i>' ?></span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between" style="width: 58px;" title="Pengacakan Opsi: <?= !empty($e['shuffle_options']) ? 'Aktif' : 'Nonaktif' ?>">
                                    <span class="text-muted" style="font-weight: 500;">Opsi:</span>
                                    <span><?= !empty($e['shuffle_options']) ? '<i class="fas fa-check text-success" style="font-size: 0.7rem;"></i>' : '<i class="fas fa-times text-danger" style="font-size: 0.7rem;"></i>' ?></span>
                                </div>
                            </div>
                        </td>
                        <td class="text-center align-middle" data-val="<?= htmlspecialchars(strtolower($e['token'])) ?>">
                            <span class="badge badge-light border px-2 py-1" style="font-family: monospace; font-size: 0.95rem; letter-spacing: 1px;">
                                <?= htmlspecialchars($e['token']) ?>
                            </span>
                            <?php if (!empty($settings['dynamic_token'])): ?>
                                <div class="mt-1 text-muted" style="font-size: 0.72rem; font-weight: 300;" title="Token Dinamis (berganti setiap <?= (int)($settings['token_interval_minutes'] ?? 15) ?> menit)">
                                    <i class="fas fa-bolt text-warning" title="Token Dinamis"></i>
                                    <span class="ml-1 text-secondary"><i class="far fa-clock"></i> <?= (int)($settings['token_interval_minutes'] ?? 15) ?>m</span>
                                </div>
                            <?php endif; ?>
                        </td>
                        <?php 
                        $status = $e['status'] ?? 'aktif'; 
                        $badgeClass = 'badge-success';
                        if ($status == 'draft') $badgeClass = 'badge-secondary';
                        else if ($status == 'selesai') $badgeClass = 'badge-info';
                        ?>
                        <td class="text-center align-middle" data-val="<?= htmlspecialchars(strtolower($status)) ?>">
                            <span class="badge font-weight-normal <?= $badgeClass ?>" style="font-size: 0.85rem; padding: 6px 12px; font-weight: 400;"><?= ucfirst($status) ?></span>
                        </td>
                        <td class="text-center align-middle text-nowrap">
                            <a href="?page=status&live_exam_id=<?= $e['id'] ?>&live_exam_name=<?= urlencode($e['name']) ?>&live_exam_token=<?= urlencode($e['token']) ?>" class="btn btn-info btn-sm mr-1" title="Lihat Status"><i class="fas fa-eye"></i></a>
                            <button onclick='openEditExamModal(<?= json_encode($e) ?>)' class="btn btn-warning btn-sm mr-1" title="Edit"><i class="fas fa-edit"></i></button>
                            <button onclick="deleteExam(<?= $e['id'] ?>)" class="btn btn-danger btn-sm" title="Hapus"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!-- Pagination Footer -->
        <div class="card-footer clearfix d-flex flex-wrap justify-content-between align-items-center py-2 bg-light border-top" id="exam-pagination-container">
            <div id="exam-page-info" class="text-muted my-1" style="font-size: 0.88rem;">
                Menampilkan data...
            </div>
            <ul class="pagination pagination-sm m-0 my-1" id="exam-pagination">
            </ul>
        </div>
    </div>
</div>
<style>
#table-exam {
    border-top: 1px solid #dee2e6 !important;
}
#table-exam thead th,
#table-exam thead tr:first-child th {
    border-top: 1px solid #dee2e6 !important;
    text-align: center !important;
    vertical-align: middle !important;
}
.sortable-th {
    cursor: pointer;
    user-select: none;
    transition: background-color 0.15s ease;
}
.sortable-th:hover {
    background-color: rgba(0, 0, 0, 0.04);
}
/* Styling Tab Filter Mata Pelajaran */
#exam-status-tabs {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}
#exam-status-tabs .nav-item {
    margin-bottom: -2px; /* Overlap baseline border */
}
#exam-status-tabs .nav-link {
    cursor: pointer;
    font-size: 0.92rem;
    font-weight: 500;
    color: #6c757d;
    padding: 9px 18px;
    border: none;
    border-bottom: 3px solid transparent;
    background: transparent;
    border-radius: 0;
    display: inline-flex;
    align-items: center;
    transition: all 0.2s ease-in-out;
    text-decoration: none;
}
#exam-status-tabs .nav-link:hover {
    color: #007bff;
    background-color: rgba(0, 123, 255, 0.04);
    border-bottom-color: rgba(0, 123, 255, 0.35);
}
#exam-status-tabs .nav-link.active {
    color: #007bff;
    font-weight: 700;
    background-color: transparent;
    border-bottom: 3px solid #007bff; /* Aksen warna biru di bawah tab aktif */
}
#exam-status-tabs .badge-tab {
    font-size: 0.78rem;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 12px;
    background-color: #e9ecef;
    color: #495057;
    margin-left: 8px;
    transition: all 0.2s ease;
}
#exam-status-tabs .nav-link:hover .badge-tab {
    background-color: rgba(0, 123, 255, 0.12);
    color: #007bff;
}
#exam-status-tabs .nav-link.active .badge-tab {
    background-color: #007bff;
    color: #ffffff;
}
</style>

<script>
let mapelSortCol = null;
let mapelSortDir = 'asc';
let currentExamStatusTab = 'all';
let examCurrentPage = 1;
let examPageSize = '10';

function changeExamPageSize(val) {
    examPageSize = val;
    examCurrentPage = 1;
    filterExamTable();
}

function goToExamPage(page) {
    examCurrentPage = page;
    filterExamTable();
}

function filterExamTab(status, tabEl) {
    currentExamStatusTab = status;
    examCurrentPage = 1;
    document.querySelectorAll('#exam-status-tabs .nav-link').forEach(el => {
        el.classList.remove('active');
    });
    if (tabEl) {
        tabEl.classList.add('active');
    }
    filterExamTable();
}

function filterExamTable() {
    const query = (document.getElementById('search-exam')?.value || '').toLowerCase().trim();
    const allRows = Array.from(document.querySelectorAll('.exam-row'));

    // Filter matched rows based on query & status
    const matchedRows = allRows.filter(row => {
        const text = row.innerText.toLowerCase();
        const matchQuery = !query || text.includes(query);

        const rowStatus = (row.getAttribute('data-exam-status') || 'aktif').toLowerCase();
        let matchStatus = true;
        if (currentExamStatusTab !== 'all') {
            if (currentExamStatusTab === 'draft' || currentExamStatusTab === 'draf') {
                matchStatus = (rowStatus === 'draft' || rowStatus === 'draf');
            } else {
                matchStatus = (rowStatus === currentExamStatusTab);
            }
        }
        return matchQuery && matchStatus;
    });

    const totalMatched = matchedRows.length;
    const isAll = (examPageSize === 'all');
    const pageSize = isAll ? totalMatched : parseInt(examPageSize, 10);
    const totalPages = isAll ? 1 : (pageSize > 0 ? Math.ceil(totalMatched / pageSize) : 1);

    if (examCurrentPage > totalPages && totalPages > 0) {
        examCurrentPage = totalPages;
    }
    if (examCurrentPage < 1) {
        examCurrentPage = 1;
    }

    const startIndex = isAll ? 0 : (examCurrentPage - 1) * pageSize;
    const endIndex = isAll ? totalMatched : Math.min(startIndex + pageSize, totalMatched);

    const visibleRowsSlice = matchedRows.slice(startIndex, endIndex);
    const visibleSet = new Set(visibleRowsSlice);

    allRows.forEach(row => {
        if (visibleSet.has(row)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });

    // Re-index No column for visible slice
    visibleRowsSlice.forEach((row, idx) => {
        const noCol = row.querySelector('.exam-no-col');
        if (noCol) {
            const num = startIndex + idx + 1;
            noCol.textContent = num;
            noCol.setAttribute('data-val', num);
        }
    });

    // Empty state
    const emptyRow = document.getElementById('row-empty-exam');
    if (emptyRow) {
        emptyRow.style.display = (totalMatched === 0 && allRows.length > 0) ? '' : 'none';
        if (totalMatched === 0 && allRows.length > 0) {
            emptyRow.querySelector('td').innerText = 'Tidak ada mata pelajaran yang cocok dengan filter / pencarian.';
        }
    }

    renderExamPagination(totalMatched, totalPages, startIndex, endIndex, isAll);

    if (typeof updateExamBulkUI === 'function') {
        updateExamBulkUI();
    }
}

function renderExamPagination(totalMatched, totalPages, startIndex, endIndex, isAll) {
    const infoEl = document.getElementById('exam-page-info');
    const paginationEl = document.getElementById('exam-pagination');
    const containerEl = document.getElementById('exam-pagination-container');
    if (!infoEl || !paginationEl) return;

    if (totalMatched === 0) {
        infoEl.innerHTML = 'Tidak ada data mata pelajaran';
        paginationEl.innerHTML = '';
        if (containerEl) containerEl.style.display = 'none';
        return;
    }

    if (containerEl) containerEl.style.display = 'flex';

    if (isAll) {
        infoEl.innerHTML = `Menampilkan semua <strong>${totalMatched}</strong> mata pelajaran`;
        paginationEl.innerHTML = '';
        return;
    }

    infoEl.innerHTML = `Menampilkan <strong>${startIndex + 1}</strong> - <strong>${endIndex}</strong> dari <strong>${totalMatched}</strong> mata pelajaran`;

    if (totalPages <= 1) {
        paginationEl.innerHTML = '';
        return;
    }

    let html = '';
    html += `<li class="page-item ${examCurrentPage === 1 ? 'disabled' : ''}">
        <a class="page-link" href="javascript:void(0)" onclick="goToExamPage(${examCurrentPage - 1})">&laquo;</a>
    </li>`;

    for (let p = 1; p <= totalPages; p++) {
        if (totalPages > 7) {
            if (p !== 1 && p !== totalPages && Math.abs(p - examCurrentPage) > 1) {
                if (p === 2 || p === totalPages - 1) {
                    html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                }
                continue;
            }
        }
        html += `<li class="page-item ${p === examCurrentPage ? 'active' : ''}">
            <a class="page-link" href="javascript:void(0)" onclick="goToExamPage(${p})">${p}</a>
        </li>`;
    }

    html += `<li class="page-item ${examCurrentPage === totalPages ? 'disabled' : ''}">
        <a class="page-link" href="javascript:void(0)" onclick="goToExamPage(${examCurrentPage + 1})">&raquo;</a>
    </li>`;

    paginationEl.innerHTML = html;
}

function sortMapelTable(colIndex) {
    const tbody = document.getElementById('tbody-exam');
    if (!tbody) return;
    const rows = Array.from(tbody.querySelectorAll('tr.exam-row'));
    if (rows.length === 0) return;

    if (mapelSortCol === colIndex) {
        mapelSortDir = (mapelSortDir === 'asc') ? 'desc' : 'asc';
    } else {
        mapelSortCol = colIndex;
        mapelSortDir = 'asc';
    }

    // Update sort icons on headers
    for (let c = 1; c <= 9; c++) {
        const icon = document.getElementById('sort-icon-' + c);
        if (icon) {
            if (c === colIndex) {
                icon.className = 'fas fa-sort-' + (mapelSortDir === 'asc' ? 'up' : 'down') + ' text-primary ml-1';
            } else {
                icon.className = 'fas fa-sort text-muted ml-1';
            }
        }
    }

    rows.sort((a, b) => {
        const tdA = a.children[colIndex];
        const tdB = b.children[colIndex];
        if (!tdA || !tdB) return 0;

        let valA = tdA.getAttribute('data-val');
        let valB = tdB.getAttribute('data-val');

        if (valA === null) valA = tdA.innerText.trim().toLowerCase();
        if (valB === null) valB = tdB.innerText.trim().toLowerCase();

        // Numeric comparison for No (1), Tanggal Timestamp (5), Jml Soal (6), and Acak (7)
        if (colIndex === 1 || colIndex === 5 || colIndex === 6 || colIndex === 7) {
            valA = parseFloat(valA) || 0;
            valB = parseFloat(valB) || 0;
        }

        if (valA < valB) return mapelSortDir === 'asc' ? -1 : 1;
        if (valA > valB) return mapelSortDir === 'asc' ? 1 : -1;
        return 0;
    });

    // Re-append sorted rows to tbody
    rows.forEach(row => tbody.appendChild(row));

    // Re-apply current page & filter slice
    filterExamTable();
}

// Initial run
document.addEventListener('DOMContentLoaded', function() {
    filterExamTable();
});
</script>
