<div id="section-log" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex align-items-center justify-content-between flex-wrap">
            <h3 class="card-title font-weight-bold my-1"><i class="fas fa-history mr-2 text-info"></i>Log Pembaruan Sistem</h3>
            <div class="d-flex flex-wrap align-items-center my-1">
                <span class="badge badge-primary px-2 py-1 mr-2"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                <span class="badge badge-success px-2 py-1 mr-2"><i class="fas fa-wrench mr-1"></i> Fix</span>
                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
            </div>
        </div>
        <div class="card-body">
            <div class="timeline">

                <!-- Versi 1.6.8 -->
                <div>
                    <i class="fas fa-user-shield text-white" style="background-color: #2563eb;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 4 Okt 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #2563eb;">
                            Versi 1.6.8 &mdash; Role &amp; Hak Akses Berbasis Tugas serta Proteksi Keamanan
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Sistem Role Berbasis Tugas:</strong> Pengaturan peran admin fleksibel (Super Admin, Proktor, Pengawas, dll.) melalui checklist hak akses interaktif.</li>
                                    <li><strong>14 Modul Hak Akses Granular:</strong> Pembagian izin akses menu mencakup Dashboard, Master Data, Bank Soal, Pelaksanaan, hingga Pengaturan Sistem.</li>
                                    <li><strong>Route Guard &amp; Sidebar Otomatis:</strong> Filter menu navigasi sesuai hak akses serta proteksi pengalihan aman bila URL diakses tanpa izin.</li>
                                    <li><strong>Proteksi Admin Utama:</strong> Perlindungan otomatis agar akun dan izin administrator utama tidak dapat dinonaktifkan atau terhapus.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Antarmuka Kelola Admin:</strong> Tampilan daftar administrator tabel penuh yang bersih dengan form tambah/edit di modal pop-up.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.7 -->
                <div>
                    <i class="fas fa-mobile-alt text-white" style="background-color: #1F7FAB;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 2 Okt 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #1F7FAB;">
                            Versi 1.6.7 &mdash; Kustomisasi Ikon PWA &amp; Sinkronisasi Otomatis
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Pengaturan Ikon PWA Terpadu:</strong> Pengaturan ikon aplikasi di menu Identitas Sekolah sejajar dengan Logo Sekolah dan Favicon.</li>
                                    <li><strong>Auto-Resizer Proporsional:</strong> Pemrosesan otomatis gambar sumber ke ukuran standar PWA 192&times;192 px dan 512&times;512 px berlatar transparan.</li>
                                    <li><strong>Pratinjau Instan &amp; Tombol Pintas:</strong> Pratinjau thumbnail instan, fitur <em>Samakan Logo</em>, serta opsi pemulihan ke ikon bawaan 1 klik.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Sinkronisasi Manifest:</strong> Pembaruan otomatis nama sekolah dan aset ikon pada berkas manifest dengan penanganan cache buster browser.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.6 -->
                <div>
                    <i class="fas fa-file-excel text-white" style="background-color: #107c41;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 29 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #107c41;">
                            Versi 1.6.6 &mdash; Ekspor Excel Analisis Butir Soal (.xlsx), Psikometri &amp; Form Login 3D
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Ekspor Excel Analisis Butir Soal (.xlsx):</strong> Format standar 4 sheet (Kualitas Soal, Matriks Skor, Distribusi Jawaban Pengecoh, dan Statistik Ketuntasan).</li>
                                    <li><strong>Kalkulasi Psikometri Lengkap:</strong> Perhitungan otomatis Daya Pembeda, Tingkat Kesukaran, pemisahan Kelompok Atas/Bawah, dan efektivitas distraktor.</li>
                                    <li><strong>Penyegaran UI Analisis Soal:</strong> Ringkasan kartu statistik metrik evaluasi dan tab interaktif rekap butir soal.</li>
                                    <li><strong>Form Login Admin 3D &amp; Modernisasi UI:</strong> Animasi robot interaktif responsif pada halaman login serta perapian aksen navigasi sidebar.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.5 -->
                <div>
                    <i class="fas fa-layer-group text-white" style="background-color: #0284c7;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 29 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #0284c7;">
                            Versi 1.6.5 &mdash; Restrukturisasi Toolbar Bank Soal, Generator AI &amp; Editor Rumus KaTeX
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Restrukturisasi Toolbar Kelola Soal:</strong> Pengelompokan 11 tombol aksi ke dalam 5 kluster rapi (Bantuan, Cadangan, Penilaian, Pratinjau, dan Aksi Utama).</li>
                                    <li><strong>Integrasi Generator Soal AI:</strong> Pembuatan naskah soal otomatis via Google Gemini dalam jendela samping (Side-by-Side) siap impor.</li>
                                    <li><strong>Editor Rumus Matematika (KaTeX):</strong> Toolbar rumus LaTeX terintegrasi Summernote dengan modal simbol cepat dan live preview.</li>
                                    <li><strong>Pembaruan Halaman Panduan:</strong> Penambahan panduan pembuatan soal AI dan penulisan format rumus matematika.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.4 -->
                <div>
                    <i class="fas fa-eye text-white" style="background-color: #0284c7;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 23 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #0284c7;">
                            Versi 1.6.4 &mdash; Pratinjau Butir Soal (Simulasi Siswa) &amp; Preview Mandiri
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Simulasi Tampilan Siswa:</strong> Pratinjau butir soal interaktif langsung dari tabel Bank Soal dan toolbar Kelola Soal.</li>
                                    <li><strong>Dukungan Semua Ragam Soal:</strong> Pratinjau akurat untuk PG Tunggal, PG Kompleks, Benar-Salah, Menjodohkan, dan Esai.</li>
                                    <li><strong>Saklar Kunci &amp; Navigasi Nomor:</strong> Fitur sorot kunci jawaban untuk verifikasi naskah dan panel lompat nomor soal.</li>
                                    <li><strong>Mode Layar Penuh (preview.php):</strong> Simulasi mandiri di tab browser baru tanpa perlu akun peserta atau token ujian.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.3 -->
                <div>
                    <i class="fas fa-mobile-alt text-white" style="background-color: #0284c7;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 23 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #0284c7;">
                            Versi 1.6.3 &mdash; Dukungan PWA: Instalasi Mandiri &amp; Tampilan Layar Penuh
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Progressive Web App (PWA):</strong> Dukungan pemasangan aplikasi langsung ke layar utama smartphone tanpa melalui Play Store.</li>
                                    <li><strong>Smart Install Banner:</strong> Tombol pasang otomatis di halaman login yang terhubung ke dialog instalasi perangkat.</li>
                                    <li><strong>Tampilan Standalone:</strong> Antarmuka layar penuh tanpa bilah URL browser untuk area pengerjaan soal yang lebih luas.</li>
                                    <li><strong>Service Worker Cache:</strong> Caching aset statis untuk pemuatan secepat kilat dengan pengamanan data ujian berbasis Network-Only.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.2 -->
                <div>
                    <i class="fas fa-bolt text-white" style="background-color: #8b5cf6;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 22 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #8b5cf6;">
                            Versi 1.6.2 &mdash; Optimasi Konkurensi Database &amp; Eliminasi Aset Redundan
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Kueri O(1) Login &amp; Mulai Ujian:</strong> Mengganti pemanggilan data massal dengan kueri SQL tertarget (<code>WHERE id = ? LIMIT 1</code>), memangkas beban RAM server.</li>
                                    <li><strong>Secondary Index MySQL:</strong> Penambahan indeks komposit <code>(exam_id, student_id)</code> pada tabel sesi dan hasil ujian untuk mencegah full table scan.</li>
                                    <li><strong>Cache Buster Aset Statis:</strong> Penerapan <code>filemtime()</code> pada logo sticky header agar tersimpan efisien di cache peramban.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Migrasi Bootstrap Icons:</strong> Menghapus ketergantungan CDN FontAwesome di halaman siswa dan beralih penuh ke Bootstrap Icons ringan.</li>
                                    <li><strong>Preconnect Google Fonts:</strong> Tag <code>rel="preconnect"</code> untuk mempercepat render teks soal pada koneksi internet terbatas.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.1 -->
                <div>
                    <i class="fas fa-tachometer-alt text-white" style="background-color: #3b82f6;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 22 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-primary">
                            Versi 1.6.1 &mdash; Optimasi Kueri Kelas &amp; Monitoring Pengawas
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Optimasi Pemilihan Kelas:</strong> Mengganti pembacaan seluruh data ujian dengan kueri filter ringan dan pencocokan hash map O(1).</li>
                                    <li><strong>Penyaringan Database Siswa:</strong> Filter per kelas diproses langsung pada level database MySQL (<code>WHERE class_id = ?</code>).</li>
                                    <li><strong>Efisiensi Live Monitoring:</strong> Pembacaan status pengawas hanya mengambil data dari jadwal ujian yang sedang aktif dipantau.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.6.0 -->
                <div>
                    <i class="fas fa-server text-white" style="background-color: #10b981;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 22 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.6.0 &mdash; Optimasi Cloud Hosting &amp; Non-Blocking Session
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Non-Blocking PHP Session:</strong> Pelepasan kunci sesi dini (<code>session_write_close</code>) untuk membebaskan antrean Entry Process pada cloud hosting.</li>
                                    <li><strong>Eliminasi Penguncian MySQL:</strong> Menghapus kueri pembersihan otomatis pada pembacaan data reguler untuk mencegah table lock.</li>
                                    <li><strong>Pengamanan DDL Skema:</strong> Eksekusi penambahan kolom database dilindungi agar hanya berjalan sekali per siklus.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Smart Image Caching:</strong> Pemanfaatan waktu modifikasi berkas (<code>filemtime</code>) pada logo dan favicon agar di-cache optimal oleh browser &amp; CDN.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.9 -->
                <div>
                    <i class="fas fa-user-check text-white" style="background-color: #007bff;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 22 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-primary">
                            Versi 1.5.9 &mdash; Perbaikan Dropdown Kelas &amp; Efisiensi Polling Token
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Dropdown Kelas Stabil:</strong> Memperbaiki pilihan kelas yang ter-reset saat siswa sedang mencari nama atau mengetik kata sandi.</li>
                                    <li><strong>Preservasi Nilai Form:</strong> Pengisian daftar kelas cerdas tanpa menimpa elemen secara berulang jika opsi kelas tidak berubah.</li>
                                    <li><strong>Efisiensi Polling Token:</strong> Mencegah verifikasi ulang token berulang ke server saat form login sedang aktif diisi.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.8 -->
                <div>
                    <i class="fas fa-bolt text-white" style="background-color: #28a745;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 21 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.5.8 &mdash; Optimasi Skalabilitas &amp; Konkurensi Tinggi (500+ Siswa)
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Atomic Submission (O(1)):</strong> Penyimpanan hasil ujian per siswa secara atomik tanpa penulisan ulang seluruh tabel data.</li>
                                    <li><strong>Kompresi GZIP API:</strong> Kompresi otomatis output JSON API untuk menghemat kuota bandwidth unduhan soal serentak.</li>
                                    <li><strong>Static Asset Caching:</strong> Cache browser permanen pada berkas CSS dan JS untuk mengurangi lalu lintas jaringan server.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Pencegahan Deadlock Database:</strong> Menghilangkan penguncian tabel global saat ratusan siswa menyelesaikan ujian secara bersamaan.</li>
                                    <li><strong>Zero Scoring Overhead:</strong> Penghitungan nilai hanya dijalankan saat ujian selesai, membebaskan beban CPU saat siswa menjawab soal.</li>
                                    <li><strong>Efisiensi Polling Pengawas:</strong> Interval pemantauan 10 detik dengan pembacaan langsung dari sesi aktif tanpa rekalkulasi berulang.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.7 -->
                <div>
                    <i class="fas fa-rocket text-white" style="background-color: #007bff;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 21 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #007bff;">
                            Versi 1.5.7 &mdash; Cetak Kartu Peserta F4, Data Ruang &amp; Fitur Ekspor/Impor
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Cetak Kartu Peserta (F4 2x5):</strong> Cetak 10 kartu per lembar F4 lengkap dengan kop dinamis, logo sekolah, dan filter ruang/kelas.</li>
                                    <li><strong>Data No Peserta &amp; Ruang:</strong> Atribut nomor peserta dan ruang ujian pada tabel data siswa, form input, dan impor/ekspor Excel.</li>
                                    <li><strong>Sorting Header Tabel Siswa:</strong> Pengurutan data langsung dengan mengklik header tabel yang tersimpan otomatis di browser.</li>
                                    <li><strong>Ekspor/Impor &amp; Generator Password:</strong> Ekspor data siswa/guru (.xlsx), impor data mapel, serta pembuatan kata sandi siswa massal.</li>
                                    <li><strong>1 Token Dinamis Terpadu:</strong> Pengaturan 1 token bersama yang tersinkronisasi untuk seluruh jadwal ujian aktif.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Tata Letak Kartu Peserta:</strong> Penyeimbangan vertikal teks kartu dan pelebaran margin cetak lembar F4.</li>
                                    <li><strong>Preservasi Angka Nol Excel:</strong> Memastikan awalan angka nol pada NIP, NIS, dan password tidak terpotong saat ekspor.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Sinkronisasi Token Serentak:</strong> Mencegah perbedaan token antar-jadwal saat opsi 1 token global aktif.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.6 -->
                <div>
                    <i class="fas fa-check-circle text-white" style="background-color: #28a745;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 21 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.5.6 &mdash; Master Mapel &amp; Jenis Ujian, Generator Bank Soal, &amp; Penjadwalan Terstruktur
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Master Data Terpusat:</strong> Menu pengelolaan data Mata Pelajaran dan Jenis Ujian (PAS, PTS, PAT, dll).</li>
                                    <li><strong>Generator Bank Soal Unik:</strong> Format otomatis <code>[Jenis]-[Kelas]-[Mapel]-[Kode]</code> dengan tombol acak kode unik.</li>
                                    <li><strong>Otomatisasi Penjadwalan Ujian:</strong> Auto-fill nama ujian kapital, auto-check kelas, dan pengaturan batas jumlah soal tampil.</li>
                                    <li><strong>Standardisasi Ekspor Excel:</strong> Header kuning standar (#FFFF00), perataan sel konsisten, dan merge vertikal identitas.</li>
                                    <li><strong>Pantauan Realtime Ujian:</strong> Membuka tab baru otomatis dengan judul tab browser dinamis sesuai nama ujian.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Modal Edit Bank Soal:</strong> Tata letak dan fungsi diseragamkan persis dengan form pembuatan bank soal.</li>
                                    <li><strong>Urutan Form Jadwal:</strong> Penataan alur form jadwal menjadi lebih logis dan efisien.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Pemotongan Soal Siswa:</strong> Memperbaiki pemotongan butir soal di sisi siswa saat jumlah soal di jadwal dibatasi.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.5 -->
                <div>
                    <i class="fas fa-rocket text-white" style="background-color: #6f42c1;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 20 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #6f42c1;">
                            Versi 1.5.5 &mdash; Rekalkulasi Nilai Otomatis, Impor Kunci Excel, Kompresi WebP, &amp; Opsi Fleksibel
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Rekalkulasi Nilai Otomatis:</strong> Nilai siswa otomatis dihitung ulang saat kunci jawaban di bank soal diperbarui tanpa perlu ujian ulang.</li>
                                    <li><strong>Impor Kunci Jawaban Excel:</strong> Unggah kunci jawaban massal (.xlsx) sesuai template dinamis per tipe dan butir soal.</li>
                                    <li><strong>Kompresi Gambar WebP Otomatis:</strong> Gambar impor Word, ZIP, JSON, dan editor otomatis dikonversi ke WebP (hemat bandwidth &gt;75%).</li>
                                    <li><strong>Dukungan 4 Opsi (A-D) &amp; 5 Opsi (A-E):</strong> Tombol pengatur opsi pada form soal untuk fleksibilitas jenjang SD/SMP/SMA.</li>
                                    <li><strong>Live Settings Sync:</strong> Pengaturan admin tersinkronisasi instan ke layar siswa secara live tanpa reload halaman.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>In-Memory Static Cache:</strong> Optimasi kalkulasi nilai untuk mengeliminasi ribuan query SQL berulang.</li>
                                    <li><strong>Skalabilitas 500+ Siswa:</strong> Optimasi Gzip, browser caching, random jitter sync, dan deteksi auto-reconnect jaringan.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Opsi Kosong:</strong> Mengeliminasi opsi ke-5 kosong tanpa teks pada butir soal bertipe 4 opsi di layar siswa.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.4 -->
                <div>
                    <i class="fas fa-file-alt text-white" style="background-color: #007bff;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 20 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #007bff;">
                            Versi 1.5.4 &mdash; Redesain Pratinjau Soal Word, Template Mandiri, &amp; Antarmuka Mobile
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Pratinjau Soal Format Dokumen:</strong> Desain kartu dokumen Word rapi, kontainer lebar maksimal 1400px, dan tombol aksi ikon ringkas.</li>
                                    <li><strong>Generator Template Word Mandiri:</strong> Unduh template dokumen Word terpisah per tipe soal (PG, PGK, Benar/Salah, Menjodohkan).</li>
                                    <li><strong>Salin Format JSON 1 Klik:</strong> Tombol interaktif untuk menyalin struktur format JSON soal ANBK ke clipboard.</li>
                                    <li><strong>UI Mobile Siswa:</strong> Tombol navigasi Bootstrap Icons dan tombol segarkan (refresh sync) di tengah bilah navigasi.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Optimasi Tampilan HP:</strong> Penataan header ujian, timer kompak, dan tabel Benar/Salah responsif di layar sentuh.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Penyimpanan Jadwal Ujian:</strong> Memperbaiki opsi kelas dan acak soal yang sempat tidak tersimpan saat tambah/update jadwal.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.3 -->
                <div>
                    <i class="fas fa-bolt text-white" style="background-color: #20c997;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 20 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #20c997;">
                            Versi 1.5.3 &mdash; Debounced Batch Sync Jawaban &amp; Realtime Monitoring 5 Detik
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Debounced Interactive Batch Sync:</strong> Jawaban siswa otomatis dikirim ke server dalam 3 detik setelah interaksi terakhir.</li>
                                    <li><strong>Autosave Rutin 20 Detik:</strong> Interval sinkronisasi latar belakang dipercepat dari 60 detik menjadi 20 detik.</li>
                                    <li><strong>Auto-Refresh Monitoring:</strong> Layar pemantauan status siswa otomatis diperbarui setiap 5 detik dengan animasi spinning feedback.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Single-Row DB Update:</strong> Endpoint sinkronisasi progres dioptimalkan menjadi single query per siswa untuk memangkas I/O database.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Concurrency Guard:</strong> Proteksi pencegahan tabrakan request HTTP saat koneksi jaringan siswa berfluktuasi.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.2 -->
                <div>
                    <i class="fas fa-tools text-white" style="background-color: #e83e8c;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #e83e8c;">
                            Versi 1.5.2 &mdash; Pembersihan Database Selektif, Paginasi Status, &amp; Penegakan Password Login
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Pembersihan Database Selektif:</strong> Hapus data per kategori (Nilai, Sesi, Jadwal, Bank Soal, Siswa, Guru) atau reset total via transaksi aman.</li>
                                    <li><strong>Live Counter Badge:</strong> Penghitung jumlah data riil langsung dari database pada setiap kategori.</li>
                                    <li><strong>Paginasi "Tampilkan Semua":</strong> Opsi menampilkan seluruh peserta dalam 1 halaman pada tabel status monitoring.</li>
                                    <li><strong>Penegakan Password Siswa:</strong> Pengisian kata sandi diwajibkan untuk seluruh mode login lengkap dengan ikon lihat password.</li>
                                    <li><strong>Reset Status Ujian:</strong> Tombol cepat untuk mengembalikan status seluruh peserta ke <em>Belum Mulai</em>.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Alokasi ID Jadwal Baru:</strong> Penomoran ID selalu menggunakan nilai tertinggi untuk mencegah daur ulang ID lama.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Cascading Delete &amp; Data Orphan:</strong> Pembersihan otomatis sisa sesi/nilai ketika jadwal ujian dihapus dari sistem.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.5.0 -->
                <div>
                    <i class="fas fa-database text-white" style="background-color: #6f42c1;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #6f42c1;">
                            Versi 1.5.0 &mdash; Migrasi Arsitektur Basis Data MySQL (PDO) &amp; Dual Live-Sync
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Migrasi Penuh MySQL PDO:</strong> Mendukung transaksi atomic, prepared statements, dan konkurensi ribuan siswa.</li>
                                    <li><strong>Struktur 9 Tabel Relasional:</strong> Pengorganisasian data terstruktur dengan pengindeksan optimal.</li>
                                    <li><strong>Integrasi Backup/Restore ZIP:</strong> Pemulihan database langsung sinkron ke seluruh tabel relasional MySQL.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Mekanisme Dual Live-Sync:</strong> Sinkronisasi instan antara tabel MySQL dan berkas arsip lokal sebagai cadangan.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>File Lock Contention:</strong> Mengeliminasi antrean dan tabrakan penulisan berkas JSON bersamaan.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.7 -->
                <div>
                    <i class="fas fa-user-check text-white" style="background-color: #17a2b8;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-info">
                            Versi 1.4.7 &mdash; Login Akun ANBK, Backup/Restore ZIP, &amp; Ekspor Semua Jawaban
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Mode Login Akun &amp; Konfirmasi Peserta:</strong> Mode login Username &amp; Password standar ANBK dengan kartu konfirmasi data peserta.</li>
                                    <li><strong>Backup &amp; Restore Database (.zip):</strong> Pencadangan dan pemulihan seluruh basis data sistem dalam 1 berkas ZIP bertanggal.</li>
                                    <li><strong>Paginasi &amp; Live Search Siswa:</strong> Navigasi halaman fleksibel dan filter pencarian instan pada tabel siswa.</li>
                                    <li><strong>Ekspor Seluruh Jawaban Siswa (.xlsx):</strong> Rekapitulasi lembar jawaban seluruh peserta dengan pewarnaan otomatis benar/salah.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Tab Database Pengaturan:</strong> Pemisahan menu pemeliharaan dan backup data pada tab tersendiri.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Validasi Restore ZIP:</strong> Pemeriksaan integritas struktur berkas arsip untuk mencegah kerusakan basis data.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.6 -->
                <div>
                    <i class="fas fa-layer-group text-white" style="background-color: #28a745;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.4.6 &mdash; Tipe Soal Menjodohkan, Bulk Download Nilai ZIP, &amp; Kustomisasi Sekolah
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Tipe Soal Menjodohkan (Matching Pairs):</strong> Format kartu horizontal bersih standar ANBK dengan penilaian parsial otomatis.</li>
                                    <li><strong>Bulk Download Nilai ZIP:</strong> Unduh massal rekap nilai banyak kelas sekaligus dikemas otomatis ke dalam berkas ZIP.</li>
                                    <li><strong>Identitas Sekolah &amp; Logo Dinamis:</strong> Kustomisasi nama dan logo sekolah pada halaman login dan panel admin.</li>
                                    <li><strong>Manajemen Akun Admin:</strong> Tab pengelolaan admin baru dan fitur ubah password administrator aktif.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Penyederhanaan UI:</strong> Pembersihan teks redundan pada sidebar dan penataan letak logo sekolah.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Perhitungan Nilai Parsial:</strong> Memperbaiki rasio skor penjodohan agar tepat proporsional terhadap pasangan yang benar.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.5 -->
                <div>
                    <i class="fas fa-shield-alt text-white" style="background-color: #007bff;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #007bff;">
                            Versi 1.4.5 &mdash; Modal Konfirmasi Bebas Pelanggaran &amp; Analisis Butir Soal ANBK
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Modal Konfirmasi Selesai Internal:</strong> Dialog konfirmasi modern dalam halaman lengkap dengan ringkasan status pengerjaan soal.</li>
                                    <li><strong>Analisis Butir Soal Lengkap:</strong> Dukungan analisis seluruh tipe soal (PG, PGK, Benar/Salah, dan Esai).</li>
                                    <li><strong>Auto-Recovery Soal:</strong> Rekonstruksi data butir soal secara otomatis dari hasil jawaban siswa jika berkas fisik terhapus.</li>
                                    <li><strong>Pemisahan Tab Token Dinamis:</strong> Konfigurasi token dipindahkan ke tab khusus dengan toggle standar.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Konsistensi Tabel Guru &amp; Analisis:</strong> Format tabel menggunakan <code>.table-bordered</code> dengan perataan tengah rapi.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Pencegahan Pelanggaran Palsu:</strong> Menonaktifkan guard anti-cheat saat konfirmasi selesai agar tidak memicu layar peringatan.</li>
                                    <li><strong>Galat Analisis Mapel:</strong> Memperbaiki error "Data soal tidak ditemukan" pada mapel ANBK/AKM.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.4 -->
                <div>
                    <i class="fas fa-tasks text-white" style="background-color: #e83e8c;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #e83e8c;">
                            Versi 1.4.4 &mdash; Aksi Massal Jadwal Ujian &amp; Bulk Delete Bank Soal
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Bulk Status &amp; Delete Jadwal:</strong> Ubah status (Aktif/Draft/Selesai) dan hapus beberapa jadwal ujian terpilih secara massal.</li>
                                    <li><strong>Hapus Terpilih Bank Soal:</strong> Checkbox multi-select pada daftar bank soal dan tombol hapus massal dengan SweetAlert2.</li>
                                    <li><strong>Hapus Terpilih Butir Soal:</strong> Fitur seleksi dan hapus massal butir soal pada pratinjau bank soal.</li>
                                    <li><strong>Kolom Status Dashboard:</strong> Indikator status ujian pada tabel Dashboard dan menu Status Ujian.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Perapian Layout Tabel:</strong> Penyelarasan kolom Status dan Aksi agar presisi dan terpusat.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Urutan Hapus Bulk Soal:</strong> Mengurutkan indeks secara terbalik (descending) untuk mencegah kerusakan urutan nomor soal JSON.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.3 -->
                <div>
                    <i class="fas fa-file-excel text-white" style="background-color: #20c997;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #20c997;">
                            Versi 1.4.3 &mdash; Impor Massal Excel &amp; Bulk Delete Akun Guru
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Impor Akun Guru (Excel):</strong> Pendaftaran massal akun guru via berkas .xlsx/.xls dengan pemetaan kolom otomatis.</li>
                                    <li><strong>Hapus Massal Akun Guru:</strong> Checkbox seleksi akun guru dan tombol hapus terpilih dengan konfirmasi keamanan.</li>
                                    <li><strong>Download Template Excel Guru:</strong> Unduh format template resmi untuk mempermudah penyusunan data akun guru.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Pencarian Cepat Guru:</strong> Filter instan data guru berdasarkan nama dan mata pelajaran langsung di tabel.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Pencegahan Duplikasi Akun:</strong> Melewati username/NIP yang sudah terdaftar secara otomatis saat impor massal.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.2 -->
                <div>
                    <i class="fas fa-key text-white" style="background-color: #fd7e14;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #fd7e14;">
                            Versi 1.4.2 &mdash; Token Ujian Dinamis &amp; Masa Tenggang (Grace Period)
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Token Dinamis Berkala:</strong> Token berganti acak secara otomatis sesuai interval menit yang ditentukan.</li>
                                    <li><strong>Monitoring &amp; Rilis Instan:</strong> Tampilan hitung mundur pergantian token dan tombol rilis token acak darurat.</li>
                                    <li><strong>Masa Tenggang 2 Menit:</strong> Token lama tetap valid selama 2 menit agar siswa yang sedang mengetik tidak gagal login.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Karakter Token Bersih:</strong> Menghilangkan karakter alfanumerik yang rancu (seperti 0/O dan 1/I) pada generator token.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Sinkronisasi Token Siswa:</strong> Mencegah kegagalan validasi token saat detik pergantian interval berlangsung.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.1 -->
                <div>
                    <i class="fas fa-file-excel text-white" style="background-color: #28a745;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.4.1 &mdash; Ekspor Nilai .xlsx Asli &amp; Perbaikan Form Soal
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Format Murni .xlsx (SheetJS):</strong> Seluruh unduhan nilai dan lembar jawaban menggunakan format resmi Microsoft Excel OpenXML.</li>
                                    <li><strong>Rekap Siswa Lengkap:</strong> Tabel dan lembar jawaban menampilkan seluruh siswa terdaftar termasuk yang belum mulai ujian.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Kunci Jawaban di Excel:</strong> Penambahan baris kunci jawaban di lembar jawaban untuk mempermudah analisis guru.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Form Tambah Soal:</strong> Memperbaiki tombol Tambah Soal tidak merespons dan masalah backdrop modal tersangkut.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.4.0 -->
                <div>
                    <i class="fas fa-check-double text-white" style="background-color: #6610f2;"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold" style="color: #6610f2;">
                            Versi 1.4.0 &mdash; Tipe Soal Pilihan Ganda Kompleks &amp; Benar-Salah (Standar ANBK)
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Pilihan Ganda Kompleks:</strong> Soal multi-jawaban dengan checkbox dan penilaian proporsional ANBK.</li>
                                    <li><strong>Benar - Salah:</strong> Tabel pernyataan asesmen dengan pilihan radio Benar/Salah dan bobot per baris.</li>
                                    <li><strong>Editor Soal Dinamis:</strong> Form tambah dan edit soal otomatis menyesuaikan kolom input sesuai tipe soal.</li>
                                    <li><strong>Badge Tipe Soal:</strong> Lencana visual tipe soal pada tabel butir soal bank soal.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Grid Nomor Soal:</strong> Deteksi otomatis nomor terjawab pada tipe PG Kompleks dan Benar-Salah.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Validasi Wajib Jawab Semua:</strong> Validasi sebelum selesai ujian kini mendukung kelengkapan soal PGK dan Benar-Salah.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.3.1 -->
                <div>
                    <i class="fas fa-folder-open bg-success text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.3.1 &mdash; Isolasi Bank Soal Guru &amp; Metadata Pengunggah
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Isolasi Bank Soal:</strong> Akun guru hanya dapat melihat dan mengelola bank soal miliknya sendiri.</li>
                                    <li><strong>Identitas Pembuat di Admin:</strong> Kolom <em>Diupload Oleh</em> pada tabel bank soal dengan badge identitas Guru/Admin.</li>
                                    <li><strong>Perekaman Metadata:</strong> Pencatatan otomatis pembuat, pengunggah, dan waktu pembuatan bank soal.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Filter Dropdown Impor:</strong> Pilihan target bank soal impor hanya menampilkan naskah milik guru login.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Ownership Guard:</strong> Proteksi backend API untuk mencegah modifikasi/hapus bank soal milik guru lain.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.3.0 -->
                <div>
                    <i class="fas fa-users-cog bg-primary text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-primary">
                            Versi 1.3.0 &mdash; Multi-Role Akun Guru &amp; Hak Akses Mandiri
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Sistem Multi-Role:</strong> Dukungan dua tingkatan peran pengguna (Administrator &amp; Guru) dengan login terpadu.</li>
                                    <li><strong>Manajemen Guru:</strong> Menu Data Guru untuk menambah, mengedit, menghapus, dan mereset password akun guru.</li>
                                    <li><strong>Hak Akses Khusus Guru:</strong> Panel guru terisolasi khusus Dashboard, Bank Soal, Status Ujian/Nilai, dan Analisis Soal.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Navigasi Menu Khusus:</strong> Menyembunyikan menu master dan pengaturan sistem saat akun guru login.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Route Guard:</strong> Pengalihan otomatis jika akun non-admin mencoba mengakses URL khusus administrator.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.2.4 -->
                <div>
                    <i class="fas fa-user-lock bg-danger text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-danger">
                            Versi 1.2.4 &mdash; Batas Toleransi Pelanggaran &amp; Fitur Lockout Siswa
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Batas Toleransi Pelanggaran:</strong> Pengaturan batas pelanggaran dengan tindakan Kunci Layar (Lockout) atau Kumpulkan Otomatis.</li>
                                    <li><strong>Hitung Mundur Kunci:</strong> Timer digital pada layar siswa sebelum ujian otomatis terbuka kembali.</li>
                                    <li><strong>Tab Filter Terkunci:</strong> Tab pemantauan khusus siswa terkunci pada status ujian beserta tombol Buka Kunci massal.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Penyederhanaan Tampilan Soal:</strong> Menghapus teks bobot poin pada kartu soal siswa agar lebih fokus.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Debounce Pelanggaran:</strong> Pencegahan penghitungan ganda (debounce 2 detik) saat siswa berpindah jendela/tab.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.2.3 -->
                <div>
                    <i class="fas fa-file-word bg-success text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 19 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.2.3 &mdash; Live Search Siswa &amp; Unduh Naskah Soal Polos
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Pencarian &amp; Paginasi Siswa:</strong> Pencarian instan dan pemilih jumlah data per halaman (10, 50, 100, Semua).</li>
                                    <li><strong>Unduh Naskah Soal Polos:</strong> Tombol unduh naskah Word bersih tanpa tabel dan tanpa kunci untuk lembar cetak ujian.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Format Teks Naskah:</strong> Spasi rapat dan tipografi rapi standar naskah ujian sekolah.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Unduh Word:</strong> Memperbaiki galat pada tombol unduh soal Word akibat konflik elemen ID dan karakter BOM.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.2.2 -->
                <div>
                    <i class="fas fa-shield-alt bg-danger text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 18 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-danger">
                            Versi 1.2.2 &mdash; Sistem Anti-Kecurangan (Anti-Cheat)
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Fullscreen Enforcer:</strong> Memaksa peramban masuk ke mode layar penuh saat ujian dimulai.</li>
                                    <li><strong>Deteksi Aktivitas Tab:</strong> Deteksi otomatis saat siswa mengecilkan browser atau membuka tab/aplikasi lain.</li>
                                    <li><strong>Tirai Pemblokir (Overlay):</strong> Layar peringatan merah yang mengunci pengerjaan hingga siswa menekan tombol kembali ke ujian.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Tombol Pemulihan Layar:</strong> Memperhalus mekanisme pengembalian mode fullscreen siswa.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Pencegahan Akses Taskbar:</strong> Menghalangi akses bilah tugas dan shortcut keyboard selama ujian.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.2.1 -->
                <div>
                    <i class="fas fa-layer-group bg-primary text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 18 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-primary">
                            Versi 1.2.1 &mdash; Rich Text Opsi Jawaban &amp; Pengamanan Berkas
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Rich Text Opsi Jawaban:</strong> Editor Summernote pada seluruh pilihan jawaban (A, B, C, D, E) untuk teks format dan gambar.</li>
                                    <li><strong>Keamanan Berkas:</strong> Konfigurasi <code>.htaccess</code> untuk memblokir akses publik langsung ke seluruh berkas <code>.json</code>.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Optimasi Lalu Lintas:</strong> Penyesuaian interval autosave dan sinkronisasi live agar lebih ramah cloud hosting.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Interupsi Tombol Simpan:</strong> Memperbaiki kegagalan tombol Buat Bank Soal akibat animasi SweetAlert.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.2.0 -->
                <div>
                    <i class="fas fa-database bg-warning text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 18 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-warning">
                            Versi 1.2.0 &mdash; Arsitektur Bank Soal Mandiri
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Bank Soal Mandiri:</strong> Entitas bank soal terpisah sepenuhnya dari siklus pembuatan jadwal ujian.</li>
                                    <li><strong>Tampilan Tabel Rapi:</strong> Menu pratinjau soal diubah menjadi daftar tabel bank soal terstruktur.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Alur Penjadwalan:</strong> Pembuatan jadwal ujian mewajibkan penautan ke bank soal yang telah dibuat.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Integritas Data:</strong> Menghapus jadwal ujian tidak akan menghapus berkas bank soal aslinya.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.1.0 -->
                <div>
                    <i class="fas fa-rocket bg-success text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> 18 Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-success">
                            Versi 1.1.0 &mdash; Pembaruan Struktur Navigasi &amp; Log Pembaruan
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Halaman Log Pembaruan:</strong> Menu changelog untuk mencatat riwayat pembaruan dan perbaikan sistem.</li>
                                    <li><strong>Struktur Menu Sidebar:</strong> Pengelompokan navigasi admin (Data Master, Manajemen Ujian, Pelaksanaan, Sistem).</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Tombol Aksi Siswa:</strong> Menyingkat teks tombol aksi di tabel data siswa agar lebih rapi.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Pemisahan Data Mapel:</strong> Memperbaiki sistem hapus mapel agar bank soal tidak ikut terhapus.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Versi 1.0.0 -->
                <div>
                    <i class="fas fa-star bg-primary text-white"></i>
                    <div class="timeline-item shadow-sm">
                        <span class="time"><i class="fas fa-clock mr-1"></i> Sept 2026</span>
                        <h3 class="timeline-header font-weight-bold text-primary">
                            Versi 1.0.0 &mdash; Rilis Perdana CBT Ujian Online
                        </h3>
                        <div class="timeline-body">
                            <div class="mb-2">
                                <span class="badge badge-primary px-2 py-1"><i class="fas fa-plus-circle mr-1"></i> Update</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Manajemen CBT Lengkap:</strong> Pengelolaan data siswa, kelas, bank soal, dan jadwal pelaksanaan ujian.</li>
                                    <li><strong>Impor Naskah Soal:</strong> Dukungan impor butir soal dari format Microsoft Word (.docx) dan JSON.</li>
                                    <li><strong>Pengerjaan Interaktif:</strong> Ujian siswa dengan pengacakan soal dan opsi jawaban secara otomatis.</li>
                                </ul>
                            </div>
                            <div class="mb-2">
                                <span class="badge badge-success px-2 py-1"><i class="fas fa-wrench mr-1"></i> Fix</span>
                                <ul class="pl-4 mt-1 mb-2">
                                    <li><strong>Antarmuka Responsif:</strong> Desain antarmuka terintegrasi berbasis AdminLTE.</li>
                                </ul>
                            </div>
                            <div class="mb-0">
                                <span class="badge badge-danger px-2 py-1"><i class="fas fa-bug mr-1"></i> Bug</span>
                                <ul class="pl-4 mt-1 mb-0">
                                    <li><strong>Validasi Form:</strong> Pengecekan awal kelengkapan input data siswa dan jadwal ujian.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div>
                    <i class="fas fa-clock bg-gray"></i>
                </div>
            </div>
        </div>
    </div>
</div>
