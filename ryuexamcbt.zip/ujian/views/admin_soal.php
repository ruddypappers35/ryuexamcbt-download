<style>
.word-doc-question-item {
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.word-doc-question-item:hover {
    box-shadow: 0 4px 14px rgba(0,0,0,0.08) !important;
}
.question-body img {
    max-width: 100%;
    height: auto;
    border-radius: 4px;
    margin: 8px 0;
    display: inline-block;
}
/* Teks button tidak terlalu bold */
#section-detail-soal .btn,
.word-doc-question-item .btn,
#container-soal .btn,
.action-buttons-col .btn {
    font-weight: 500;
    letter-spacing: 0.2px;
}
#section-detail-soal .btn.font-weight-bold,
#section-list-bank-soal .btn.font-weight-bold {
    font-weight: 600 !important;
}
</style>

<!-- Modal Edit Soal -->
<div class="modal fade" id="modalEditSoal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="form-edit-soal" onsubmit="submitEditQuestion(event)" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title">Edit Soal</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="edit_q_exam_id">
                    <input type="hidden" id="edit_q_index">
                    
                    <div class="form-group mb-3">
                        <label>Tipe Soal</label>
                        <select id="edit_q_type" class="form-control" onchange="toggleEditQType(this.value)">
                            <option value="multiple_choice">Pilihan Ganda (1 Jawaban Benar)</option>
                            <option value="complex_mc">Pilihan Ganda Kompleks (Centang Banyak)</option>
                            <option value="true_false">Benar - Salah (Tabel Pernyataan)</option>
                            <option value="matching">Menjodohkan (Mencocokkan Pasangan)</option>
                            <option value="essay">Esai (Uraian)</option>
                        </select>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label>Pertanyaan / Stimulus</label>
                        <textarea id="edit_q_text" class="form-control" rows="4"></textarea>
                    </div>
                    
                    <!-- Pilihan Ganda & PG Kompleks Container -->
                    <div id="edit_q_mc_fields">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="mb-0 font-weight-bold">Pilihan Jawaban</label>
                            <div class="btn-group btn-group-sm" role="group">
                                <button type="button" class="btn btn-outline-primary active" id="btn_edit_opt_4" onclick="setOptionCount('edit', 4)">4 Opsi (A-D)</button>
                                <button type="button" class="btn btn-outline-primary" id="btn_edit_opt_5" onclick="setOptionCount('edit', 5)">5 Opsi (A-E)</button>
                            </div>
                        </div>
                        <div id="edit_q_options_container">
                            <!-- Options injected by JS -->
                        </div>
                        
                        <!-- Kunci PG Biasa (Single Select) -->
                        <div id="edit_q_single_answer_container" class="form-group mt-3">
                            <label>Kunci Jawaban (Pilih Opsi Benar)</label>
                            <select id="edit_q_answer" class="form-control">
                                <!-- Injected by JS -->
                            </select>
                        </div>

                        <!-- Kunci PG Kompleks (Multi Checkbox) -->
                        <div id="edit_q_complex_answer_container" class="form-group mt-3" style="display:none;">
                            <label class="font-weight-bold">Kunci Jawaban Benar (Bisa Pilih Lebih dari 1):</label>
                            <div id="edit_q_complex_checkboxes" class="d-flex flex-wrap gap-2 p-2 border rounded bg-light">
                                <!-- Injected by JS -->
                            </div>
                        </div>
                    </div>

                    <!-- Benar - Salah Container -->
                    <div id="edit_q_tf_fields" style="display:none;">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="mb-0 font-weight-bold">Daftar Pernyataan & Kunci Nilai:</label>
                            <button type="button" class="btn btn-sm btn-success" onclick="addStatementRow('edit')"><i class="fas fa-plus mr-1"></i> Tambah Pernyataan</button>
                        </div>
                        <table class="table table-bordered table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th style="width: 40px" class="text-center">No</th>
                                    <th>Pernyataan</th>
                                    <th style="width: 140px" class="text-center">Kunci</th>
                                    <th style="width: 50px" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="edit_q_tf_tbody">
                                <!-- Statement rows injected by JS -->
                            </tbody>
                        </table>
                    </div>

                    <!-- Menjodohkan Container -->
                    <div id="edit_q_matching_fields" style="display:none;">
                        <!-- Bagian Opsi Jawaban (Kolom Kanan) -->
                        <div class="card card-outline card-primary p-3 mb-3 bg-light">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="mb-0 font-weight-bold text-primary"><i class="fas fa-list-ol mr-1"></i> Pilihan Jawaban / Target (Kolom Kanan):</label>
                                <button type="button" class="btn btn-xs btn-primary" onclick="addMatchingOptionRow('edit')"><i class="fas fa-plus mr-1"></i> Tambah Pilihan</button>
                            </div>
                            <small class="text-muted d-block mb-2">Pilihan jawaban yang dapat dipilih siswa (A, B, C, dst). Anda juga bisa menambahkan pilihan pengecoh.</small>
                            <div id="edit_q_matching_options_list">
                                <!-- Option rows injected by JS -->
                            </div>
                        </div>

                        <!-- Bagian Premis / Pernyataan (Kolom Kiri) -->
                        <div class="card card-outline card-success p-3 mb-2 bg-light">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="mb-0 font-weight-bold text-success"><i class="fas fa-tasks mr-1"></i> Daftar Pertanyaan/Pernyataan & Kunci Pasangan (Kolom Kiri):</label>
                                <button type="button" class="btn btn-xs btn-success" onclick="addMatchingPremiseRow('edit')"><i class="fas fa-plus mr-1"></i> Tambah Baris</button>
                            </div>
                            <small class="text-muted d-block mb-2">Setiap baris pernyataan di kiri dicocokkan dengan kunci jawaban yang benar di kanan.</small>
                            <table class="table table-bordered table-sm bg-white">
                                <thead class="thead-light">
                                    <tr>
                                        <th style="width: 40px" class="text-center">No</th>
                                        <th>Pernyataan (Kiri)</th>
                                        <th style="width: 220px" class="text-center">Kunci Pasangan (Kanan)</th>
                                        <th style="width: 50px" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="edit_q_matching_tbody">
                                    <!-- Matching premise rows injected by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="form-group mt-3">
                        <label>Poin (Skor)</label>
                        <input type="number" step="0.1" id="edit_q_points" class="form-control" value="2">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Add Soal -->
<div class="modal fade" id="modalAddSoal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="form-add-soal" onsubmit="submitAddQuestion(event)" novalidate>
                <div class="modal-header">
                    <h5 class="modal-title">Buat Soal Baru</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="add_q_exam_id">
                    
                    <div class="form-group mb-3">
                        <label>Tipe Soal</label>
                        <select id="add_q_type" class="form-control" onchange="toggleAddQType(this.value)">
                            <option value="multiple_choice">Pilihan Ganda (1 Jawaban Benar)</option>
                            <option value="complex_mc">Pilihan Ganda Kompleks (Centang Banyak)</option>
                            <option value="true_false">Benar - Salah (Tabel Pernyataan)</option>
                            <option value="matching">Menjodohkan (Mencocokkan Pasangan)</option>
                            <option value="essay">Esai (Uraian)</option>
                        </select>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label>Pertanyaan / Stimulus</label>
                        <textarea id="add_q_text" class="form-control" rows="4"></textarea>
                    </div>
                    
                    <!-- Pilihan Ganda & PG Kompleks Container -->
                    <div id="add_q_mc_fields">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="mb-0 font-weight-bold">Pilihan Jawaban</label>
                            <div class="btn-group btn-group-sm" role="group">
                                <button type="button" class="btn btn-outline-primary" id="btn_add_opt_4" onclick="setOptionCount('add', 4)">4 Opsi (A-D)</button>
                                <button type="button" class="btn btn-primary active" id="btn_add_opt_5" onclick="setOptionCount('add', 5)">5 Opsi (A-E)</button>
                            </div>
                        </div>
                        <div id="add_q_options_container">
                            <div class="mb-3">
                                <label>Opsi A</label>
                                <textarea name="option_0" class="form-control summernote-option-add"></textarea>
                            </div>
                            <div class="mb-3">
                                <label>Opsi B</label>
                                <textarea name="option_1" class="form-control summernote-option-add"></textarea>
                            </div>
                            <div class="mb-3">
                                <label>Opsi C</label>
                                <textarea name="option_2" class="form-control summernote-option-add"></textarea>
                            </div>
                            <div class="mb-3">
                                <label>Opsi D</label>
                                <textarea name="option_3" class="form-control summernote-option-add"></textarea>
                            </div>
                            <div class="mb-3" id="add_opt_wrapper_4">
                                <label>Opsi E</label>
                                <textarea name="option_4" class="form-control summernote-option-add"></textarea>
                            </div>
                        </div>
                        
                        <!-- Kunci PG Biasa (Single Select) -->
                        <div id="add_q_single_answer_container" class="form-group mt-3">
                            <label>Kunci Jawaban (Pilih Opsi Benar)</label>
                            <select id="add_q_answer" class="form-control">
                                <option value="0">Pilihan A</option>
                                <option value="1">Pilihan B</option>
                                <option value="2">Pilihan C</option>
                                <option value="3">Pilihan D</option>
                                <option value="4" id="add_ans_opt_4">Pilihan E</option>
                            </select>
                        </div>

                        <!-- Kunci PG Kompleks (Multi Checkbox) -->
                        <div id="add_q_complex_answer_container" class="form-group mt-3" style="display:none;">
                            <label class="font-weight-bold">Kunci Jawaban Benar (Bisa Pilih Lebih dari 1):</label>
                            <div class="d-flex flex-wrap gap-2 p-2 border rounded bg-light">
                                <div class="form-check mr-3">
                                    <input class="form-check-input" type="checkbox" name="add_complex_ans[]" value="0" id="add_chk_0">
                                    <label class="form-check-label font-weight-bold" for="add_chk_0">Opsi A</label>
                                </div>
                                <div class="form-check mr-3">
                                    <input class="form-check-input" type="checkbox" name="add_complex_ans[]" value="1" id="add_chk_1">
                                    <label class="form-check-label font-weight-bold" for="add_chk_1">Opsi B</label>
                                </div>
                                <div class="form-check mr-3">
                                    <input class="form-check-input" type="checkbox" name="add_complex_ans[]" value="2" id="add_chk_2">
                                    <label class="form-check-label font-weight-bold" for="add_chk_2">Opsi C</label>
                                </div>
                                <div class="form-check mr-3">
                                    <input class="form-check-input" type="checkbox" name="add_complex_ans[]" value="3" id="add_chk_3">
                                    <label class="form-check-label font-weight-bold" for="add_chk_3">Opsi D</label>
                                </div>
                                <div class="form-check mr-3" id="add_chk_wrapper_4">
                                    <input class="form-check-input" type="checkbox" name="add_complex_ans[]" value="4" id="add_chk_4">
                                    <label class="form-check-label font-weight-bold" for="add_chk_4">Opsi E</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Benar - Salah Container -->
                    <div id="add_q_tf_fields" style="display:none;">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="mb-0 font-weight-bold">Daftar Pernyataan & Kunci Nilai:</label>
                            <button type="button" class="btn btn-sm btn-success" onclick="addStatementRow('add')"><i class="fas fa-plus mr-1"></i> Tambah Pernyataan</button>
                        </div>
                        <table class="table table-bordered table-sm">
                            <thead class="thead-light">
                                <tr>
                                    <th style="width: 40px" class="text-center">No</th>
                                    <th>Pernyataan</th>
                                    <th style="width: 140px" class="text-center">Kunci</th>
                                    <th style="width: 50px" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="add_q_tf_tbody">
                                <tr>
                                    <td class="text-center align-middle statement-no">1</td>
                                    <td><input type="text" class="form-control form-control-sm statement-text" placeholder="Ketik pernyataan 1..."></td>
                                    <td>
                                        <select class="form-control form-control-sm statement-ans">
                                            <option value="true">Benar</option>
                                            <option value="false">Salah</option>
                                        </select>
                                    </td>
                                    <td class="text-center align-middle">
                                        <button type="button" class="btn btn-danger btn-xs" onclick="removeStatementRow(this)"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center align-middle statement-no">2</td>
                                    <td><input type="text" class="form-control form-control-sm statement-text" placeholder="Ketik pernyataan 2..."></td>
                                    <td>
                                        <select class="form-control form-control-sm statement-ans">
                                            <option value="true">Benar</option>
                                            <option value="false" selected>Salah</option>
                                        </select>
                                    </td>
                                    <td class="text-center align-middle">
                                        <button type="button" class="btn btn-danger btn-xs" onclick="removeStatementRow(this)"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Menjodohkan Container -->
                    <div id="add_q_matching_fields" style="display:none;">
                        <!-- Bagian Opsi Jawaban (Kolom Kanan) -->
                        <div class="card card-outline card-primary p-3 mb-3 bg-light">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="mb-0 font-weight-bold text-primary"><i class="fas fa-list-ol mr-1"></i> Pilihan Jawaban / Target (Kolom Kanan):</label>
                                <button type="button" class="btn btn-xs btn-primary" onclick="addMatchingOptionRow('add')"><i class="fas fa-plus mr-1"></i> Tambah Pilihan</button>
                            </div>
                            <small class="text-muted d-block mb-2">Pilihan jawaban yang dapat dipilih siswa (A, B, C, dst). Anda juga bisa menambahkan pilihan pengecoh.</small>
                            <div id="add_q_matching_options_list">
                                <!-- Option rows injected by JS -->
                            </div>
                        </div>

                        <!-- Bagian Premis / Pernyataan (Kolom Kiri) -->
                        <div class="card card-outline card-success p-3 mb-2 bg-light">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <label class="mb-0 font-weight-bold text-success"><i class="fas fa-tasks mr-1"></i> Daftar Pertanyaan/Pernyataan & Kunci Pasangan (Kolom Kiri):</label>
                                <button type="button" class="btn btn-xs btn-success" onclick="addMatchingPremiseRow('add')"><i class="fas fa-plus mr-1"></i> Tambah Baris</button>
                            </div>
                            <small class="text-muted d-block mb-2">Setiap baris pernyataan di kiri dicocokkan dengan kunci jawaban yang benar di kanan.</small>
                            <table class="table table-bordered table-sm bg-white">
                                <thead class="thead-light">
                                    <tr>
                                        <th style="width: 40px" class="text-center">No</th>
                                        <th>Pernyataan (Kiri)</th>
                                        <th style="width: 220px" class="text-center">Kunci Pasangan (Kanan)</th>
                                        <th style="width: 50px" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="add_q_matching_tbody">
                                    <!-- Matching premise rows injected by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="form-group mt-3">
                        <label>Poin (Skor)</label>
                        <input type="number" step="0.1" id="add_q_points" class="form-control" value="2">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Tambah Soal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Editor Rumus LaTeX / KaTeX -->
<style>
#modalLatexEditor {
    z-index: 1065 !important;
}
#modalLatexEditor .modal-dialog {
    max-width: 820px;
}
.latex-sym-btn {
    min-width: 44px;
    height: 38px;
    padding: 2px 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.95rem;
    transition: all 0.15s ease;
    background-color: #f8fafc;
    border: 1px solid #cbd5e1;
    color: #334155;
}
.latex-sym-btn:hover {
    background-color: #e0f2fe !important;
    border-color: #0284c7 !important;
    color: #0369a1 !important;
    transform: translateY(-1px);
    box-shadow: 0 2px 5px rgba(2, 132, 199, 0.15);
}
.latex-sym-btn .katex {
    font-size: 1.05em;
}
</style>

<div class="modal fade" id="modalLatexEditor" tabindex="-1" role="dialog" aria-labelledby="modalLatexEditorTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content shadow-lg border-0">
            <div class="modal-header text-white py-2 px-3" style="background: linear-gradient(135deg, #1F7FAB 0%, #176589 100%);">
                <h5 class="modal-title font-weight-bold" id="modalLatexEditorTitle" style="font-size: 1.1rem;">
                    <i class="fas fa-square-root-alt mr-2 text-warning"></i> Editor Rumus Matematika (LaTeX &amp; KaTeX)
                </h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body p-3">
                <!-- Toolbar Palet Simbol Cepat & CodeCogs -->
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap" style="gap: 6px;">
                        <label class="font-weight-bold text-dark mb-0">
                            <i class="fas fa-th mr-1 text-primary"></i> Palet Simbol &amp; Template Rumus Cepat:
                        </label>
                        <button type="button" class="btn btn-outline-info btn-xs shadow-sm font-weight-bold" onclick="openCodeCogsPopup()" title="Buka editor visual penuh CodeCogs di jendela baru untuk menyusun rumus dengan antarmuka grafis">
                            <i class="fas fa-external-link-alt mr-1"></i> Buka Visual Editor CodeCogs
                        </button>
                    </div>

                    <!-- Tabs Kategori Simbol -->
                    <ul class="nav nav-pills nav-fill bg-light p-1 rounded border mb-2" id="latexPaletteTabs" role="tablist" style="font-size: 0.85rem;">
                        <li class="nav-item">
                            <a class="nav-link active py-1 px-2 font-weight-bold" id="tab-latex-basic" data-toggle="pill" href="#pane-latex-basic" role="tab">Pecahan &amp; Akar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link py-1 px-2 font-weight-bold" id="tab-latex-ops" data-toggle="pill" href="#pane-latex-ops" role="tab">Operasi &amp; Simbol</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link py-1 px-2 font-weight-bold" id="tab-latex-greek" data-toggle="pill" href="#pane-latex-greek" role="tab">Huruf Yunani</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link py-1 px-2 font-weight-bold" id="tab-latex-calc" data-toggle="pill" href="#pane-latex-calc" role="tab">Kalkulus &amp; Vektor</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link py-1 px-2 font-weight-bold" id="tab-latex-matrix" data-toggle="pill" href="#pane-latex-matrix" role="tab">Matriks &amp; Sistem</a>
                        </li>
                    </ul>

                    <!-- Isi Tab Kategori -->
                    <div class="tab-content border rounded p-2 bg-white" style="min-height: 85px;">
                        <!-- Tab 1: Pecahan & Akar -->
                        <div class="tab-pane fade show active" id="pane-latex-basic">
                            <div class="d-flex flex-wrap" style="gap: 6px;">
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\frac{a}{b}')" title="Pecahan biasa">$\frac{a}{b}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('x^{2}')" title="Pangkat">$x^{2}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('x_{i}')" title="Subskrip / Indeks">$x_{i}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('x_{i}^{2}')" title="Indeks & Pangkat">$x_{i}^{2}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\sqrt{x}')" title="Akar kuadrat">$\sqrt{x}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\sqrt[n]{x}')" title="Akar pangkat n">$\sqrt[n]{x}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}')" title="Rumus ABC">$x = \frac{-b \pm \sqrt{D}}{2a}$</button>
                            </div>
                        </div>

                        <!-- Tab 2: Operasi & Simbol -->
                        <div class="tab-pane fade" id="pane-latex-ops">
                            <div class="d-flex flex-wrap" style="gap: 6px;">
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\pm')">$\pm$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\times')">$\times$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\div')">$\div$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\cdot')">$\cdot$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\le')">$\le$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\ge')">$\ge$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\neq')">$\neq$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\approx')">$\approx$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\infty')">$\infty$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('^{\\circ}')">$^{\circ}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\in')">$\in$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\notin')">$\notin$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\subset')">$\subset$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\cup')">$\cup$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\cap')">$\cap$</button>
                            </div>
                        </div>

                        <!-- Tab 3: Huruf Yunani -->
                        <div class="tab-pane fade" id="pane-latex-greek">
                            <div class="d-flex flex-wrap" style="gap: 6px;">
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\alpha')">$\alpha$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\beta')">$\beta$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\gamma')">$\gamma$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\Delta')">$\Delta$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\theta')">$\theta$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\pi')">$\pi$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\lambda')">$\lambda$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\mu')">$\mu$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\sigma')">$\sigma$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\omega')">$\omega$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\Omega')">$\Omega$</button>
                            </div>
                        </div>

                        <!-- Tab 4: Kalkulus & Vektor -->
                        <div class="tab-pane fade" id="pane-latex-calc">
                            <div class="d-flex flex-wrap" style="gap: 6px;">
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\sin(x)')">$\sin(x)$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\cos(x)')">$\cos(x)$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\tan(x)')">$\tan(x)$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\log(x)')">$\log(x)$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\lim_{x \\to 0} f(x)')">$\lim_{x \to 0}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\int f(x) \\, dx')">$\int f(x) dx$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\int_{a}^{b} f(x) \\, dx')">$\int_{a}^{b}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\sum_{i=1}^{n} x_i')">$\sum_{i=1}^{n}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\vec{v}')">$\vec{v}$</button>
                            </div>
                        </div>

                        <!-- Tab 5: Matriks & Sistem -->
                        <div class="tab-pane fade" id="pane-latex-matrix">
                            <div class="d-flex flex-wrap" style="gap: 6px;">
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}')" title="Matriks 2x2">$\begin{pmatrix} a & b \\ c & d \end{pmatrix}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\begin{vmatrix} a & b \\\\ c & d \\end{vmatrix}')" title="Determinan 2x2">$\begin{vmatrix} a & b \\ c & d \end{vmatrix}$</button>
                                <button type="button" class="btn btn-sm latex-sym-btn" onclick="insertLatexSnippet('\\begin{cases} 2x + y = 10 \\\\ x - y = 2 \\end{cases}')" title="Sistem Persamaan">$\begin{cases} ... \end{cases}$</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Input Kode LaTeX -->
                <div class="form-group mb-2">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label for="latex_input_code" class="font-weight-bold text-dark mb-0">
                            <i class="fas fa-code mr-1 text-primary"></i> Kode Rumus LaTeX:
                        </label>
                        <button type="button" class="btn btn-xs btn-link text-danger p-0 font-weight-bold" onclick="clearLatexInput()">
                            <i class="fas fa-trash-alt mr-1"></i> Bersihkan
                        </button>
                    </div>
                    <textarea id="latex_input_code" class="form-control" rows="3" placeholder="Ketik kode LaTeX di sini atau klik simbol pada palet di atas... Contoh: \frac{a}{b} + \sqrt{x}" oninput="updateLatexLivePreview()" style="font-family: Consolas, 'Courier New', monospace; font-size: 0.95rem;"></textarea>
                </div>

                <!-- Pilihan Mode Display vs Inline -->
                <div class="d-flex align-items-center mb-3 p-2 bg-light rounded border flex-wrap" style="gap: 8px;">
                    <span class="font-weight-bold text-secondary mr-2" style="font-size: 0.88rem;">Format Tampilan:</span>
                    <div class="custom-control custom-radio custom-control-inline mr-3">
                        <input type="radio" id="mode_latex_inline" name="latex_display_mode" class="custom-control-input" value="inline" checked onchange="updateLatexLivePreview()">
                        <label class="custom-control-label font-weight-bold text-dark" for="mode_latex_inline" style="cursor: pointer; font-size: 0.88rem;">
                            Inline <code>$ ... $</code> <small class="text-muted font-weight-normal">(Menyatu dalam kalimat teks)</small>
                        </label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="mode_latex_display" name="latex_display_mode" class="custom-control-input" value="display" onchange="updateLatexLivePreview()">
                        <label class="custom-control-label font-weight-bold text-dark" for="mode_latex_display" style="cursor: pointer; font-size: 0.88rem;">
                            Baris Baru / Display <code>$$ ... $$</code> <small class="text-muted font-weight-normal">(Besar di baris tengah)</small>
                        </label>
                    </div>
                </div>

                <!-- Kotak Live Real-time KaTeX Preview -->
                <div class="card border mb-0" style="background-color: #f8fafc;">
                    <div class="card-header bg-white py-1 px-3 d-flex justify-content-between align-items-center border-bottom">
                        <span class="font-weight-bold text-secondary" style="font-size: 0.85rem;">
                            <i class="fas fa-eye mr-1 text-info"></i> Pratinjau Real-Time (KaTeX Live):
                        </span>
                        <span id="latex_status_badge" class="badge badge-secondary px-2 py-1" style="font-size: 0.75rem;">Kosong</span>
                    </div>
                    <div class="card-body p-4 text-center d-flex align-items-center justify-content-center" style="min-height: 90px; overflow-x: auto;">
                        <div id="latex_preview_box" class="w-100" style="font-size: 1.3rem;">
                            <span class="text-muted" style="font-size: 0.95rem; font-style: italic;">Pratinjau rumus akan muncul di sini secara otomatis...</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2 px-3 bg-light d-flex justify-content-between">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">
                    <i class="fas fa-times mr-1"></i> Batal
                </button>
                <button type="button" class="btn btn-primary btn-sm font-weight-bold px-3 shadow-sm" onclick="insertLatexFormulaToEditor()">
                    <i class="fas fa-check mr-1"></i> Sisipkan Rumus ke Soal
                </button>
            </div>
        </div>
    </div>
</div>

<script>
window.currentSummernoteContext = null;

window.openLatexEquationModal = function(context) {
    window.currentSummernoteContext = context;
    const modal = $('#modalLatexEditor');
    modal.modal('show');
    setTimeout(() => {
        if (typeof renderMath === 'function') {
            renderMath(document.getElementById('modalLatexEditor'));
        }
        updateLatexLivePreview();
        const input = document.getElementById('latex_input_code');
        if (input) input.focus();
    }, 200);
};

window.insertLatexSnippet = function(snippet) {
    const input = document.getElementById('latex_input_code');
    if (!input) return;
    const start = input.selectionStart || 0;
    const end = input.selectionEnd || 0;
    const val = input.value;
    input.value = val.substring(0, start) + snippet + val.substring(end);
    input.selectionStart = input.selectionEnd = start + snippet.length;
    input.focus();
    updateLatexLivePreview();
};

window.clearLatexInput = function() {
    const input = document.getElementById('latex_input_code');
    if (input) {
        input.value = '';
        input.focus();
        updateLatexLivePreview();
    }
};

window.updateLatexLivePreview = function() {
    const input = document.getElementById('latex_input_code');
    const previewBox = document.getElementById('latex_preview_box');
    const badge = document.getElementById('latex_status_badge');
    if (!input || !previewBox) return;

    const raw = input.value.trim();
    const isDisplay = document.getElementById('mode_latex_display')?.checked;

    if (!raw) {
        previewBox.innerHTML = '<span class="text-muted" style="font-size: 0.95rem; font-style: italic;">Pratinjau rumus akan muncul di sini secara otomatis...</span>';
        if (badge) {
            badge.className = 'badge badge-secondary px-2 py-1';
            badge.innerText = 'Kosong';
        }
        return;
    }

    try {
        if (typeof katex !== 'undefined') {
            const html = katex.renderToString(raw, {
                displayMode: isDisplay,
                throwOnError: true
            });
            previewBox.innerHTML = html;
            if (badge) {
                badge.className = 'badge badge-success px-2 py-1';
                badge.innerText = 'Valid LaTeX';
            }
        } else {
            previewBox.innerText = raw;
        }
    } catch (e) {
        previewBox.innerHTML = '<span class="text-danger" style="font-size: 0.9rem;"><i class="fas fa-exclamation-circle mr-1"></i> ' + (e.message || 'Sintaks LaTeX belum lengkap') + '</span>';
        if (badge) {
            badge.className = 'badge badge-warning text-dark px-2 py-1';
            badge.innerText = 'Sintaks Belum Lengkap';
        }
    }
};

window.insertLatexFormulaToEditor = function() {
    const input = document.getElementById('latex_input_code');
    if (!input) return;
    const raw = input.value.trim();
    if (!raw) {
        Swal.fire({
            title: 'Rumus Kosong',
            text: 'Silakan ketik atau pilih rumus matematika terlebih dahulu.',
            icon: 'warning',
            timer: 1500,
            showConfirmButton: false
        });
        return;
    }

    const isDisplay = document.getElementById('mode_latex_display')?.checked;
    const formula = isDisplay ? `$$${raw}$$` : `$${raw}$`;

    if (window.currentSummernoteContext) {
        window.currentSummernoteContext.invoke('editor.insertText', formula + ' ');
    } else {
        navigator.clipboard.writeText(formula);
        Swal.fire('Disalin ke Clipboard', 'Rumus berhasil disalin: ' + formula, 'info');
    }

    $('#modalLatexEditor').modal('hide');
};

window.openCodeCogsPopup = function() {
    const url = 'https://editor.codecogs.com/';
    const win = window.open(url, 'CodeCogsEditor', 'width=980,height=650,resizable=yes,scrollbars=yes');
    if (win) win.focus();
};

$(document).on('show.bs.modal', '#modalLatexEditor', function () {
    setTimeout(function() {
        $('.modal-backdrop').not('.stacked').css('z-index', 1060).addClass('stacked');
    }, 0);
});
</script>

<div id="section-list-bank-soal" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
            <h3 class="card-title font-weight-bold mb-0">Daftar Bank Soal</h3>
            <div class="ml-auto d-flex align-items-center flex-wrap" style="gap: 6px;">
                <!-- 1. Pencarian & Aksi Massal -->
                <div class="d-flex align-items-center mb-1">
                    <div class="input-group input-group-sm" style="width: 200px;">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white border-right-0"><i class="fas fa-search text-muted"></i></span>
                        </div>
                        <input type="text" id="search-bank-soal" class="form-control border-left-0" placeholder="Cari bank soal..." oninput="filterBankSoalTable()">
                    </div>
                    <button id="btn-bulk-delete-bank" class="btn btn-danger btn-sm ml-1" style="display: none;" onclick="bulkDeleteBankSoal()"><i class="fas fa-trash mr-1"></i> Hapus (<span id="selected-bank-count">0</span>)</button>
                    <button id="btn-bulk-backup-bank" class="btn btn-success btn-sm ml-1" style="display: none;" onclick="bulkBackupSelectedBankSoal()"><i class="fas fa-file-archive mr-1"></i> Backup (<span id="selected-bank-count-backup">0</span>)</button>
                </div>

                <div class="d-none d-md-block border-left mx-1" style="height: 24px;"></div>

                <!-- 2. Bantuan & Format -->
                <a href="?page=panduan" class="btn btn-outline-secondary btn-sm mb-1" title="Petunjuk Pembuatan Soal">
                    <i class="fas fa-book-reader text-warning mr-1"></i> Petunjuk
                </a>
                <div class="btn-group mb-1">
                    <button type="button" class="btn btn-outline-secondary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Unduh format template soal Microsoft Word">
                        <i class="fas fa-file-word text-primary mr-1"></i> Template
                    </button>
                    <div class="dropdown-menu dropdown-menu-right shadow">
                        <h6 class="dropdown-header text-uppercase font-weight-bold">Pilih Template Word:</h6>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplatePGBiasa()"><i class="fas fa-dot-circle text-primary mr-2"></i> 1. Template PG Biasa</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplatePGKompleks()"><i class="fas fa-check-square text-success mr-2"></i> 2. Template PG Kompleks</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplateBenarSalah()"><i class="fas fa-check-circle text-warning mr-2"></i> 3. Template Benar / Salah</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplateMenjodohkan()"><i class="fas fa-exchange-alt text-info mr-2"></i> 4. Template Menjodohkan</a>
                    </div>
                </div>

                <div class="d-none d-md-block border-left mx-1" style="height: 24px;"></div>

                <!-- 3. Migrasi & Arsip -->
                <button class="btn btn-outline-primary btn-sm mb-1" data-toggle="modal" data-target="#modalImportBankSoalZip" title="Impor Bank Soal dari file ZIP beserta gambar">
                    <i class="fas fa-file-import mr-1"></i> Impor ZIP
                </button>
                <div class="btn-group mb-1">
                    <button type="button" class="btn btn-outline-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Cadangkan bank soal beserta folder gambar">
                        <i class="fas fa-file-archive mr-1"></i> Backup ZIP
                    </button>
                    <div class="dropdown-menu dropdown-menu-right shadow">
                        <h6 class="dropdown-header text-uppercase font-weight-bold">Pilihan Backup ZIP:</h6>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="backupAllBankSoal()"><i class="fas fa-archive text-success mr-2"></i> Backup Semua Bank Soal (.zip)</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="bulkBackupSelectedBankSoal()"><i class="fas fa-check-square text-primary mr-2"></i> Backup Bank Soal Terpilih</a>
                    </div>
                </div>

                <div class="d-none d-md-block border-left mx-1" style="height: 24px;"></div>

                <!-- 4. Aksi Utama (CTA) -->
                <a href="https://share.gemini.google/ReefFdC6lnEu" target="_blank" rel="noopener noreferrer" onclick="return openGeminiAiPopup(event)" class="btn btn-sm mb-1 shadow-sm font-weight-bold text-white mr-1" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); border: none;" title="Buka Generator Soal AI (Google Gemini) di Jendela Mengambang (Side-by-Side)">
                    <i class="fas fa-robot mr-1"></i> Buat via AI
                </a>
                <button class="btn btn-primary btn-sm mb-1 shadow-sm font-weight-bold" data-toggle="modal" data-target="#modalAddBankSoal" title="Buat Bank Soal baru">
                    <i class="fas fa-plus-circle mr-1"></i> Buat Bank Soal
                </button>
            </div>
        </div>
        <div class="card-body p-0 table-responsive">
            <table class="table table-striped table-bordered mb-0" id="table-bank-soal">
                <thead>
                    <tr>
                        <th style="width: 40px" class="text-center"><input type="checkbox" id="cb-all-bank" onchange="toggleAllBank(this)" title="Pilih Semua"></th>
                        <th style="width: 50px" class="text-center">No</th>
                        <th>Nama Bank Soal</th>
                        <?php if ($user_role === 'admin'): ?>
                        <th style="width: 200px">Diupload Oleh</th>
                        <?php endif; ?>
                        <th style="width: 150px" class="text-center">Jumlah Soal</th>
                        <th style="width: 215px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbody-bank-soal">
                    <?php if (empty($bank_soal)): ?>
                    <tr id="row-empty-bank"><td colspan="<?= $user_role === 'admin' ? 6 : 5 ?>" class="text-center">Belum ada bank soal</td></tr>
                    <?php else: ?>
                    <?php $no=1; foreach($bank_soal as $b): ?>
                    <tr class="bank-soal-row" data-bank-id="<?= $b['id'] ?>" data-bank-name="<?= strtolower(htmlspecialchars($b['name'])) ?>">
                        <td class="text-center"><input type="checkbox" class="cb-bank" value="<?= $b['id'] ?>" onchange="toggleBankSelection(this)"></td>
                        <td class="text-center bank-soal-num"><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($b['name']) ?></strong></td>
                        <?php if ($user_role === 'admin'): ?>
                        <td class="align-middle">
                            <?= htmlspecialchars(!empty($b['created_by']) ? $b['created_by'] : (!empty($b['uploaded_by']) ? $b['uploaded_by'] : 'Administrator')) ?>
                        </td>
                        <?php endif; ?>
                        <td class="text-center align-middle"><?= $b['question_count'] ?? 0 ?> Soal</td>
                        <td class="text-center align-middle text-nowrap">
                            <button class="btn btn-info btn-sm" title="Kelola Soal" onclick="openDetailSoal(<?= $b['id'] ?>, '<?= addslashes(htmlspecialchars($b['name'])) ?>')"><i class="fas fa-list"></i></button>
                            <button class="btn btn-primary btn-sm" title="Preview Soal seperti di Halaman Siswa" onclick="openStudentPreview(<?= $b['id'] ?>, '<?= addslashes(htmlspecialchars($b['name'])) ?>')"><i class="fas fa-eye"></i></button>
                            <button class="btn btn-warning btn-sm" title="Edit Bank Soal" onclick="openEditBankSoalModal(<?= $b['id'] ?>, '<?= addslashes(htmlspecialchars($b['name'])) ?>', '<?= addslashes(htmlspecialchars($b['classes'] ?? '')) ?>')"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-secondary btn-sm" title="Backup Soal & Gambar (.zip)" onclick="backupBankSoalZip(<?= $b['id'] ?>, '<?= addslashes(htmlspecialchars($b['name'])) ?>')"><i class="fas fa-download"></i></button>
                            <button class="btn btn-danger btn-sm" title="Hapus Bank Soal" onclick="deleteBankSoal(<?= $b['id'] ?>, '<?= addslashes(htmlspecialchars($b['name'])) ?>')"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="section-detail-soal" style="display:none;" class="content-section">
    <div class="card card-outline card-info mt-3">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
            <div class="d-flex align-items-center flex-wrap" style="gap: 8px;">
                <h3 class="card-title font-weight-bold mb-0" id="detail-soal-title">Kelola Soal</h3>
                <span class="badge badge-info ml-1" id="badge-total-soal">0 Soal</span>
            </div>
            <div class="d-flex align-items-center ml-auto flex-wrap" style="gap: 6px;">
                <input type="hidden" id="preview_exam_id">

                <!-- 1. Bantuan & Format Template -->
                <a href="?page=panduan" class="btn btn-outline-secondary btn-sm mb-1" title="Petunjuk Pembuatan Soal">
                    <i class="fas fa-book-reader text-warning mr-1"></i> Petunjuk
                </a>
                <div class="btn-group mb-1">
                    <button type="button" class="btn btn-outline-secondary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Unduh format template soal Microsoft Word">
                        <i class="fas fa-file-word text-primary mr-1"></i> Template
                    </button>
                    <div class="dropdown-menu dropdown-menu-right shadow">
                        <h6 class="dropdown-header text-uppercase font-weight-bold">Pilih Template Word:</h6>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplatePGBiasa()"><i class="fas fa-dot-circle text-primary mr-2"></i> 1. Template PG Biasa</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplatePGKompleks()"><i class="fas fa-check-square text-success mr-2"></i> 2. Template PG Kompleks</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplateBenarSalah()"><i class="fas fa-check-circle text-warning mr-2"></i> 3. Template Benar / Salah</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="promptTemplateMenjodohkan()"><i class="fas fa-exchange-alt text-info mr-2"></i> 4. Template Menjodohkan</a>
                    </div>
                </div>

                <div class="d-none d-lg-block border-left mx-1" style="height: 24px;"></div>

                <!-- 2. Pemeliharaan & Cadangan -->
                <button class="btn btn-outline-secondary btn-sm mb-1" id="btn-backup-soal-zip" onclick="backupCurrentBankSoalZip()" title="Download Backup ZIP beserta Folder Gambar">
                    <i class="fas fa-file-archive mr-1"></i> Backup ZIP
                </button>
                <button class="btn btn-outline-info btn-sm mb-1" id="btn-opt-webp" style="display:none;" onclick="optimizeBankImagesWebp()" title="Kompresi dan ubah seluruh gambar di bank soal ini ke format .webp agar ringan bagi server dan siswa">
                    <i class="fas fa-file-image mr-1"></i> WebP
                </button>

                <div class="d-none d-lg-block border-left mx-1" style="height: 24px;"></div>

                <!-- 3. Kunci & Penilaian -->
                <button class="btn btn-outline-success btn-sm mb-1" id="btn-kunci-excel" style="display:none;" onclick="openModalKunciExcel()" title="Unduh template Excel atau impor kunci jawaban dari Excel">
                    <i class="fas fa-file-excel mr-1"></i> Kunci Excel
                </button>
                <button class="btn btn-outline-primary btn-sm mb-1" id="btn-recalc-bank" style="display:none;" onclick="recalculateBankScores()" title="Hitung ulang nilai siswa berdasarkan kunci jawaban terbaru di Bank Soal">
                    <i class="fas fa-calculator mr-1"></i> Hitung Nilai
                </button>

                <div class="d-none d-lg-block border-left mx-1" style="height: 24px;"></div>

                <!-- 4. Pratinjau & Ekspor Soal -->
                <div class="btn-group mb-1" id="btn-download-word" style="display:none;">
                    <button type="button" class="btn btn-outline-info btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" title="Unduh naskah soal dalam format Microsoft Word">
                        <i class="fas fa-file-word mr-1"></i> Word
                    </button>
                    <div class="dropdown-menu dropdown-menu-right shadow">
                        <a class="dropdown-item" href="javascript:void(0)" onclick="downloadWordSoal()"><i class="fas fa-file-word text-info mr-2"></i> Word Lengkap (Format Tabel & Kunci)</a>
                        <a class="dropdown-item" href="javascript:void(0)" onclick="downloadWordSoalPlain()"><i class="fas fa-file-alt text-secondary mr-2"></i> Word Polos (Tanpa Tabel)</a>
                    </div>
                </div>
                <span id="btn-download-word-plain" style="display:none;"></span>
                <button class="btn btn-info btn-sm mb-1" id="btn-preview-siswa" style="display:none;" onclick="openCurrentBankStudentPreview()" title="Preview Soal seperti di halaman siswa">
                    <i class="fas fa-eye mr-1"></i> Preview
                </button>

                <div class="d-none d-lg-block border-left mx-1" style="height: 24px;"></div>

                <!-- 5. Aksi Utama (Input Butir Soal) -->
                <button class="btn btn-primary btn-sm mb-1 shadow-sm font-weight-bold" data-toggle="modal" data-target="#modalImportSoal" title="Impor butir soal dari file Microsoft Word atau JSON">
                    <i class="fas fa-upload mr-1"></i> Impor Soal
                </button>
                <button id="btn-add-soal" onclick="openAddQModal()" class="btn btn-success btn-sm mb-1 shadow-sm font-weight-bold" style="display:none;" title="Tambah butir soal manual">
                    <i class="fas fa-plus mr-1"></i> Tambah Soal
                </button>
                <a href="https://share.gemini.google/ReefFdC6lnEu" target="_blank" rel="noopener noreferrer" onclick="return openGeminiAiPopup(event)" id="btn-ai-soal" class="btn btn-sm mb-1 shadow-sm font-weight-bold text-white" style="display:none; background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); border: none;" title="Buka Generator Soal AI (Google Gemini) di Jendela Mengambang (Side-by-Side)">
                    <i class="fas fa-robot mr-1"></i> Buat via AI
                </a>
            </div>
        </div>
        <!-- Toolbar Kontrol Dokumen Soal -->
        <div class="card-header bg-light border-bottom d-flex justify-content-between align-items-center flex-wrap py-2 px-3" style="gap: 8px;">
            <div class="d-flex align-items-center flex-wrap" style="gap: 8px;">
                <div class="custom-control custom-checkbox mr-2">
                    <input type="checkbox" class="custom-control-input" id="cb-all-q" onchange="toggleAllQ()">
                    <label class="custom-control-label text-dark" for="cb-all-q" style="cursor:pointer; font-weight: 500;">Pilih Semua Soal</label>
                </div>
                <button onclick="deleteBulkQuestions()" class="btn btn-danger btn-sm" id="btn-bulk-delete-q" style="display:none; font-weight: 400;">
                    <i class="fas fa-trash mr-1"></i> Hapus Terpilih (<span id="selected-q-count">0</span>)
                </button>
                <div class="border-left mx-1 d-none d-sm-block" style="height: 20px;"></div>
                <button class="btn btn-outline-warning text-dark btn-sm shadow-sm" id="btn-auto-poin" style="display:none;" onclick="autoSetPoints()" title="Set poin otomatis agar total nilai pas 100">
                    <i class="fas fa-magic mr-1"></i> Set Poin
                </button>
                <span class="align-items-center ml-2" id="badge-total-poin" style="display:none; font-size: 0.875rem; font-weight: 300; color: #000;" title="Total akumulasi poin nilai seluruh butir soal">
                    Total: <span id="val-total-poin" style="font-weight: 300; color: #000; margin: 0 3px;">0</span> Poin
                </span>
            </div>
        </div>

        <!-- Container Pratinjau Dokumen Soal -->
        <div class="card-body p-3" style="max-height: 780px; overflow-y: auto; background-color: #f4f6f9;">
            <div id="container-soal" class="w-100 mx-auto" style="max-width: 1400px;">
                <div id="tbody-soal"></div>
            </div>
        </div>
    </div>

    <!-- Modal Import Soal -->
    <div class="modal fade" id="modalImportSoal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="form-upload-soal" onsubmit="uploadSoal(event)">
                    <div class="modal-header">
                        <h5 class="modal-title">Impor Data Soal (Word / JSON / ZIP)</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="upload_exam_id">Pilih Bank Soal</label>
                            <select id="upload_exam_id" class="form-control" required>
                                <option value="" disabled selected>Pilih Bank Soal Tujuan</option>
                                <?php foreach ($bank_soal as $b): ?>
                                    <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="file-soal">Pilih file Soal (.docx, .doc, .json, atau .zip)</label>
                            <input type="file" name="file" id="file-soal" class="form-control-file" accept=".json, .docx, .doc, .zip" required>
                            <small class="text-muted mt-2 d-block">Pilih file Word (.docx / .doc), JSON, atau ZIP backup. Seluruh butir soal dan gambar akan otomatis diproses.</small>
                            <div class="alert alert-success py-2 px-3 mt-2 mb-0" style="font-size: 0.85rem;">
                                <i class="fas fa-bolt text-warning mr-1"></i> <strong>Optimasi Otomatis:</strong> Gambar yang diimpor akan otomatis dikompresi dan dikonversi ke format <strong>.webp</strong> agar hemat memori server dan cepat dimuat oleh siswa.
                            </div>
                            
                            <!-- Box Template Word Satu per Satu -->
                            <div class="mt-3 p-3 bg-light border rounded">
                                <label class="font-weight-bold text-dark mb-2 d-block">
                                    <i class="fas fa-file-word text-success mr-1"></i> Buat & Unduh Template Word per Jenis Soal:
                                </label>
                                <div class="d-grid gap-2">
                                    <button type="button" class="btn btn-outline-primary btn-sm btn-block text-left mb-2 d-flex justify-content-between align-items-center" onclick="promptTemplatePGBiasa()">
                                        <span><i class="fas fa-dot-circle mr-2"></i> <strong>1. Template PG Biasa</strong></span>
                                        <span class="badge badge-primary"><i class="fas fa-download mr-1"></i> Tentukan Jumlah Soal</span>
                                    </button>
                                    <button type="button" class="btn btn-outline-success btn-sm btn-block text-left mb-2 d-flex justify-content-between align-items-center" onclick="promptTemplatePGKompleks()">
                                        <span><i class="fas fa-check-square mr-2"></i> <strong>2. Template PG Kompleks</strong></span>
                                        <span class="badge badge-success"><i class="fas fa-download mr-1"></i> Tentukan Jumlah Soal</span>
                                    </button>
                                    <button type="button" class="btn btn-outline-warning btn-sm btn-block text-left mb-2 d-flex justify-content-between align-items-center" onclick="promptTemplateBenarSalah()">
                                        <span><i class="fas fa-check-circle mr-2"></i> <strong>3. Template Soal Benar / Salah</strong></span>
                                        <span class="badge badge-warning"><i class="fas fa-download mr-1"></i> Tentukan Jumlah Soal</span>
                                    </button>
                                    <button type="button" class="btn btn-outline-info btn-sm btn-block text-left mb-2 d-flex justify-content-between align-items-center" onclick="promptTemplateMenjodohkan()">
                                        <span><i class="fas fa-exchange-alt mr-2"></i> <strong>4. Template Soal Menjodohkan</strong></span>
                                        <span class="badge badge-info"><i class="fas fa-download mr-1"></i> Tentukan Jumlah Soal</span>
                                    </button>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                                    <button type="button" class="btn btn-xs btn-link text-info p-0" onclick="showFormatWord()"><i class="fas fa-info-circle mr-1"></i> Petunjuk & Aturan Format Word</button>
                                    <button type="button" class="btn btn-xs btn-link text-secondary p-0" onclick="showFormatSoal()"><i class="fas fa-code mr-1"></i> Format JSON</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" id="btn-upload-soal" class="btn btn-primary"><i class="fas fa-upload mr-2"></i> Unggah Soal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>
</div>

<!-- Modal Buat Bank Soal Baru -->
<div class="modal fade" id="modalAddBankSoal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="form-add-bank-soal" onsubmit="submitAddBankSoal(event)">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title font-weight-bold">Buat Bank Soal Baru</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <!-- Jenis Ujian -->
                        <div class="col-md-6 mb-3">
                            <label class="font-weight-bold">Jenis Ujian <span class="text-danger">*</span></label>
                            <select id="add_bank_jenis_ujian" class="form-control" onchange="autoGenerateBankSoalName()">
                                <option value="" selected disabled>-- Pilih Jenis Ujian --</option>
                                <?php 
                                $all_jenis = get_jenis_ujian_list();
                                foreach ($all_jenis as $j): 
                                    $jCode = !empty($j['code']) ? $j['code'] : $j['name'];
                                ?>
                                    <option value="<?= htmlspecialchars($jCode) ?>" data-code="<?= htmlspecialchars($jCode) ?>" data-name="<?= htmlspecialchars($j['name']) ?>">
                                        <?= htmlspecialchars($jCode) ?> - <?= htmlspecialchars($j['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Mata Pelajaran -->
                        <div class="col-md-6 mb-3">
                            <label class="font-weight-bold">Mata Pelajaran <span class="text-danger">*</span></label>
                            <select id="add_bank_mapel" class="form-control" onchange="autoGenerateBankSoalName()">
                                <option value="" selected disabled>-- Pilih Mata Pelajaran --</option>
                                <?php 
                                $all_mapels = get_mapel_list();
                                foreach ($all_mapels as $m): 
                                    $mName = $m['name'];
                                    $mCode = !empty($m['code']) ? $m['code'] : '';
                                ?>
                                    <option value="<?= htmlspecialchars($mName) ?>" data-name="<?= htmlspecialchars($mName) ?>" data-code="<?= htmlspecialchars($mCode) ?>">
                                        <?= htmlspecialchars($mName) ?><?= !empty($mCode) ? ' (' . htmlspecialchars($mCode) . ')' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Pilih Kelas (Bisa Ceklis Banyak) -->
                    <div class="form-group mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="font-weight-bold mb-0">Pilih Kelas (Bisa Ceklis Banyak)</label>
                            <small>
                                <a href="javascript:void(0)" onclick="$('.add-bank-class-cb').prop('checked', true); autoGenerateBankSoalName();" class="mr-2">Pilih Semua</a>
                                <a href="javascript:void(0)" onclick="$('.add-bank-class-cb').prop('checked', false); autoGenerateBankSoalName();" class="text-muted">Kosongkan</a>
                            </small>
                        </div>
                        <div class="border p-2 rounded bg-light" style="max-height: 140px; overflow-y: auto;">
                            <div class="row">
                                <?php foreach ($classes as $c): ?>
                                    <div class="col-md-3 col-6">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input add-bank-class-cb" id="add_bank_class_<?= $c['id'] ?>" value="<?= htmlspecialchars($c['name']) ?>" onchange="autoGenerateBankSoalName()">
                                            <label class="custom-control-label font-weight-normal text-dark" for="add_bank_class_<?= $c['id'] ?>" style="cursor: pointer;"><?= htmlspecialchars($c['name']) ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <small class="text-muted">Centang kelas target untuk ujian ini.</small>
                    </div>

                    <!-- Kolom Nama Bank Soal (Auto Generate & Editable) -->
                    <div class="form-group mb-2">
                        <label class="font-weight-bold">Nama Bank Soal <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="text" id="add_bank_soal_name" class="form-control font-weight-bold" required placeholder="Contoh: PAS-XII-Matematika-8X2K">
                            <div class="input-group-append">
                                <button type="button" class="btn btn-outline-secondary" onclick="regenerateBankRandomCode()" title="Acak Ulang Kode Unik">
                                    <i class="fas fa-random mr-1"></i> Acak Kode
                                </button>
                            </div>
                        </div>
                        <small class="text-muted mt-1 d-block">
                            Otomatis dibuat dengan format: <code>[Jenis Ujian]-[Kelas]-[Mata Pelajaran]-[Kode Unik]</code>. Anda tetap dapat mengeditnya secara manual.
                        </small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary font-weight-bold">Simpan Bank Soal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Bank Soal -->
<div class="modal fade" id="modalEditBankSoal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="form-edit-bank-soal" onsubmit="submitEditBankSoal(event)">
                <input type="hidden" id="edit_bank_soal_id">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title font-weight-bold">Edit Bank Soal</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <!-- Jenis Ujian -->
                        <div class="col-md-6 mb-3">
                            <label class="font-weight-bold">Jenis Ujian <span class="text-danger">*</span></label>
                            <select id="edit_bank_jenis_ujian" class="form-control" onchange="autoGenerateEditBankSoalName()">
                                <option value="" selected disabled>-- Pilih Jenis Ujian --</option>
                                <?php 
                                foreach ($all_jenis as $j): 
                                    $jCode = !empty($j['code']) ? $j['code'] : $j['name'];
                                ?>
                                    <option value="<?= htmlspecialchars($jCode) ?>" data-code="<?= htmlspecialchars($jCode) ?>" data-name="<?= htmlspecialchars($j['name']) ?>">
                                        <?= htmlspecialchars($jCode) ?> - <?= htmlspecialchars($j['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Mata Pelajaran -->
                        <div class="col-md-6 mb-3">
                            <label class="font-weight-bold">Mata Pelajaran <span class="text-danger">*</span></label>
                            <select id="edit_bank_mapel" class="form-control" onchange="autoGenerateEditBankSoalName()">
                                <option value="" selected disabled>-- Pilih Mata Pelajaran --</option>
                                <?php 
                                foreach ($all_mapels as $m): 
                                    $mName = $m['name'];
                                    $mCode = !empty($m['code']) ? $m['code'] : '';
                                ?>
                                    <option value="<?= htmlspecialchars($mName) ?>" data-name="<?= htmlspecialchars($mName) ?>" data-code="<?= htmlspecialchars($mCode) ?>">
                                        <?= htmlspecialchars($mName) ?><?= !empty($mCode) ? ' (' . htmlspecialchars($mCode) . ')' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Pilih Kelas (Bisa Ceklis Banyak) -->
                    <div class="form-group mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <label class="font-weight-bold mb-0">Pilih Kelas (Bisa Ceklis Banyak)</label>
                            <small>
                                <a href="javascript:void(0)" onclick="$('.edit-bank-class-cb').prop('checked', true); autoGenerateEditBankSoalName();" class="mr-2">Pilih Semua</a>
                                <a href="javascript:void(0)" onclick="$('.edit-bank-class-cb').prop('checked', false); autoGenerateEditBankSoalName();" class="text-muted">Kosongkan</a>
                            </small>
                        </div>
                        <div class="border p-2 rounded bg-light" style="max-height: 140px; overflow-y: auto;">
                            <div class="row">
                                <?php foreach ($classes as $c): ?>
                                    <div class="col-md-3 col-6">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input edit-bank-class-cb" id="edit_bank_class_<?= $c['id'] ?>" value="<?= htmlspecialchars($c['name']) ?>" onchange="autoGenerateEditBankSoalName()">
                                            <label class="custom-control-label font-weight-normal text-dark" for="edit_bank_class_<?= $c['id'] ?>" style="cursor: pointer;"><?= htmlspecialchars($c['name']) ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <small class="text-muted">Centang kelas target untuk ujian ini.</small>
                    </div>

                    <!-- Kolom Nama Bank Soal (Auto Generate & Editable) -->
                    <div class="form-group mb-2">
                        <label class="font-weight-bold">Nama Bank Soal <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="text" id="edit_bank_soal_name" class="form-control font-weight-bold" required placeholder="Contoh: PAS-XII-Matematika-8X2K">
                            <div class="input-group-append">
                                <button type="button" class="btn btn-outline-secondary" onclick="regenerateEditBankRandomCode()" title="Acak Ulang Kode Unik">
                                    <i class="fas fa-random mr-1"></i> Acak Kode
                                </button>
                            </div>
                        </div>
                        <small class="text-muted mt-1 d-block">
                            Otomatis dibuat dengan format: <code>[Jenis Ujian]-[Kelas]-[Mata Pelajaran]-[Kode Unik]</code>. Anda tetap dapat mengeditnya secara manual.
                        </small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary font-weight-bold">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let currentBankUniqueCode = '';
let currentEditBankUniqueCode = '';

function generateRandomBankCode(len = 4) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let res = '';
    for (let i = 0; i < len; i++) {
        res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
}

function getSelectedClassesLabel() {
    const checked = Array.from(document.querySelectorAll('.add-bank-class-cb:checked'));
    if (checked.length === 0) return '';
    const names = checked.map(cb => cb.value.trim()).filter(Boolean);
    return names.join(',');
}

function getSelectedEditClassesLabel() {
    const checked = Array.from(document.querySelectorAll('.edit-bank-class-cb:checked'));
    if (checked.length === 0) return '';
    const names = checked.map(cb => cb.value.trim()).filter(Boolean);
    return names.join(',');
}

function autoGenerateBankSoalName() {
    const jenisEl = document.getElementById('add_bank_jenis_ujian');
    const mapelEl = document.getElementById('add_bank_mapel');
    const nameInput = document.getElementById('add_bank_soal_name');
    if (!nameInput) return;

    if (!currentBankUniqueCode) {
        currentBankUniqueCode = generateRandomBankCode(4);
    }

    const selectedJenis = jenisEl && jenisEl.value ? jenisEl.value.trim() : '';
    const selectedMapel = mapelEl && mapelEl.value ? mapelEl.value.trim() : '';
    const selectedKelas = getSelectedClassesLabel();

    const parts = [];
    if (selectedJenis) parts.push(selectedJenis);
    if (selectedKelas) parts.push(selectedKelas);
    if (selectedMapel) parts.push(selectedMapel);
    if (currentBankUniqueCode) parts.push(currentBankUniqueCode);

    if (parts.length > 1) {
        nameInput.value = parts.join('-');
    }
}

function autoGenerateEditBankSoalName() {
    const jenisEl = document.getElementById('edit_bank_jenis_ujian');
    const mapelEl = document.getElementById('edit_bank_mapel');
    const nameInput = document.getElementById('edit_bank_soal_name');
    if (!nameInput) return;

    if (!currentEditBankUniqueCode) {
        currentEditBankUniqueCode = generateRandomBankCode(4);
    }

    const selectedJenis = jenisEl && jenisEl.value ? jenisEl.value.trim() : '';
    const selectedMapel = mapelEl && mapelEl.value ? mapelEl.value.trim() : '';
    const selectedKelas = getSelectedEditClassesLabel();

    const parts = [];
    if (selectedJenis) parts.push(selectedJenis);
    if (selectedKelas) parts.push(selectedKelas);
    if (selectedMapel) parts.push(selectedMapel);
    if (currentEditBankUniqueCode) parts.push(currentEditBankUniqueCode);

    if (parts.length > 1) {
        nameInput.value = parts.join('-');
    }
}

function regenerateBankRandomCode() {
    currentBankUniqueCode = generateRandomBankCode(4);
    autoGenerateBankSoalName();
}

function regenerateEditBankRandomCode() {
    currentEditBankUniqueCode = generateRandomBankCode(4);
    autoGenerateEditBankSoalName();
}

function openEditBankSoalModal(id, currentName, storedClassesStr) {
    document.getElementById('edit_bank_soal_id').value = id;
    const nameInput = document.getElementById('edit_bank_soal_name');
    if (nameInput) nameInput.value = currentName || '';

    const jenisEl = document.getElementById('edit_bank_jenis_ujian');
    if (jenisEl) jenisEl.selectedIndex = 0;
    const mapelEl = document.getElementById('edit_bank_mapel');
    if (mapelEl) mapelEl.selectedIndex = 0;
    $('.edit-bank-class-cb').prop('checked', false);

    currentEditBankUniqueCode = '';

    let detectedJenis = '';
    let detectedClasses = [];
    let detectedMapel = '';
    let detectedCode = '';

    if (storedClassesStr) {
        try {
            const p = JSON.parse(storedClassesStr);
            if (Array.isArray(p)) detectedClasses = p.map(s => String(s).trim()).filter(Boolean);
        } catch(e) {
            if (typeof storedClassesStr === 'string' && storedClassesStr.trim()) {
                detectedClasses = storedClassesStr.split(',').map(s => s.trim()).filter(Boolean);
            }
        }
    }

    if (currentName && currentName.includes('-')) {
        let parts = currentName.split('-').map(p => p.trim());
        if (parts.length >= 4 && /^[A-Za-z0-9]{3,6}$/.test(parts[parts.length - 1])) {
            detectedCode = parts.pop();
        }
        if (parts.length >= 3) {
            detectedJenis = parts[0];
            if (detectedClasses.length === 0 && parts[1]) {
                detectedClasses = parts[1].split(',').map(s => s.trim()).filter(Boolean);
            }
            detectedMapel = parts.slice(2).join('-');
        }
    }

    currentEditBankUniqueCode = detectedCode || generateRandomBankCode(4);

    // Set Jenis Ujian jika cocok
    if (jenisEl && detectedJenis) {
        const djLower = detectedJenis.toLowerCase();
        for (let i = 0; i < jenisEl.options.length; i++) {
            const opt = jenisEl.options[i];
            const optVal = (opt.value || '').toLowerCase();
            const optCode = (opt.getAttribute('data-code') || '').toLowerCase();
            if (optVal === djLower || optCode === djLower) {
                jenisEl.selectedIndex = i;
                break;
            }
        }
    }

    // Set Mapel jika cocok
    if (mapelEl && detectedMapel) {
        const dmLower = detectedMapel.toLowerCase();
        for (let i = 0; i < mapelEl.options.length; i++) {
            const opt = mapelEl.options[i];
            const optVal = (opt.value || '').toLowerCase();
            const optName = (opt.getAttribute('data-name') || '').toLowerCase();
            const optCode = (opt.getAttribute('data-code') || '').toLowerCase();
            if (optVal === dmLower || optName === dmLower || (optCode && optCode === dmLower)) {
                mapelEl.selectedIndex = i;
                break;
            }
        }
    }

    // Centang Kelas
    if (detectedClasses.length > 0) {
        document.querySelectorAll('.edit-bank-class-cb').forEach(cb => {
            const cName = (cb.value || cb.nextElementSibling?.textContent || '').trim().toLowerCase();
            let matched = false;
            for (const dc of detectedClasses) {
                const dcLower = dc.toLowerCase();
                if (cName === dcLower) {
                    matched = true;
                    break;
                }
                if (/^(XII|XI|IX|VIII|VII|VI|IV|V|X|\d+)$/i.test(dc)) {
                    const regex = new RegExp('^' + dc + '([.\\-\\s_A-Za-z0-9]|$)', 'i');
                    if (regex.test(cName)) {
                        matched = true;
                        break;
                    }
                }
            }
            if (matched) cb.checked = true;
        });
    }

    $('#modalEditBankSoal').modal('show');
}

function editBankSoalName(id, currentName) {
    openEditBankSoalModal(id, currentName, '');
}

async function submitEditBankSoal(e) {
    e.preventDefault();
    const id = document.getElementById('edit_bank_soal_id').value;
    const name = document.getElementById('edit_bank_soal_name').value;
    const checkedClasses = Array.from(document.querySelectorAll('.edit-bank-class-cb:checked')).map(cb => cb.value.trim()).filter(Boolean);

    const fd = new FormData();
    fd.append('action', 'edit_bank_soal_name');
    fd.append('id', id);
    fd.append('name', name);
    fd.append('classes', JSON.stringify(checkedClasses));

    try {
        const res = await fetch('api.php', { method: 'POST', body: fd });
        const json = await res.json();
        if (json.status === 'success') {
            location.reload();
        } else {
            Swal.fire('Gagal', json.message || 'Gagal mengubah Bank Soal', 'error');
        }
    } catch(err) {
        Swal.fire('Error', 'Gagal memproses perubahan Bank Soal', 'error');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.jQuery) {
        $('#modalAddBankSoal').on('show.bs.modal', function () {
            currentBankUniqueCode = generateRandomBankCode(4);
            const nameInput = document.getElementById('add_bank_soal_name');
            if (nameInput) nameInput.value = '';
            const jenisEl = document.getElementById('add_bank_jenis_ujian');
            if (jenisEl) jenisEl.selectedIndex = 0;
            const mapelEl = document.getElementById('add_bank_mapel');
            if (mapelEl) mapelEl.selectedIndex = 0;
            $('.add-bank-class-cb').prop('checked', false);
        });
    }
});
</script>

<!-- Modal Impor Bank Soal dari ZIP -->
<div class="modal fade" id="modalImportBankSoalZip" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form-import-bank-soal-zip" onsubmit="submitImportBankSoalZip(event)">
                <div class="modal-header bg-secondary text-white">
                    <h5 class="modal-title"><i class="fas fa-file-import mr-2"></i>Impor Bank Soal (ZIP)</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info py-2 px-3 mb-3" style="font-size: 0.9rem;">
                        <i class="fas fa-info-circle mr-1"></i>
                        Pilih satu atau banyak file arsip <strong>.zip</strong> hasil backup (atau 1 file zip paket massal). Seluruh Bank Soal, butir soal, dan gambar di dalam folder akan dipulihkan secara otomatis.
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="zip_file_input" class="font-weight-bold">Pilih File Backup Soal (.zip) <span class="text-danger">*</span></label>
                        <input type="file" name="files_zip[]" id="zip_file_input" class="form-control-file" accept=".zip" multiple required>
                        <small class="text-muted d-block mt-1">Dapat memilih <strong>satu atau banyak file .zip</strong> sekaligus (Bulk Import), atau 1 file .zip paket massal yang memuat banyak bank soal.</small>
                    </div>

                    <div class="form-group mb-3">
                        <label class="font-weight-bold">Tujuan Impor:</label>
                        <div class="custom-control custom-radio mb-2">
                            <input type="radio" id="target_new_bank" name="zip_target_type" class="custom-control-input" value="new" checked onchange="toggleZipTargetType(this.value)">
                            <label class="custom-control-label" for="target_new_bank">Buat Bank Soal Baru Otomatis (Nama dari file backup)</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="target_existing_bank" name="zip_target_type" class="custom-control-input" value="existing" onchange="toggleZipTargetType(this.value)">
                            <label class="custom-control-label" for="target_existing_bank">Masukkan ke Bank Soal yang Sudah Ada</label>
                        </div>
                    </div>

                    <!-- Container Nama Bank Baru -->
                    <div id="container-zip-new-bank" class="form-group mb-3">
                        <label for="zip_custom_bank_name">Nama Bank Soal Baru (Opsional)</label>
                        <input type="text" id="zip_custom_bank_name" class="form-control" placeholder="Biarkan kosong untuk memakai nama dari file backup">
                        <small class="text-muted">Jika dikosongkan, nama bank soal akan diambil otomatis dari file backup.</small>
                    </div>

                    <!-- Container Pilih Bank Eksisting -->
                    <div id="container-zip-existing-bank" class="form-group mb-3" style="display: none;">
                        <label for="zip_existing_bank_id" class="font-weight-bold">Pilih Bank Soal Tujuan <span class="text-danger">*</span></label>
                        <select id="zip_existing_bank_id" class="form-control">
                            <option value="" disabled selected>-- Pilih Bank Soal Tujuan --</option>
                            <?php foreach ($bank_soal as $b): ?>
                                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="mt-2">
                            <label class="font-weight-bold mb-1">Mode Masukkan Soal:</label>
                            <select id="zip_import_mode" class="form-control form-control-sm">
                                <option value="append" selected>Tambahkan (Pertahankan soal yang sudah ada)</option>
                                <option value="replace">Timpa Semua (Hapus & gantikan soal yang sudah ada)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" id="btn-submit-import-zip" class="btn btn-primary"><i class="fas fa-upload mr-2"></i>Mulai Impor ZIP</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Kelola Kunci Jawaban Excel -->
<div class="modal fade" id="modalKunciExcel" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title font-weight-bold"><i class="fas fa-file-excel mr-2"></i>Kelola Kunci Jawaban via Excel</h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body p-0">
                <!-- Nav Tabs Unduh & Impor -->
                <ul class="nav nav-tabs px-3 pt-2 bg-light border-bottom" id="tabKunciExcel">
                    <li class="nav-item">
                        <a class="nav-link active font-weight-bold text-primary" href="#tab-unduh-kunci" data-toggle="tab">
                            <i class="fas fa-download mr-1"></i> 1. Unduh Template Excel
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link font-weight-bold text-success" href="#tab-impor-kunci" data-toggle="tab">
                            <i class="fas fa-upload mr-1"></i> 2. Impor Kunci dari Excel
                        </a>
                    </li>
                </ul>

                <div class="tab-content p-3">
                    <!-- Tab 1: Unduh Template Excel -->
                    <div class="tab-pane active" id="tab-unduh-kunci">
                        <div class="alert alert-info py-2 mb-3" style="font-size: 0.9rem;">
                            <i class="fas fa-info-circle mr-1"></i> Unduh berkas format Excel (.xlsx) untuk mengisi atau merevisi kunci jawaban secara cepat dan massal.
                        </div>

                        <div class="form-group mb-3">
                            <label class="font-weight-bold text-dark">Pilih Format Template:</label>
                            <div class="custom-control custom-radio mb-2">
                                <input type="radio" id="template_source_current" name="template_source" class="custom-control-input" value="current" checked onchange="toggleTemplateSource(this.value)">
                                <label class="custom-control-label font-weight-bold" for="template_source_current">
                                    Sesuai Bank Soal Saat Ini (<span id="tpl-current-q-count">0</span> Soal)
                                </label>
                                <small class="text-muted d-block ml-4">Mencantumkan seluruh butir soal yang sudah ada di bank soal ini lengkap dengan stimulus dan kunci jawaban saat ini (tinggal revisi yang salah).</small>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" id="template_source_custom" name="template_source" class="custom-control-input" value="custom" onchange="toggleTemplateSource(this.value)">
                                <label class="custom-control-label font-weight-bold" for="template_source_custom">
                                    Kustom Baru (Tentukan Tipe & Jumlah Soal Sendiri)
                                </label>
                                <small class="text-muted d-block ml-4">Buat lembar template baru dengan menentukan tipe butir soal dan jumlah baris soal bebas (misal 20, 30, 40, 50 soal).</small>
                            </div>
                        </div>

                        <!-- Opsi Kustom (Muncul jika pilih Kustom Baru) -->
                        <div id="container-kustom-template" class="p-3 bg-light border rounded mb-3" style="display: none;">
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <label class="font-weight-bold mb-1" style="font-size: 0.88rem;">Tipe Soal:</label>
                                    <select id="tpl_custom_type" class="form-control form-control-sm">
                                        <option value="multiple_choice" selected>Pilihan Ganda Biasa (A, B, C, D, E)</option>
                                        <option value="complex_mc">Pilihan Ganda Kompleks (Contoh: A, C)</option>
                                        <option value="true_false">Benar - Salah (Contoh: B, S, B)</option>
                                        <option value="matching">Menjodohkan (Contoh: A, C, B)</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-2">
                                    <label class="font-weight-bold mb-1" style="font-size: 0.88rem;">Jumlah Soal:</label>
                                    <input type="number" id="tpl_custom_count" class="form-control form-control-sm" value="40" min="1" max="250">
                                </div>
                                <div class="col-md-3 mb-2">
                                    <label class="font-weight-bold mb-1" style="font-size: 0.88rem;">Poin / Soal:</label>
                                    <input type="number" id="tpl_custom_points" class="form-control form-control-sm" value="2.5" step="0.1" min="0">
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end pt-2 border-top">
                            <button type="button" onclick="downloadTemplateKunciExcel()" class="btn btn-primary">
                                <i class="fas fa-file-excel mr-1"></i> Unduh File Template (.xlsx)
                            </button>
                        </div>
                    </div>

                    <!-- Tab 2: Impor Kunci Jawaban -->
                    <div class="tab-pane" id="tab-impor-kunci">
                        <form id="form-import-kunci-excel" onsubmit="submitImportKunciExcel(event)">
                            <div class="form-group mb-3">
                                <label class="font-weight-bold" for="file_kunci_excel">Pilih Berkas Excel Kunci Jawaban (.xlsx / .xls) <span class="text-danger">*</span></label>
                                <input type="file" id="file_kunci_excel" class="form-control-file border p-2 rounded bg-light" accept=".xlsx, .xls" required>
                                <small class="text-muted d-block mt-1">Gunakan file template Excel yang telah diisi kolom Kunci Jawaban.</small>
                            </div>

                            <div class="p-3 bg-light border rounded mb-3" style="font-size: 0.86rem;">
                                <div class="font-weight-bold text-dark mb-1"><i class="fas fa-lightbulb text-warning mr-1"></i> Panduan Pengisian Kunci di Excel:</div>
                                <ul class="mb-0 pl-3 text-muted">
                                    <li><strong>Pilihan Ganda:</strong> Cukup ketik huruf opsi yang benar, contoh: <code>A</code>, <code>B</code>, <code>C</code>, <code>D</code>, atau <code>E</code>.</li>
                                    <li><strong>PG Kompleks:</strong> Tuliskan huruf opsi dipisahkan koma, contoh: <code>A, C</code> atau <code>B, D, E</code>.</li>
                                    <li><strong>Benar - Salah:</strong> Tuliskan status tiap baris pernyataan dipisahkan koma, contoh: <code>B, S, B</code>.</li>
                                    <li><strong>Bobot Poin (Opsional):</strong> Kolom poin dapat diisi angka (contoh: <code>2.5</code>) jika ingin mengubah bobot butir soal sekaligus.</li>
                                </ul>
                            </div>

                            <div class="custom-control custom-checkbox mb-3">
                                <input type="checkbox" class="custom-control-input" id="cb_auto_recalc_excel" checked>
                                <label class="custom-control-label font-weight-bold text-dark" for="cb_auto_recalc_excel" style="cursor: pointer;">
                                    Otomatis hitung ulang nilai siswa yang telah menyelesaikan ujian
                                </label>
                                <small class="text-muted d-block ml-4">Sistem akan langsung mencocokkan lembar jawaban siswa yang tersimpan dengan kunci jawaban baru ini.</small>
                            </div>

                            <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                <button type="submit" id="btn-submit-kunci-excel" class="btn btn-success">
                                    <i class="fas fa-save mr-1"></i> Simpan & Terapkan Kunci
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    window.openGeminiAiPopup = function(e) {
        if (e && e.preventDefault) e.preventDefault();
        const url = 'https://share.gemini.google/ReefFdC6lnEu';
        const width = Math.min(Math.max(Math.round(window.screen.availWidth * 0.46), 540), 850);
        const height = Math.max(window.screen.availHeight - 60, 600);
        const left = Math.max(window.screen.availWidth - width - 10, 0);
        const top = 30;
        const windowFeatures = `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=no,toolbar=no,menubar=no,location=yes`;
        
        const popup = window.open(url, 'GeminiSoalPopup', windowFeatures);
        if (popup && !popup.closed) {
            popup.focus();
        } else {
            window.open(url, '_blank', 'noopener,noreferrer');
        }
        return false;
    };
</script>

<?php if (isset($_GET['open_bank_id']) && isset($_GET['open_bank_name'])): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        let checkExist = setInterval(function() {
            if (typeof openDetailSoal === 'function') {
                openDetailSoal(<?= (int)$_GET['open_bank_id'] ?>, '<?= addslashes(htmlspecialchars(urldecode($_GET['open_bank_name']))) ?>');
                clearInterval(checkExist);
            }
        }, 100);
    });
</script>
<?php endif; ?>

<!-- ======================================================== -->
<!-- MODAL PRATINJAU SOAL PERSIS HALAMAN SISWA -->
<!-- ======================================================== -->
<style>
.modal-preview-dialog {
    max-width: 900px !important;
}
.preview-student-header {
    background-color: #1F7FAB;
    background-image: 
        linear-gradient(to right, rgba(255, 255, 255, 0.06) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(255, 255, 255, 0.06) 1px, transparent 1px),
        radial-gradient(circle at center, #1F7FAB 0%, #14597b 50%, #0d3d54 100%);
    background-size: 24px 24px, 24px 24px, auto;
}
.preview-opt-label {
    display: flex;
    align-items: center;
    padding: 0.85rem 1.1rem;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    margin-bottom: 0.75rem;
    cursor: pointer;
    background: #f8fafc;
    transition: all 0.2s ease;
    user-select: none;
}
.preview-opt-label:hover {
    border-color: #a5b4fc;
    background: #eef2ff;
}
.preview-opt-label.is-checked {
    border-color: #4f46e5 !important;
    background: #eef2ff !important;
    box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.1);
}
.preview-opt-label.is-correct-key {
    border-color: #10b981 !important;
    background: #ecfdf5 !important;
    box-shadow: 0 0 0 1.5px #10b981;
}
.preview-opt-input {
    margin-right: 0.85rem;
    width: 20px;
    height: 20px;
    accent-color: #4f46e5;
    cursor: pointer;
}
.preview-key-badge {
    background: #10b981;
    color: #ffffff;
    font-size: 0.72rem;
    padding: 2px 7px;
    border-radius: 4px;
    font-weight: 700;
    margin-left: 8px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}
.preview-map-cell {
    width: 42px;
    height: 42px;
    border-radius: 8px;
    border: 1px solid #cbd5e1;
    background: #ffffff;
    font-weight: 700;
    font-size: 0.92rem;
    color: #334155;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.15s ease;
    user-select: none;
}
.preview-map-cell:hover {
    border-color: #94a3b8;
    background: #f1f5f9;
}
.preview-map-cell.answered {
    background: #10b981 !important;
    color: #ffffff !important;
    border-color: #10b981 !important;
}
.preview-map-cell.active {
    border: 2.5px solid #4f46e5 !important;
    box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.25);
}
.modal-preview-dialog {
    max-width: 900px !important;
    width: 95% !important;
    margin-top: 1.5rem !important;
    margin-bottom: 4.5rem !important;
}
#modalStudentPreview .modal-content {
    border-radius: 14px !important;
    overflow: hidden !important;
    background-color: #f8fafc !important;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.25), 0 10px 10px -5px rgba(0, 0, 0, 0.1) !important;
}
#modalStudentPreview .modal-body {
    min-height: 280px !important;
    max-height: calc(100vh - 300px) !important;
    background-color: #f1f5f9 !important;
}
#modalStudentPreview .modal-footer {
    background-color: #ffffff !important;
    border-top: 1px solid #e2e8f0 !important;
    padding: 0.95rem 1.5rem 1.25rem 1.5rem !important;
    box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.04) !important;
    z-index: 10;
}
#modalStudentPreview .btn-preview-nav {
    font-weight: 700;
    font-size: 0.92rem;
    padding: 0.45rem 1.15rem;
    border-radius: 8px;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
}
#modalStudentPreview .btn-preview-nav:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}
</style>

<div class="modal fade" id="modalStudentPreview" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-preview-dialog" style="max-width: 900px; width: 95%;">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 12px; overflow: hidden; background-color: #f4f6f9;">
            
            <!-- Blue Top Header (Identical to Student index.php) -->
            <div class="preview-student-header text-white p-3 p-sm-4">
                <div class="d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-display mr-2" style="font-size: 1.85rem; color: #7dd3fc;"></i>
                        <div>
                            <span class="font-weight-bold" style="font-size: 1.35rem; letter-spacing: 0.5px;">
                                <span style="color: #DF2463;">Ryu</span><span style="color: #38bdf8;">Exam</span>
                            </span>
                            <span class="badge badge-warning text-dark ml-2 font-weight-bold" style="font-size: 0.72rem; vertical-align: middle;">SIMULASI SISWA</span>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center ml-auto">
                        <a href="javascript:void(0)" id="modal-btn-open-fulltab" target="_blank" class="btn btn-sm btn-outline-light mr-2 font-weight-bold" title="Buka Pratinjau Layar Penuh di Tab Baru">
                            <i class="fas fa-external-link-alt mr-1"></i> <span class="d-none d-sm-inline">Layar Penuh</span>
                        </a>
                        <button type="button" class="btn btn-sm btn-light font-weight-bold text-dark" data-dismiss="modal" title="Tutup Pratinjau">&times; Tutup</button>
                    </div>
                </div>
            </div>

            <!-- Sticky Student Info & Controls Bar -->
            <div class="bg-white border-bottom px-3 py-2 px-sm-4 d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
                <div>
                    <span class="font-weight-bold text-dark d-block" style="font-size: 0.95rem;">Siswa Simulasi (Pratinjau)</span>
                    <span class="badge badge-info" id="modal-preview-bank-badge">Bank Soal</span>
                </div>
                
                <div class="d-flex align-items-center flex-wrap" style="gap: 8px;">
                    <!-- Kunci Jawaban Switch -->
                    <div class="custom-control custom-switch mr-2" title="Tampilkan Kunci Jawaban">
                        <input type="checkbox" class="custom-control-input" id="sw-modal-preview-kunci" onchange="toggleModalPreviewKunci(this.checked)">
                        <label class="custom-control-label font-weight-bold text-secondary" for="sw-modal-preview-kunci" style="cursor: pointer; font-size: 0.85rem;">
                            <i class="fas fa-key text-warning mr-1"></i>Kunci
                        </label>
                    </div>

                    <!-- Mode Timer Badge -->
                    <div class="px-2 py-1 rounded font-weight-bold d-flex align-items-center" style="background-color: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe; font-size: 0.85rem;">
                        <i class="bi bi-clock mr-1"></i> <span id="modal-preview-timer-text">Simulasi Waktu</span>
                    </div>

                    <!-- Tombol Daftar Soal (Map) -->
                    <button type="button" class="btn btn-sm btn-outline-secondary font-weight-bold" onclick="toggleModalPreviewMap()" title="Daftar Soal">
                        <i class="bi bi-grid-3x3-gap-fill text-primary mr-1"></i> <span class="d-none d-sm-inline">Daftar Soal</span>
                    </button>
                </div>
            </div>

            <!-- Modal Body: Single Question Container -->
            <div class="modal-body p-3 p-sm-4 position-relative" style="min-height: 280px; background-color: #f1f5f9; overflow-y: auto; max-height: calc(100vh - 300px);">
                <!-- Question Map Popup Drawer -->
                <div id="modal-preview-map-popup" style="display: none; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.65); z-index: 20; padding: 1.5rem; backdrop-filter: blur(2px);">
                    <div class="bg-white rounded-lg p-3 shadow-lg mx-auto" style="max-width: 480px; max-height: 90%; overflow-y: auto; border-radius: 10px;">
                        <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom">
                            <h5 class="font-weight-bold mb-0 text-dark"><i class="bi bi-grid-3x3-gap-fill text-primary mr-1"></i> Daftar Soal</h5>
                            <button type="button" class="close text-muted" onclick="toggleModalPreviewMap()">&times;</button>
                        </div>
                        <small class="text-muted d-block mb-3">Klik nomor butir soal untuk berpindah nomor secara langsung.</small>
                        <div id="modal-preview-map-grid" class="d-flex flex-wrap" style="gap: 8px;"></div>
                    </div>
                </div>

                <!-- Question Card Container -->
                <div id="modal-single-question-container" class="bg-white p-3 p-sm-4 rounded shadow-sm border mb-1">
                    <!-- Injected by JavaScript -->
                </div>
            </div>

            <!-- Modal Footer: Navigation Toolbar -->
            <div class="modal-footer bg-white border-top px-3 py-3 px-sm-4 d-flex justify-content-between align-items-center">
                <button type="button" id="modal-btn-prev" class="btn btn-primary btn-preview-nav" onclick="modalNavigatePrev()">
                    <i class="bi bi-chevron-left mr-1"></i> Sebelumnya
                </button>
                
                <button type="button" class="btn btn-outline-secondary btn-preview-nav text-dark font-weight-bold" onclick="toggleModalPreviewMap()">
                    <i class="bi bi-grid-3x3-gap-fill text-primary mr-1"></i> Nomor Soal
                </button>

                <button type="button" id="modal-btn-next" class="btn btn-primary btn-preview-nav" onclick="modalNavigateNext()">
                    Selanjutnya <i class="bi bi-chevron-right ml-1"></i>
                </button>
            </div>

        </div>
    </div>
</div>

<script>
let previewModalQuestions = [];
let previewModalCurrentIndex = 0;
let previewModalAnswers = {};
let previewModalShowKunci = false;
let previewModalBankName = '';
let previewModalBankId = 0;

async function openStudentPreview(bankId, bankName) {
    previewModalBankId = bankId;
    previewModalBankName = bankName || 'Bank Soal #' + bankId;
    previewModalCurrentIndex = 0;
    previewModalAnswers = {};
    previewModalShowKunci = false;
    
    const swKunci = document.getElementById('sw-modal-preview-kunci');
    if (swKunci) swKunci.checked = false;

    const bankBadge = document.getElementById('modal-preview-bank-badge');
    if (bankBadge) bankBadge.textContent = previewModalBankName;

    const btnTab = document.getElementById('modal-btn-open-fulltab');
    if (btnTab) btnTab.href = `preview.php?bank_id=${bankId}`;

    const container = document.getElementById('modal-single-question-container');
    if (container) {
        container.innerHTML = '<div class="p-5 text-center text-muted"><i class="fas fa-spinner fa-spin fa-2x mb-3 text-primary d-block"></i><span>Memuat butir soal pratinjau siswa...</span></div>';
    }

    const drawer = document.getElementById('modal-preview-map-popup');
    if (drawer) drawer.style.display = 'none';

    $('#modalStudentPreview').modal('show');

    try {
        const res = await fetch(`api.php?action=get_questions&bank_soal_id=${bankId}&exam_id=${bankId}`);
        const json = await res.json();
        if (json.status === 'success' && Array.isArray(json.data)) {
            previewModalQuestions = json.data;
            renderModalQuestion(0);
        } else {
            if (container) container.innerHTML = '<div class="alert alert-danger">Gagal memuat butir soal.</div>';
        }
    } catch (e) {
        if (container) container.innerHTML = '<div class="alert alert-danger">Terjadi kesalahan koneksi saat memuat soal.</div>';
    }
}

function openCurrentBankStudentPreview() {
    const previewEl = document.getElementById('preview_exam_id');
    const bankId = previewEl ? previewEl.value : 0;
    let bankTitle = document.getElementById('detail-soal-title')?.innerText || '';
    bankTitle = bankTitle.replace(/^Kelola Soal:\s*/i, '').trim();
    if (bankId) {
        openStudentPreview(bankId, bankTitle);
    }
}

function toggleModalPreviewKunci(isChecked) {
    previewModalShowKunci = isChecked;
    renderModalQuestion(previewModalCurrentIndex);
}

function toggleModalPreviewMap() {
    const drawer = document.getElementById('modal-preview-map-popup');
    if (drawer) {
        const isHidden = (drawer.style.display === 'none' || !drawer.style.display);
        drawer.style.display = isHidden ? 'block' : 'none';
        if (isHidden) {
            renderModalMap();
        }
    }
}

function isModalQuestionAnswered(idx) {
    const ans = previewModalAnswers[idx];
    if (ans === undefined || ans === null || ans === '') return false;
    if (Array.isArray(ans) && ans.length === 0) return false;
    if (typeof ans === 'object' && Object.keys(ans).length === 0) return false;
    return true;
}

function renderModalMap() {
    const grid = document.getElementById('modal-preview-map-grid');
    if (!grid) return;
    grid.innerHTML = '';
    
    previewModalQuestions.forEach((q, idx) => {
        const cell = document.createElement('div');
        cell.className = 'preview-map-cell';
        cell.textContent = idx + 1;
        
        if (idx === previewModalCurrentIndex) {
            cell.classList.add('active');
        }
        if (isModalQuestionAnswered(idx)) {
            cell.classList.add('answered');
        }
        
        cell.onclick = () => {
            previewModalCurrentIndex = idx;
            renderModalQuestion(previewModalCurrentIndex);
            toggleModalPreviewMap();
        };
        grid.appendChild(cell);
    });
}

function renderModalQuestion(index) {
    const container = document.getElementById('modal-single-question-container');
    if (!container) return;
    container.innerHTML = '';

    if (previewModalQuestions.length === 0) {
        container.innerHTML = `
            <div class="p-5 text-center text-muted">
                <i class="fas fa-folder-open fa-3x text-muted mb-3 d-block" style="opacity: 0.4;"></i>
                <h5 class="font-weight-bold text-secondary">Bank Soal Masih Kosong</h5>
                <p class="text-muted small">Belum ada butir soal pada bank soal ini.</p>
            </div>`;
        document.getElementById('modal-btn-prev').disabled = true;
        document.getElementById('modal-btn-next').disabled = true;
        return;
    }

    const q = previewModalQuestions[index];
    const qType = q.type || 'multiple_choice';
    let contentHtml = '';

    if (qType === 'essay') {
        const savedVal = previewModalAnswers[index] || '';
        contentHtml = `
            <textarea class="form-control mt-3 essay-input" rows="5" placeholder="Ketik jawaban uraian Anda di sini..." oninput="previewModalAnswers[${index}] = this.value; renderModalMap();">${savedVal}</textarea>
        `;
    } else if (qType === 'complex_mc') {
        let optsHtml = '';
        const selectedArr = Array.isArray(previewModalAnswers[index]) ? previewModalAnswers[index] : [];
        const correctAnswers = Array.isArray(q.answers) ? q.answers.map(a => parseInt(a)) : [];

        (q.options || []).forEach((opt, optIdx) => {
            const isChecked = selectedArr.includes(optIdx) ? 'checked' : '';
            const isKey = previewModalShowKunci && correctAnswers.includes(optIdx);
            const keyBadge = isKey ? `<span class="preview-key-badge"><i class="fas fa-check mr-1"></i> KUNCI</span>` : '';
            const keyClass = isKey ? 'is-correct-key' : (isChecked ? 'is-checked' : '');

            optsHtml += `
                <label class="preview-opt-label ${keyClass}">
                    <input type="checkbox" value="${optIdx}" class="preview-opt-input" ${isChecked} onchange="handleModalComplexChange(${index}, ${optIdx}, this.checked)">
                    <div class="d-flex justify-content-between align-items-center w-100">
                        <span>${opt}</span>
                        ${keyBadge}
                    </div>
                </label>
            `;
        });

        contentHtml = `
            <div class="p-2 mb-3 rounded" style="background:#EFF6FF; border:1px solid #BFDBFE; color:#1E40AF; font-size:0.9rem;">
                <i class="bi bi-check-all mr-1"></i> <strong>Pilihan Ganda Kompleks:</strong> Anda dapat memilih lebih dari satu jawaban benar.
            </div>
            <div>${optsHtml}</div>
        `;
    } else if (qType === 'true_false') {
        let rowsHtml = '';
        const selectedObj = previewModalAnswers[index] || {};

        (q.statements || []).forEach((stmt, sIdx) => {
            const isTrueChecked = selectedObj[sIdx] === true || selectedObj[sIdx] === 'true' ? 'checked' : '';
            const isFalseChecked = selectedObj[sIdx] === false || selectedObj[sIdx] === 'false' ? 'checked' : '';
            
            let keyHint = '';
            if (previewModalShowKunci && stmt.answer !== undefined) {
                const correctBool = (stmt.answer === true || stmt.answer === 'true');
                keyHint = `<span class="preview-key-badge" style="background:${correctBool ? '#10B981':'#EF4444'}"><i class="fas fa-key mr-1"></i> ${correctBool ? 'BENAR':'SALAH'}</span>`;
            }

            rowsHtml += `
                <tr>
                    <td class="text-center font-weight-bold align-middle">${sIdx + 1}</td>
                    <td class="align-middle">
                        <span>${stmt.text}</span>
                        ${keyHint}
                    </td>
                    <td class="text-center align-middle" style="width: 85px;">
                        <input type="radio" name="modal_tf_${index}_${sIdx}" value="true" class="tf-radio" ${isTrueChecked} onchange="handleModalTfChange(${index}, ${sIdx}, true)" style="accent-color: #10B981; width: 20px; height: 20px; cursor: pointer;">
                    </td>
                    <td class="text-center align-middle" style="width: 85px;">
                        <input type="radio" name="modal_tf_${index}_${sIdx}" value="false" class="tf-radio" ${isFalseChecked} onchange="handleModalTfChange(${index}, ${sIdx}, false)" style="accent-color: #EF4444; width: 20px; height: 20px; cursor: pointer;">
                    </td>
                </tr>
            `;
        });

        contentHtml = `
            <div class="p-2 mb-3 rounded" style="background:#ECFDF5; border:1px solid #A7F3D0; color:#047857; font-size:0.9rem;">
                <i class="bi bi-list-check mr-1"></i> <strong>Benar - Salah:</strong> Tentukan status Benar atau Salah untuk setiap pernyataan berikut:
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-sm bg-white mb-2">
                    <thead class="thead-light">
                        <tr>
                            <th style="width: 45px;" class="text-center">No</th>
                            <th>Pernyataan</th>
                            <th style="width: 85px;" class="text-center text-success font-weight-bold">Benar</th>
                            <th style="width: 85px;" class="text-center text-danger font-weight-bold">Salah</th>
                        </tr>
                    </thead>
                    <tbody>${rowsHtml}</tbody>
                </table>
            </div>
        `;
    } else if (qType === 'matching') {
        const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
        const selectedObj = previewModalAnswers[index] || {};
        let rowsHtml = '';

        (q.premises || []).forEach((premiseText, pIdx) => {
            const userChoice = selectedObj[pIdx] !== undefined ? parseInt(selectedObj[pIdx]) : null;
            
            let selectOptionsHtml = '<option value="">-- Pilih Pasangan Jawaban --</option>';
            (q.options || []).forEach((opt, optIdx) => {
                const letter = letters[optIdx] || (optIdx + 1);
                const isSel = (userChoice !== null && userChoice === optIdx) ? 'selected' : '';
                selectOptionsHtml += `<option value="${optIdx}" ${isSel}>${letter}. ${opt}</option>`;
            });

            let keyHint = '';
            if (previewModalShowKunci && q.pairs) {
                const correctOptIdx = q.pairs[pIdx] !== undefined ? q.pairs[pIdx] : q.pairs[String(pIdx)];
                if (correctOptIdx !== undefined && q.options && q.options[correctOptIdx]) {
                    const ltr = letters[correctOptIdx] || (correctOptIdx + 1);
                    keyHint = `<span class="preview-key-badge"><i class="fas fa-key mr-1"></i> Kunci: ${ltr}</span>`;
                }
            }

            rowsHtml += `
                <div class="p-2 mb-2 rounded bg-light border d-flex justify-content-between align-items-center flex-wrap" style="gap: 10px;">
                    <div style="flex: 1; min-width: 200px;">
                        <span class="badge badge-primary mr-1">${pIdx + 1}</span>
                        <span>${premiseText}</span>
                        ${keyHint}
                    </div>
                    <div style="width: 250px;">
                        <select class="form-control form-control-sm" onchange="handleModalMatchingChange(${index}, ${pIdx}, this.value)">
                            ${selectOptionsHtml}
                        </select>
                    </div>
                </div>
            `;
        });

        contentHtml = `
            <div class="p-2 mb-3 rounded" style="background:#F0F9FF; border:1px solid #BAE6FD; color:#0369A1; font-size:0.9rem;">
                <i class="bi bi-link-45deg mr-1"></i> <strong>Menjodohkan:</strong> Pasangkan setiap pernyataan dengan jawaban yang tepat:
            </div>
            <div>${rowsHtml}</div>
        `;
    } else {
        // Multiple Choice (Single Correct)
        let optsHtml = '';
        const selectedVal = previewModalAnswers[index];
        const correctAns = parseInt(q.answer);

        (q.options || []).forEach((opt, optIdx) => {
            const isChecked = (selectedVal !== undefined && selectedVal === optIdx) ? 'checked' : '';
            const isKey = previewModalShowKunci && (correctAns === optIdx);
            const keyBadge = isKey ? `<span class="preview-key-badge"><i class="fas fa-check mr-1"></i> KUNCI</span>` : '';
            const keyClass = isKey ? 'is-correct-key' : (isChecked ? 'is-checked' : '');

            optsHtml += `
                <label class="preview-opt-label ${keyClass}">
                    <input type="radio" name="modal_q_${index}" value="${optIdx}" class="preview-opt-input" ${isChecked} onchange="handleModalSingleMcChange(${index}, ${optIdx})">
                    <div class="d-flex justify-content-between align-items-center w-100">
                        <span>${opt}</span>
                        ${keyBadge}
                    </div>
                </label>
            `;
        });

        contentHtml = `<div>${optsHtml}</div>`;
    }

    const examTitle = previewModalBankName || 'Bank Soal';
    const points = q.points !== undefined ? q.points : 2;

    container.innerHTML = `
        <div class="d-flex justify-content-between align-items-center pb-2 mb-3 border-bottom flex-wrap" style="gap: 6px;">
            <div class="d-flex align-items-center">
                <span class="font-weight-bold text-dark" style="font-size: 1.05rem;">Soal ${index + 1} dari ${previewModalQuestions.length}</span>
                <span class="badge badge-light border text-muted ml-2 font-weight-normal px-2 py-1">
                    <i class="fas fa-award text-warning mr-1"></i>${points} Poin
                </span>
            </div>
            <span class="badge badge-light border text-primary px-2 py-1">
                <i class="bi bi-book mr-1"></i> ${examTitle}
            </span>
        </div>
        <div class="question-body text-dark mb-3" style="font-size: 1.05rem; line-height: 1.6; word-break: break-word;">
            ${q.question}
        </div>
        ${contentHtml}
    `;

    if (window.renderMath) {
        window.renderMath(container);
    }

    updateModalNavState();
}

function handleModalSingleMcChange(qIdx, optIdx) {
    previewModalAnswers[qIdx] = optIdx;
    renderModalQuestion(qIdx);
}

function handleModalComplexChange(qIdx, optIdx, isChecked) {
    if (!Array.isArray(previewModalAnswers[qIdx])) {
        previewModalAnswers[qIdx] = [];
    }
    if (isChecked) {
        if (!previewModalAnswers[qIdx].includes(optIdx)) previewModalAnswers[qIdx].push(optIdx);
    } else {
        previewModalAnswers[qIdx] = previewModalAnswers[qIdx].filter(x => x !== optIdx);
    }
    renderModalQuestion(qIdx);
}

function handleModalTfChange(qIdx, sIdx, val) {
    if (!previewModalAnswers[qIdx] || typeof previewModalAnswers[qIdx] !== 'object') {
        previewModalAnswers[qIdx] = {};
    }
    previewModalAnswers[qIdx][sIdx] = val;
    renderModalQuestion(qIdx);
}

function handleModalMatchingChange(qIdx, pIdx, val) {
    if (!previewModalAnswers[qIdx] || typeof previewModalAnswers[qIdx] !== 'object') {
        previewModalAnswers[qIdx] = {};
    }
    if (val !== '') {
        previewModalAnswers[qIdx][pIdx] = parseInt(val);
    } else {
        delete previewModalAnswers[qIdx][pIdx];
    }
    renderModalQuestion(qIdx);
}

function updateModalNavState() {
    const btnPrev = document.getElementById('modal-btn-prev');
    const btnNext = document.getElementById('modal-btn-next');
    if (btnPrev) btnPrev.disabled = (previewModalCurrentIndex === 0);
    if (btnNext) btnNext.disabled = (previewModalCurrentIndex >= previewModalQuestions.length - 1);
}

function modalNavigatePrev() {
    if (previewModalCurrentIndex > 0) {
        previewModalCurrentIndex--;
        renderModalQuestion(previewModalCurrentIndex);
    }
}

function modalNavigateNext() {
    if (previewModalCurrentIndex < previewModalQuestions.length - 1) {
        previewModalCurrentIndex++;
        renderModalQuestion(previewModalCurrentIndex);
    }
}
</script>

