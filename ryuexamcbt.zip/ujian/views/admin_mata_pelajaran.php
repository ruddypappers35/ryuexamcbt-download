<?php
$mapel_list = get_mapel_list();
?>
<div id="section-mata-pelajaran" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
            <div class="d-flex align-items-center flex-wrap" style="gap: 10px;">
                <h3 class="card-title font-weight-bold mb-0">Daftar Mata Pelajaran</h3>
            </div>
            <div class="card-tools d-flex align-items-center flex-wrap ml-auto" style="gap: 8px;">
                <button id="btn-bulk-delete-mapel" class="btn btn-danger btn-sm" style="display: none;" onclick="bulkDeleteMapel()">
                    <i class="fas fa-trash mr-1"></i> Hapus Terpilih (<span id="selected-mapel-count">0</span>)
                </button>
                <div class="input-group input-group-sm" style="width: 220px;">
                    <input type="text" id="search-mapel" class="form-control" placeholder="Cari mata pelajaran..." onkeyup="filterMapelTable()">
                    <div class="input-group-append">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                </div>
                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#modalImportMapel" title="Impor Mata Pelajaran dari Excel">
                    <i class="fas fa-file-excel mr-1"></i> Impor Excel
                </button>
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalAddMapel">
                    <i class="fas fa-plus mr-1"></i> Tambah Mata Pelajaran
                </button>
            </div>
        </div>
        <div class="card-body p-0 table-responsive">
            <table class="table table-striped table-hover mb-0" id="table-mapel">
                <thead>
                    <tr>
                        <th style="width: 40px" class="text-center">
                            <input type="checkbox" id="cb-all-mapel" onchange="toggleAllMapel(this)" title="Pilih Semua">
                        </th>
                        <th style="width: 50px" class="text-center">No</th>
                        <th style="width: 150px">Kode Mapel</th>
                        <th>Nama Mata Pelajaran</th>
                        <th style="width: 120px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbody-mapel">
                    <?php if (empty($mapel_list)): ?>
                    <tr id="row-empty-mapel"><td colspan="5" class="text-center py-3 text-muted">Belum ada data mata pelajaran</td></tr>
                    <?php else: ?>
                    <?php foreach ($mapel_list as $i => $m): ?>
                    <tr class="mapel-row" data-id="<?= $m['id'] ?>">
                        <td class="text-center align-middle">
                            <input type="checkbox" class="cb-mapel" value="<?= $m['id'] ?>" onchange="toggleMapelSelection(this)">
                        </td>
                        <td class="text-center align-middle"><?= $i + 1 ?></td>
                        <td class="align-middle font-weight-bold mapel-code"><?= htmlspecialchars($m['code']) ?></td>
                        <td class="align-middle mapel-name"><?= htmlspecialchars($m['name']) ?></td>
                        <td class="text-center align-middle text-nowrap">
                            <button class="btn btn-warning btn-sm" title="Edit" onclick="editMapel(<?= $m['id'] ?>, '<?= htmlspecialchars(addslashes($m['code'])) ?>', '<?= htmlspecialchars(addslashes($m['name'])) ?>')"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-danger btn-sm" title="Hapus" onclick="deleteMapel(<?= $m['id'] ?>, '<?= htmlspecialchars(addslashes($m['name'])) ?>')"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Mata Pelajaran -->
    <div class="modal fade" id="modalAddMapel" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold">Tambah Mata Pelajaran</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Kode Mapel <span class="text-danger">*</span></label>
                            <input type="text" name="mapel_code" class="form-control" placeholder="Contoh: MAT, BIN, IPA" style="text-transform: uppercase;" required>
                            <small class="text-muted">Singkatan atau kode mata pelajaran (maksimal 20 karakter).</small>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Nama Mata Pelajaran <span class="text-danger">*</span></label>
                            <input type="text" name="mapel_name" class="form-control" placeholder="Contoh: Matematika, Bahasa Indonesia" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="add_mata_pelajaran" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Simpan Mata Pelajaran</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Mata Pelajaran -->
    <div class="modal fade" id="modalEditMapel" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit_mapel_id" id="edit_mapel_id">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold">Edit Mata Pelajaran</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Kode Mapel <span class="text-danger">*</span></label>
                            <input type="text" name="mapel_code" id="edit_mapel_code" class="form-control" style="text-transform: uppercase;" required>
                        </div>
                        <div class="form-group mb-3">
                            <label class="font-weight-bold">Nama Mata Pelajaran <span class="text-danger">*</span></label>
                            <input type="text" name="mapel_name" id="edit_mapel_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="edit_mata_pelajaran" class="btn btn-primary"><i class="fas fa-save mr-1"></i> Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Import Mata Pelajaran -->
    <div class="modal fade" id="modalImportMapel" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form id="form-import-mapel" onsubmit="importExcelMapel(event)">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold"><i class="fas fa-file-excel text-success mr-2"></i>Impor Mata Pelajaran (Excel)</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="file_mapel" class="font-weight-bold">Pilih File Excel (.xlsx / .xls)</label>
                            <input type="file" id="file_mapel" class="form-control-file" accept=".xlsx, .xls" required>
                            <small class="text-muted mt-2 d-block">
                                File Excel harus memiliki kolom: <strong>Kode Mapel</strong> dan <strong>Nama Mata Pelajaran</strong> di baris pertama.
                            </small>
                            <div class="mt-3">
                                <button type="button" class="btn btn-sm btn-outline-info" onclick="downloadTemplateMapel()">
                                    <i class="fas fa-download mr-1"></i> Download Format Template Excel (.xlsx)
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" id="btn-import-mapel" class="btn btn-success">
                            <i class="fas fa-upload mr-1"></i> Impor Mata Pelajaran
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const selectedMapelIds = new Set();

function toggleMapelSelection(cb) {
    const id = parseInt(cb.value);
    if (cb.checked) {
        selectedMapelIds.add(id);
    } else {
        selectedMapelIds.delete(id);
    }
    updateMapelBulkUI();
}

function toggleAllMapel(cbAll) {
    const isChecked = cbAll.checked;
    const visibleRows = document.querySelectorAll('#tbody-mapel tr.mapel-row:not([style*="display: none"])');
    visibleRows.forEach(row => {
        const cb = row.querySelector('.cb-mapel');
        if (cb) {
            cb.checked = isChecked;
            const id = parseInt(cb.value);
            if (isChecked) {
                selectedMapelIds.add(id);
            } else {
                selectedMapelIds.delete(id);
            }
        }
    });
    updateMapelBulkUI();
}

function updateMapelBulkUI() {
    const countEl = document.getElementById('selected-mapel-count');
    const btnBulk = document.getElementById('btn-bulk-delete-mapel');
    const cbAll = document.getElementById('cb-all-mapel');
    
    if (countEl) countEl.textContent = selectedMapelIds.size;
    if (btnBulk) {
        btnBulk.style.display = selectedMapelIds.size > 0 ? 'inline-block' : 'none';
    }
    
    const visibleRows = document.querySelectorAll('#tbody-mapel tr.mapel-row:not([style*="display: none"])');
    if (visibleRows.length === 0) {
        if (cbAll) cbAll.checked = false;
        return;
    }
    let allSelected = true;
    visibleRows.forEach(row => {
        const cb = row.querySelector('.cb-mapel');
        if (cb && !selectedMapelIds.has(parseInt(cb.value))) {
            allSelected = false;
        }
    });
    if (cbAll) cbAll.checked = allSelected;
}

async function bulkDeleteMapel() {
    if (selectedMapelIds.size === 0) {
        Swal.fire('Oops', 'Pilih minimal satu mata pelajaran untuk dihapus.', 'warning');
        return;
    }
    
    const result = await Swal.fire({
        title: 'Hapus Mata Pelajaran Terpilih?',
        text: `Yakin ingin menghapus ${selectedMapelIds.size} mata pelajaran terpilih secara permanen?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus Semua',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33'
    });

    if (result.isConfirmed) {
        const ids = Array.from(selectedMapelIds);
        Swal.fire({ title: 'Menghapus...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        
        try {
            const fd = new FormData();
            fd.append('action', 'bulk_delete_mata_pelajaran');
            fd.append('ids', JSON.stringify(ids));
            
            const response = await fetch('api.php', { method: 'POST', body: fd });
            const res = await response.json();
            
            if (res.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: res.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => location.reload());
            } else {
                Swal.fire('Gagal', res.message || 'Gagal menghapus mata pelajaran.', 'error');
            }
        } catch(e) {
            Swal.fire('Error', 'Gagal memproses bulk delete mata pelajaran.', 'error');
        }
    }
}

function editMapel(id, code, name) {
    document.getElementById('edit_mapel_id').value = id;
    document.getElementById('edit_mapel_code').value = code;
    document.getElementById('edit_mapel_name').value = name;
    $('#modalEditMapel').modal('show');
}

async function deleteMapel(id, name) {
    const result = await Swal.fire({
        title: 'Hapus Mata Pelajaran?',
        text: `Yakin ingin menghapus mata pelajaran "${name}"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33'
    });

    if (result.isConfirmed) {
        const formData = new FormData();
        formData.append('action', 'delete_mata_pelajaran');
        formData.append('id', id);

        try {
            const response = await fetch('api.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            if (data.status === 'success') {
                Swal.fire('Berhasil!', data.message, 'success').then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Gagal!', data.message, 'error');
            }
        } catch (error) {
            Swal.fire('Error!', 'Terjadi kesalahan sistem.', 'error');
        }
    }
}

function filterMapelTable() {
    const query = document.getElementById('search-mapel').value.toLowerCase();
    const rows = document.querySelectorAll('.mapel-row');
    rows.forEach(r => {
        const code = r.querySelector('.mapel-code') ? r.querySelector('.mapel-code').textContent.toLowerCase() : '';
        const name = r.querySelector('.mapel-name') ? r.querySelector('.mapel-name').textContent.toLowerCase() : '';
        if (code.includes(query) || name.includes(query)) {
            r.style.display = '';
        } else {
            r.style.display = 'none';
        }
    });
    updateMapelBulkUI();
}

function downloadTemplateMapel() {
    if (typeof XLSX === 'undefined') {
        Swal.fire('Error', 'Pustaka Excel (SheetJS) belum termuat. Silakan muat ulang halaman.', 'error');
        return;
    }

    const templateData = [
        ['Kode Mapel', 'Nama Mata Pelajaran'],
        ['MAT', 'Matematika'],
        ['BIN', 'Bahasa Indonesia'],
        ['BIG', 'Bahasa Inggris'],
        ['IPA', 'Ilmu Pengetahuan Alam (IPA)'],
        ['IPS', 'Ilmu Pengetahuan Sosial (IPS)'],
        ['INF', 'Informatika'],
        ['PAI', 'Pendidikan Agama Islam'],
        ['PPKN', 'Pendidikan Pancasila dan Kewarganegaraan'],
        ['PJOK', 'Pendidikan Jasmani, Olahraga, dan Kesehatan'],
        ['SBK', 'Seni Budaya dan Keterampilan']
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(templateData);

    worksheet['!cols'] = [
        { wch: 16 }, // Kode Mapel
        { wch: 45 }  // Nama Mata Pelajaran
    ];

    // Styling: Header kuning (#FFFF00) & thin border
    const borderThin = {
        top: { style: 'thin', color: { rgb: '000000' } },
        bottom: { style: 'thin', color: { rgb: '000000' } },
        left: { style: 'thin', color: { rgb: '000000' } },
        right: { style: 'thin', color: { rgb: '000000' } }
    };

    const headerStyle = {
        fill: { fgColor: { rgb: 'FFFF00' } },
        font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
        alignment: { vertical: 'center', horizontal: 'center' },
        border: borderThin
    };

    const bodyStyleCenter = {
        font: { name: 'Calibri', sz: 11 },
        alignment: { vertical: 'center', horizontal: 'center' },
        border: borderThin
    };

    const bodyStyleLeft = {
        font: { name: 'Calibri', sz: 11 },
        alignment: { vertical: 'center', horizontal: 'left' },
        border: borderThin
    };

    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let R = range.s.r; R <= range.e.r; ++R) {
        for (let C = range.s.c; C <= range.e.c; ++C) {
            const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
            if (!worksheet[cell_address]) {
                worksheet[cell_address] = { t: 's', v: '' };
            }
            if (R === 0) {
                worksheet[cell_address].s = headerStyle;
            } else {
                worksheet[cell_address].s = (C === 0) ? bodyStyleCenter : bodyStyleLeft;
            }
        }
    }

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Template Mapel");
    XLSX.writeFile(workbook, "Template_Import_Mata_Pelajaran.xlsx", { compression: true });
}

async function importExcelMapel(e) {
    e.preventDefault();
    const fileInput = document.getElementById('file_mapel');
    if (!fileInput.files.length) {
        Swal.fire('Peringatan', 'Silakan pilih file Excel terlebih dahulu.', 'warning');
        return;
    }

    const btn = document.getElementById('btn-import-mapel');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Memproses...';
    btn.disabled = true;

    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = async function(evt) {
        try {
            const data = new Uint8Array(evt.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const json = XLSX.utils.sheet_to_json(worksheet);

            let mapelData = [];
            json.forEach(row => {
                let code = row['Kode Mapel'] || row['Kode'] || row['Code'] || row['kode_mapel'] || '';
                let name = row['Nama Mata Pelajaran'] || row['Nama Mapel'] || row['Mata Pelajaran'] || row['Nama'] || row['Name'] || Object.values(row)[1] || Object.values(row)[0] || '';

                if (typeof code === 'string' && code.length > 20 && !name) {
                    name = code;
                    code = '';
                }

                if (name && typeof name === 'string' && name.trim().length > 0) {
                    mapelData.push({
                        code: (code + '').trim().toUpperCase(),
                        name: (name + '').trim()
                    });
                }
            });

            if (mapelData.length === 0) {
                Swal.fire('Format Salah', 'Tidak ada data mata pelajaran yang valid. Pastikan kolom "Nama Mata Pelajaran" atau "Kode Mapel" terisi.', 'error');
                resetBtn();
                return;
            }

            const formData = new FormData();
            formData.append('action', 'import_mapel_batch');
            formData.append('mapels', JSON.stringify(mapelData));

            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();

            if (res.status === 'success') {
                $('#modalImportMapel').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: res.message,
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Gagal', res.message || 'Gagal mengimpor mata pelajaran.', 'error');
            }
        } catch(err) {
            console.error(err);
            Swal.fire('Error', 'Gagal memproses file Excel: ' + err.message, 'error');
        } finally {
            resetBtn();
        }
    };

    function resetBtn() {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }

    reader.readAsArrayBuffer(file);
}
</script>
