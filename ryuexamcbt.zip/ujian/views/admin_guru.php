<div id="section-guru" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
            <h3 class="card-title">Daftar Akun Guru</h3>
            <div class="ml-auto d-flex align-items-center flex-wrap">
                <input type="text" id="search-guru-input" class="form-control form-control-sm mr-2 mb-1" placeholder="Cari nama / mapel..." style="width: 200px; display: inline-block;" oninput="filterGuruTable()">
                <button id="btn-bulk-delete-guru" class="btn btn-danger btn-sm mr-2 mb-1" style="display: none;" onclick="bulkDeleteGuru()">
                    <i class="fas fa-trash mr-1"></i> Hapus Terpilih (<span id="selected-guru-count">0</span>)
                </button>
                <button class="btn btn-success btn-sm mr-2 mb-1" data-toggle="modal" data-target="#modalImportGuru">
                    <i class="fas fa-file-excel mr-1"></i> Impor Excel
                </button>
                <button class="btn btn-success btn-sm mr-2 mb-1" onclick="exportExcelGuru()" title="Ekspor Data Guru ke Excel (.xlsx)">
                    <i class="fas fa-file-export mr-1"></i> Ekspor Excel
                </button>
                <button class="btn btn-primary btn-sm mb-1" data-toggle="modal" data-target="#modalAddGuru">
                    <i class="fas fa-plus mr-1"></i> Tambah Guru
                </button>
            </div>
        </div>
        <div class="card-body p-0 table-responsive">
            <table class="table table-striped table-bordered mb-0" id="table-guru">
                <thead>
                    <tr>
                        <th style="width: 40px" class="text-center"><input type="checkbox" id="cb-all-guru" onchange="toggleAllGuru(this)" title="Pilih Semua"></th>
                        <th style="width: 50px" class="text-center">No</th>
                        <th>Nama Guru</th>
                        <th style="width: 160px">Username</th>
                        <th style="width: 160px">Password</th>
                        <th style="width: 180px" class="text-center">Mata Pelajaran</th>
                        <th style="width: 170px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody id="guru-table-body">
                    <?php 
                    $users = get_users();
                    $guruList = array_filter($users, function($u) { return ($u['role'] ?? 'guru') === 'guru'; });
                    $i = 1;
                    foreach ($guruList as $g): 
                    ?>
                    <tr class="guru-row" data-id="<?= $g['id'] ?>">
                        <td class="text-center align-middle">
                            <input type="checkbox" class="cb-guru" value="<?= $g['id'] ?>" onchange="toggleGuruSelection(this)">
                        </td>
                        <td class="text-center align-middle font-weight-bold"><?= $i++ ?></td>
                        <td class="align-middle"><strong><?= htmlspecialchars($g['name']) ?></strong></td>
                        <td class="align-middle"><code><?= htmlspecialchars($g['username']) ?></code></td>
                        <td class="align-middle">
                            <span class="text-muted" style="font-family: monospace;"><?= htmlspecialchars($g['password']) ?></span>
                        </td>
                        <td class="text-center align-middle">
                            <span class="badge badge-info" style="font-size: 0.85rem; padding: 5px 10px;"><?= htmlspecialchars($g['mapel'] ?? '-') ?></span>
                        </td>
                        <td class="text-center align-middle text-nowrap">
                            <button class="btn btn-warning btn-sm mr-1" onclick="editGuru(<?= $g['id'] ?>, '<?= htmlspecialchars(addslashes($g['name'])) ?>', '<?= htmlspecialchars(addslashes($g['username'])) ?>', '<?= htmlspecialchars(addslashes($g['password'])) ?>', '<?= htmlspecialchars(addslashes($g['mapel'] ?? '')) ?>')">
                                <i class="fas fa-edit mr-1"></i> Edit
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteGuru(<?= $g['id'] ?>, '<?= htmlspecialchars(addslashes($g['name'])) ?>')">
                                <i class="fas fa-trash mr-1"></i> Hapus
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($guruList)): ?>
                        <tr id="row-empty-guru"><td colspan="7" class="text-center py-3 text-muted">Belum ada akun guru terdaftar</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Add Guru -->
    <div class="modal fade" id="modalAddGuru" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-user-plus mr-2 text-primary"></i> Tambah Akun Guru</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label>Nama Lengkap & Gelar</label>
                            <input type="text" name="guru_name" class="form-control" placeholder="Contoh: Ahmad Fauzi, S.Pd" required>
                        </div>
                        <div class="form-group mb-3">
                            <label>Username</label>
                            <input type="text" name="guru_username" class="form-control" placeholder="Contoh: guru_ahmad" required>
                            <small class="form-text text-muted">Digunakan untuk login ke panel guru.</small>
                        </div>
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <input type="text" name="guru_password" class="form-control" placeholder="Password untuk guru" required>
                        </div>
                        <div class="form-group mb-3">
                            <label>Mata Pelajaran (Opsional)</label>
                            <input type="text" name="guru_mapel" class="form-control" placeholder="Contoh: Matematika / Informatika">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="add_guru" class="btn btn-primary">Simpan Akun Guru</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Guru -->
    <div class="modal fade" id="modalEditGuru" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit_guru_id" id="edit_guru_id">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-user-edit mr-2 text-warning"></i> Edit Akun Guru</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label>Nama Lengkap & Gelar</label>
                            <input type="text" name="guru_name" id="edit_guru_name" class="form-control" required>
                        </div>
                        <div class="form-group mb-3">
                            <label>Username</label>
                            <input type="text" name="guru_username" id="edit_guru_username" class="form-control" required>
                        </div>
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <input type="text" name="guru_password" id="edit_guru_password" class="form-control" required>
                        </div>
                        <div class="form-group mb-3">
                            <label>Mata Pelajaran (Opsional)</label>
                            <input type="text" name="guru_mapel" id="edit_guru_mapel" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="edit_guru" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Import Guru -->
    <div class="modal fade" id="modalImportGuru" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form id="form-import-guru" onsubmit="importExcelGuru(event)">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-file-excel text-success mr-2"></i> Impor Data Guru (Excel)</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="file_guru">Pilih File Excel (.xlsx / .xls)</label>
                            <input type="file" id="file_guru" class="form-control-file" accept=".xlsx, .xls" required>
                            <small class="text-muted mt-2 d-block">
                                File Excel harus memiliki kolom: <strong>Nama Guru</strong>, <strong>Username</strong>, <strong>Password</strong>, dan <strong>Mata Pelajaran</strong> di baris pertama.
                            </small>
                            <div class="mt-3">
                                <button type="button" class="btn btn-sm btn-outline-info" onclick="downloadTemplateGuru()">
                                    <i class="fas fa-download mr-1"></i> Download Format Template Excel
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" id="btn-import-guru" class="btn btn-success">
                            <i class="fas fa-upload mr-1"></i> Impor Akun Guru
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const rawGuruData = <?= json_encode(array_values(array_map(function($g) {
    return [
        'id' => (int)$g['id'],
        'name' => $g['name'] ?? '',
        'username' => $g['username'] ?? '',
        'password' => $g['password'] ?? '',
        'mapel' => $g['mapel'] ?? '-'
    ];
}, $guruList))) ?>;
const schoolNameGuruExport = <?= json_encode(!empty($settings['school_name']) ? $settings['school_name'] : 'CBT') ?>;

function editGuru(id, name, username, password, mapel) {
    document.getElementById('edit_guru_id').value = id;
    document.getElementById('edit_guru_name').value = name;
    document.getElementById('edit_guru_username').value = username;
    document.getElementById('edit_guru_password').value = password;
    document.getElementById('edit_guru_mapel').value = mapel;
    $('#modalEditGuru').modal('show');
}

async function deleteGuru(id, name) {
    const result = await Swal.fire({
        title: 'Hapus Akun Guru?',
        text: `Yakin ingin menghapus akun guru "${name}"? Guru ini tidak akan bisa login lagi ke sistem.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33'
    });

    if (result.isConfirmed) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'admin.php?page=guru';
        
        const inputAction = document.createElement('input');
        inputAction.type = 'hidden';
        inputAction.name = 'delete_guru';
        inputAction.value = '1';
        form.appendChild(inputAction);

        const inputId = document.createElement('input');
        inputId.type = 'hidden';
        inputId.name = 'guru_id';
        inputId.value = id;
        form.appendChild(inputId);

        document.body.appendChild(form);
        form.submit();
    }
}

function downloadTemplateGuru() {
    const templateData = [
        {
            "Nama Guru": "Budi Raharjo, S.Pd",
            "Username": "budi_guru",
            "Password": "guru123",
            "Mata Pelajaran": "Matematika"
        },
        {
            "Nama Guru": "Siti Aminah, M.Pd",
            "Username": "siti_guru",
            "Password": "guru123",
            "Mata Pelajaran": "Bahasa Indonesia"
        },
        {
            "Nama Guru": "Dedi Kurniawan, S.Kom",
            "Username": "dedi_guru",
            "Password": "guru123",
            "Mata Pelajaran": "Informatika"
        }
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    worksheet['!cols'] = [
        { wch: 26 },
        { wch: 18 },
        { wch: 15 },
        { wch: 22 }
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Template Guru");
    XLSX.writeFile(workbook, "Template_Import_Guru.xlsx", { compression: true });
}

async function importExcelGuru(e) {
    e.preventDefault();
    const fileInput = document.getElementById('file_guru');
    if (!fileInput.files.length) {
        Swal.fire('Peringatan', 'Pilih file Excel terlebih dahulu.', 'warning');
        return;
    }

    const btn = document.getElementById('btn-import-guru');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Memproses...';
    btn.disabled = true;

    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = async function(evt) {
        try {
            const data = new Uint8Array(evt.target.result);
            const workbook = XLSX.read(data, {type: 'array'});
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const json = XLSX.utils.sheet_to_json(worksheet);

            let guruData = [];
            json.forEach(row => {
                let name = row['Nama Guru'] || row['Nama'] || row['Name'] || row['nama_guru'] || Object.values(row)[0];
                let username = row['Username'] || row['NIP'] || row['User'] || row['username'] || Object.values(row)[1];
                let password = row['Password'] || row['Sandi'] || row['password'] || Object.values(row)[2] || 'guru123';
                let mapel = row['Mata Pelajaran'] || row['Mapel'] || row['Pelajaran'] || row['mapel'] || Object.values(row)[3] || '';

                if (name && username) {
                    guruData.push({
                        name: (name + '').trim(),
                        username: (username + '').trim(),
                        password: (password + '').trim(),
                        mapel: (mapel + '').trim()
                    });
                }
            });

            if (guruData.length === 0) {
                Swal.fire('Format Salah', 'Tidak ada data guru yang valid. Pastikan kolom "Nama Guru" dan "Username" terisi.', 'error');
                resetBtn();
                return;
            }

            const formData = new FormData();
            formData.append('action', 'import_guru_batch');
            formData.append('gurus', JSON.stringify(guruData));

            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();

            if (res.status === 'success') {
                $('#modalImportGuru').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: res.message,
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    location.reload();
                });
            } else {
                Swal.fire('Gagal', res.message || 'Gagal mengimpor akun guru.', 'error');
            }
        } catch(err) {
            console.error(err);
            Swal.fire('Error', 'Gagal memproses file Excel: ' + err.message, 'error');
        } finally {
            resetBtn();
        }
    };

    function resetBtn() {
        btn.innerHTML = '<i class="fas fa-upload mr-1"></i> Impor Akun Guru';
        btn.disabled = false;
    }

    reader.readAsArrayBuffer(file);
}

const selectedGuruIds = new Set();

function toggleGuruSelection(cb) {
    const id = parseInt(cb.value);
    if (cb.checked) {
        selectedGuruIds.add(id);
    } else {
        selectedGuruIds.delete(id);
    }
    updateGuruBulkUI();
}

function toggleAllGuru(cbAll) {
    const isChecked = cbAll.checked;
    const visibleRows = document.querySelectorAll('#guru-table-body tr.guru-row:not([style*="display: none"])');
    visibleRows.forEach(row => {
        const cb = row.querySelector('.cb-guru');
        if (cb) {
            cb.checked = isChecked;
            const id = parseInt(cb.value);
            if (isChecked) {
                selectedGuruIds.add(id);
            } else {
                selectedGuruIds.delete(id);
            }
        }
    });
    updateGuruBulkUI();
}

function updateGuruBulkUI() {
    const countEl = document.getElementById('selected-guru-count');
    const btnBulk = document.getElementById('btn-bulk-delete-guru');
    const cbAll = document.getElementById('cb-all-guru');
    
    if (countEl) countEl.textContent = selectedGuruIds.size;
    if (btnBulk) {
        btnBulk.style.display = selectedGuruIds.size > 0 ? 'inline-block' : 'none';
    }
    
    const visibleRows = document.querySelectorAll('#guru-table-body tr.guru-row:not([style*="display: none"])');
    if (visibleRows.length === 0) {
        if (cbAll) cbAll.checked = false;
        return;
    }
    let allSelected = true;
    visibleRows.forEach(row => {
        const cb = row.querySelector('.cb-guru');
        if (cb && !selectedGuruIds.has(parseInt(cb.value))) {
            allSelected = false;
        }
    });
    if (cbAll) cbAll.checked = allSelected;
}

async function bulkDeleteGuru() {
    if (selectedGuruIds.size === 0) {
        Swal.fire('Oops', 'Pilih minimal satu akun guru untuk dihapus.', 'warning');
        return;
    }
    
    const result = await Swal.fire({
        title: 'Hapus Terpilih?',
        text: `Yakin ingin menghapus ${selectedGuruIds.size} akun guru terpilih secara permanen? Guru yang dihapus tidak akan dapat login lagi.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus Semua',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#d33'
    });

    if (result.isConfirmed) {
        const ids = Array.from(selectedGuruIds);
        Swal.fire({ title: 'Menghapus...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        
        try {
            const fd = new FormData();
            fd.append('action', 'bulk_delete_guru');
            fd.append('ids', JSON.stringify(ids));
            
            const response = await fetch('api.php', { method: 'POST', body: fd });
            const res = await response.json();
            
            if (res.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: res.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => location.reload());
            } else {
                Swal.fire('Gagal', res.message || 'Gagal menghapus akun guru.', 'error');
            }
        } catch(e) {
            Swal.fire('Error', 'Gagal memproses bulk delete guru.', 'error');
        }
    }
}

function filterGuruTable() {
    const q = (document.getElementById('search-guru-input').value || '').toLowerCase();
    const rows = document.querySelectorAll('#guru-table-body tr.guru-row');
    rows.forEach(r => {
        const text = r.textContent.toLowerCase();
        r.style.display = text.includes(q) ? '' : 'none';
    });
    updateGuruBulkUI();
}

async function exportExcelGuru() {
    if (typeof XLSX === 'undefined') {
        Swal.fire('Error', 'Pustaka Excel (SheetJS) belum termuat. Silakan muat ulang halaman.', 'error');
        return;
    }

    if (!rawGuruData || rawGuruData.length === 0) {
        Swal.fire('Informasi', 'Belum ada data guru untuk diekspor.', 'info');
        return;
    }

    let targetGuru = rawGuruData;
    let exportTypeDesc = 'Semua';

    if (selectedGuruIds && selectedGuruIds.size > 0) {
        const result = await Swal.fire({
            title: 'Ekspor Data Guru (.xlsx)',
            text: `Terdapat ${selectedGuruIds.size} akun guru terpilih. Pilih data yang ingin diekspor:`,
            icon: 'question',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: `<i class="fas fa-check-square mr-1"></i> Guru Terpilih (${selectedGuruIds.size})`,
            denyButtonText: `<i class="fas fa-users mr-1"></i> Semua Guru (${rawGuruData.length})`,
            cancelButtonText: 'Batal',
            confirmButtonColor: '#28a745',
            denyButtonColor: '#17a2b8'
        });

        if (result.isConfirmed) {
            targetGuru = rawGuruData.filter(g => selectedGuruIds.has(g.id));
            exportTypeDesc = 'Terpilih';
        } else if (result.isDenied) {
            targetGuru = rawGuruData;
            exportTypeDesc = 'Semua';
        } else {
            return;
        }
    } else {
        const q = (document.getElementById('search-guru-input')?.value || '').trim().toLowerCase();
        if (q) {
            const matchedGuru = rawGuruData.filter(g => {
                const name = (g.name || '').toLowerCase();
                const usr = (g.username || '').toLowerCase();
                const mpl = (g.mapel || '').toLowerCase();
                return name.includes(q) || usr.includes(q) || mpl.includes(q);
            });

            if (matchedGuru.length > 0 && matchedGuru.length < rawGuruData.length) {
                const result = await Swal.fire({
                    title: 'Ekspor Data Guru (.xlsx)',
                    text: `Pencarian aktif menemukan ${matchedGuru.length} guru. Pilih data yang ingin diekspor:`,
                    icon: 'question',
                    showCancelButton: true,
                    showDenyButton: true,
                    confirmButtonText: `<i class="fas fa-filter mr-1"></i> Hasil Filter (${matchedGuru.length})`,
                    denyButtonText: `<i class="fas fa-users mr-1"></i> Semua Guru (${rawGuruData.length})`,
                    cancelButtonText: 'Batal',
                    confirmButtonColor: '#28a745',
                    denyButtonColor: '#17a2b8'
                });

                if (result.isConfirmed) {
                    targetGuru = matchedGuru;
                    exportTypeDesc = 'Filter';
                } else if (result.isDenied) {
                    targetGuru = rawGuruData;
                    exportTypeDesc = 'Semua';
                } else {
                    return;
                }
            }
        }
    }

    // Build worksheet AOA
    const sheetData = [
        ['No', 'ID Guru', 'Nama Guru', 'Username', 'Password', 'Mata Pelajaran']
    ];

    targetGuru.forEach((g, idx) => {
        sheetData.push([
            idx + 1,
            g.id,
            g.name || '',
            g.username || '',
            g.password !== undefined && g.password !== null ? String(g.password) : '',
            g.mapel || '-'
        ]);
    });

    const worksheet = XLSX.utils.aoa_to_sheet(sheetData);

    // Column widths
    worksheet['!cols'] = [
        { wch: 6 },  // No
        { wch: 10 }, // ID Guru
        { wch: 30 }, // Nama Guru
        { wch: 20 }, // Username
        { wch: 18 }, // Password
        { wch: 25 }  // Mata Pelajaran
    ];

    // Styles: Header kuning (#FFFF00) & thin border
    const borderThin = {
        top: { style: 'thin', color: { rgb: '000000' } },
        bottom: { style: 'thin', color: { rgb: '000000' } },
        left: { style: 'thin', color: { rgb: '000000' } },
        right: { style: 'thin', color: { rgb: '000000' } }
    };

    const headerStyle = {
        fill: { fgColor: { rgb: 'FFFF00' } },
        font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
        alignment: { vertical: 'center', horizontal: 'center' },
        border: borderThin
    };

    const bodyStyleCenter = {
        font: { name: 'Calibri', sz: 11 },
        alignment: { vertical: 'center', horizontal: 'center' },
        border: borderThin
    };

    const bodyStyleLeft = {
        font: { name: 'Calibri', sz: 11 },
        alignment: { vertical: 'center', horizontal: 'left' },
        border: borderThin
    };

    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let R = range.s.r; R <= range.e.r; ++R) {
        for (let C = range.s.c; C <= range.e.c; ++C) {
            const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
            if (!worksheet[cell_address]) {
                worksheet[cell_address] = { t: 's', v: '' };
            }
            if (R === 0) {
                worksheet[cell_address].s = headerStyle;
            } else {
                // Ensure text formatting for Username & Password to preserve leading zeroes
                if (C === 3 || C === 4) {
                    worksheet[cell_address].t = 's';
                }
                // Nama Guru (C === 2) is left-aligned, others centered
                worksheet[cell_address].s = (C === 2) ? bodyStyleLeft : bodyStyleCenter;
            }
        }
    }

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Data Guru");

    const cleanSchool = (schoolNameGuruExport || 'CBT').trim().replace(/[\s\/\\]+/g, '_').replace(/[^a-zA-Z0-9_.-]/g, '');
    const dateStr = new Date().toISOString().split('T')[0];

    let fileName = `Data_Guru_${cleanSchool}_${dateStr}.xlsx`;
    if (exportTypeDesc !== 'Semua') {
        fileName = `Data_Guru_${exportTypeDesc}_${cleanSchool}_${dateStr}.xlsx`;
    }

    XLSX.writeFile(workbook, fileName, { compression: true });

    Swal.fire({
        title: 'Berhasil!',
        text: `Data ${targetGuru.length} akun guru berhasil diekspor ke Excel (${fileName}).`,
        icon: 'success',
        timer: 2000,
        showConfirmButton: false
    });
}
</script>
