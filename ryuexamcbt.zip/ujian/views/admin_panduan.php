<?php
// views/admin_panduan.php - Dokumentasi & Petunjuk Teknis Pembuatan Bank Soal CBT
?>
<style>
/* ========================================================
   DOKUMENTASI CBT - CLEAN & MODERN DESIGN SYSTEM
   ======================================================== */
:root {
    --doc-primary: #2563eb;
    --doc-primary-light: #eff6ff;
    --doc-border: #e2e8f0;
    --doc-card-bg: #ffffff;
    --doc-subcard-bg: #f8fafc;
    --doc-text-dark: #1e293b;
    --doc-text-muted: #64748b;
}

html {
    scroll-behavior: smooth;
}

/* Breadcrumb & Hero Header */
.doc-header-card {
    background: #ffffff;
    border: 1px solid var(--doc-border);
    border-radius: 12px;
    padding: 24px 28px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
}

.doc-breadcrumb {
    font-size: 0.84rem;
    color: var(--doc-text-muted);
    margin-bottom: 8px;
}
.doc-breadcrumb a {
    color: var(--doc-primary);
    text-decoration: none;
}
.doc-breadcrumb a:hover {
    text-decoration: underline;
}

/* Quick Search Box */
.doc-search-box {
    position: relative;
    max-width: 380px;
    width: 100%;
}
.doc-search-box input {
    border-radius: 20px;
    padding-left: 38px;
    font-size: 0.88rem;
    border: 1px solid #cbd5e1;
    transition: all 0.2s ease;
}
.doc-search-box input:focus {
    border-color: var(--doc-primary);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}
.doc-search-box .search-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    font-size: 0.88rem;
}

/* Sticky Sidebar Table of Contents */
.doc-toc-wrapper {
    position: sticky;
    top: 20px;
    z-index: 10;
}
.doc-toc-card {
    background: #ffffff;
    border: 1px solid var(--doc-border);
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}
.doc-toc-title {
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    font-weight: 700;
    color: #64748b;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.doc-toc-nav {
    list-style: none;
    padding-left: 0;
    margin-bottom: 0;
}
.doc-toc-item {
    margin-bottom: 2px;
}
.doc-toc-link {
    display: flex;
    align-items: center;
    padding: 7px 12px;
    border-radius: 6px;
    font-size: 0.86rem;
    color: #475569;
    text-decoration: none;
    transition: all 0.15s ease;
    border-left: 3px solid transparent;
}
.doc-toc-link:hover {
    color: var(--doc-primary);
    background: var(--doc-primary-light);
    text-decoration: none;
}
.doc-toc-link.active {
    color: var(--doc-primary);
    background: var(--doc-primary-light);
    border-left-color: var(--doc-primary);
    font-weight: 600;
}
.doc-toc-link i {
    width: 20px;
    font-size: 0.88rem;
    margin-right: 8px;
}

/* Documentation Content Sections */
.doc-section-card {
    background: #ffffff;
    border: 1px solid var(--doc-border);
    border-radius: 12px;
    padding: 26px 28px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
    scroll-margin-top: 24px;
}
.doc-section-title {
    font-size: 1.18rem;
    font-weight: 700;
    color: var(--doc-text-dark);
    margin-bottom: 4px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
}
.doc-section-desc {
    color: var(--doc-text-muted);
    font-size: 0.92rem;
    line-height: 1.6;
    margin-bottom: 20px;
}

/* Steps Grid */
.doc-step-box {
    background: var(--doc-subcard-bg);
    border: 1px solid var(--doc-border);
    border-radius: 10px;
    padding: 18px 20px;
    height: 100%;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.doc-step-box:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.04);
}
.doc-step-number {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    border-radius: 8px;
    background: #ffffff;
    border: 1px solid var(--doc-border);
    font-weight: 700;
    font-size: 0.92rem;
    box-shadow: 0 1px 2px rgba(0,0,0,0.04);
    margin-right: 10px;
}

/* Documentation Tables */
.doc-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.88rem;
}
.doc-table th {
    background-color: var(--doc-subcard-bg);
    border: 1px solid var(--doc-border);
    padding: 10px 14px;
    color: #475569;
    font-weight: 600;
}
.doc-table td {
    border: 1px solid var(--doc-border);
    padding: 10px 14px;
    vertical-align: middle;
}

/* Prompt Box / Code Highlight */
.doc-code-block {
    background: #0f172a;
    color: #e2e8f0;
    border-radius: 8px;
    padding: 14px 16px;
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 0.84rem;
    line-height: 1.6;
    position: relative;
    overflow-x: auto;
}
.doc-code-copy-btn {
    position: absolute;
    top: 8px;
    right: 8px;
    padding: 3px 8px;
    font-size: 0.75rem;
    border-radius: 4px;
    background: rgba(255,255,255,0.15);
    color: #ffffff;
    border: none;
    cursor: pointer;
    transition: background 0.15s ease;
}
.doc-code-copy-btn:hover {
    background: rgba(255,255,255,0.3);
}

/* Floating Back to Top Button */
#btn-doc-top {
    position: fixed;
    bottom: 72px;
    right: 28px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: #ffffff;
    color: var(--doc-primary);
    border: 1px solid #cbd5e1;
    box-shadow: 0 4px 14px rgba(0,0,0,0.12);
    display: none;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 1045;
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}
#btn-doc-top:hover {
    background: var(--doc-primary);
    color: #ffffff;
    border-color: var(--doc-primary);
    transform: translateY(-4px);
}

/* Callout Note */
.doc-callout {
    border-radius: 8px;
    padding: 14px 18px;
    font-size: 0.88rem;
    line-height: 1.6;
    margin-top: 14px;
    margin-bottom: 14px;
}
.doc-callout-warning {
    background: #fffbe6;
    border: 1px solid #ffe58f;
    border-left: 4px solid #fa8c16;
}
.doc-callout-info {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-left: 4px solid #22c55e;
}
</style>

<div class="container-fluid px-2 pt-2">
    
    <!-- ======================================================== -->
    <!-- 1. HEADER DOKUMENTASI & PENCARIAN CEPAT -->
    <!-- ======================================================== -->
    <div class="doc-header-card">
        <div class="doc-breadcrumb">
            <a href="admin.php"><i class="fas fa-home mr-1"></i> Dashboard</a>
            <span class="mx-1">/</span>
            <a href="admin.php?page=soal">Bank Soal</a>
            <span class="mx-1">/</span>
            <span class="text-dark font-weight-bold">Dokumentasi &amp; Panduan</span>
        </div>
        
        <div class="d-flex flex-wrap align-items-center justify-content-between pt-1" style="gap: 16px;">
            <div>
                <h3 class="font-weight-bold text-dark mb-1">
                    <i class="fas fa-book-reader text-primary mr-2"></i>Panduan &amp; Dokumentasi Bank Soal CBT
                </h3>
                <p class="text-muted mb-0" style="font-size: 0.93rem;">
                    Petunjuk teknis terpadu: penyusunan naskah Word (.docx), generator AI (JSON), penulisan rumus KaTeX, dan pembobotan nilai.
                </p>
            </div>
            
            <div class="d-flex align-items-center flex-wrap" style="gap: 10px;">
                <!-- Pencarian Cepat Dokumentasi -->
                <div class="doc-search-box">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="docSearchInput" class="form-control" placeholder="Cari topik, rumus, atau format..." onkeyup="filterDocSections(this.value)">
                </div>
                
                <a href="https://share.gemini.google/ReefFdC6lnEu" target="_blank" rel="noopener noreferrer" onclick="return openGeminiAiPopup(event)" class="btn btn-sm font-weight-bold px-3 text-white shadow-sm" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); border: none;" title="Buka Generator AI di Jendela Pop-up Mengambang">
                    <i class="fas fa-robot mr-1"></i> Buat via AI
                </a>
                <a href="admin.php?page=soal" class="btn btn-primary btn-sm font-weight-bold px-3 shadow-sm">
                    <i class="fas fa-folder-plus mr-1"></i> Buka Bank Soal
                </a>
            </div>
        </div>
    </div>

    <!-- ======================================================== -->
    <!-- 2. GRID UTAMA: SIDEBAR TOC (KIRI/KANAN) & KONTEN DOKS -->
    <!-- ======================================================== -->
    <div class="row">
        
        <!-- KOLOM DAFTAR ISI (TABLE OF CONTENTS) -->
        <div class="col-lg-3 col-xl-3 mb-4 order-lg-2">
            <div class="doc-toc-wrapper">
                <div class="doc-toc-card mb-3">
                    <div class="doc-toc-title">
                        <span><i class="fas fa-list-ul mr-1 text-primary"></i> Daftar Isi</span>
                        <span class="badge badge-light border text-muted">7 Bagian</span>
                    </div>
                    
                    <ul class="doc-toc-nav" id="docTocNav">
                        <li class="doc-toc-item">
                            <a href="#sec-alur-dasar" class="doc-toc-link active">
                                <i class="fas fa-tasks text-primary"></i> 1. Alur 4 Langkah Dasar
                            </a>
                        </li>
                        <li class="doc-toc-item">
                            <a href="#sec-soal-ai" class="doc-toc-link">
                                <i class="fas fa-robot text-purple" style="color: #7c3aed;"></i> 2. Buat Soal via AI (JSON)
                            </a>
                        </li>
                        <li class="doc-toc-item">
                            <a href="#sec-rumus-katex" class="doc-toc-link">
                                <i class="fas fa-square-root-alt text-info"></i> 3. Rumus LaTeX / KaTeX
                            </a>
                        </li>
                        <li class="doc-toc-item">
                            <a href="#sec-format-word" class="doc-toc-link">
                                <i class="fas fa-file-word text-success"></i> 4. Format Tabel Word (.docx)
                            </a>
                        </li>
                        <li class="doc-toc-item">
                            <a href="#sec-kunci-excel" class="doc-toc-link">
                                <i class="fas fa-file-excel text-warning"></i> 5. Kunci &amp; Nilai Excel
                            </a>
                        </li>
                        <li class="doc-toc-item">
                            <a href="#sec-tips-guru" class="doc-toc-link">
                                <i class="fas fa-lightbulb text-warning"></i> 6. Rekomendasi Guru
                            </a>
                        </li>
                        <li class="doc-toc-item">
                            <a href="#sec-faq" class="doc-toc-link">
                                <i class="fas fa-question-circle text-secondary"></i> 7. FAQ &amp; Tanya Jawab
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Widget Unduh Template Cepat -->
                <div class="doc-toc-card p-3 bg-light border">
                    <div class="font-weight-bold text-dark small mb-2">
                        <i class="fas fa-download mr-1 text-primary"></i> Akses Template Cepat:
                    </div>
                    <div class="d-grid gap-1">
                        <button class="btn btn-outline-secondary btn-xs btn-block text-left mb-1 py-1" onclick="promptTemplatePGBiasa()">
                            <i class="fas fa-file-word text-primary mr-1"></i> Template PG Biasa
                        </button>
                        <button class="btn btn-outline-secondary btn-xs btn-block text-left mb-1 py-1" onclick="promptTemplatePGKompleks()">
                            <i class="fas fa-check-square text-success mr-1"></i> Template PG Kompleks
                        </button>
                        <button class="btn btn-outline-secondary btn-xs btn-block text-left mb-1 py-1" onclick="downloadPanduanExcelKeyDirect(40, 'multiple_choice')">
                            <i class="fas fa-file-excel text-success mr-1"></i> Template Kunci (40 Soal)
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- KOLOM UTAMA KONTEN DOKUMENTASI -->
        <div class="col-lg-9 col-xl-9 order-lg-1">
            
            <!-- ======================================================== -->
            <!-- BAGIAN 1: ALUR 4 LANGKAH DASAR -->
            <!-- ======================================================== -->
            <section id="sec-alur-dasar" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h4 class="doc-section-title">
                        <i class="fas fa-tasks text-primary mr-2"></i>1. Alur 4 Langkah Standar Bank Soal
                    </h4>
                    <span class="badge badge-light border text-muted">Standar CBT</span>
                </div>
                <p class="doc-section-desc">
                    Alur sistematis untuk guru dalam mengelola bank soal, mulai dari pembuatan ruang ujian, penyiapan naskah, impor soal, hingga validasi kunci jawaban.
                </p>

                <div class="row">
                    <!-- Step 1 -->
                    <div class="col-md-6 mb-3">
                        <div class="doc-step-box">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-primary">1</span>
                                <h6 class="font-weight-bold text-dark mb-0">Buat Bank Soal</h6>
                            </div>
                            <p class="text-muted small mb-3" style="line-height: 1.6;">
                                Buka menu <b>Bank Soal</b> lalu klik tombol biru <b>+ Buat Bank Soal</b>. Tentukan nama bank soal (misal: <i>PAS Ganjil Matematika Kelas X</i>), mata pelajaran, dan jenjang kelas sasaran.
                            </p>
                            <a href="admin.php?page=soal" class="btn btn-outline-primary btn-xs font-weight-bold">
                                <i class="fas fa-plus mr-1"></i> Buat Bank Soal Sekarang
                            </a>
                        </div>
                    </div>

                    <!-- Step 2 -->
                    <div class="col-md-6 mb-3">
                        <div class="doc-step-box">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-success">2</span>
                                <h6 class="font-weight-bold text-dark mb-0">Siapkan Naskah Soal</h6>
                            </div>
                            <p class="text-muted small mb-3" style="line-height: 1.6;">
                                Anda dapat mengunduh <b>Template Word</b> yang telah disediakan, atau menggunakan <b>Generator AI</b> untuk membuat puluhan butir soal siap impor dalam format JSON.
                            </p>
                            <div class="dropdown d-inline-block">
                                <button class="btn btn-outline-success btn-xs font-weight-bold dropdown-toggle" type="button" data-toggle="dropdown">
                                    <i class="fas fa-file-word mr-1"></i> Pilih Template Word
                                </button>
                                <div class="dropdown-menu shadow">
                                    <a class="dropdown-item py-2" href="javascript:void(0)" onclick="promptTemplatePGBiasa()"><i class="fas fa-dot-circle text-primary mr-2"></i> 1. Pilihan Ganda (PG)</a>
                                    <a class="dropdown-item py-2" href="javascript:void(0)" onclick="promptTemplatePGKompleks()"><i class="fas fa-check-square text-success mr-2"></i> 2. PG Kompleks (Centang)</a>
                                    <a class="dropdown-item py-2" href="javascript:void(0)" onclick="promptTemplateBenarSalah()"><i class="fas fa-check-circle text-warning mr-2"></i> 3. Benar / Salah (Tabel)</a>
                                    <a class="dropdown-item py-2" href="javascript:void(0)" onclick="promptTemplateMenjodohkan()"><i class="fas fa-exchange-alt text-info mr-2"></i> 4. Menjodohkan (Pasangan)</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 3 -->
                    <div class="col-md-6 mb-3">
                        <div class="doc-step-box">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-info">3</span>
                                <h6 class="font-weight-bold text-dark mb-0">Impor Naskah ke Sistem</h6>
                            </div>
                            <p class="text-muted small mb-3" style="line-height: 1.6;">
                                Masuk ke <b>Kelola Soal &rarr; Impor Soal</b>. Unggah dokumen Word (format <b>.docx</b>) atau file <b>.json</b> dari AI. Sistem akan memproses seluruh butir pertanyaan, opsi, dan gambar secara otomatis.
                            </p>
                            <a href="admin.php?page=soal" class="btn btn-outline-info btn-xs font-weight-bold">
                                <i class="fas fa-upload mr-1"></i> Buka Menu Impor
                            </a>
                        </div>
                    </div>

                    <!-- Step 4 -->
                    <div class="col-md-6 mb-3">
                        <div class="doc-step-box">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-warning">4</span>
                                <h6 class="font-weight-bold text-dark mb-0">Kunci &amp; Pembobotan Nilai</h6>
                            </div>
                            <p class="text-muted small mb-3" style="line-height: 1.6;">
                                Periksa kunci jawaban. Klik <b>Set Poin</b> agar total nilai seluruh soal otomatis bernilai 100. Setelah selesai, klik tombol <b>Preview Siswa</b> untuk menguji tampilan pengerjaan.
                            </p>
                            <span class="badge badge-light border text-muted py-1 px-2 font-weight-normal">
                                <i class="fas fa-check text-success mr-1"></i> Siap diujikan ke siswa
                            </span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ======================================================== -->
            <!-- BAGIAN 2: BUAT SOAL VIA AI (GOOGLE GEMINI & JSON) -->
            <!-- ======================================================== -->
            <section id="sec-soal-ai" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between flex-wrap pb-2 mb-3 border-bottom" style="gap: 8px;">
                    <div>
                        <h4 class="doc-section-title">
                            <i class="fas fa-robot text-purple mr-2" style="color: #7c3aed;"></i>2. Pembuatan Soal via AI (Format JSON &amp; Impor Langsung)
                        </h4>
                        <span class="badge badge-light border font-weight-bold px-2 py-1" style="color: #6f42c1; border-color: #d8b4fe !important; background: #faf5ff;">
                            <i class="fas fa-bolt mr-1"></i> REKOMENDASI TERCEPAT
                        </span>
                    </div>
                    <a href="https://share.gemini.google/ReefFdC6lnEu" target="_blank" rel="noopener noreferrer" onclick="return openGeminiAiPopup(event)" class="btn btn-sm font-weight-bold px-3 text-white shadow-sm" style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); border: none;">
                        <i class="fas fa-robot mr-1"></i> Buka Generator Soal AI
                    </a>
                </div>

                <p class="doc-section-desc">
                    Fitur integrasi <strong>Google Gemini AI</strong> memungkinkan Anda membuat puluhan soal ujian bermutu tinggi hanya dalam beberapa detik. Soal otomatis memiliki struktur JSON yang 100% kompatibel dengan CBT tanpa perlu diedit manual.
                </p>

                <!-- 3 Langkah AI -->
                <div class="row mb-3">
                    <div class="col-md-4 mb-3 mb-md-0">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-primary">1</span>
                                <strong class="text-dark small">Buka AI &amp; Kirim Topik</strong>
                            </div>
                            <p class="text-muted small mb-0" style="line-height: 1.6;">
                                Klik tombol <b>Buat via AI</b>. Jendela pop-up Gemini akan muncul mengambang di sisi kanan. Ketik topik, kompetensi dasar, jumlah soal, dan tingkatan kelas.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 mb-md-0">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-success">2</span>
                                <strong class="text-dark small">Unduh File .JSON</strong>
                            </div>
                            <p class="text-muted small mb-0" style="line-height: 1.6;">
                                AI menyusun butir soal, opsi jawaban (A&ndash;E), dan kunci jawaban ke format JSON standar CBT. Setelah selesai, klik tombol <b>Unduh file .JSON</b> di respons AI.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="d-flex align-items-center mb-2">
                                <span class="doc-step-number text-info">3</span>
                                <strong class="text-dark small">Langsung Impor ke CBT</strong>
                            </div>
                            <p class="text-muted small mb-0" style="line-height: 1.6;">
                                Di halaman Bank Soal, klik tombol <b>Impor Soal</b>. Pilih file <code>.json</code> yang baru diunduh tadi, lalu klik <b>Upload &amp; Impor</b>. Soal langsung terpasang instan!
                            </p>
                        </div>
                    </div>
                </div>


                <div class="doc-callout doc-callout-info">
                    <i class="fas fa-columns text-success mr-2"></i>
                    <strong>Fitur Side-by-Side (Berdampingan):</strong> Jendela pop-up AI dirancang mengambang di sebelah kanan layar web CBT. Anda dapat berinteraksi dengan AI sambil tetap melihat daftar soal tanpa perlu berganti-ganti tab browser.
                </div>
            </section>

            <!-- ======================================================== -->
            <!-- BAGIAN 3: EDITOR RUMUS MATEMATIKA (LATEX / KATEX) -->
            <!-- ======================================================== -->
            <section id="sec-rumus-katex" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between flex-wrap pb-2 mb-3 border-bottom" style="gap: 8px;">
                    <div>
                        <h4 class="doc-section-title">
                            <i class="fas fa-square-root-alt text-primary mr-2"></i>3. Tools Penulisan Rumus Matematika &amp; Sains (LaTeX / KaTeX)
                        </h4>
                        <span class="badge badge-light border text-primary font-weight-bold px-2 py-1">
                            <i class="fas fa-star text-warning mr-1"></i> FITUR VERSI 1.6.5
                        </span>
                    </div>
                    <a href="admin.php?page=soal" class="btn btn-outline-primary btn-sm font-weight-bold px-3">
                        <i class="fas fa-pencil-alt mr-1"></i> Coba di Editor Soal
                    </a>
                </div>

                <p class="doc-section-desc">
                    Bapak/Ibu Guru Matematika, Fisika, dan Kimia kini tidak perlu lagi memotong gambar tangkapan layar (screenshot) rumus. Sistem telah dilengkapi <strong>Equation Editor</strong> terintegrasi dengan palet simbol visual dan pratinjau instan KaTeX.
                </p>

                <div class="row mb-3">
                    <div class="col-lg-6 mb-3 mb-lg-0">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="font-weight-bold mb-2 text-dark small">
                                <i class="fas fa-mouse-pointer text-primary mr-1"></i> Cara Memasukkan Rumus di Editor:
                            </div>
                            <ol class="pl-3 mb-0 text-muted small" style="line-height: 1.75;">
                                <li>Di halaman Kelola Soal, klik tombol <b>+ Tambah Soal</b> atau klik <b>Edit</b> pada butir soal.</li>
                                <li>Pada toolbar Summernote teks pertanyaan atau pilihan jawaban A&ndash;E, klik tombol <b><i class="fas fa-square-root-alt text-primary"></i> Rumus</b>.</li>
                                <li>Pilih simbol pada <b>Palet Simbol Visual</b> (Pecahan, Akar, Huruf Yunani, Matriks) atau ketik kode LaTeX secara langsung.</li>
                                <li>Periksa hasil pada <b>Pratinjau KaTeX Real-Time</b> &amp; tentukan mode <code>Inline ($...$)</code> atau <code>Display ($$...$$)</code>.</li>
                                <li>Klik <b>Sisipkan Rumus ke Soal</b>. Rumus otomatis ditampilkan tajam dan jernih di layar siswa.</li>
                            </ol>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="font-weight-bold mb-2 text-dark small">
                                <i class="fas fa-code text-primary mr-1"></i> Contoh Rumus &amp; Kode LaTeX:
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered bg-white mb-2" style="font-size: 0.84rem;">
                                    <thead>
                                        <tr class="bg-light">
                                            <th>Kategori</th>
                                            <th>Kode LaTeX</th>
                                            <th class="text-center">Tampilan KaTeX</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-muted">Pecahan</td>
                                            <td><code>\frac{a}{b}</code></td>
                                            <td class="text-primary text-center font-weight-bold">$\frac{a}{b}$</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Akar Kuadrat</td>
                                            <td><code>\sqrt{x^2 + y^2}</code></td>
                                            <td class="text-primary text-center font-weight-bold">$\sqrt{x^2+y^2}$</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Pangkat &amp; Indeks</td>
                                            <td><code>x_1^2 + x_2^2</code></td>
                                            <td class="text-primary text-center font-weight-bold">$x_1^2 + x_2^2$</td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Rumus ABC</td>
                                            <td><code>x = \frac{-b \pm \sqrt{D}}{2a}</code></td>
                                            <td class="text-primary text-center font-weight-bold">$x = \frac{-b \pm \sqrt{D}}{2a}$</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <small class="text-muted d-block">
                                <i class="fas fa-info-circle text-info mr-1"></i> Tersedia juga tombol <em>"Buka Visual Editor CodeCogs"</em> di modal jika ingin merakit rumus secara grafis.
                            </small>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ======================================================== -->
            <!-- BAGIAN 4: FORMAT TABEL WORD (.DOCX) -->
            <!-- ======================================================== -->
            <section id="sec-format-word" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between flex-wrap pb-2 mb-3 border-bottom" style="gap: 8px;">
                    <div>
                        <h4 class="doc-section-title">
                            <i class="fas fa-file-word text-success mr-2"></i>4. Format Dokumen Microsoft Word (1 Soal = 1 Tabel)
                        </h4>
                        <span class="badge badge-light border text-muted">Format Standar 3 Kolom</span>
                    </div>
                    <button class="btn btn-outline-success btn-sm font-weight-bold" onclick="promptTemplatePGBiasa()">
                        <i class="fas fa-download mr-1"></i> Unduh Template Word (.docx)
                    </button>
                </div>

                <p class="doc-section-desc">
                    Jika Anda menyusun naskah di Microsoft Word, gunakan struktur <strong>1 Tabel untuk 1 Butir Soal</strong> dengan format 3 kolom. Berikan satu baris spasi kosong (Enter) di antara tabel nomor soal.
                </p>

                <!-- Tabel Contoh Format Word -->
                <div class="table-responsive mb-3">
                    <table class="doc-table">
                        <thead>
                            <tr>
                                <th style="width: 10%;">No</th>
                                <th style="width: 20%;">Opsi / Label</th>
                                <th>Isi Pertanyaan / Pilihan Jawaban</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="font-weight-bold text-center">1.</td>
                                <td colspan="2">Tuliskan teks pertanyaan di sini... (dapat disisipkan gambar di sel ini)</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td class="font-weight-bold">A</td>
                                <td>Pilihan jawaban A</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td class="font-weight-bold">B</td>
                                <td>Pilihan jawaban B</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td class="font-weight-bold">C</td>
                                <td>Pilihan jawaban C</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td class="font-weight-bold">D</td>
                                <td>Pilihan jawaban D</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td class="font-weight-bold text-danger">Jawaban</td>
                                <td><span class="badge badge-success px-2 py-1">A</span> <i>(atau <code>A, C</code> untuk PG Kompleks)</i></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="doc-callout doc-callout-warning">
                    <strong class="text-dark"><i class="fas fa-exclamation-triangle text-warning mr-1"></i> PENTING - Wajib Format .docx:</strong><br>
                    Saat menyimpan naskah di Microsoft Word, pastikan memilih menu <b>File &rarr; Save As &rarr; format Word Document (*.docx)</b>. File berformat <code>.doc</code> lama berisiko gagal membaca gambar atau kunci jawaban.
                </div>
            </section>

            <!-- ======================================================== -->
            <!-- BAGIAN 5: KUNCI JAWABAN & PEMBOBOTAN EXCEL -->
            <!-- ======================================================== -->
            <section id="sec-kunci-excel" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between flex-wrap pb-2 mb-3 border-bottom" style="gap: 8px;">
                    <div>
                        <h4 class="doc-section-title">
                            <i class="fas fa-file-excel text-warning mr-2"></i>5. Template Kunci Jawaban Excel &amp; Pembobotan
                        </h4>
                        <span class="badge badge-light border text-muted">Format .xlsx</span>
                    </div>
                </div>

                <p class="doc-section-desc">
                    Kunci jawaban dapat diperiksa dan diimpor sekaligus melalui file Excel (.xlsx), atau diatur otomatis langsung di halaman Kelola Soal CBT.
                </p>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="font-weight-bold text-dark small mb-2">
                                <i class="fas fa-download text-success mr-1"></i> Unduh Format Kunci Excel:
                            </div>
                            <div class="d-grid gap-2">
                                <button class="btn btn-outline-success btn-xs btn-block text-left mb-1 py-1" onclick="downloadPanduanExcelKeyDirect(40, 'multiple_choice')">
                                    <i class="fas fa-file-excel mr-1"></i> Kunci PG Biasa 40 Soal (Default)
                                </button>
                                <button class="btn btn-outline-primary btn-xs btn-block text-left mb-1 py-1" onclick="downloadPanduanExcelKeyDirect(25, 'multiple_choice')">
                                    <i class="fas fa-file-excel mr-1"></i> Kunci PG Biasa 25 Soal
                                </button>
                                <button class="btn btn-outline-info btn-xs btn-block text-left mb-1 py-1" onclick="downloadPanduanExcelKeyDirect(50, 'multiple_choice')">
                                    <i class="fas fa-file-excel mr-1"></i> Kunci PG Biasa 50 Soal
                                </button>
                                <button class="btn btn-outline-warning text-dark btn-xs btn-block text-left mb-1 py-1" onclick="downloadPanduanExcelKeyDirect(20, 'complex_mc')">
                                    <i class="fas fa-check-square mr-1"></i> Kunci PG Kompleks (20 Soal)
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="font-weight-bold text-dark small mb-2">
                                <i class="fas fa-magic text-primary mr-1"></i> Fitur Penilaian Otomatis di CBT:
                            </div>
                            <ul class="pl-3 mb-0 text-muted small" style="line-height: 1.7;">
                                <li><strong>Tombol "Set Poin":</strong> Meratakan bobot nilai seluruh butir soal secara otomatis sehingga total nilai pas 100.</li>
                                <li><strong>Tombol "Hitung Nilai":</strong> Menghitung ulang riwayat nilai siswa secara otomatis jika kunci jawaban baru saja diperbaiki/diubah setelah ujian berlangsung.</li>
                                <li><strong>Optimasi Gambar WebP:</strong> Mengompres gambar bank soal agar hemat kuota server dan dimuat sangat cepat di HP siswa.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ======================================================== -->
            <!-- BAGIAN 6: REKOMENDASI & BEST PRACTICE GURU -->
            <!-- ======================================================== -->
            <section id="sec-tips-guru" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between flex-wrap pb-2 mb-3 border-bottom" style="gap: 8px;">
                    <h4 class="doc-section-title">
                        <i class="fas fa-lightbulb text-warning mr-2"></i>6. Rekomendasi Praktis Guru (Best Practices)
                    </h4>
                    <span class="badge badge-light border text-muted">Checklist</span>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="font-weight-bold text-dark small mb-2">
                                <i class="fas fa-check-circle text-success mr-1"></i> Checklist Sebelum Ujian Dimulai:
                            </div>
                            <ul class="text-muted pl-3 mb-0 small" style="line-height: 1.75;">
                                <li><strong>Gunakan Preview Siswa:</strong> Selalu klik tombol mata biru <i>Preview Siswa</i> untuk menguji kesesuaian gambar, teks soal, dan opsi sebelum jadwal ujian diaktifkan.</li>
                                <li><strong>Periksa Kunci Jawaban:</strong> Pastikan seluruh soal telah memiliki kunci yang tepat dengan mengecek kolom status kunci di daftar kelola soal.</li>
                                <li><strong>Klik Set Poin:</strong> Pastikan total poin bank soal berjumlah 100 agar kalkulasi skor siswa akurat.</li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <div class="p-3 rounded h-100" style="background: #f8fafc; border: 1px solid var(--doc-border);">
                            <div class="font-weight-bold text-dark small mb-2">
                                <i class="fas fa-shield-alt text-primary mr-1"></i> Keamanan &amp; Cadangan Data:
                            </div>
                            <ul class="text-muted pl-3 mb-0 small" style="line-height: 1.75;">
                                <li><strong>Backup ZIP Berkala:</strong> Unduh cadangan bank soal beserta seluruh foldernya dengan tombol <i>Backup ZIP</i> di toolbar.</li>
                                <li><strong>Menyisipkan Gambar di Word:</strong> Klik kanan gambar di Word &rarr; <i>Wrap Text</i> &rarr; pilih <b>In Line with Text</b> agar posisi gambar tidak bergeser saat diimpor.</li>
                                <li><strong>Buat Soal Instan AI:</strong> Manfaatkan tombol <i>Buat via AI</i> untuk menyusun soal cepat berformat JSON tanpa repot mengetik manual.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ======================================================== -->
            <!-- BAGIAN 7: FAQ & TANYA JAWAB UMUM -->
            <!-- ======================================================== -->
            <section id="sec-faq" class="doc-section-card">
                <div class="d-flex align-items-center justify-content-between flex-wrap pb-2 mb-3 border-bottom" style="gap: 8px;">
                    <h4 class="doc-section-title">
                        <i class="fas fa-question-circle text-secondary mr-2"></i>7. Tanya Jawab &amp; Masalah Umum (FAQ)
                    </h4>
                    <span class="badge badge-light border text-muted">Troubleshooting</span>
                </div>

                <div class="accordion" id="accordionDocFaq">
                    
                    <!-- Q1 -->
                    <div class="card border mb-2 shadow-none rounded">
                        <div class="card-header bg-white p-2" id="headingOne">
                            <h6 class="mb-0">
                                <button class="btn btn-link btn-block text-left text-dark font-weight-bold text-decoration-none small py-1" type="button" data-toggle="collapse" data-target="#collapseOne">
                                    <i class="fas fa-chevron-right text-muted mr-2" style="font-size: 0.75rem;"></i>
                                    Mengapa gambar di dokumen Word tidak terbaca saat diimpor?
                                </button>
                            </h6>
                        </div>
                        <div id="collapseOne" class="collapse show" data-parent="#accordionDocFaq">
                            <div class="card-body text-muted small pt-1 pb-3" style="line-height: 1.6;">
                                Pastikan file disimpan dengan format <b>.docx</b> (Word Document modern). Selain itu, pastikan gambar berada di dalam sel tabel pertanyaan dan pengaturan tata letak (*Wrap Text*) gambar adalah <b>In Line with Text</b> (Sejajar Teks).
                            </div>
                        </div>
                    </div>

                    <!-- Q2 -->
                    <div class="card border mb-2 shadow-none rounded">
                        <div class="card-header bg-white p-2" id="headingTwo">
                            <h6 class="mb-0">
                                <button class="btn btn-link btn-block text-left text-dark font-weight-bold text-decoration-none small py-1 collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo">
                                    <i class="fas fa-chevron-right text-muted mr-2" style="font-size: 0.75rem;"></i>
                                    Bagaimana cara mengimpor soal yang dibuat dari Google Gemini AI?
                                </button>
                            </h6>
                        </div>
                        <div id="collapseTwo" class="collapse" data-parent="#accordionDocFaq">
                            <div class="card-body text-muted small pt-1 pb-3" style="line-height: 1.6;">
                                Setelah Gemini AI menghasilkan butir soal berformat JSON, klik tombol <b>Unduh File .JSON</b>. Kemudian di halaman CBT, buka menu <b>Kelola Soal &rarr; Impor Soal</b>, pilih file <code>.json</code> tersebut dan klik <b>Upload &amp; Impor</b>. Soal dan kunci jawaban langsung aktif otomatis.
                            </div>
                        </div>
                    </div>

                    <!-- Q3 -->
                    <div class="card border mb-2 shadow-none rounded">
                        <div class="card-header bg-white p-2" id="headingThree">
                            <h6 class="mb-0">
                                <button class="btn btn-link btn-block text-left text-dark font-weight-bold text-decoration-none small py-1 collapsed" type="button" data-toggle="collapse" data-target="#collapseThree">
                                    <i class="fas fa-chevron-right text-muted mr-2" style="font-size: 0.75rem;"></i>
                                    Apakah rumus matematika (KaTeX) tetap tampil jika server offline/tanpa internet?
                                </button>
                            </h6>
                        </div>
                        <div id="collapseThree" class="collapse" data-parent="#accordionDocFaq">
                            <div class="card-body text-muted small pt-1 pb-3" style="line-height: 1.6;">
                                Ya. Seluruh aset rendering pustaka KaTeX telah disediakan secara terintegrasi di sistem CBT, sehingga rumus matematika dan sains tetap ter-render tajam dan presisi baik saat online maupun jaringan lokal/offline.
                            </div>
                        </div>
                    </div>

                </div>
            </section>

        </div>
    </div>
</div>

<!-- ======================================================== -->
<!-- FLOATING TOMBOL KEMBALI KE ATAS -->
<!-- ======================================================== -->
<div id="btn-doc-top" onclick="window.scrollTo({top: 0, behavior: 'smooth'})" title="Kembali ke atas">
    <i class="fas fa-arrow-up"></i>
</div>

<!-- ======================================================== -->
<!-- SCRIPT: SCROLLSPY, FILTER CARI & EXCEL KEY DIRECT -->
<!-- ======================================================== -->
<script>
// Filter Dokumen Cepat
function filterDocSections(query) {
    const q = query.trim().toLowerCase();
    const sections = document.querySelectorAll('.doc-section-card');
    
    sections.forEach(sec => {
        if (!q) {
            sec.style.display = 'block';
            return;
        }
        const text = sec.innerText.toLowerCase();
        if (text.includes(q)) {
            sec.style.display = 'block';
        } else {
            sec.style.display = 'none';
        }
    });
}


// Unduh Template Excel Kunci Langsung
function downloadPanduanExcelKeyDirect(customCount = 40, customType = 'multiple_choice') {
    try {
        if (typeof XLSX === 'undefined') {
            Swal.fire('Error', 'Pustaka Excel belum selesai dimuat, silakan muat ulang halaman.', 'error');
            return;
        }

        const rows = [];
        rows.push(['No Soal', 'Tipe Soal', 'Kunci Jawaban', 'Bobot Poin', 'Ringkasan Soal']);

        let typeLabel = 'Pilihan Ganda';
        let sampleKey = 'A';
        let defaultPoint = parseFloat((100 / customCount).toFixed(2));

        if (customType === 'complex_mc') {
            typeLabel = 'PG Kompleks';
            sampleKey = 'A, C';
        } else if (customType === 'true_false') {
            typeLabel = 'Benar - Salah';
            sampleKey = 'B, S, B';
        } else if (customType === 'matching') {
            typeLabel = 'Menjodohkan';
            sampleKey = 'A, C, B';
        }

        for (let i = 1; i <= customCount; i++) {
            const contohKunci = (i === 1) ? sampleKey : '';
            rows.push([i, typeLabel, contohKunci, defaultPoint, 'Soal nomor ' + i]);
        }

        const worksheet = XLSX.utils.aoa_to_sheet(rows);
        worksheet['!cols'] = [
            { wch: 10 },
            { wch: 18 },
            { wch: 18 },
            { wch: 12 },
            { wch: 45 }
        ];

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Kunci Jawaban");
        const cleanType = typeLabel.replace(/[^a-zA-Z0-9]/g, '_');
        XLSX.writeFile(workbook, `Template_Kunci_${cleanType}_${customCount}_Soal.xlsx`);

        Swal.fire({
            icon: 'success',
            title: 'Berhasil Diunduh!',
            text: `Template Kunci Excel (${typeLabel} - ${customCount} Soal) berhasil diunduh.`,
            timer: 2000,
            showConfirmButton: false
        });
    } catch (err) {
        Swal.fire('Error', 'Gagal membuat file template Excel: ' + err.message, 'error');
    }
}

// ScrollSpy & Floating Back to Top
document.addEventListener('DOMContentLoaded', function() {
    // Render KaTeX Formulas
    if (typeof renderMath === 'function') {
        renderMath(document.querySelector('.container-fluid'));
    }

    // Fallback Popup AI jika dipanggil
    if (typeof window.openGeminiAiPopup !== 'function') {
        window.openGeminiAiPopup = function(e) {
            if (e && e.preventDefault) e.preventDefault();
            const url = 'https://share.gemini.google/ReefFdC6lnEu';
            const width = Math.min(Math.max(Math.round(window.screen.availWidth * 0.46), 540), 850);
            const height = Math.max(window.screen.availHeight - 60, 600);
            const left = Math.max(window.screen.availWidth - width - 10, 0);
            const top = 30;
            const windowFeatures = `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=no,toolbar=no,menubar=no,location=yes`;
            const popup = window.open(url, 'GeminiSoalPopup', windowFeatures);
            if (popup && !popup.closed) popup.focus();
            else window.open(url, '_blank', 'noopener,noreferrer');
            return false;
        };
    }

    // ScrollSpy implementation
    const tocLinks = document.querySelectorAll('.doc-toc-link');
    const sections = document.querySelectorAll('.doc-section-card');
    const btnTop = document.getElementById('btn-doc-top');

    window.addEventListener('scroll', function() {
        let currentSectionId = '';
        const scrollPosition = window.pageYOffset + 120;

        // Show/hide floating back to top button
        if (window.pageYOffset > 300) {
            btnTop.style.display = 'flex';
        } else {
            btnTop.style.display = 'none';
        }

        sections.forEach(sec => {
            const sectionTop = sec.offsetTop;
            const sectionHeight = sec.offsetHeight;
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                currentSectionId = sec.getAttribute('id');
            }
        });

        if (currentSectionId) {
            tocLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === '#' + currentSectionId) {
                    link.classList.add('active');
                }
            });
        }
    });
});
</script>
