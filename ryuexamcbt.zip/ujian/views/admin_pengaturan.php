<?php $settings = get_settings(); ?>
<div id="section-pengaturan" class="content-section">
    <div class="card card-primary card-outline card-outline-tabs">
        <div class="card-header p-0 border-bottom-0">
            <ul class="nav nav-tabs" id="setting-tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="tab-umum" data-toggle="pill" href="#content-umum" role="tab"><i class="fas fa-cog mr-2"></i>Umum</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab-login" data-toggle="pill" href="#content-login" role="tab"><i class="fas fa-sign-in-alt mr-2"></i>Metode Login Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab-pelanggaran" data-toggle="pill" href="#content-pelanggaran" role="tab"><i class="fas fa-exclamation-triangle mr-2"></i>Pengaturan Pelanggaran</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab-admin" data-toggle="pill" href="#content-admin" role="tab"><i class="fas fa-user-shield mr-2"></i>Kelola Admin</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab-token" data-toggle="pill" href="#content-token" role="tab"><i class="fas fa-key mr-2"></i>Token Dinamis</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="tab-database" data-toggle="pill" href="#content-database" role="tab"><i class="fas fa-database mr-2"></i>Database</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content" id="setting-tabs-content">
                
                <!-- TAB UMUM -->
                <div class="tab-pane fade show active" id="content-umum" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <form id="form-settings" onsubmit="saveSettings(event)">
                                
                                <!-- IDENTITAS SEKOLAH & BRANDING -->
                                <div class="card card-outline card-primary mb-4 shadow-sm">
                                    <div class="card-header py-2 bg-light">
                                        <h3 class="card-title font-weight-bold" style="font-size: 1rem;">
                                            Identitas Sekolah / Madrasah &amp; Branding
                                        </h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <div class="form-group mb-3">
                                                    <label for="setting_school_name" class="font-weight-bold">Nama Sekolah / Lembaga</label>
                                                    <input type="text" class="form-control" id="setting_school_name" value="<?= htmlspecialchars($settings['school_name'] ?? '') ?>" placeholder="Contoh: SMP Negeri 1 Contoh">
                                                    <small class="form-text text-muted">Nama sekolah akan ditampilkan di bagian atas formulir login siswa dan judul halaman.</small>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group mb-3">
                                                    <label for="setting_school_logo" class="font-weight-bold">Logo Sekolah</label>
                                                    <div class="d-flex align-items-center">
                                                        <?php if(!empty($settings['school_logo']) && file_exists($settings['school_logo'])): ?>
                                                            <div class="mr-3 text-center" id="wrapper-current-school-logo">
                                                                <img src="<?= htmlspecialchars($settings['school_logo']) ?>?v=<?= time() ?>" alt="Logo Sekolah" style="max-height: 50px; max-width: 70px; object-fit: contain; border: 1px solid #ced4da; padding: 3px; border-radius: 6px; background: #fff;">
                                                                <div class="mt-1">
                                                                    <button type="button" class="btn btn-outline-danger btn-xs" onclick="markRemoveLogo()" title="Hapus logo"><i class="fas fa-trash-alt"></i> Hapus</button>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="flex-grow-1">
                                                            <input type="file" class="form-control-file" id="setting_school_logo" accept=".png,.jpg,.jpeg,.svg,.webp">
                                                            <input type="hidden" id="remove_school_logo" value="false">
                                                            <small class="form-text text-muted">Format: PNG, JPG, SVG, WebP. Disarankan format PNG transparan.</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mt-2">
                                            <div class="col-md-7">
                                                <div class="form-group mb-2">
                                                    <label for="setting_pwa_icon" class="font-weight-bold">Ikon PWA Aplikasi</label>
                                                    <div class="d-flex align-items-center">
                                                        <?php $pwaIconVer = file_exists('icon-192.png') ? filemtime('icon-192.png') : time(); ?>
                                                        <div class="mr-3 text-center" id="wrapper-current-pwa-icon">
                                                            <img id="pwa-icon-preview" src="icon-192.png?v=<?= $pwaIconVer ?>" alt="Ikon PWA" style="width: 46px; height: 46px; object-fit: contain; border: 1px solid #ced4da; padding: 2px; border-radius: 8px; background: #fff;">
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <input type="file" class="form-control-file" id="setting_pwa_icon" accept=".png,.jpg,.jpeg,.webp,.svg" onchange="previewCleanPwaIcon(this)">
                                                            <input type="hidden" id="action_pwa_icon" value="">
                                                            <small class="form-text text-muted">
                                                                Ikon install PWA di HP &amp; Desktop (otomatis dibuat 192x192 &amp; 512x512).
                                                                <?php if(!empty($settings['school_logo']) && file_exists($settings['school_logo'])): ?>
                                                                    <a href="javascript:void(0)" class="text-primary ml-1" onclick="syncPwaFromLogo()"><i class="fas fa-sync-alt"></i> Samakan Logo</a> &bull;
                                                                <?php endif; ?>
                                                                <a href="javascript:void(0)" class="text-secondary ml-1" onclick="resetPwaToDefault()"><i class="fas fa-undo"></i> Reset Default</a>
                                                            </small>
                                                            <div id="pwa_clean_notice" class="text-success small font-weight-bold mt-1" style="display: none;"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="form-group mb-2">
                                                    <label for="setting_favicon" class="font-weight-bold">Favicon Aplikasi (Opsional)</label>
                                                    <div class="d-flex align-items-center">
                                                        <?php if(!empty($settings['favicon'])): ?>
                                                            <img src="<?= htmlspecialchars($settings['favicon']) ?>?v=<?= time() ?>" alt="Favicon" style="width:32px; height:32px; margin-right:10px; border:1px solid #ced4da; border-radius:4px; padding: 2px; background: #fff;">
                                                        <?php endif; ?>
                                                        <div class="flex-grow-1">
                                                            <input type="file" class="form-control-file" id="setting_favicon" accept=".ico,.png,.jpg,.jpeg">
                                                            <small class="form-text text-muted">Ikon tab browser (format .ico, .png, .jpg).</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ATURAN PENGERJAAN UJIAN -->
                                <div class="card card-outline card-primary mb-4 shadow-sm">
                                    <div class="card-header py-2 bg-light">
                                        <h3 class="card-title font-weight-bold" style="font-size: 1rem;">
                                            Aturan Pengerjaan Ujian
                                        </h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group mb-3">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="setting_require_all" <?= $settings['require_all_answered'] ? 'checked' : '' ?>>
                                                <label class="custom-control-label font-weight-bold" for="setting_require_all">Wajib Jawab Semua Soal</label>
                                                <small class="form-text text-muted">Jika diaktifkan, siswa tidak bisa mengumpulkan ujian sebelum seluruh soal dijawab.</small>
                                            </div>
                                        </div>
                                        <div class="form-group mb-3">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="setting_show_score" <?= (!isset($settings['show_score']) || $settings['show_score']) ? 'checked' : '' ?>>
                                                <label class="custom-control-label font-weight-bold" for="setting_show_score">Tampilkan Nilai ke Siswa</label>
                                                <small class="form-text text-muted">Jika dinonaktifkan, siswa hanya akan melihat pesan "Ujian Selesai" tanpa mengetahui nilainya di akhir ujian.</small>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="setting_min_time" class="font-weight-bold">Waktu Minimal Mengerjakan (Menit)</label>
                                                    <input type="number" class="form-control" id="setting_min_time" value="<?= $settings['min_time_submit'] ?? 0 ?>" min="0">
                                                    <small class="form-text text-muted">Siswa baru bisa menekan tombol Selesai setelah mengerjakan selama waktu yang ditentukan. Isi 0 untuk menonaktifkan.</small>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label for="setting_sync_interval" class="font-weight-bold">Interval Sinkronisasi Jawaban (Detik)</label>
                                                    <input type="number" class="form-control" id="setting_sync_interval" value="<?= htmlspecialchars($settings['sync_interval_seconds'] ?? 60) ?>" min="15" max="300" step="5">
                                                    <small class="form-text text-muted">Jeda waktu otomatis pencadangan jawaban siswa ke server. Default: 60 detik (disarankan 60-90 detik untuk Cloud Hosting).</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary" id="btn-save-settings">
                                    <i class="fas fa-save mr-2"></i> Simpan Pengaturan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- TAB METODE LOGIN SISWA -->
                <div class="tab-pane fade" id="content-login" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <form id="form-login-settings" onsubmit="saveSettings(event)">
                                
                                <!-- FORMAT ALUR LOGIN -->
                                <div class="card card-outline card-primary mb-4 shadow-sm">
                                    <div class="card-header py-2 bg-light">
                                        <h3 class="card-title font-weight-bold" style="font-size: 1rem;">
                                            Metode Login Siswa
                                        </h3>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted small mb-3">Pilih format tampilan dan alur autentikasi yang digunakan siswa saat masuk ke halaman ujian.</p>
                                        <div class="custom-control custom-radio mb-3">
                                            <input type="radio" id="login_method_name" name="student_login_method" class="custom-control-input" value="name_select" <?= (($settings['student_login_method'] ?? 'name_select') !== 'username') ? 'checked' : '' ?>>
                                            <label class="custom-control-label font-weight-bold" for="login_method_name">Pilih Nama Saja (Metode Cepat / Dropdown Kelas &amp; Nama)</label>
                                            <div class="text-muted small ml-1">Siswa memilih mata pelajaran, memasukkan token, memilih kelas, dan memilih namanya sendiri dari daftar pencarian.</div>
                                        </div>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="login_method_username" name="student_login_method" class="custom-control-input" value="username" <?= (($settings['student_login_method'] ?? 'name_select') === 'username') ? 'checked' : '' ?>>
                                            <label class="custom-control-label font-weight-bold" for="login_method_username">Gunakan Username &amp; Password (Disertai Konfirmasi Data Peserta)</label>
                                            <div class="text-muted small ml-1">Siswa mengetik Username, Password, dan memilih Mata Pelajaran. Setelah itu muncul kartu <strong>Konfirmasi Data Peserta</strong> (Nama, Kelas, Mapel, dan input Token) sebelum menekan tombol Mulai Ujian.</div>
                                        </div>
                                    </div>
                                </div>

                                <!-- OPSI & KEAMANAN LOGIN -->
                                <div class="card card-outline card-primary mb-4 shadow-sm">
                                    <div class="card-header py-2 bg-light">
                                        <h3 class="card-title font-weight-bold" style="font-size: 1rem;">
                                            Keamanan &amp; Autentikasi Login Siswa
                                        </h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group mb-3">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="setting_disable_token" <?= (!empty($settings['disable_token'])) ? 'checked' : '' ?> onchange="syncDisableToken(this)">
                                                <label class="custom-control-label font-weight-bold" for="setting_disable_token">Masuk Ujian Tanpa Token</label>
                                                <small class="form-text text-muted">Jika diaktifkan, kolom token ujian akan dihilangkan pada formulir login siswa sehingga siswa dapat langsung memilih kelas dan nama untuk memulai ujian.</small>
                                            </div>
                                        </div>
                                        <div class="form-group mb-3">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="setting_require_password" <?= (!isset($settings['require_password']) || $settings['require_password']) ? 'checked' : '' ?>>
                                                <label class="custom-control-label font-weight-bold" for="setting_require_password">Aktifkan Password Login</label>
                                                <small class="form-text text-muted">Jika dinonaktifkan, siswa tidak perlu memasukkan password saat login meskipun password tersimpan di database.</small>
                                            </div>
                                        </div>
                                        <div class="form-group mb-3">
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="setting_prevent_multi_login" <?= ($settings['prevent_multi_login'] ?? false) ? 'checked' : '' ?>>
                                                <label class="custom-control-label font-weight-bold" for="setting_prevent_multi_login">Pencegahan Multi Login</label>
                                                <small class="form-text text-muted">Jika diaktifkan, siswa tidak bisa login ganda di beberapa perangkat sekaligus.</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary" id="btn-save-login-settings">
                                    <i class="fas fa-save mr-2"></i> Simpan Pengaturan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- TAB PENGATURAN PELANGGARAN -->
                <div class="tab-pane fade" id="content-pelanggaran" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <form id="form-pelanggaran-settings" onsubmit="saveSettings(event)">
                                
                                <div class="card card-outline card-primary mb-4 shadow-sm">
                                    <div class="card-header py-2 bg-light">
                                        <h3 class="card-title font-weight-bold" style="font-size: 1rem;">
                                            Pengaturan Pelanggaran &amp; Anti-Cheat
                                        </h3>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted small mb-4">Pengaturan batas toleransi saat siswa berpindah tab atau keluar dari mode layar penuh (fullscreen), serta tindakan otomatis yang diterapkan oleh sistem jika batas toleransi terlampaui.</p>
                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="setting_max_violations" class="font-weight-bold">Batas Toleransi Pelanggaran</label>
                                                    <input type="number" class="form-control" id="setting_max_violations" value="<?= $settings['max_violations'] ?? 3 ?>" min="0" max="50">
                                                    <small class="form-text text-muted">Batas maksimal ganti tab/keluar layar penuh. Isi 0 untuk menonaktifkan peringatan.</small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="setting_violation_action" class="font-weight-bold">Tindakan Saat Batas Terlampaui</label>
                                                    <select class="form-control" id="setting_violation_action">
                                                        <option value="lockout" <?= (($settings['violation_action'] ?? 'lockout') === 'lockout') ? 'selected' : '' ?>>Kunci Ujian (Lockout)</option>
                                                        <option value="auto_submit" <?= (($settings['violation_action'] ?? 'lockout') === 'auto_submit') ? 'selected' : '' ?>>Kumpulkan Otomatis (Auto Submit)</option>
                                                    </select>
                                                    <small class="form-text text-muted">Aksi sistem ketika siswa melebihi batas toleransi pelanggaran.</small>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="setting_lockout_duration" class="font-weight-bold">Durasi Terkunci (Detik)</label>
                                                    <input type="number" class="form-control" id="setting_lockout_duration" value="<?= $settings['lockout_duration'] ?? 60 ?>" min="0" step="5">
                                                    <small class="form-text text-muted">Waktu hitung mundur kunci di siswa (contoh: 60 = 1 menit). Isi <strong>0</strong> jika hanya boleh dibuka oleh Admin.</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary" id="btn-save-pelanggaran-settings">
                                    <i class="fas fa-save mr-2"></i> Simpan Pengaturan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- TAB KELOLA ADMIN -->
                <div class="tab-pane fade" id="content-admin" role="tabpanel">
                    <div class="row">
                        <div class="col-12">
                            <div class="card card-outline card-primary shadow-sm mb-4">
                                <div class="card-header py-2 d-flex justify-content-between align-items-center">
                                    <h3 class="card-title text-dark mb-0 font-weight-normal" style="font-size: 1rem; line-height: 2;">
                                        Daftar Administrator
                                    </h3>
                                    <div class="card-tools ml-auto">
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalAddAdmin" onclick="resetAddAdminForm()" style="font-weight: normal;">
                                            <i class="fas fa-plus mr-1"></i> Tambah Admin
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body p-0 table-responsive">
                                    <table class="table table-hover table-striped table-bordered mb-0 align-middle">
                                        <thead class="bg-light text-dark">
                                            <tr>
                                                <th style="width: 45px;" class="text-center align-middle font-weight-normal">No</th>
                                                <th style="min-width: 160px;" class="align-middle font-weight-normal">Nama</th>
                                                <th style="min-width: 120px;" class="align-middle font-weight-normal">Username</th>
                                                <th style="min-width: 120px;" class="align-middle font-weight-normal">Role</th>
                                                <th style="min-width: 250px;" class="align-middle font-weight-normal">Hak Akses</th>
                                                <th style="min-width: 100px;" class="align-middle font-weight-normal">Password</th>
                                                <th style="width: 100px;" class="text-center align-middle font-weight-normal">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                             $allUsers = get_users();
                                            $adminList = array_values(array_filter($allUsers, function($u) { 
                                                return ($u['role'] ?? '') === 'admin'; 
                                            }));
                                            $curUsername = $_SESSION['username'] ?? 'admin';
                                            $allSystemTasks = get_admin_tasks_list();
                                            
                                            foreach ($adminList as $idx => $adm): 
                                                $isCurrent = (strtolower($adm['username'] ?? '') === strtolower($curUsername));
                                                $admRole = !empty($adm['admin_role']) ? $adm['admin_role'] : 'Super Admin';
                                                $admPerms = parse_admin_permissions($adm['permissions'] ?? 'all');
                                                $isFullAccess = ($adm['permissions'] === 'all' || count($admPerms) >= count($allSystemTasks));
                                            ?>
                                            <tr>
                                                <td class="text-center align-middle"><?= $idx + 1 ?></td>
                                                <td class="align-middle">
                                                    <span class="text-dark font-weight-bold"><?= htmlspecialchars($adm['name'] ?? 'Administrator') ?></span>
                                                    <?php if ($isCurrent): ?>
                                                        <span class="badge badge-success ml-1 font-weight-normal" style="font-size: 0.72rem;">Saya</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="align-middle">
                                                    <code><?= htmlspecialchars($adm['username'] ?? '') ?></code>
                                                </td>
                                                <td class="align-middle">
                                                    <span class="badge badge-light border text-dark font-weight-normal"><?= htmlspecialchars($admRole) ?></span>
                                                </td>
                                                <td class="align-middle">
                                                    <?php if ($isFullAccess): ?>
                                                        <span class="text-success font-weight-normal" style="font-size: 0.85rem;">Semua Akses</span>
                                                    <?php else: ?>
                                                        <div class="d-flex flex-wrap align-items-center" style="gap: 4px;">
                                                            <?php 
                                                            $shown = array_slice($admPerms, 0, 3);
                                                            foreach ($shown as $tKey):
                                                                if (isset($allSystemTasks[$tKey])):
                                                            ?>
                                                                <span class="badge badge-light border text-secondary font-weight-normal" style="font-size: 0.75rem;">
                                                                    <?= htmlspecialchars($allSystemTasks[$tKey]['name']) ?>
                                                                </span>
                                                            <?php 
                                                                endif;
                                                            endforeach; 
                                                            $moreCount = count($admPerms) - count($shown);
                                                            if ($moreCount > 0):
                                                            ?>
                                                                <span class="badge badge-secondary font-weight-normal" style="font-size: 0.75rem;">
                                                                    +<?= $moreCount ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="align-middle">
                                                    <span class="text-muted" style="font-family: monospace; font-size: 0.82rem;"><?= htmlspecialchars($adm['password'] ?? '******') ?></span>
                                                </td>
                                                <td class="text-center align-middle text-nowrap">
                                                    <button class="btn btn-outline-primary btn-xs mr-1" title="Edit Admin" onclick='openEditAdminModal(<?= json_encode([
                                                        'id' => (int)$adm['id'],
                                                        'name' => $adm['name'] ?? '',
                                                        'username' => $adm['username'] ?? '',
                                                        'admin_role' => $admRole,
                                                        'permissions' => $adm['permissions'] ?? 'all',
                                                        'is_main_admin' => (strtolower($adm['username'] ?? '') === 'admin')
                                                    ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)'>
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <?php if (!$isCurrent && count($adminList) > 1): ?>
                                                    <button class="btn btn-outline-danger btn-xs" title="Hapus Admin" onclick="deleteAdmin(<?= (int)$adm['id'] ?>, '<?= htmlspecialchars(addslashes($adm['name'] ?? $adm['username'])) ?>')">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                    <?php else: ?>
                                                    <button class="btn btn-outline-secondary btn-xs" disabled title="Akun login tidak dapat dihapus">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php if (empty($adminList)): ?>
                                                <tr><td colspan="7" class="text-center py-4 text-muted">Belum ada akun admin</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- TAB TOKEN DINAMIS -->
                <div class="tab-pane fade" id="content-token" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <form id="form-token-settings" onsubmit="saveSettings(event)">
                                <div class="form-group mb-3 p-3 bg-light rounded border">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="setting_disable_token_tab" <?= (!empty($settings['disable_token'])) ? 'checked' : '' ?> onchange="syncDisableToken(this)">
                                        <label class="custom-control-label font-weight-bold" for="setting_disable_token_tab">Masuk Ujian Tanpa Token</label>
                                        <small class="form-text text-muted d-block mt-1">Jika opsi ini diaktifkan, formulir login siswa tidak akan meminta token ujian sama sekali.</small>
                                    </div>
                                </div>
                                <div class="form-group mb-3">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="setting_dynamic_token" <?= (!empty($settings['dynamic_token'])) ? 'checked' : '' ?> onchange="toggleDynamicTokenInterval(this)">
                                        <label class="custom-control-label font-weight-bold" for="setting_dynamic_token">Aktifkan Token Dinamis (Otomatis Berganti)</label>
                                        <small class="form-text text-muted">Jika diaktifkan, token ujian akan berubah secara acak otomatis setiap interval menit yang ditentukan di bawah ini.</small>
                                    </div>
                                </div>
                                <div class="form-group mb-3" id="wrapper_token_interval" style="<?= empty($settings['dynamic_token']) ? 'display:none;' : '' ?>">
                                    <label for="setting_token_interval">Interval Pergantian Token (Menit)</label>
                                    <div class="input-group" style="max-width: 200px;">
                                        <input type="number" class="form-control" id="setting_token_interval" value="<?= htmlspecialchars($settings['token_interval_minutes'] ?? 15) ?>" min="1" max="1440" step="1">
                                        <div class="input-group-append">
                                            <span class="input-group-text">Menit</span>
                                        </div>
                                    </div>
                                    <small class="form-text text-muted">Contoh: 15 menit, 30 menit. Sistem memberikan toleransi 2 menit untuk token sebelumnya agar siswa yang sedang mengetik tidak gagal login.</small>
                                    
                                    <div class="mt-3 pt-3 border-top">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="setting_dynamic_token_all_exams" <?= (!empty($settings['dynamic_token_all_exams'])) ? 'checked' : '' ?>>
                                            <label class="custom-control-label font-weight-bold" for="setting_dynamic_token_all_exams">Gunakan 1 Token Dinamis untuk Semua Ujian</label>
                                            <small class="form-text text-muted d-block mt-1">Jika opsi ini diaktifkan, seluruh jadwal ujian yang aktif akan menggunakan 1 token dinamis yang sama secara serentak (jika banyak ujian aktif, hanya memakai 1 token saja). Nonaktifkan jika ingin tiap ujian memiliki token terpisah.</small>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary" id="btn-save-token-settings">
                                    <i class="fas fa-save mr-2"></i> Simpan Pengaturan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- TAB DATABASE -->
                <div class="tab-pane fade" id="content-database" role="tabpanel">
                    <!-- Info Koneksi Database -->
                    <div class="d-flex align-items-center justify-content-between p-3 mb-4 bg-light rounded border flex-wrap" style="gap: 10px;">
                        <div class="d-flex align-items-center flex-wrap" style="gap: 12px; font-size: 0.88rem;">
                            <span class="text-dark font-weight-bold">MySQL (PDO)</span>
                            <span class="text-muted">&bull;</span>
                            <span class="text-muted">Database: <code class="text-dark"><?= htmlspecialchars(defined('DB_NAME') ? DB_NAME : 'cbt_ujian') ?></code></span>
                            <span class="text-muted">&bull;</span>
                            <span class="text-muted">Host: <code class="text-dark"><?= htmlspecialchars(defined('DB_HOST') ? DB_HOST : 'localhost') ?>:<?= htmlspecialchars(defined('DB_PORT') ? DB_PORT : '3306') ?></code></span>
                            <span class="text-muted">&bull;</span>
                            <span class="text-muted">Dual Live-Sync</span>
                        </div>
                        <span class="badge badge-success font-weight-normal px-2 py-1" style="font-size: 0.78rem;">Terhubung</span>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card card-outline card-primary shadow-sm h-100">
                                <div class="card-header py-2">
                                    <h3 class="card-title text-dark mb-0 font-weight-normal" style="font-size: 1rem; line-height: 2;">
                                        Backup Database
                                    </h3>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between">
                                    <p class="text-muted small mb-3">
                                        Unduh seluruh struktur tabel dan data database MySQL ke dalam file <code>.sql</code> standar.
                                    </p>
                                    <div>
                                        <button type="button" onclick="backupDatabase()" class="btn btn-primary btn-block py-2" id="btn-backup" style="font-weight: normal;">
                                            <i class="fas fa-download mr-1"></i> Download Backup (.sql)
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-4">
                            <div class="card card-outline card-danger shadow-sm h-100">
                                <div class="card-header py-2">
                                    <h3 class="card-title text-dark mb-0 font-weight-normal" style="font-size: 1rem; line-height: 2;">
                                        Restore Database
                                    </h3>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between">
                                    <form id="form-restore" onsubmit="restoreDatabase(event)">
                                        <p class="text-muted small mb-2">
                                            Unggah file cadangan <code>.sql</code> untuk memulihkan database. Isi tabel saat ini akan ditimpa.
                                        </p>
                                        <div class="form-group mb-3">
                                            <div class="custom-file">
                                                <input type="file" id="file_backup" class="custom-file-input" accept=".sql" required onchange="updateSqlFileName(this)">
                                                <label class="custom-file-label font-weight-normal" id="label-file-backup" for="file_backup">Pilih file .sql...</label>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-danger btn-block py-2" id="btn-restore" style="font-weight: normal;">
                                            <i class="fas fa-upload mr-1"></i> Mulai Restore (.sql)
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                    $pdo = get_db_connection();
                    $countResults = (int)$pdo->query("SELECT COUNT(*) FROM exam_results")->fetchColumn();
                    $countSessions = (int)$pdo->query("SELECT COUNT(*) FROM exam_sessions")->fetchColumn();
                    $countExams = (int)$pdo->query("SELECT COUNT(*) FROM exams")->fetchColumn();
                    $countBankSoal = (int)$pdo->query("SELECT COUNT(*) FROM bank_soal")->fetchColumn();
                    $countQuestions = (int)$pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
                    $countStudents = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
                    $countClasses = (int)$pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
                    $countGurus = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'guru'")->fetchColumn();
                    ?>

                    <!-- CARD KOSONGKAN / HAPUS DATA DATABASE -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-outline card-warning shadow-sm">
                                <div class="card-header py-2 d-flex justify-content-between align-items-center">
                                    <h3 class="card-title text-dark mb-0 font-weight-normal" style="font-size: 1rem; line-height: 2;">
                                        Kosongkan Data
                                    </h3>
                                    <div class="card-tools ml-auto">
                                        <button type="button" class="btn btn-xs btn-link text-primary p-0 mr-2" onclick="toggleSelectAllPurge(true)" style="text-decoration: none;">Pilih Semua</button>
                                        <span class="text-muted small mr-2">|</span>
                                        <button type="button" class="btn btn-xs btn-link text-secondary p-0" onclick="toggleSelectAllPurge(false)" style="text-decoration: none;">Batal</button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <p class="text-muted small mb-3">
                                        Pilih kategori data yang ingin dibersihkan dari database MySQL. Akun administrator tetap aman.
                                    </p>

                                    <!-- Grid Checklist Kategori Data -->
                                    <div class="row">
                                        <!-- Hasil & Nilai Ujian -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_results">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_results" value="results">
                                                    <span class="task-title text-truncate">Nilai &amp; Hasil Ujian</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countResults ?> data</span>
                                            </label>
                                        </div>

                                        <!-- Sesi Ujian Aktif -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_sessions">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_sessions" value="sessions">
                                                    <span class="task-title text-truncate">Sesi Ujian Aktif</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countSessions ?> sesi</span>
                                            </label>
                                        </div>

                                        <!-- Jadwal Ujian / Mapel -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_exams">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_exams" value="exams">
                                                    <span class="task-title text-truncate">Jadwal Ujian</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countExams ?> jadwal</span>
                                            </label>
                                        </div>

                                        <!-- Bank Soal & Butir Soal -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_questions">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_questions" value="questions">
                                                    <span class="task-title text-truncate">Bank Soal &amp; Soal</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countBankSoal ?> bank</span>
                                            </label>
                                        </div>

                                        <!-- Data Siswa -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_students">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_students" value="students">
                                                    <span class="task-title text-truncate">Data Siswa</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countStudents ?> siswa</span>
                                            </label>
                                        </div>

                                        <!-- Data Kelas -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_classes">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_classes" value="classes">
                                                    <span class="task-title text-truncate">Data Kelas</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countClasses ?> kelas</span>
                                            </label>
                                        </div>

                                        <!-- Akun Guru -->
                                        <div class="col-md-6 col-lg-4 mb-2">
                                            <label class="admin-task-card purge-card d-flex justify-content-between align-items-center" for="purge_gurus">
                                                <div class="d-flex align-items-center text-truncate mr-2">
                                                    <input type="checkbox" class="purge-item" id="purge_gurus" value="gurus">
                                                    <span class="task-title text-truncate">Data Guru</span>
                                                </div>
                                                <span class="badge badge-light border text-muted font-weight-normal ml-auto flex-shrink-0" style="font-size: 0.76rem;"><?= $countGurus ?> guru</span>
                                            </label>
                                        </div>
                                    </div>

                                    <!-- Tombol Aksi Hapus -->
                                    <div class="d-flex justify-content-end align-items-center mt-3 pt-3 border-top">
                                        <button type="button" class="btn btn-danger btn-sm px-4" id="btn-purge-data" onclick="executePurgeData()" style="font-weight: normal;">
                                            <i class="fas fa-trash-alt mr-1"></i> Hapus Data Terpilih
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<style>
.admin-task-card {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    background: #ffffff;
    border: 1px solid #dbe2ea;
    border-radius: 8px;
    cursor: pointer;
    margin-bottom: 0;
    transition: all 0.15s ease-in-out;
    user-select: none;
    min-height: 48px;
    height: 100%;
}
.admin-task-card:hover {
    background-color: #f8fafc;
    border-color: #94a3b8;
}
.admin-task-card:has(input:checked) {
    background-color: #f0f7ff;
    border-color: #3b82f6;
}
.admin-task-card input[type="checkbox"] {
    width: 18px;
    height: 18px;
    margin: 0 14px 0 0;
    cursor: pointer;
    accent-color: #2563eb;
    flex-shrink: 0;
}
.admin-task-card .task-title {
    font-size: 0.88rem;
    font-weight: 500;
    color: #1e293b;
    margin: 0;
    line-height: 1.3;
}
.purge-card:has(input:checked) {
    background-color: #fef2f2 !important;
    border-color: #f87171 !important;
}
.purge-card input[type="checkbox"] {
    accent-color: #dc2626 !important;
}
</style>

<!-- Modal Tambah Admin -->
<div class="modal fade" id="modalAddAdmin" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title font-weight-bold" style="font-size: 1.05rem;">Tambah Admin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form onsubmit="submitAddAdmin(event)">
                <div class="modal-body p-3" style="max-height: calc(85vh - 120px); overflow-y: auto;">
                    <div class="row">
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" id="add_admin_name" class="form-control" placeholder="Nama Lengkap" required>
                        </div>
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Username <span class="text-danger">*</span></label>
                            <input type="text" id="add_admin_username" class="form-control" placeholder="Username" required autocomplete="off">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="password" id="add_admin_password" class="form-control" placeholder="Password" required>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('add_admin_password')"><i class="fas fa-eye"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Role / Jabatan <span class="text-danger">*</span></label>
                            <select id="add_admin_role_preset" class="form-control mb-1" onchange="applyRolePreset('add', this.value)">
                                <option value="Super Admin">Super Admin</option>
                                <option value="Proktor">Proktor</option>
                                <option value="Teknisi">Teknisi</option>
                                <option value="Pengawas">Pengawas</option>
                                <option value="Admin Kurikulum">Admin Kurikulum</option>
                                <option value="custom">Kustom (Pilih Manual)</option>
                            </select>
                            <input type="text" id="add_admin_role" class="form-control" placeholder="Nama Label Role" value="Super Admin" required>
                        </div>
                    </div>

                    <!-- Checklist Tugas Admin -->
                    <div class="mt-3 pt-3 border-top">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="font-weight-bold mb-0 text-dark">Pilih Tugas Admin</label>
                            <div class="d-flex align-items-center" style="gap: 8px;">
                                <button type="button" class="btn btn-xs btn-link text-primary p-0" onclick="toggleAllTasks('add', true)" style="text-decoration: none;">Pilih Semua</button>
                                <span class="text-muted small">&bull;</span>
                                <button type="button" class="btn btn-xs btn-link text-secondary p-0" onclick="toggleAllTasks('add', false)" style="text-decoration: none;">Kosongkan</button>
                                <span class="badge badge-light border text-dark ml-1 font-weight-normal" id="add_admin_count_badge">14 dipilih</span>
                            </div>
                        </div>
                        <div class="row">
                            <?php 
                            $allSystemTasks = get_admin_tasks_list();
                            foreach ($allSystemTasks as $tKey => $t): 
                            ?>
                            <div class="col-md-6 mb-2">
                                <label class="admin-task-card" for="add_task_<?= $tKey ?>">
                                    <input type="checkbox" class="add-task-cb" id="add_task_<?= $tKey ?>" value="<?= $tKey ?>" checked onchange="onTaskCheckboxChange('add')">
                                    <span class="task-title"><?= htmlspecialchars($t['name']) ?></span>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer py-2 bg-light">
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary btn-sm" id="btn-submit-add-admin">
                        Simpan Admin
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Admin -->
<div class="modal fade" id="modalEditAdmin" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header py-2">
                <h5 class="modal-title font-weight-bold" style="font-size: 1.05rem;">Edit Admin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form onsubmit="submitEditAdmin(event)">
                <input type="hidden" id="edit_admin_id">
                <div class="modal-body p-3" style="max-height: calc(85vh - 120px); overflow-y: auto;">
                    <div class="row">
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" id="edit_admin_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Username <span class="text-danger">*</span></label>
                            <input type="text" id="edit_admin_username" class="form-control" required autocomplete="off">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Password Baru (Opsional)</label>
                            <div class="input-group">
                                <input type="password" id="edit_admin_password" class="form-control" placeholder="Biarkan kosong jika tidak diubah">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('edit_admin_password')"><i class="fas fa-eye"></i></button>
                                </div>
                            </div>
                            <small class="form-text text-muted">Isi hanya jika ingin mengganti password login.</small>
                        </div>
                        <div class="col-md-6 form-group mb-3">
                            <label class="font-weight-normal text-dark mb-1">Role / Jabatan <span class="text-danger">*</span></label>
                            <select id="edit_admin_role_preset" class="form-control mb-1" onchange="applyRolePreset('edit', this.value)">
                                <option value="Super Admin">Super Admin</option>
                                <option value="Proktor">Proktor</option>
                                <option value="Teknisi">Teknisi</option>
                                <option value="Pengawas">Pengawas</option>
                                <option value="Admin Kurikulum">Admin Kurikulum</option>
                                <option value="custom">Kustom (Pilih Manual)</option>
                            </select>
                            <input type="text" id="edit_admin_role" class="form-control" placeholder="Nama Label Role" required>
                        </div>
                    </div>

                    <div id="edit_admin_protection_box" class="alert alert-info py-2 px-3 mb-3 small" style="display: none;">
                        Akun admin utama wajib memiliki izin <strong>Pengaturan & Kelola Admin</strong>.
                    </div>

                    <!-- Checklist Tugas Admin -->
                    <div class="mt-3 pt-3 border-top">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="font-weight-bold mb-0 text-dark">Pilih Tugas Admin</label>
                            <div class="d-flex align-items-center" style="gap: 8px;">
                                <button type="button" class="btn btn-xs btn-link text-primary p-0" onclick="toggleAllTasks('edit', true)" style="text-decoration: none;">Pilih Semua</button>
                                <span class="text-muted small">&bull;</span>
                                <button type="button" class="btn btn-xs btn-link text-secondary p-0" onclick="toggleAllTasks('edit', false)" style="text-decoration: none;">Kosongkan</button>
                                <span class="badge badge-light border text-dark ml-1 font-weight-normal" id="edit_admin_count_badge">0 dipilih</span>
                            </div>
                        </div>
                        <div class="row">
                            <?php foreach ($allSystemTasks as $tKey => $t): ?>
                            <div class="col-md-6 mb-2">
                                <label class="admin-task-card" for="edit_task_<?= $tKey ?>">
                                    <input type="checkbox" class="edit-task-cb" id="edit_task_<?= $tKey ?>" value="<?= $tKey ?>" onchange="onTaskCheckboxChange('edit')">
                                    <span class="task-title"><?= htmlspecialchars($t['name']) ?></span>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer py-2 bg-light">
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary btn-sm" id="btn-submit-edit-admin">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    async function saveSettings(e) {
        if (e) e.preventDefault();
        const btn = (e && e.submitter) ? e.submitter : (document.activeElement?.tagName === 'BUTTON' ? document.activeElement : document.getElementById('btn-save-settings'));
        const originalHtml = btn ? btn.innerHTML : '<i class="fas fa-save mr-2"></i> Simpan Pengaturan';
        if (btn) {
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Menyimpan...';
            btn.disabled = true;
        }
        
        const fd = new FormData();
        fd.append('action', 'save_settings');
        fd.append('school_name', document.getElementById('setting_school_name') ? document.getElementById('setting_school_name').value : '');
        fd.append('require_all_answered', document.getElementById('setting_require_all')?.checked ? 'true' : 'false');
        fd.append('min_time_submit', document.getElementById('setting_min_time')?.value || 0);
        fd.append('require_password', document.getElementById('setting_require_password')?.checked ? 'true' : 'false');
        fd.append('prevent_multi_login', document.getElementById('setting_prevent_multi_login')?.checked ? 'true' : 'false');
        fd.append('show_score', document.getElementById('setting_show_score')?.checked ? 'true' : 'false');
        fd.append('max_violations', document.getElementById('setting_max_violations')?.value || 0);
        fd.append('violation_action', document.getElementById('setting_violation_action')?.value || 'lockout');
        fd.append('lockout_duration', document.getElementById('setting_lockout_duration')?.value || 60);
        fd.append('dynamic_token', document.getElementById('setting_dynamic_token')?.checked ? 'true' : 'false');
        fd.append('dynamic_token_all_exams', document.getElementById('setting_dynamic_token_all_exams')?.checked ? 'true' : 'false');
        fd.append('token_interval_minutes', document.getElementById('setting_token_interval')?.value || 15);
        fd.append('disable_token', (document.getElementById('setting_disable_token')?.checked || document.getElementById('setting_disable_token_tab')?.checked) ? 'true' : 'false');
        const loginMethodEl = document.querySelector('input[name="student_login_method"]:checked');
        fd.append('student_login_method', loginMethodEl ? loginMethodEl.value : 'name_select');
        const syncIntervalEl = document.getElementById('setting_sync_interval');
        fd.append('sync_interval_seconds', syncIntervalEl ? syncIntervalEl.value : '60');
        
        const schoolLogoFile = document.getElementById('setting_school_logo')?.files?.[0];
        if (schoolLogoFile) {
            fd.append('school_logo', schoolLogoFile);
        }
        fd.append('remove_school_logo', document.getElementById('remove_school_logo')?.value || 'false');

        const faviconFile = document.getElementById('setting_favicon')?.files?.[0];
        if (faviconFile) {
            fd.append('favicon', faviconFile);
        }

        const pwaIconFile = document.getElementById('setting_pwa_icon')?.files?.[0];
        if (pwaIconFile) {
            fd.append('pwa_icon', pwaIconFile);
        }
        fd.append('action_pwa_icon', document.getElementById('action_pwa_icon')?.value || '');
        
        try {
            const res = await fetch('api.php', { method: 'POST', body: fd });
            const json = await res.json();
            Swal.fire({
                icon: json.status === 'success' ? 'success' : 'error',
                title: json.status === 'success' ? 'Berhasil' : 'Gagal',
                text: json.message,
                timer: 1500,
                showConfirmButton: false
            }).then(() => {
                if (json.status === 'success') {
                    location.reload();
                }
            });
        } catch (error) {
            Swal.fire('Error', 'Gagal menyimpan pengaturan', 'error');
        } finally {
            if (btn) {
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            }
        }
    }

    function markRemoveLogo() {
        const removeInput = document.getElementById('remove_school_logo');
        if (removeInput) removeInput.value = 'true';
        const wrapper = document.getElementById('wrapper-current-school-logo');
        if (wrapper) wrapper.style.display = 'none';
    }

    function previewCleanPwaIcon(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.getElementById('pwa-icon-preview');
                if (img) img.src = e.target.result;
                const notice = document.getElementById('pwa_clean_notice');
                if (notice) {
                    notice.textContent = 'Ikon baru dipilih. Klik tombol Simpan Pengaturan di bawah.';
                    notice.style.display = 'block';
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    function syncPwaFromLogo() {
        const actionInput = document.getElementById('action_pwa_icon');
        if (actionInput) actionInput.value = 'sync_logo';
        const logoImg = document.querySelector('#wrapper-current-school-logo img');
        const pwaImg = document.getElementById('pwa-icon-preview');
        if (logoImg && pwaImg) {
            pwaImg.src = logoImg.src;
        }
        const notice = document.getElementById('pwa_clean_notice');
        if (notice) {
            notice.textContent = 'Ikon akan disamakan dengan Logo Sekolah saat disimpan.';
            notice.style.display = 'block';
        }
    }

    function resetPwaToDefault() {
        const actionInput = document.getElementById('action_pwa_icon');
        if (actionInput) actionInput.value = 'reset_default';
        const pwaImg = document.getElementById('pwa-icon-preview');
        if (pwaImg) {
            pwaImg.src = 'icon-192.default.png?v=' + Date.now();
        }
        const notice = document.getElementById('pwa_clean_notice');
        if (notice) {
            notice.textContent = 'Ikon akan dikembalikan ke default saat disimpan.';
            notice.style.display = 'block';
        }
    }

    function setTokenIntervalPreset(minutes) {
        const input = document.getElementById('setting_token_interval');
        if (input) {
            input.value = minutes;
        }
    }

    function updateSqlFileName(input) {
        const label = document.getElementById('label-file-backup');
        if (label && input.files.length) {
            label.textContent = input.files[0].name;
        }
    }

    function backupDatabase() {
        const btn = document.getElementById('btn-backup');
        const origHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Membuat File Backup .sql...';
        btn.disabled = true;
        
        // Membuka URL unduhan file .sql MySQL
        window.location.href = 'api.php?action=backup_database_mysql';
        
        setTimeout(() => {
            btn.innerHTML = origHtml;
            btn.disabled = false;
        }, 3000);
    }
    
    async function restoreDatabase(e) {
        e.preventDefault();
        
        const fileInput = document.getElementById('file_backup');
        if (!fileInput.files.length) {
            Swal.fire('Peringatan', 'Silakan pilih file backup .sql terlebih dahulu!', 'warning');
            return;
        }

        const fileName = fileInput.files[0].name;
        if (!fileName.toLowerCase().endsWith('.sql')) {
            Swal.fire('Format Salah', 'Harap pilih file dengan ekstensi .sql!', 'error');
            return;
        }
        
        const result = await Swal.fire({
            title: 'Konfirmasi Restore MySQL',
            html: `Apakah Anda yakin ingin menimpa seluruh database dengan file <strong>${fileName}</strong>?<br><small class="text-danger">Seluruh data yang ada saat ini akan digantikan dengan isi file backup.</small>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: '<i class="fas fa-upload mr-1"></i> Ya, Restore Sekarang',
            cancelButtonText: 'Batal'
        });

        if (!result.isConfirmed) {
            return;
        }
        
        const btn = document.getElementById('btn-restore');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Menjalankan Query SQL...';
        btn.disabled = true;

        Swal.fire({
            title: 'Memproses Restore Database',
            html: 'Sedang mengeksekusi struktur tabel dan sinkronisasi Dual Live-Sync data soal... Harap tunggu.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        
        const formData = new FormData();
        formData.append('action', 'restore_database_mysql');
        formData.append('sql_file', fileInput.files[0]);
        
        try {
            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();
            
            if (res.status === 'success') {
                await Swal.fire({
                    title: 'Restore Berhasil!',
                    text: res.message,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
                window.location.reload();
            } else {
                Swal.fire('Gagal Restore', res.message || 'Terjadi kesalahan saat mengeksekusi SQL.', 'error');
            }
        } catch (error) {
            console.error(error);
            Swal.fire('Kesalahan Koneksi', 'Gagal menghubungi server. Pastikan koneksi dan ukuran file memenuhi batas upload server.', 'error');
        } finally {
            btn.innerHTML = '<i class="fas fa-upload mr-2"></i> Mulai Restore Database MySQL';
            btn.disabled = false;
            fileInput.value = '';
            const label = document.getElementById('label-file-backup');
            if (label) label.textContent = 'Pilih file .sql...';
        }
    }

    function toggleSelectAllPurge(status) {
        const checkboxes = document.querySelectorAll('.purge-item');
        checkboxes.forEach(cb => cb.checked = status);
        const master = document.getElementById('check_purge_all');
        if (master) master.checked = status;
    }

    function onMasterCheckPurgeChange(master) {
        toggleSelectAllPurge(master.checked);
    }

    // Listener otomatis untuk mengupdate master checkbox jika semua item tercentang/tidak
    document.addEventListener('DOMContentLoaded', function() {
        const purgeItems = document.querySelectorAll('.purge-item');
        const master = document.getElementById('check_purge_all');
        if (purgeItems.length && master) {
            purgeItems.forEach(cb => {
                cb.addEventListener('change', function() {
                    const allChecked = Array.from(purgeItems).every(item => item.checked);
                    master.checked = allChecked;
                });
            });
        }
    });

    async function executePurgeData() {
        const checkedItems = Array.from(document.querySelectorAll('.purge-item:checked'));
        if (checkedItems.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Pilih Data',
                text: 'Silakan centang minimal satu kategori data yang ingin dihapus!'
            });
            return;
        }

        const targetNames = {
            'results': 'Hasil Ujian & Nilai Siswa',
            'sessions': 'Sesi Ujian Aktif',
            'exams': 'Jadwal Ujian',
            'questions': 'Bank Soal & Butir Soal',
            'students': 'Data Siswa',
            'classes': 'Data Kelas',
            'gurus': 'Data Akun Guru'
        };

        const listHtml = checkedItems.map(cb => `<li><strong>${targetNames[cb.value] || cb.value}</strong></li>`).join('');

        const isAll = checkedItems.length === document.querySelectorAll('.purge-item').length;
        const confirmTitle = isAll ? 'HAPUS SEMUA DATA SISTEM?' : 'Hapus Data Terpilih?';

        const result = await Swal.fire({
            title: confirmTitle,
            html: `
                <div class="text-left">
                    <p class="text-danger font-weight-bold mb-2"><i class="fas fa-exclamation-triangle mr-1"></i> PERINGATAN: Tindakan ini TIDAK DAPAT DIBATALKAN!</p>
                    <p class="mb-2">Kategori data berikut akan dihapus secara permanen dari database:</p>
                    <ul class="text-danger mb-3" style="padding-left: 20px; line-height: 1.6;">
                        ${listHtml}
                    </ul>
                    <p class="small text-muted mb-0">Pastikan Anda telah membuat cadangan (backup .sql) terlebih dahulu jika data sewaktu-waktu masih dibutuhkan.</p>
                </div>
            `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: '<i class="fas fa-trash-alt mr-1"></i> Ya, Hapus Sekarang',
            cancelButtonText: 'Batal',
            focusCancel: true
        });

        if (!result.isConfirmed) return;

        const btn = document.getElementById('btn-purge-data');
        const origHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Menghapus Data...';
        btn.disabled = true;

        Swal.fire({
            title: 'Menghapus Data...',
            text: 'Sedang mengosongkan tabel data terpilih di database. Harap tunggu...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        const fd = new FormData();
        fd.append('action', 'purge_database_data');
        checkedItems.forEach(cb => {
            fd.append('targets[]', cb.value);
        });

        try {
            const res = await fetch('api.php', { method: 'POST', body: fd });
            const json = await res.json();

            if (json.status === 'success') {
                sessionStorage.setItem('activeSettingTab', '#content-database');
                await Swal.fire({
                    icon: 'success',
                    title: 'Berhasil Dikosongkan!',
                    text: json.message,
                    timer: 2000,
                    showConfirmButton: true
                });
                window.location.reload();
            } else {
                Swal.fire('Gagal Menghapus Data', json.message || 'Terjadi kesalahan sistem.', 'error');
            }
        } catch (err) {
            console.error(err);
            Swal.fire('Kesalahan Sistem', 'Gagal memproses permintaan: ' + err.message, 'error');
        } finally {
            btn.innerHTML = origHtml;
            btn.disabled = false;
        }
    }

    function toggleDynamicTokenInterval(checkbox) {
        const wrapper = document.getElementById('wrapper_token_interval');
        if (wrapper) {
            wrapper.style.display = checkbox.checked ? 'block' : 'none';
        }
    }

    function syncDisableToken(el) {
        const checked = el.checked;
        const el1 = document.getElementById('setting_disable_token');
        const el2 = document.getElementById('setting_disable_token_tab');
        if (el1) el1.checked = checked;
        if (el2) el2.checked = checked;
    }

    function togglePasswordVisibility(inputId) {
        const input = document.getElementById(inputId);
        if (!input) return;
        if (input.type === 'password') {
            input.type = 'text';
        } else {
            input.type = 'password';
        }
    }


    const ADMIN_ROLE_PRESETS = {
        'Super Admin': {
            title: 'Super Admin',
            tasks: ['dashboard', 'kelas', 'siswa', 'guru', 'mata_pelajaran', 'jenis_ujian', 'soal', 'mapel', 'cetak_kartu', 'status', 'analisis', 'pengaturan', 'log', 'panduan']
        },
        'Proktor': {
            title: 'Proktor',
            tasks: ['dashboard', 'soal', 'mapel', 'cetak_kartu', 'status', 'analisis', 'panduan']
        },
        'Teknisi': {
            title: 'Teknisi',
            tasks: ['dashboard', 'kelas', 'siswa', 'status', 'pengaturan', 'log', 'panduan']
        },
        'Pengawas': {
            title: 'Pengawas',
            tasks: ['dashboard', 'status', 'panduan']
        },
        'Admin Kurikulum': {
            title: 'Admin Kurikulum',
            tasks: ['dashboard', 'kelas', 'mata_pelajaran', 'jenis_ujian', 'soal', 'mapel', 'analisis', 'panduan']
        }
    };

    function resetAddAdminForm() {
        document.getElementById('add_admin_name').value = '';
        document.getElementById('add_admin_username').value = '';
        document.getElementById('add_admin_password').value = '';
        document.getElementById('add_admin_role_preset').value = 'Super Admin';
        document.getElementById('add_admin_role').value = 'Super Admin';
        toggleAllTasks('add', true);
    }

    function applyRolePreset(type, presetKey) {
        const roleInput = document.getElementById(type + '_admin_role');
        const prefix = type + '-task-cb';
        const checkboxes = document.querySelectorAll('.' + prefix);

        if (presetKey === 'custom') {
            if (roleInput && (!roleInput.value || roleInput.value === 'Super Admin')) {
                roleInput.value = 'Admin Kustom';
            }
            updateTaskCount(type);
            return;
        }

        const preset = ADMIN_ROLE_PRESETS[presetKey];
        if (preset) {
            if (roleInput) {
                roleInput.value = preset.title;
            }
            checkboxes.forEach(cb => {
                if (!cb.disabled) {
                    cb.checked = preset.tasks.includes(cb.value);
                }
            });
            updateTaskCount(type);
        }
    }

    function toggleAllTasks(type, check) {
        const prefix = type + '-task-cb';
        const checkboxes = document.querySelectorAll('.' + prefix);
        checkboxes.forEach(cb => {
            if (!cb.disabled) {
                cb.checked = check;
            }
        });
        const select = document.getElementById(type + '_admin_role_preset');
        if (select) {
            select.value = check ? 'Super Admin' : 'custom';
        }
        updateTaskCount(type);
    }

    function updateTaskCount(type) {
        const prefix = type + '-task-cb';
        const checkboxes = document.querySelectorAll('.' + prefix);
        const checked = Array.from(checkboxes).filter(cb => cb.checked);
        const countBadge = document.getElementById(type + '_admin_count_badge');
        if (countBadge) {
            countBadge.textContent = `${checked.length} dipilih`;
            if (checked.length === checkboxes.length) {
                countBadge.className = 'badge badge-success px-2 py-1 font-weight-normal';
            } else if (checked.length === 0) {
                countBadge.className = 'badge badge-secondary px-2 py-1 font-weight-normal';
            } else {
                countBadge.className = 'badge badge-light border text-dark px-2 py-1 font-weight-normal';
            }
        }
    }

    function onTaskCheckboxChange(type) {
        updateTaskCount(type);
        const prefix = type + '-task-cb';
        const checkboxes = document.querySelectorAll('.' + prefix);
        const checkedValues = Array.from(checkboxes).filter(cb => cb.checked).map(cb => cb.value).sort();
        
        let matchedPreset = 'custom';
        for (const [key, p] of Object.entries(ADMIN_ROLE_PRESETS)) {
            const pTasks = [...p.tasks].sort();
            if (checkedValues.length === pTasks.length && checkedValues.every((val, idx) => val === pTasks[idx])) {
                matchedPreset = key;
                break;
            }
        }
        const select = document.getElementById(type + '_admin_role_preset');
        if (select) {
            select.value = matchedPreset;
        }
    }

    async function submitAddAdmin(e) {
        e.preventDefault();
        const name = document.getElementById('add_admin_name').value.trim();
        const username = document.getElementById('add_admin_username').value.trim();
        const password = document.getElementById('add_admin_password').value;
        const role = document.getElementById('add_admin_role').value.trim() || 'Admin';

        const checkedBoxes = Array.from(document.querySelectorAll('.add-task-cb:checked')).map(cb => cb.value);
        if (checkedBoxes.length === 0) {
            Swal.fire('Peringatan', 'Silakan pilih minimal 1 tugas / menu hak akses dengan menceklis tugas yang tersedia!', 'warning');
            return;
        }

        const btn = document.getElementById('btn-submit-add-admin');
        const origHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Menyimpan...';
        btn.disabled = true;

        const fd = new FormData();
        fd.append('action', 'add_admin');
        fd.append('name', name);
        fd.append('username', username);
        fd.append('password', password);
        fd.append('admin_role', role);
        checkedBoxes.forEach(task => {
            fd.append('permissions[]', task);
        });

        try {
            const res = await fetch('api.php', { method: 'POST', body: fd });
            const json = await res.json();
            if (json.status === 'success') {
                $('#modalAddAdmin').modal('hide');
                sessionStorage.setItem('activeSettingTab', '#content-admin');
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: json.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => location.reload());
            } else {
                Swal.fire('Gagal', json.message || 'Terjadi kesalahan.', 'error');
            }
        } catch (err) {
            Swal.fire('Error', 'Gagal menambahkan admin: ' + err.message, 'error');
        } finally {
            btn.innerHTML = origHtml;
            btn.disabled = false;
        }
    }

    function openEditAdminModal(adm) {
        if (!adm) return;
        document.getElementById('edit_admin_id').value = adm.id;
        document.getElementById('edit_admin_name').value = adm.name || '';
        document.getElementById('edit_admin_username').value = adm.username || '';
        document.getElementById('edit_admin_password').value = '';
        
        const roleTitle = adm.admin_role || 'Super Admin';
        document.getElementById('edit_admin_role').value = roleTitle;

        // Cek apakah akun admin utama (username admin)
        const isMainAdmin = (adm.username && adm.username.toLowerCase() === 'admin');
        const protBox = document.getElementById('edit_admin_protection_box');
        if (protBox) {
            protBox.style.display = isMainAdmin ? 'block' : 'none';
        }

        // Tentukan permissions
        let perms = [];
        const allTaskKeys = ADMIN_ROLE_PRESETS['Super Admin'].tasks;
        if (!adm.permissions || adm.permissions === 'all') {
            perms = allTaskKeys;
            document.querySelectorAll('.edit-task-cb').forEach(cb => {
                cb.checked = true;
                cb.disabled = false;
            });
        } else {
            try {
                perms = (typeof adm.permissions === 'string') ? JSON.parse(adm.permissions) : adm.permissions;
            } catch (e) {
                perms = adm.permissions.split(',').map(s => s.trim());
            }
            if (!Array.isArray(perms)) perms = [];
            
            document.querySelectorAll('.edit-task-cb').forEach(cb => {
                cb.checked = perms.includes(cb.value);
                cb.disabled = false;
            });
        }

        // Jika akun admin utama, kunci tugas 'pengaturan' agar selalu aktif
        if (isMainAdmin) {
            const cbPengaturan = document.getElementById('edit_task_pengaturan');
            if (cbPengaturan) {
                cbPengaturan.checked = true;
                cbPengaturan.disabled = true;
            }
        }

        onTaskCheckboxChange('edit');
        $('#modalEditAdmin').modal('show');
    }

    async function submitEditAdmin(e) {
        e.preventDefault();
        const id = document.getElementById('edit_admin_id').value;
        const name = document.getElementById('edit_admin_name').value.trim();
        const username = document.getElementById('edit_admin_username').value.trim();
        const password = document.getElementById('edit_admin_password').value;
        const role = document.getElementById('edit_admin_role').value.trim() || 'Admin';

        // Ambil semua task terpilih termasuk yang disabled
        const checkedBoxes = Array.from(document.querySelectorAll('.edit-task-cb'))
            .filter(cb => cb.checked)
            .map(cb => cb.value);

        if (checkedBoxes.length === 0) {
            Swal.fire('Peringatan', 'Silakan pilih minimal 1 tugas / menu hak akses dengan menceklis tugas yang tersedia!', 'warning');
            return;
        }

        const btn = document.getElementById('btn-submit-edit-admin');
        const origHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Menyimpan...';
        btn.disabled = true;

        const fd = new FormData();
        fd.append('action', 'edit_admin');
        fd.append('id', id);
        fd.append('name', name);
        fd.append('username', username);
        fd.append('admin_role', role);
        if (password) {
            fd.append('password', password);
        }
        checkedBoxes.forEach(task => {
            fd.append('permissions[]', task);
        });

        try {
            const res = await fetch('api.php', { method: 'POST', body: fd });
            const json = await res.json();
            if (json.status === 'success') {
                $('#modalEditAdmin').modal('hide');
                sessionStorage.setItem('activeSettingTab', '#content-admin');
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: json.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => location.reload());
            } else {
                Swal.fire('Gagal', json.message || 'Terjadi kesalahan.', 'error');
            }
        } catch (err) {
            Swal.fire('Error', 'Gagal mengubah data admin: ' + err.message, 'error');
        } finally {
            btn.innerHTML = origHtml;
            btn.disabled = false;
        }
    }

    async function deleteAdmin(id, name) {
        const result = await Swal.fire({
            title: 'Hapus Admin?',
            text: `Yakin ingin menghapus akun admin "${name}"?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal'
        });

        if (!result.isConfirmed) return;

        const fd = new FormData();
        fd.append('action', 'delete_admin');
        fd.append('id', id);

        try {
            const res = await fetch('api.php', { method: 'POST', body: fd });
            const json = await res.json();
            if (json.status === 'success') {
                sessionStorage.setItem('activeSettingTab', '#content-admin');
                Swal.fire({
                    icon: 'success',
                    title: 'Terhapus!',
                    text: json.message,
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => location.reload());
            } else {
                Swal.fire('Gagal', json.message || 'Terjadi kesalahan.', 'error');
            }
        } catch (err) {
            Swal.fire('Error', 'Gagal menghapus admin: ' + err.message, 'error');
        }
    }

    $(document).ready(function() {
        const activeTab = sessionStorage.getItem('activeSettingTab');
        if (activeTab) {
            $('#setting-tabs a[href="' + activeTab + '"]').tab('show');
        }
        $('#setting-tabs a').on('shown.bs.tab', function(e) {
            sessionStorage.setItem('activeSettingTab', $(e.target).attr('href'));
        });
    });
</script>
