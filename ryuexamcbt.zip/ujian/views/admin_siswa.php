<div id="section-siswa" class="content-section">
    <div class="card card-outline card-info mt-4">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap" style="gap: 8px;">
            <h3 class="card-title mb-0">Daftar Siswa</h3>
            <div>
                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#modalImportSiswa" title="Impor Data Siswa">
                    <i class="fas fa-file-excel mr-1"></i> Impor
                </button>
                <button class="btn btn-success btn-sm ml-1" onclick="exportExcelSiswa()" title="Ekspor Data Siswa ke Excel (.xlsx)">
                    <i class="fas fa-file-export mr-1"></i> Ekspor
                </button>
                <button class="btn btn-primary btn-sm ml-1" data-toggle="modal" data-target="#modalAddSiswa" title="Tambah Siswa Manual">
                    <i class="fas fa-plus mr-1"></i> Tambah
                </button>
                <button class="btn btn-warning btn-sm ml-1" onclick="setAllPasswords()" title="Generate Password Siswa (Sama Semua / Random 6 Angka)">
                    <i class="fas fa-key mr-1"></i> Password
                </button>
                <button class="btn btn-danger btn-sm ml-1" onclick="bulkDeleteStudents()" title="Hapus Siswa Terpilih">
                    <i class="fas fa-trash mr-1"></i> Hapus
                </button>
                <button class="btn btn-info btn-sm ml-1" onclick="bulkResetStudents()" title="Reset Siswa Terpilih">
                    <i class="fas fa-sync-alt mr-1"></i> Reset
                </button>
                <a href="?page=cetak_kartu" class="btn btn-outline-info btn-sm ml-1" title="Cetak Kartu Peserta Ujian (F4)">
                    <i class="fas fa-id-card mr-1"></i> Cetak Kartu
                </a>
            </div>
        </div>
        <!-- Toolbar: Search & Tampilkan Per Halaman -->
        <div class="px-3 py-2 border-bottom bg-light">
            <div class="row align-items-center">
                <div class="col-12 col-sm-6 d-flex align-items-center mb-2 mb-sm-0">
                    <label class="mb-0 mr-2 text-muted" style="white-space: nowrap; font-size: 0.9rem;">Tampilkan:</label>
                    <select id="siswa-per-page" class="form-control form-control-sm" style="width: auto; min-width: 90px;" onchange="changeSiswaPerPage()">
                        <option value="all">Semua</option>
                        <option value="10" selected>10</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    <span class="ml-2 text-muted" style="font-size: 0.9rem;">data</span>
                </div>
                <div class="col-12 col-sm-6 d-flex justify-content-sm-end">
                    <div class="input-group input-group-sm" style="max-width: 320px; width: 100%;">
                        <input type="text" id="siswa-search-input" class="form-control" placeholder="Cari siswa (nama, no peserta, kelas, ruang, ID)..." oninput="filterSiswaSearch()" onsearch="filterSiswaSearch()">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="button" id="btn-clear-search" onclick="clearSiswaSearch()" style="display:none;" title="Hapus pencarian">
                                <i class="fas fa-times"></i>
                            </button>
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<style>
    th.sortable-th {
        cursor: pointer;
        user-select: none;
        white-space: nowrap;
        transition: background-color 0.15s ease, color 0.15s ease;
    }
    th.sortable-th:hover {
        background-color: #f1f5f9 !important;
        color: #007bff;
    }
    th.sortable-th i.sort-icon {
        font-size: 0.75rem;
        margin-left: 4px;
        opacity: 0.45;
        transition: opacity 0.15s ease;
    }
    th.sortable-th:hover i.sort-icon {
        opacity: 0.9;
    }
    th.sortable-th.active-sort {
        color: #007bff;
    }
    th.sortable-th.active-sort i.sort-icon {
        opacity: 1;
    }
</style>
        <div class="card-body p-0" style="overflow-x: auto;">
            <table class="table table-striped table-bordered mb-0">
                <thead style="position: sticky; top: 0; background: #fff; z-index: 1;">
                    <tr>
                        <th style="width: 40px"><input type="checkbox" id="cb-all-students" onchange="toggleAllStudents()"></th>
                        <th class="sortable-th" style="width: 70px" onclick="sortSiswaTable('id')" title="Urutkan berdasarkan ID">
                            ID <i id="sort-icon-id" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th class="sortable-th" onclick="sortSiswaTable('no_peserta')" title="Urutkan berdasarkan No Peserta">
                            No Peserta <i id="sort-icon-no_peserta" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th class="sortable-th" onclick="sortSiswaTable('username')" title="Urutkan berdasarkan Username">
                            Username <i id="sort-icon-username" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th class="sortable-th" onclick="sortSiswaTable('name')" title="Urutkan berdasarkan Nama Siswa">
                            Nama Siswa <i id="sort-icon-name" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th class="sortable-th" onclick="sortSiswaTable('class')" title="Urutkan berdasarkan Kelas">
                            Kelas <i id="sort-icon-class" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th class="sortable-th" onclick="sortSiswaTable('ruang')" title="Urutkan berdasarkan Ruang">
                            Ruang <i id="sort-icon-ruang" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th class="sortable-th" onclick="sortSiswaTable('password')" title="Urutkan berdasarkan Password">
                            Password <i id="sort-icon-password" class="fas fa-sort sort-icon text-muted"></i>
                        </th>
                        <th style="width: 160px">Aksi</th>
                    </tr>
                </thead>
                <tbody id="tbody-siswa">
                    <?php 
                    $classMap = [];
                    foreach($classes as $c) { $classMap[$c['id']] = $c['name']; }
                    foreach ($all_students as $s): 
                        $cName = $classMap[$s['class_id']] ?? 'Tidak Diketahui';
                        $sUsername = $s['username'] ?? ('siswa' . $s['id']);
                        $sRuang = $s['ruang'] ?? '';
                        $sNoPeserta = $s['no_peserta'] ?? '';
                    ?>
                    <tr class="student-row"
                        data-id="<?= $s['id'] ?>"
                        data-no-peserta="<?= htmlspecialchars(strtolower($sNoPeserta)) ?>"
                        data-username="<?= htmlspecialchars(strtolower($sUsername)) ?>"
                        data-name="<?= htmlspecialchars(strtolower($s['name'])) ?>"
                        data-class="<?= htmlspecialchars(strtolower($cName)) ?>"
                        data-ruang="<?= htmlspecialchars(strtolower($sRuang)) ?>"
                        data-password="<?= htmlspecialchars(strtolower($s['password'] ?? '')) ?>">
                        <td><input type="checkbox" class="cb-student-row" value="<?= $s['id'] ?>" onchange="toggleStudentSelection(this)"></td>
                        <td><?= $s['id'] ?></td>
                        <td>
                            <?php if (!empty($sNoPeserta)): ?>
                                <span class="badge badge-light border text-dark font-weight-bold" style="font-family: monospace; font-size: 0.88rem;"><?= htmlspecialchars($sNoPeserta) ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-light border text-primary" style="font-family: monospace; font-size: 0.9rem;"><?= htmlspecialchars($sUsername) ?></span></td>
                        <td><?= htmlspecialchars($s['name']) ?></td>
                        <td><?= htmlspecialchars($cName) ?></td>
                        <td>
                            <?php if (!empty($sRuang)): ?>
                                <span class="badge badge-info" style="font-size: 0.85rem;"><i class="fas fa-door-open mr-1"></i><?= htmlspecialchars($sRuang) ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($s['password'] ?? '') ?></td>
                        <td>
                            <button class="btn btn-info btn-sm" onclick="resetLogin(<?= $s['id'] ?>)" title="Reset Login"><i class="fas fa-sync-alt"></i></button>
                            <button class="btn btn-warning btn-sm" onclick="editStudent(<?= $s['id'] ?>, '<?= htmlspecialchars(addslashes($sUsername)) ?>', '<?= htmlspecialchars(addslashes($s['name'])) ?>', <?= $s['class_id'] ?>, '<?= htmlspecialchars(addslashes($s['password'] ?? '')) ?>', '<?= htmlspecialchars(addslashes($sRuang)) ?>', '<?= htmlspecialchars(addslashes($sNoPeserta)) ?>')" title="Edit"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStudent(<?= $s['id'] ?>)" title="Hapus"><i class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <tr id="no-search-results" style="display: none;">
                        <td colspan="9" class="text-center py-4 text-muted">
                            <i class="fas fa-search mr-1"></i> Tidak ada data siswa yang cocok dengan pencarian.
                        </td>
                    </tr>
                    <?php if(empty($all_students)): ?>
                        <tr id="no-students-data"><td colspan="9" class="text-center">Belum ada siswa</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer clearfix d-flex flex-wrap justify-content-between align-items-center py-2" id="siswa-pagination-container">
            <div id="siswa-page-info" class="text-muted my-1" style="font-size: 0.9em;">
                Menampilkan data...
            </div>
            <ul class="pagination pagination-sm m-0 my-1" id="siswa-pagination">
            </ul>
        </div>
    </div>

    <!-- Modal Add Siswa -->
    <div class="modal fade" id="modalAddSiswa" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form method="POST">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Siswa Manual</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label>Pilih Kelas</label>
                            <select name="class_id" class="form-control" required>
                                <option value="" disabled selected>Pilih Kelas</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label>Username Siswa</label>
                            <input type="text" name="student_username" class="form-control" placeholder="Contoh: siswa1, 24001, nisn123 (Opsional)">
                            <small class="form-text text-muted">Jika dikosongkan, username otomatis diisi <code>siswa{ID}</code>.</small>
                        </div>
                        <div class="form-group mb-3">
                            <label>Nama Lengkap Siswa</label>
                            <input type="text" name="student_name" class="form-control" placeholder="Masukkan nama..." required>
                        </div>
                        <div class="form-group mb-3">
                            <label>No Peserta Ujian</label>
                            <input type="text" name="student_no_peserta" class="form-control" placeholder="Contoh: 01-001-001-8 (Opsional)">
                        </div>
                        <div class="form-group mb-3">
                            <label>Ruang Ujian</label>
                            <input type="text" name="student_ruang" class="form-control" placeholder="Contoh: Ruang 1, R.01 (Opsional)">
                        </div>
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <input type="text" name="student_password" class="form-control" placeholder="Opsional...">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="add_student" class="btn btn-primary">Simpan Siswa</button>
                    </div>
                </div>
            </form>
        </div>
        </div>
    </div>

    <!-- Modal Import Siswa -->
    <div class="modal fade" id="modalImportSiswa" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form id="form-import-siswa" onsubmit="importExcelSiswa(event)">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Impor Data Siswa (Excel)</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="file_siswa">File Excel (.xlsx)</label>
                            <input type="file" id="file_siswa" class="form-control-file" accept=".xlsx, .xls" required>
                            <small class="text-muted mt-2 d-block">File Excel dapat memiliki kolom <strong>No Peserta</strong>, <strong>Username</strong>, <strong>Nama</strong>, <strong>Kelas</strong>, <strong>Ruang</strong>, dan <strong>Password</strong> di baris pertama.</small>
                            <button type="button" class="btn btn-sm btn-info mt-2" onclick="downloadTemplateSiswa()">
                                <i class="fas fa-download mr-1"></i> Download Template Excel
                            </button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" id="btn-import-siswa" class="btn btn-success"><i class="fas fa-file-excel mr-1"></i> Impor Siswa</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Edit Siswa -->
    <div class="modal fade" id="modalEditSiswa" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form method="POST">
                <input type="hidden" name="edit_student_id" id="edit_student_id">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Siswa</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label>Pilih Kelas</label>
                            <select name="class_id" id="edit_class_id" class="form-control" required>
                                <option value="" disabled>Pilih Kelas</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label>Username Siswa</label>
                            <input type="text" name="student_username" id="edit_student_username" class="form-control" placeholder="Username siswa..." required>
                        </div>
                        <div class="form-group mb-3">
                            <label>Nama Lengkap Siswa</label>
                            <input type="text" name="student_name" id="edit_student_name" class="form-control" required>
                        </div>
                        <div class="form-group mb-3">
                            <label>No Peserta Ujian</label>
                            <input type="text" name="student_no_peserta" id="edit_student_no_peserta" class="form-control" placeholder="Contoh: 01-001-001-8 (Opsional)">
                        </div>
                        <div class="form-group mb-3">
                            <label>Ruang Ujian</label>
                            <input type="text" name="student_ruang" id="edit_student_ruang" class="form-control" placeholder="Contoh: Ruang 1, R.01 (Opsional)">
                        </div>
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <input type="text" name="student_password" id="edit_student_password" class="form-control" placeholder="Opsional...">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" name="edit_student" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const rawStudentsData = <?= json_encode(array_values(array_map(function($s) use ($classMap) {
    return [
        'id' => (int)$s['id'],
        'no_peserta' => $s['no_peserta'] ?? '',
        'username' => $s['username'] ?? ('siswa' . $s['id']),
        'name' => $s['name'] ?? '',
        'class' => $classMap[$s['class_id']] ?? 'Tidak Diketahui',
        'ruang' => $s['ruang'] ?? '',
        'password' => $s['password'] ?? ''
    ];
}, $all_students))) ?>;
const schoolNameExport = <?= json_encode(!empty($settings['school_name']) ? $settings['school_name'] : 'CBT') ?>;

let selectedStudentIds = new Set();
let siswaCurrentPage = 1;
let siswaPerPage = '10';
let siswaSearchQuery = '';
let siswaSortColumn = 'id';
let siswaSortDirection = 'asc';

function escapeHtml(str) {
    return (str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function initSiswaTable() {
    const savedPerPage = localStorage.getItem('admin_siswa_per_page');
    if (savedPerPage && ['all', '10', '50', '100'].includes(savedPerPage)) {
        siswaPerPage = savedPerPage;
        const selectEl = document.getElementById('siswa-per-page');
        if (selectEl) selectEl.value = savedPerPage;
    } else {
        const selectEl = document.getElementById('siswa-per-page');
        if (selectEl) siswaPerPage = selectEl.value;
    }

    const savedSortCol = localStorage.getItem('admin_siswa_sort_col');
    const savedSortDir = localStorage.getItem('admin_siswa_sort_dir');
    if (savedSortCol && ['id', 'no_peserta', 'username', 'name', 'class', 'ruang', 'password'].includes(savedSortCol)) {
        siswaSortColumn = savedSortCol;
    }
    if (savedSortDir && ['asc', 'desc'].includes(savedSortDir)) {
        siswaSortDirection = savedSortDir;
    }

    applySiswaSort();
    renderSiswaTable();
}

function sortSiswaTable(column) {
    if (siswaSortColumn === column) {
        siswaSortDirection = (siswaSortDirection === 'asc') ? 'desc' : 'asc';
    } else {
        siswaSortColumn = column;
        siswaSortDirection = 'asc';
    }
    
    localStorage.setItem('admin_siswa_sort_col', siswaSortColumn);
    localStorage.setItem('admin_siswa_sort_dir', siswaSortDirection);
    
    applySiswaSort();
    siswaCurrentPage = 1;
    renderSiswaTable();
}

function updateSortIcons() {
    const columns = ['id', 'no_peserta', 'username', 'name', 'class', 'ruang', 'password'];
    columns.forEach(col => {
        const icon = document.getElementById('sort-icon-' + col);
        if (!icon) return;
        const th = icon.closest('th');
        if (col === siswaSortColumn) {
            if (th) th.classList.add('active-sort');
            if (siswaSortDirection === 'asc') {
                icon.className = 'fas fa-sort-up sort-icon text-primary';
            } else {
                icon.className = 'fas fa-sort-down sort-icon text-primary';
            }
        } else {
            if (th) th.classList.remove('active-sort');
            icon.className = 'fas fa-sort sort-icon text-muted';
        }
    });
}

function applySiswaSort() {
    const tbody = document.getElementById('tbody-siswa');
    if (!tbody) return;
    
    const rows = Array.from(tbody.querySelectorAll('.student-row'));
    if (rows.length === 0) return;
    
    const noResultsRow = document.getElementById('no-search-results');
    const noDataRow = document.getElementById('no-students-data');
    
    const dataAttrMap = {
        'id': 'data-id',
        'no_peserta': 'data-no-peserta',
        'username': 'data-username',
        'name': 'data-name',
        'class': 'data-class',
        'ruang': 'data-ruang',
        'password': 'data-password'
    };
    
    const attrName = dataAttrMap[siswaSortColumn] || 'data-id';
    
    rows.sort((a, b) => {
        let valA = a.getAttribute(attrName) || '';
        let valB = b.getAttribute(attrName) || '';
        
        let comparison = 0;
        if (siswaSortColumn === 'id') {
            const intA = parseInt(valA, 10) || 0;
            const intB = parseInt(valB, 10) || 0;
            comparison = intA - intB;
        } else {
            comparison = valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' });
        }
        
        return (siswaSortDirection === 'asc') ? comparison : -comparison;
    });
    
    const referenceNode = noResultsRow || noDataRow || null;
    rows.forEach(row => {
        tbody.insertBefore(row, referenceNode);
    });
    
    updateSortIcons();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSiswaTable);
} else {
    initSiswaTable();
}

function changeSiswaPerPage() {
    const selectEl = document.getElementById('siswa-per-page');
    siswaPerPage = selectEl.value;
    localStorage.setItem('admin_siswa_per_page', siswaPerPage);
    siswaCurrentPage = 1;
    renderSiswaTable();
}

function filterSiswaSearch() {
    const input = document.getElementById('siswa-search-input');
    siswaSearchQuery = input.value.trim().toLowerCase();
    
    const clearBtn = document.getElementById('btn-clear-search');
    if (clearBtn) {
        clearBtn.style.display = siswaSearchQuery ? 'inline-block' : 'none';
    }
    
    siswaCurrentPage = 1;
    renderSiswaTable();
}

function clearSiswaSearch() {
    const input = document.getElementById('siswa-search-input');
    input.value = '';
    siswaSearchQuery = '';
    const clearBtn = document.getElementById('btn-clear-search');
    if (clearBtn) clearBtn.style.display = 'none';
    siswaCurrentPage = 1;
    renderSiswaTable();
    input.focus();
}

function changeSiswaPage(page) {
    siswaCurrentPage = page;
    renderSiswaTable();
}

function renderSiswaTable() {
    const allRows = Array.from(document.querySelectorAll('.student-row'));
    const totalOriginal = allRows.length;
    
    const matchedRows = allRows.filter(row => {
        if (!siswaSearchQuery) return true;
        const name = row.getAttribute('data-name') || '';
        const noPeserta = row.getAttribute('data-no-peserta') || '';
        const usr = row.getAttribute('data-username') || '';
        const cls = row.getAttribute('data-class') || '';
        const id = row.getAttribute('data-id') || '';
        const pwd = row.getAttribute('data-password') || '';
        const ruang = row.getAttribute('data-ruang') || '';
        return name.includes(siswaSearchQuery) || 
               noPeserta.includes(siswaSearchQuery) || 
               usr.includes(siswaSearchQuery) ||
               cls.includes(siswaSearchQuery) || 
               id.includes(siswaSearchQuery) || 
               pwd.includes(siswaSearchQuery) ||
               ruang.includes(siswaSearchQuery);
    });
    
    const totalMatched = matchedRows.length;
    const isAll = (siswaPerPage === 'all');
    const pageSize = isAll ? totalMatched : parseInt(siswaPerPage, 10);
    const totalPages = isAll ? 1 : (pageSize > 0 ? Math.ceil(totalMatched / pageSize) : 1);
    
    if (siswaCurrentPage > totalPages && totalPages > 0) {
        siswaCurrentPage = totalPages;
    }
    if (siswaCurrentPage < 1) {
        siswaCurrentPage = 1;
    }
    
    const startIndex = isAll ? 0 : (siswaCurrentPage - 1) * pageSize;
    const endIndex = isAll ? totalMatched : Math.min(startIndex + pageSize, totalMatched);
    
    const visibleRowsSlice = matchedRows.slice(startIndex, endIndex);
    const visibleRowsSet = new Set(visibleRowsSlice);
    
    allRows.forEach(row => {
        if (visibleRowsSet.has(row)) {
            row.style.display = '';
            const cb = row.querySelector('.cb-student-row');
            if (cb) {
                cb.checked = selectedStudentIds.has(cb.value);
            }
        } else {
            row.style.display = 'none';
        }
    });
    
    const noResultsRow = document.getElementById('no-search-results');
    if (noResultsRow) {
        noResultsRow.style.display = (totalMatched === 0 && totalOriginal > 0) ? '' : 'none';
    }
    
    const infoEl = document.getElementById('siswa-page-info');
    if (infoEl) {
        if (totalOriginal === 0) {
            infoEl.textContent = 'Belum ada data siswa';
        } else if (totalMatched === 0) {
            infoEl.innerHTML = `Tidak ada hasil untuk "<strong>${escapeHtml(siswaSearchQuery)}</strong>" (dari total ${totalOriginal} siswa)`;
        } else if (siswaSearchQuery) {
            infoEl.innerHTML = `Menampilkan <strong>${startIndex + 1}</strong> - <strong>${endIndex}</strong> dari <strong>${totalMatched}</strong> siswa (difilter dari total ${totalOriginal} siswa)`;
        } else {
            if (isAll) {
                infoEl.innerHTML = `Menampilkan semua <strong>${totalMatched}</strong> siswa`;
            } else {
                infoEl.innerHTML = `Menampilkan <strong>${startIndex + 1}</strong> - <strong>${endIndex}</strong> dari <strong>${totalMatched}</strong> siswa`;
            }
        }
    }
    
    renderSiswaPagination(totalMatched, totalPages);
    updateSelectAllCheckbox(visibleRowsSet);
}

function renderSiswaPagination(totalMatched, totalPages) {
    const paginationEl = document.getElementById('siswa-pagination');
    if (!paginationEl) return;
    
    if (totalPages <= 1 || siswaPerPage === 'all' || totalMatched === 0) {
        paginationEl.innerHTML = '';
        return;
    }
    
    let html = '';
    const prevDisabled = (siswaCurrentPage === 1) ? 'disabled' : '';
    html += `<li class="page-item ${prevDisabled}">
                <a class="page-link" href="javascript:void(0)" onclick="${siswaCurrentPage > 1 ? `changeSiswaPage(1)` : ''}" title="Halaman Pertama">«</a>
             </li>`;
    html += `<li class="page-item ${prevDisabled}">
                <a class="page-link" href="javascript:void(0)" onclick="${siswaCurrentPage > 1 ? `changeSiswaPage(${siswaCurrentPage - 1})` : ''}" title="Halaman Sebelumnya">‹</a>
             </li>`;
             
    let startPage = Math.max(1, siswaCurrentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);
    if (endPage - startPage < 4) {
        startPage = Math.max(1, endPage - 4);
    }
    
    if (startPage > 1) {
        html += `<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="changeSiswaPage(1)">1</a></li>`;
        if (startPage > 2) {
            html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
    }
    
    for (let i = startPage; i <= endPage; i++) {
        const active = (i === siswaCurrentPage) ? 'active' : '';
        html += `<li class="page-item ${active}">
                    <a class="page-link" href="javascript:void(0)" onclick="changeSiswaPage(${i})">${i}</a>
                 </li>`;
    }
    
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            html += `<li class="page-item disabled"><span class="page-link">...</span></li>`;
        }
        html += `<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="changeSiswaPage(${totalPages})">${totalPages}</a></li>`;
    }
    
    const nextDisabled = (siswaCurrentPage === totalPages) ? 'disabled' : '';
    html += `<li class="page-item ${nextDisabled}">
                <a class="page-link" href="javascript:void(0)" onclick="${siswaCurrentPage < totalPages ? `changeSiswaPage(${siswaCurrentPage + 1})` : ''}" title="Halaman Berikutnya">›</a>
             </li>`;
    html += `<li class="page-item ${nextDisabled}">
                <a class="page-link" href="javascript:void(0)" onclick="${siswaCurrentPage < totalPages ? `changeSiswaPage(${totalPages})` : ''}" title="Halaman Terakhir">»</a>
             </li>`;
             
    paginationEl.innerHTML = html;
}

function updateSelectAllCheckbox(visibleRowsSet) {
    const cbAll = document.getElementById('cb-all-students');
    if (!cbAll) return;
    
    if (!visibleRowsSet || visibleRowsSet.size === 0) {
        cbAll.checked = false;
        cbAll.indeterminate = false;
        return;
    }
    
    let allChecked = true;
    let someChecked = false;
    
    visibleRowsSet.forEach(row => {
        const cb = row.querySelector('.cb-student-row');
        if (cb) {
            if (selectedStudentIds.has(cb.value)) {
                someChecked = true;
            } else {
                allChecked = false;
            }
        }
    });
    
    cbAll.checked = allChecked && someChecked;
    cbAll.indeterminate = someChecked && !allChecked;
}

function toggleAllStudents() {
    const cbAll = document.getElementById('cb-all-students');
    const isChecked = cbAll.checked;
    
    const visibleRows = document.querySelectorAll('.student-row:not([style*="display: none"])');
    visibleRows.forEach(row => {
        const cb = row.querySelector('.cb-student-row');
        if (cb) {
            cb.checked = isChecked;
            if (isChecked) {
                selectedStudentIds.add(cb.value);
            } else {
                selectedStudentIds.delete(cb.value);
            }
        }
    });
    
    cbAll.indeterminate = false;
}

function toggleStudentSelection(cb) {
    if (cb && cb.value) {
        if (cb.checked) {
            selectedStudentIds.add(cb.value);
        } else {
            selectedStudentIds.delete(cb.value);
        }
    } else {
        document.querySelectorAll('.cb-student-row').forEach(c => {
            if (c.checked) selectedStudentIds.add(c.value);
            else selectedStudentIds.delete(c.value);
        });
    }
    
    const visibleRows = new Set(document.querySelectorAll('.student-row:not([style*="display: none"])'));
    updateSelectAllCheckbox(visibleRows);
}

async function bulkDeleteStudents() {
    if (selectedStudentIds.size === 0) {
        Swal.fire('Oops', 'Pilih minimal satu siswa untuk dihapus.', 'warning');
        return;
    }
    
    const result = await Swal.fire({
        title: 'Hapus Terpilih?',
        text: `Yakin ingin menghapus ${selectedStudentIds.size} siswa terpilih secara permanen?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal'
    });

    if(result.isConfirmed) {
        const ids = Array.from(selectedStudentIds);
        Swal.fire({ title: 'Memproses...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        
        try {
            const fd = new FormData();
            fd.append('action', 'bulk_delete_students');
            fd.append('ids', JSON.stringify(ids));
            
            const response = await fetch('api.php', { method: 'POST', body: fd });
            const res = await response.json();
            
            if (res.status === 'success') {
                Swal.fire('Berhasil!', res.message, 'success').then(() => window.location.reload());
            } else {
                Swal.fire('Gagal', res.message, 'error');
            }
        } catch(e) {
            Swal.fire('Error', 'Gagal memproses bulk delete.', 'error');
        }
    }
}

async function bulkResetStudents() {
    if (selectedStudentIds.size === 0) {
        Swal.fire('Oops', 'Pilih minimal satu siswa untuk direset.', 'warning');
        return;
    }
    
    const result = await Swal.fire({
        title: 'Reset Login Terpilih?',
        text: `Yakin ingin mereset sesi login untuk ${selectedStudentIds.size} siswa terpilih?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Reset',
        cancelButtonText: 'Batal'
    });

    if(result.isConfirmed) {
        const ids = Array.from(selectedStudentIds);
        Swal.fire({ title: 'Memproses...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        
        try {
            const fd = new FormData();
            fd.append('action', 'bulk_reset_logins');
            fd.append('ids', JSON.stringify(ids));
            
            const response = await fetch('api.php', { method: 'POST', body: fd });
            const res = await response.json();
            
            if (res.status === 'success') {
                Swal.fire('Berhasil!', res.message, 'success').then(() => window.location.reload());
            } else {
                Swal.fire('Gagal', res.message, 'error');
            }
        } catch(e) {
            Swal.fire('Error', 'Gagal memproses bulk reset.', 'error');
        }
    }
}

function editStudent(id, username, name, classId, password, ruang, noPeserta) {
    document.getElementById('edit_student_id').value = id;
    document.getElementById('edit_student_no_peserta').value = noPeserta || '';
    document.getElementById('edit_student_username').value = username;
    document.getElementById('edit_student_name').value = name;
    document.getElementById('edit_class_id').value = classId;
    document.getElementById('edit_student_password').value = password;
    document.getElementById('edit_student_ruang').value = ruang || '';
    $('#modalEditSiswa').modal('show');
}

async function deleteStudent(id) {
    const result = await Swal.fire({
        title: 'Konfirmasi',
        text: 'Yakin ingin menghapus siswa ini secara permanen?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    });

    if (result.isConfirmed) {
        const formData = new FormData();
        formData.append('action', 'delete_student');
        formData.append('id', id);
        
        try {
            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.status === 'success') {
                Swal.fire({
                    title: 'Berhasil!',
                    text: 'Siswa berhasil dihapus.',
                    icon: 'success',
                    timer: 1000,
                    showConfirmButton: false
                }).then(() => {
                    window.location.reload();
                });
            } else {
                Swal.fire('Gagal', res.message, 'error');
            }
        } catch (error) {
            console.error(error);
            Swal.fire('Gagal', 'Gagal menghubungi server.', 'error');
        }
    }
}

async function resetLogin(id) {
    const result = await Swal.fire({
        title: 'Reset Login?',
        text: 'Ini akan menghapus sesi login aktif untuk siswa ini. Siswa dapat login kembali dari perangkat mana saja.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Reset',
        cancelButtonText: 'Batal'
    });
    
    if (result.isConfirmed) {
        const formData = new FormData();
        formData.append('action', 'reset_login');
        formData.append('student_id', id);
        
        try {
            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();
            Swal.fire({
                title: res.status === 'success' ? 'Berhasil' : 'Informasi',
                text: res.message,
                icon: res.status === 'success' ? 'success' : 'info',
                timer: 1500,
                showConfirmButton: false
            });
        } catch (error) {
            Swal.fire('Error', 'Gagal menghubungi server', 'error');
        }
    }
}

async function setAllPasswords() {
    const hasSelection = (typeof selectedStudentIds !== 'undefined' && selectedStudentIds && selectedStudentIds.size > 0);
    const totalCount = (typeof rawStudentsData !== 'undefined' && rawStudentsData) ? rawStudentsData.length : 0;
    const selectedCount = hasSelection ? selectedStudentIds.size : 0;

    let targetScopeHtml = '';
    if (hasSelection) {
        targetScopeHtml = `
            <div class="alert alert-info py-2 px-3 mb-3 text-left small">
                <i class="fas fa-info-circle mr-1"></i> Terdapat <b>${selectedCount}</b> siswa yang sedang dicentang.
                <div class="mt-2">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="pwd_scope_selected" name="pwd_target_scope" value="selected" class="custom-control-input" checked>
                        <label class="custom-control-label font-weight-normal" for="pwd_scope_selected">Siswa Terpilih (${selectedCount})</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="pwd_scope_all" name="pwd_target_scope" value="all" class="custom-control-input">
                        <label class="custom-control-label font-weight-normal" for="pwd_scope_all">Semua Siswa (${totalCount})</label>
                    </div>
                </div>
            </div>
        `;
    }

    const { value: formValues } = await Swal.fire({
        title: '<i class="fas fa-key text-warning mr-2"></i>Generate Password Siswa',
        html: `
            <div class="text-left" style="font-size: 0.95rem;">
                ${targetScopeHtml}
                <div class="p-3 border rounded bg-light">
                    <label class="font-weight-bold text-dark d-block mb-2">Pilih Metode Generate Password:</label>
                    
                    <div class="custom-control custom-radio mb-2">
                        <input type="radio" id="pwd_mode_same" name="pwd_generate_mode" value="same" class="custom-control-input" checked onchange="document.getElementById('wrapper-same-pwd').style.display='block'; document.getElementById('input_same_password').focus();">
                        <label class="custom-control-label font-weight-bold" for="pwd_mode_same">1. Buat Password Sama Semua</label>
                        <div class="text-muted small ml-4">Gunakan satu password yang sama untuk siswa.</div>
                    </div>
                    
                    <div id="wrapper-same-pwd" class="mt-2 ml-4 mb-3">
                        <label class="small font-weight-bold text-muted mb-1">Masukkan Password:</label>
                        <input type="text" id="input_same_password" class="form-control form-control-sm" placeholder="Contoh: 123456" value="123456" autocomplete="off">
                    </div>
                    
                    <hr class="my-2">
                    
                    <div class="custom-control custom-radio">
                        <input type="radio" id="pwd_mode_random" name="pwd_generate_mode" value="random" class="custom-control-input" onchange="document.getElementById('wrapper-same-pwd').style.display='none';">
                        <label class="custom-control-label font-weight-bold" for="pwd_mode_random">2. Buat Password Random 6 Karakter Angka Semua</label>
                        <div class="text-muted small ml-4">Setiap siswa akan mendapatkan password acak 6 digit angka yang berbeda (contoh: <code>482910</code>, <code>710529</code>).</div>
                    </div>
                </div>
            </div>
        `,
        focusConfirm: false,
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-check mr-1"></i> Terapkan Password',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#f39c12',
        cancelButtonColor: '#6c757d',
        preConfirm: () => {
            const mode = document.querySelector('input[name="pwd_generate_mode"]:checked')?.value || 'same';
            const samePwdInput = document.getElementById('input_same_password')?.value.trim();
            let scope = 'all';
            if (hasSelection) {
                scope = document.querySelector('input[name="pwd_target_scope"]:checked')?.value || 'selected';
            }

            if (mode === 'same') {
                if (!samePwdInput) {
                    Swal.showValidationMessage('Password sama tidak boleh kosong!');
                    return false;
                }
            }
            return { mode, password: samePwdInput, scope };
        }
    });

    if (formValues) {
        Swal.fire({
            title: 'Memproses...',
            text: 'Sedang memperbarui password siswa...',
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading()
        });

        const formData = new FormData();
        formData.append('action', 'set_all_passwords');
        formData.append('mode', formValues.mode);
        formData.append('password', formValues.password || '');
        formData.append('scope', formValues.scope);

        if (formValues.scope === 'selected') {
            formData.append('ids', JSON.stringify(Array.from(selectedStudentIds)));
        }

        try {
            const response = await fetch('api.php', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.status === 'success') {
                Swal.fire({
                    title: 'Berhasil!',
                    text: res.message,
                    icon: 'success',
                    timer: 1800,
                    showConfirmButton: false
                }).then(() => {
                    window.location.reload();
                });
            } else {
                Swal.fire('Gagal', res.message, 'error');
            }
        } catch (error) {
            console.error(error);
            Swal.fire('Gagal', 'Gagal menghubungi server.', 'error');
        }
    }
}

async function exportExcelSiswa() {
    if (typeof XLSX === 'undefined') {
        Swal.fire('Error', 'Pustaka Excel (SheetJS) belum termuat. Silakan muat ulang halaman.', 'error');
        return;
    }

    if (!rawStudentsData || rawStudentsData.length === 0) {
        Swal.fire('Informasi', 'Belum ada data siswa untuk diekspor.', 'info');
        return;
    }

    let targetStudents = rawStudentsData;
    let exportTypeDesc = 'Semua';

    if (selectedStudentIds && selectedStudentIds.size > 0) {
        const result = await Swal.fire({
            title: 'Ekspor Data Siswa (.xlsx)',
            text: `Terdapat ${selectedStudentIds.size} siswa terpilih. Pilih data yang ingin diekspor ke Excel:`,
            icon: 'question',
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: `<i class="fas fa-check-square mr-1"></i> Terpilih (${selectedStudentIds.size})`,
            denyButtonText: `<i class="fas fa-users mr-1"></i> Semua Siswa (${rawStudentsData.length})`,
            cancelButtonText: 'Batal',
            confirmButtonColor: '#28a745',
            denyButtonColor: '#17a2b8'
        });

        if (result.isConfirmed) {
            targetStudents = rawStudentsData.filter(s => selectedStudentIds.has(s.id.toString()));
            exportTypeDesc = 'Terpilih';
        } else if (result.isDenied) {
            targetStudents = rawStudentsData;
            exportTypeDesc = 'Semua';
        } else {
            return;
        }
    } else if (typeof siswaSearchQuery !== 'undefined' && siswaSearchQuery) {
        const allRows = Array.from(document.querySelectorAll('.student-row'));
        const matchedIds = new Set();
        allRows.forEach(row => {
            const name = row.getAttribute('data-name') || '';
            const noPeserta = row.getAttribute('data-no-peserta') || '';
            const usr = row.getAttribute('data-username') || '';
            const cls = row.getAttribute('data-class') || '';
            const id = row.getAttribute('data-id') || '';
            const pwd = row.getAttribute('data-password') || '';
            const ruang = row.getAttribute('data-ruang') || '';
            if (name.includes(siswaSearchQuery) || noPeserta.includes(siswaSearchQuery) || usr.includes(siswaSearchQuery) || cls.includes(siswaSearchQuery) || id.includes(siswaSearchQuery) || pwd.includes(siswaSearchQuery) || ruang.includes(siswaSearchQuery)) {
                matchedIds.add(parseInt(id, 10));
            }
        });

        if (matchedIds.size > 0 && matchedIds.size < rawStudentsData.length) {
            const result = await Swal.fire({
                title: 'Ekspor Data Siswa (.xlsx)',
                text: `Pencarian aktif menemukan ${matchedIds.size} siswa. Pilih data yang ingin diekspor:`,
                icon: 'question',
                showCancelButton: true,
                showDenyButton: true,
                confirmButtonText: `<i class="fas fa-filter mr-1"></i> Hasil Filter (${matchedIds.size})`,
                denyButtonText: `<i class="fas fa-users mr-1"></i> Semua Siswa (${rawStudentsData.length})`,
                cancelButtonText: 'Batal',
                confirmButtonColor: '#28a745',
                denyButtonColor: '#17a2b8'
            });

            if (result.isConfirmed) {
                targetStudents = rawStudentsData.filter(s => matchedIds.has(s.id));
                exportTypeDesc = 'Filter';
            } else if (result.isDenied) {
                targetStudents = rawStudentsData;
                exportTypeDesc = 'Semua';
            } else {
                return;
            }
        }
    }

    // Urutkan targetStudents sesuai urutan tabel saat ini (hasil sorting DOM)
    const domRows = Array.from(document.querySelectorAll('.student-row'));
    const domOrderMap = new Map();
    domRows.forEach((r, idx) => {
        const rId = parseInt(r.getAttribute('data-id'), 10);
        if (rId) domOrderMap.set(rId, idx);
    });
    targetStudents.sort((a, b) => {
        const orderA = domOrderMap.has(a.id) ? domOrderMap.get(a.id) : 999999;
        const orderB = domOrderMap.has(b.id) ? domOrderMap.get(b.id) : 999999;
        return orderA - orderB;
    });

    // Build worksheet AOA
    const sheetData = [
        ['No', 'ID Siswa', 'No Peserta', 'Username', 'Nama Siswa', 'Kelas', 'Ruang', 'Password']
    ];

    targetStudents.forEach((s, idx) => {
        sheetData.push([
            idx + 1,
            s.id,
            s.no_peserta || '',
            s.username || ('siswa' + s.id),
            s.name || '',
            s.class || '',
            s.ruang || '',
            s.password !== undefined && s.password !== null ? String(s.password) : ''
        ]);
    });

    const worksheet = XLSX.utils.aoa_to_sheet(sheetData);

    // Column widths
    worksheet['!cols'] = [
        { wch: 6 },  // No
        { wch: 10 }, // ID Siswa
        { wch: 18 }, // No Peserta
        { wch: 18 }, // Username
        { wch: 35 }, // Nama Siswa
        { wch: 16 }, // Kelas
        { wch: 14 }, // Ruang
        { wch: 18 }  // Password
    ];

    // Styles: Header warna kuning (#FFFF00) & thin border
    const borderThin = {
        top: { style: 'thin', color: { rgb: '000000' } },
        bottom: { style: 'thin', color: { rgb: '000000' } },
        left: { style: 'thin', color: { rgb: '000000' } },
        right: { style: 'thin', color: { rgb: '000000' } }
    };

    const headerStyle = {
        fill: { fgColor: { rgb: 'FFFF00' } },
        font: { name: 'Calibri', sz: 11, bold: true, color: { rgb: '000000' } },
        alignment: { vertical: 'center', horizontal: 'center' },
        border: borderThin
    };

    const bodyStyleCenter = {
        font: { name: 'Calibri', sz: 11 },
        alignment: { vertical: 'center', horizontal: 'center' },
        border: borderThin
    };

    const bodyStyleLeft = {
        font: { name: 'Calibri', sz: 11 },
        alignment: { vertical: 'center', horizontal: 'left' },
        border: borderThin
    };

    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let R = range.s.r; R <= range.e.r; ++R) {
        for (let C = range.s.c; C <= range.e.c; ++C) {
            const cell_address = XLSX.utils.encode_cell({ r: R, c: C });
            if (!worksheet[cell_address]) {
                worksheet[cell_address] = { t: 's', v: '' };
            }
            if (R === 0) {
                worksheet[cell_address].s = headerStyle;
            } else {
                // Ensure text formatting for No Peserta, Username, Ruang & Password to avoid leading zero truncation
                if (C === 2 || C === 3 || C === 6 || C === 7) {
                    worksheet[cell_address].t = 's';
                }
                worksheet[cell_address].s = (C === 4) ? bodyStyleLeft : bodyStyleCenter;
            }
        }
    }

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Data Siswa");

    const cleanSchool = (schoolNameExport || 'CBT').trim().replace(/[\s\/\\]+/g, '_').replace(/[^a-zA-Z0-9_.-]/g, '');
    const dateStr = new Date().toISOString().split('T')[0];
    
    let fileName = `Data_Siswa_${cleanSchool}_${dateStr}.xlsx`;
    if (exportTypeDesc !== 'Semua') {
        fileName = `Data_Siswa_${exportTypeDesc}_${cleanSchool}_${dateStr}.xlsx`;
    }

    XLSX.writeFile(workbook, fileName, { compression: true });

    Swal.fire({
        title: 'Berhasil!',
        text: `Data ${targetStudents.length} siswa berhasil diekspor ke Excel (${fileName}).`,
        icon: 'success',
        timer: 2000,
        showConfirmButton: false
    });
}
</script>
