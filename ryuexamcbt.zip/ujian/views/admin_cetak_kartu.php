<?php
// Ensure database and data are loaded
$settings = function_exists('get_settings') ? get_settings() : [];
$classes = function_exists('get_classes') ? get_classes() : [];
$students = function_exists('get_students') ? get_students() : [];

$classMap = [];
foreach ($classes as $c) {
    $classMap[$c['id']] = $c['name'];
}

$ruangList = [];
foreach ($students as $s) {
    $r = trim($s['ruang'] ?? '');
    if ($r !== '' && !in_array($r, $ruangList)) {
        $ruangList[] = $r;
    }
}
natcasesort($ruangList);

$defaultSchoolName = !empty($settings['school_name']) ? $settings['school_name'] : 'SMP NEGERI 2 TUNGKAL JAYA';
$defaultLogo = (!empty($settings['school_logo']) && file_exists($settings['school_logo'])) ? $settings['school_logo'] : '';

$currentYear = (int)date('Y');
$defaultTahunAjaran = "TAHUN PELAJARAN " . $currentYear . "/" . ($currentYear + 1);
$defaultNamaUjian = "ASESMEN SUMATIF AKHIR SEMESTER";

// Prepare JS student data
$jsStudents = [];
foreach ($students as $s) {
    $cName = $classMap[$s['class_id']] ?? 'Tidak Diketahui';
    $sUsername = !empty($s['username']) ? $s['username'] : ('siswa' . $s['id']);
    $jsStudents[] = [
        'id' => (int)$s['id'],
        'no_peserta' => (string)($s['no_peserta'] ?? ''),
        'name' => (string)($s['name'] ?? ''),
        'class_id' => (int)$s['class_id'],
        'class_name' => (string)$cName,
        'ruang' => (string)($s['ruang'] ?? ''),
        'username' => (string)$sUsername,
        'password' => (string)($s['password'] ?? '')
    ];
}
?>

<style>
/* ==================== PRINT & F4 PAGE STYLING ==================== */
@page {
    size: 215mm 330mm; /* F4 / Folio Portrait */
    margin: 4.5mm 5mm 4.5mm 5mm;
}

@media print {
    html, body {
        width: 215mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
    .no-print, 
    .main-sidebar, 
    .main-header, 
    .main-footer, 
    .content-header,
    #btn-scroll-top,
    .brand-link {
        display: none !important;
    }
    .content-wrapper, .content {
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        width: 100% !important;
        border: none !important;
    }
    .preview-container {
        padding: 0 !important;
        margin: 0 !important;
        background: transparent !important;
    }
    .f4-sheet {
        box-shadow: none !important;
        border: none !important;
        margin: 0 auto !important;
        padding: 0 !important;
        page-break-after: always !important;
        break-after: page !important;
    }
    .f4-sheet:last-child {
        page-break-after: avoid !important;
        break-after: avoid !important;
    }
}

/* ==================== SCREEN PREVIEW STYLING ==================== */
.preview-container {
    background: #525659;
    padding: 24px 12px;
    border-radius: 8px;
    overflow-x: auto;
    text-align: center;
}

.f4-sheet {
    width: 215mm;
    min-height: 330mm;
    box-sizing: border-box;
    display: grid;
    grid-template-columns: repeat(2, 101mm);
    grid-template-rows: repeat(6, 51.8mm);
    column-gap: 3mm;
    row-gap: 2mm;
    justify-content: center;
    align-content: start;
    background: #fff;
    margin: 0 auto 24px auto;
    padding: 4.5mm 5mm;
    box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    border: 1px solid #ccc;
    text-align: left;
    position: relative;
    overflow: hidden;
}

@media print {
    .f4-sheet {
        width: 205mm !important;
        height: 321mm !important;
        max-height: 321mm !important;
        box-shadow: none !important;
        border: none !important;
        margin: 0 auto !important;
        padding: 0 !important;
        page-break-after: always !important;
        break-after: page !important;
        overflow: hidden !important;
    }
    .card-peserta {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
    }
}

/* ==================== CARD PESERTA (KTP LANDSCAPE) ==================== */
.card-peserta {
    width: 101mm;
    height: 51.8mm;
    border: 1.2px solid #111;
    border-radius: 7px;
    box-sizing: border-box;
    padding: 2mm 3.5mm 1.8mm 3.5mm;
    background: #fff;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    overflow: hidden;
    color: #000;
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
}

.card-kop {
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;
    min-height: 10.5mm;
    margin-bottom: 0.8mm;
}

.card-kop-logo {
    width: 10.5mm;
    height: 10.5mm;
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
}

.card-kop-logo img {
    max-width: 10.5mm;
    max-height: 10.5mm;
    object-fit: contain;
}

.card-kop-text {
    width: 100%;
    text-align: center;
    padding-left: 11.5mm;
    padding-right: 1mm;
    box-sizing: border-box;
}

.card-kop-text.no-logo {
    padding-left: 0 !important;
    padding-right: 0 !important;
}

.kop-line-1 {
    font-size: 7.2pt;
    font-weight: 800;
    text-transform: uppercase;
    line-height: 1.15;
    letter-spacing: 0.1px;
    color: #000;
}

.kop-line-2 {
    font-size: 6.8pt;
    font-weight: 800;
    text-transform: uppercase;
    line-height: 1.15;
    margin-top: 0.3mm;
    color: #000;
}

.kop-line-3 {
    font-size: 6.2pt;
    font-weight: 600;
    text-transform: uppercase;
    line-height: 1.15;
    margin-top: 0.2mm;
    color: #111;
}

.card-divider {
    width: 100%;
    border-bottom: 1.5px solid #000;
    margin: 0 0 1mm 0;
}

.card-subtitle {
    text-align: center;
    font-size: 7.6pt;
    font-weight: 800;
    text-transform: uppercase;
    text-decoration: underline;
    letter-spacing: 0.4px;
    margin-top: 0.2mm;
    margin-bottom: 1.2mm;
    line-height: 1;
    color: #000;
}

.card-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 7.2pt;
    line-height: 1.2;
    color: #000;
    margin-top: 0;
}

.card-table tr td {
    padding: 0.3mm 0;
    vertical-align: middle;
}

.card-table .col-label {
    width: 21mm;
    font-weight: 600;
    white-space: nowrap;
}

.card-table .col-sep {
    width: 2.5mm;
    text-align: center;
    font-weight: bold;
}

.card-table .col-val {
    font-weight: 600;
    word-break: break-word;
}

.card-table .val-name {
    font-weight: 800;
    font-size: 7.2pt;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 68mm;
    display: inline-block;
    vertical-align: middle;
}

.card-table .val-mono {
    font-family: 'Courier New', Courier, monospace, sans-serif;
    font-weight: 700;
    font-size: 7.6pt;
}

.card-empty {
    width: 101mm;
    height: 51.8mm;
    border: 1px dashed #bbb;
    border-radius: 7px;
    box-sizing: border-box;
    background: transparent;
}
@media print {
    .card-empty {
        border: none !important;
        visibility: hidden !important;
    }
}
</style>

<div class="content-section">
    <!-- PANEL PENGATURAN & FILTER KARTU -->
    <div class="card card-outline card-primary no-print shadow-sm">
        <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap">
            <h3 class="card-title font-weight-bold text-primary mb-0">
                <i class="fas fa-id-card mr-2"></i>Cetak Kartu Peserta Ujian (F4 &mdash; 12 Kartu/Lembar)
            </h3>
            <div class="mt-2 mt-sm-0">
                <button type="button" class="btn btn-primary px-3 shadow-sm" onclick="printKartu()">
                    <i class="fas fa-print mr-1"></i> Cetak Kartu (Print / PDF)
                </button>
                <a href="?page=siswa" class="btn btn-outline-secondary ml-1">
                    <i class="fas fa-arrow-left mr-1"></i> Data Siswa
                </a>
            </div>
        </div>
        <div class="card-body py-3">
            <div class="row">
                <!-- Kolom 1: Generator Header Kop -->
                <div class="col-lg-6 col-12 border-right">
                    <h6 class="font-weight-bold text-dark border-bottom pb-2 mb-3">
                        <i class="fas fa-heading mr-1 text-info"></i> Generator Header Kop Kartu
                    </h6>
                    <div class="form-group mb-2">
                        <label class="small font-weight-bold mb-1">Header 1 (Nama Ujian):</label>
                        <input type="text" id="cfg-nama-ujian" class="form-control form-control-sm" 
                               value="<?= htmlspecialchars($defaultNamaUjian) ?>" 
                               placeholder="Contoh: ASESMEN SUMATIF AKHIR SEMESTER" 
                               oninput="applyLiveConfig()">
                    </div>
                    <div class="form-group mb-2">
                        <label class="small font-weight-bold mb-1">Header 2 (Nama Sekolah - Default dapat diedit):</label>
                        <input type="text" id="cfg-nama-sekolah" class="form-control form-control-sm" 
                               value="<?= htmlspecialchars($defaultSchoolName) ?>" 
                               placeholder="Contoh: SMP NEGERI 2 TUNGKAL JAYA" 
                               oninput="applyLiveConfig()">
                    </div>
                    <div class="form-group mb-2">
                        <label class="small font-weight-bold mb-1">Header 3 (Tahun Pelajaran):</label>
                        <input type="text" id="cfg-tahun-ajaran" class="form-control form-control-sm" 
                               value="<?= htmlspecialchars($defaultTahunAjaran) ?>" 
                               placeholder="Contoh: TAHUN PELAJARAN 2025/2026" 
                               oninput="applyLiveConfig()">
                    </div>
                    <div class="d-flex align-items-center mt-3 pt-2 border-top flex-wrap" style="gap: 15px;">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="cfg-show-logo" checked onchange="applyLiveConfig()">
                            <label class="custom-control-label font-weight-bold small cursor-pointer" for="cfg-show-logo">
                                Tampilkan Logo Sekolah di Kiri
                            </label>
                        </div>
                        <div class="d-flex align-items-center">
                            <label class="small text-muted mb-0 mr-2">Ganti Logo:</label>
                            <input type="file" id="cfg-custom-logo-file" class="form-control-file form-control-sm" style="width: auto; max-width: 200px;" accept="image/*" onchange="previewCustomLogo(this)">
                        </div>
                    </div>
                </div>

                <!-- Kolom 2: Filter & Urutan Cetak Siswa -->
                <div class="col-lg-6 col-12 mt-3 mt-lg-0">
                    <h6 class="font-weight-bold text-dark border-bottom pb-2 mb-3">
                        <i class="fas fa-filter mr-1 text-info"></i> Filter &amp; Urutan Data Siswa
                    </h6>
                    <div class="row">
                        <div class="col-sm-6 col-12 mb-2">
                            <label class="small font-weight-bold mb-1">Filter Kelas:</label>
                            <select id="filter-kelas" class="form-control form-control-sm" onchange="renderCards()">
                                <option value="all">-- Semua Kelas (Semua Siswa) --</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-sm-6 col-12 mb-2">
                            <label class="small font-weight-bold mb-1">Filter Ruang:</label>
                            <select id="filter-ruang" class="form-control form-control-sm" onchange="renderCards()">
                                <option value="all">-- Semua Ruang --</option>
                                <?php foreach ($ruangList as $r): ?>
                                    <option value="<?= htmlspecialchars($r) ?>"><?= htmlspecialchars($r) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-sm-6 col-12 mb-2">
                            <label class="small font-weight-bold mb-1">Urutan Kartu:</label>
                            <select id="sort-by" class="form-control form-control-sm" onchange="renderCards()">
                                <option value="no_peserta">No. Peserta (Naik / ASC)</option>
                                <option value="name">Nama Siswa (A - Z)</option>
                                <option value="class">Kelas, lalu Nama</option>
                                <option value="ruang">Ruang, lalu No. Peserta</option>
                                <option value="id">ID Siswa (ASC)</option>
                            </select>
                        </div>
                        <div class="col-sm-6 col-12 mb-2">
                            <label class="small font-weight-bold mb-1">Cari Nama / No Peserta / User:</label>
                            <input type="text" id="filter-search" class="form-control form-control-sm" placeholder="Ketik kata kunci..." oninput="renderCards()">
                        </div>
                    </div>
                    
                    <div class="alert py-2 px-3 mb-0 mt-2 small d-flex justify-content-between align-items-center flex-wrap shadow-sm" style="background: linear-gradient(135deg, #007bff, #0056b3); border: none; color: #ffffff;">
                        <div style="color: #ffffff !important;">
                            <i class="fas fa-info-circle mr-1 text-white"></i>
                            Kertas: <strong class="text-white">F4 / Folio (215 x 330 mm)</strong> &bull; Kisi: <strong class="text-white">2 x 6 (12 Kartu per Lembar)</strong>
                        </div>
                        <div id="stat-info" class="font-weight-bold text-white mt-1 mt-sm-0" style="color: #ffffff !important; font-size: 0.92rem; letter-spacing: 0.3px;">
                            Memuat...
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- AREA PRATINJAU KARTU (LAYAR & CETAK) -->
    <div class="preview-container">
        <div id="cards-container">
            <!-- Lembar F4 akan di-render secara dinamis di sini -->
        </div>
    </div>
</div>

<script>
const allStudentsData = <?= json_encode($jsStudents) ?>;
let defaultSchoolLogo = <?= json_encode($defaultLogo) ?>;
let activeSchoolLogo = defaultSchoolLogo;

function previewCustomLogo(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            activeSchoolLogo = e.target.result;
            applyLiveConfig();
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function applyLiveConfig() {
    const namaUjian = document.getElementById('cfg-nama-ujian').value.trim() || 'ASESMEN SUMATIF AKHIR SEMESTER';
    const namaSekolah = document.getElementById('cfg-nama-sekolah').value.trim() || 'SMP NEGERI 2 TUNGKAL JAYA';
    const tahunAjaran = document.getElementById('cfg-tahun-ajaran').value.trim() || 'TAHUN PELAJARAN';
    const showLogo = document.getElementById('cfg-show-logo').checked;

    document.querySelectorAll('.kop-line-1').forEach(el => el.textContent = namaUjian);
    document.querySelectorAll('.kop-line-2').forEach(el => el.textContent = namaSekolah);
    document.querySelectorAll('.kop-line-3').forEach(el => el.textContent = tahunAjaran);

    document.querySelectorAll('.card-kop-logo').forEach(el => {
        el.style.display = showLogo ? 'flex' : 'none';
        const img = el.querySelector('img');
        if (img) {
            img.src = activeSchoolLogo || '';
            img.style.display = activeSchoolLogo ? 'block' : 'none';
        }
    });

    document.querySelectorAll('.card-kop-text').forEach(el => {
        if (!showLogo || !activeSchoolLogo) {
            el.classList.add('no-logo');
        } else {
            el.classList.remove('no-logo');
        }
    });
}

function escapeHtml(str) {
    return (str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderCards() {
    const filterClass = document.getElementById('filter-kelas').value;
    const filterRuang = document.getElementById('filter-ruang').value;
    const filterSearch = document.getElementById('filter-search').value.trim().toLowerCase();
    const sortBy = document.getElementById('sort-by').value;

    let filtered = allStudentsData.filter(s => {
        if (filterClass !== 'all' && s.class_id != filterClass) return false;
        if (filterRuang !== 'all' && (s.ruang || '').toLowerCase() !== filterRuang.toLowerCase()) return false;
        if (filterSearch) {
            const match = (s.name || '').toLowerCase().includes(filterSearch) ||
                          (s.no_peserta || '').toLowerCase().includes(filterSearch) ||
                          (s.username || '').toLowerCase().includes(filterSearch) ||
                          (s.class_name || '').toLowerCase().includes(filterSearch) ||
                          (s.ruang || '').toLowerCase().includes(filterSearch);
            if (!match) return false;
        }
        return true;
    });

    // Sorting
    filtered.sort((a, b) => {
        if (sortBy === 'no_peserta') {
            return (a.no_peserta || '').localeCompare(b.no_peserta || '', undefined, { numeric: true, sensitivity: 'base' }) || (a.id - b.id);
        } else if (sortBy === 'name') {
            return (a.name || '').localeCompare(b.name || '', undefined, { sensitivity: 'base' });
        } else if (sortBy === 'class') {
            const cComp = (a.class_name || '').localeCompare(b.class_name || '', undefined, { numeric: true, sensitivity: 'base' });
            return cComp !== 0 ? cComp : (a.name || '').localeCompare(b.name || '');
        } else if (sortBy === 'ruang') {
            const rComp = (a.ruang || '').localeCompare(b.ruang || '', undefined, { numeric: true, sensitivity: 'base' });
            return rComp !== 0 ? rComp : (a.no_peserta || '').localeCompare(b.no_peserta || '', undefined, { numeric: true });
        } else {
            return a.id - b.id;
        }
    });

    const totalStudents = filtered.length;
    const totalSheets = Math.ceil(totalStudents / 12);
    const statEl = document.getElementById('stat-info');
    if (statEl) {
        statEl.innerHTML = `Total: <strong class="text-white" style="color: #ffffff !important;">${totalStudents}</strong> Siswa &bull; <strong class="text-white" style="color: #ffffff !important;">${totalSheets}</strong> Lembar F4`;
        statEl.style.color = '#ffffff';
    }

    const container = document.getElementById('cards-container');
    if (!container) return;

    if (totalStudents === 0) {
        container.innerHTML = `
            <div class="bg-white p-5 rounded text-center shadow-sm" style="max-width: 500px; margin: 40px auto;">
                <i class="fas fa-users-slash text-muted fa-3x mb-3"></i>
                <h5 class="text-dark font-weight-bold">Tidak Ada Data Siswa</h5>
                <p class="text-muted mb-0">Tidak ditemukan siswa yang cocok dengan filter yang dipilih.</p>
            </div>
        `;
        return;
    }

    const namaUjian = document.getElementById('cfg-nama-ujian').value.trim() || 'ASESMEN SUMATIF AKHIR SEMESTER';
    const namaSekolah = document.getElementById('cfg-nama-sekolah').value.trim() || 'SMP NEGERI 2 TUNGKAL JAYA';
    const tahunAjaran = document.getElementById('cfg-tahun-ajaran').value.trim() || 'TAHUN PELAJARAN';
    const showLogo = document.getElementById('cfg-show-logo').checked;
    const logoSrc = activeSchoolLogo;
    const noLogoClass = (!showLogo || !logoSrc) ? 'no-logo' : '';

    let html = '';
    // Chunk into groups of 12 for each F4 sheet (2 x 6)
    for (let i = 0; i < totalStudents; i += 12) {
        const sheetSlice = filtered.slice(i, i + 12);
        html += `<div class="f4-sheet">`;
        
        // Render 12 slots
        for (let j = 0; j < 12; j++) {
            if (j < sheetSlice.length) {
                const s = sheetSlice[j];
                const sNoPeserta = s.no_peserta ? s.no_peserta : '-';
                const sRuang = s.ruang ? s.ruang : '-';

                html += `
                <div class="card-peserta">
                    <!-- Header Kop -->
                    <div class="card-kop">
                        <div class="card-kop-logo" style="${showLogo ? '' : 'display: none;'}">
                            <img src="${escapeHtml(logoSrc)}" alt="Logo" style="${logoSrc ? '' : 'display: none;'}">
                        </div>
                        <div class="card-kop-text ${noLogoClass}">
                            <div class="kop-line-1">${escapeHtml(namaUjian)}</div>
                            <div class="kop-line-2">${escapeHtml(namaSekolah)}</div>
                            <div class="kop-line-3">${escapeHtml(tahunAjaran)}</div>
                        </div>
                    </div>
                    <div class="card-divider"></div>
                    <div class="card-subtitle">KARTU PESERTA</div>

                    <!-- Data Siswa Table -->
                    <table class="card-table">
                        <tr>
                            <td class="col-label">No. Peserta</td>
                            <td class="col-sep">:</td>
                            <td class="col-val val-mono">${escapeHtml(sNoPeserta)}</td>
                        </tr>
                        <tr>
                            <td class="col-label">Nama</td>
                            <td class="col-sep">:</td>
                            <td class="col-val"><span class="val-name" title="${escapeHtml(s.name)}">${escapeHtml(s.name)}</span></td>
                        </tr>
                        <tr>
                            <td class="col-label">Kelas</td>
                            <td class="col-sep">:</td>
                            <td class="col-val">${escapeHtml(s.class_name)}</td>
                        </tr>
                        <tr>
                            <td class="col-label">Ruang</td>
                            <td class="col-sep">:</td>
                            <td class="col-val">${escapeHtml(sRuang)}</td>
                        </tr>
                        <tr>
                            <td class="col-label">Username</td>
                            <td class="col-sep">:</td>
                            <td class="col-val val-mono">${escapeHtml(s.username)}</td>
                        </tr>
                        <tr>
                            <td class="col-label">Password</td>
                            <td class="col-sep">:</td>
                            <td class="col-val val-mono">${escapeHtml(s.password)}</td>
                        </tr>
                    </table>
                </div>
                `;
            } else {
                // Empty placeholder to preserve 2x6 grid layout
                html += `<div class="card-empty"></div>`;
            }
        }

        html += `</div>`;
    }

    container.innerHTML = html;
}

function printKartu() {
    window.print();
}

// Initial render
document.addEventListener('DOMContentLoaded', function() {
    renderCards();
});
if (document.readyState !== 'loading') {
    renderCards();
}
</script>
