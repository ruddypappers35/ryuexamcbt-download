<?php
require_once 'database.php';
$settings = get_settings();
$disable_token = !empty($settings['disable_token']);
$login_method = $settings['student_login_method'] ?? 'name_select';
$school_name = !empty($settings['school_name']) ? $settings['school_name'] : 'CBT ONLINE';
$school_desc = !empty($settings['school_description']) ? $settings['school_description'] : 'Computer Based Test Application';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($school_name) ?> - Ujian CBT Online</title>
    <?php 
    $fav = !empty($settings['favicon']) ? $settings['favicon'] : (!empty($settings['school_logo']) ? $settings['school_logo'] : '');
    if(!empty($fav)): 
        $favVersion = file_exists($fav) ? filemtime($fav) : '1.0';
    ?>
        <link rel="icon" type="image/png" href="<?= htmlspecialchars($fav) ?>?v=<?= $favVersion ?>">
    <?php endif; ?>
    <meta name="theme-color" content="#1F7FAB">

    <!-- Progressive Web App (PWA) Meta & Manifest -->
    <?php
    $manifestVer = file_exists('manifest.json') ? filemtime('manifest.json') : '1.0';
    $pwa192Ver = file_exists('icon-192.png') ? filemtime('icon-192.png') : '1.0';
    $pwa512Ver = file_exists('icon-512.png') ? filemtime('icon-512.png') : '1.0';
    ?>
    <link rel="manifest" href="manifest.json?v=<?= $manifestVer ?>">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="<?= htmlspecialchars($school_name) ?>">
    <link rel="apple-touch-icon" href="icon-192.png?v=<?= $pwa192Ver ?>">
    <link rel="apple-touch-icon" sizes="512x512" href="icon-512.png?v=<?= $pwa512Ver ?>">

    <!-- Google Fonts Preconnect, Stylesheets & Bootstrap Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css?v=<?= file_exists('style.css') ? filemtime('style.css') : '1.6.8' ?>">

    <!-- KaTeX & MathJax Support for Mathematics & LaTeX Formulas -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js" onload="if(window.triggerMathRender) window.triggerMathRender();"></script>
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']],
                processEscapes: true
            },
            options: {
                skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre', 'code', 'annotation', 'annotation-xml'],
                ignoreHtmlClass: 'tex2jax_ignore|katex'
            }
        };
        function renderMath(target) {
            if (!target) target = document.body;
            var rendered = false;
            if (typeof renderMathInElement === 'function') {
                try {
                    renderMathInElement(target, {
                        delimiters: [
                            {left: '$$', right: '$$', display: true},
                            {left: '\\[', right: '\\]', display: true},
                            {left: '$', right: '$', display: false},
                            {left: '\\(', right: '\\)', display: false},
                            {left: '[math]', right: '[/math]', display: false}
                        ],
                        throwOnError: false,
                        ignoredTags: ["script", "noscript", "style", "textarea", "pre", "code", "option"]
                    });
                    rendered = true;
                } catch (e) {
                    console.warn('KaTeX render warning:', e);
                }
            }
            if (!rendered && (typeof renderMathInElement !== 'function')) {
                var retries = 0;
                var retryTimer = setInterval(function() {
                    retries++;
                    if (typeof renderMathInElement === 'function') {
                        clearInterval(retryTimer);
                        renderMath(target);
                    } else if (retries > 25) {
                        clearInterval(retryTimer);
                    }
                }, 100);
            }
            if (window.MathJax && window.MathJax.typesetPromise) {
                try {
                    window.MathJax.typesetPromise([target]).catch(function(err) {});
                } catch(e) {}
            }
        }
        window.renderMath = renderMath;
        window.triggerMathRender = function() {
            var el = document.getElementById('single-question-container');
            if (el && typeof renderMath === 'function') {
                renderMath(el);
            }
        };
        window.addEventListener('load', function() {
            if (window.triggerMathRender) window.triggerMathRender();
        });
    </script>
    <script async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        .katex-display {
            overflow-x: auto;
            overflow-y: hidden;
            padding: 4px 0;
            margin: 0.5em 0;
        }
        .katex {
            font-size: 1.05em;
        }
        body {
            background-color: #f4f6f9;
        }
        .header-bg {
            background-color: #1F7FAB;
            background-image: 
                linear-gradient(to right, rgba(255, 255, 255, 0.06) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(255, 255, 255, 0.06) 1px, transparent 1px),
                radial-gradient(circle at center, #1F7FAB 0%, #14597b 50%, #0d3d54 100%);
            background-size: 24px 24px, 24px 24px, auto;
        }
        .btn-primary {
            background: linear-gradient(180deg, #1F7FAB 0%, #155675 100%);
            border-color: #155675;
            color: #ffffff !important;
        }
        .btn-primary:hover {
            background: #155675;
            color: #ffffff !important;
        }
        .btn-info {
            background: linear-gradient(180deg, #71b1d3 0%, #579ebd 100%);
            border-color: #4b8ba8;
        }
        .btn-info:hover {
            background: #579ebd;
        }
        /* Unified Input Group & Form Control */
        .custom-input-group {
            display: flex;
            align-items: stretch;
            width: 100%;
            position: relative;
        }
        .input-group-addon {
            background-color: #eeeeee;
            border: 1px solid #cccccc;
            border-right: none;
            border-radius: 3px 0 0 3px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 46px;
            min-width: 46px;
            max-width: 46px;
            color: #555555;
            padding: 0;
            flex-shrink: 0;
            box-sizing: border-box;
            height: 42px;
        }
        .form-control {
            display: block;
            width: 100%;
            flex: 1 1 auto;
            height: 42px;
            padding: 8px 12px;
            font-size: 15px;
            line-height: 1.42857143;
            color: #555555;
            background-color: #ffffff;
            border: 1px solid #cccccc;
            border-radius: 0 3px 3px 0;
            box-sizing: border-box;
            position: relative;
            z-index: 1;
        }
        .form-control:focus {
            border-color: #66afe9;
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
            outline: none;
            z-index: 3;
        }
        .form-control:disabled,
        .form-control[disabled] {
            background-color: #f9f9f9;
            color: #777777;
            cursor: not-allowed;
        }
        .dropdown-open .input-group-addon {
            border-bottom-left-radius: 0 !important;
        }
        .dropdown-open .form-control {
            border-bottom-right-radius: 0 !important;
        }

        /* Override Tailwind CSS Reset for Tables in Questions & Options */
        .q-text, .option-text, .complex-label-text, .match-premise-text {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .q-text table,
        .option-text table,
        .complex-label-text table,
        .match-premise-text table,
        .question-card table,
        #single-question-container table,
        table.table-bordered,
        table.table {
            display: table !important;
            border-collapse: collapse !important;
            border-spacing: 0 !important;
            margin: 12px 0 16px 0 !important;
            background-color: #ffffff !important;
            border: 1px solid #cbd5e1 !important;
            max-width: 100% !important;
            box-sizing: border-box !important;
        }
        .q-text table th,
        .q-text table td,
        .option-text table th,
        .option-text table td,
        .complex-label-text table th,
        .complex-label-text table td,
        .match-premise-text table th,
        .match-premise-text table td,
        .question-card table th,
        .question-card table td,
        #single-question-container table th,
        #single-question-container table td,
        table.table-bordered th,
        table.table-bordered td,
        table.table th,
        table.table td {
            border: 1px solid #cbd5e1 !important;
            padding: 8px 12px !important;
            vertical-align: middle !important;
            font-size: 0.95rem !important;
            line-height: 1.5 !important;
            color: #1e293b !important;
            box-sizing: border-box !important;
        }
        .q-text table th,
        .option-text table th,
        .complex-label-text table th,
        .match-premise-text table th,
        .question-card table th,
        #single-question-container table th,
        table.table-bordered th,
        table.table th {
            background-color: #f1f5f9 !important;
            font-weight: 700 !important;
            color: #0f172a !important;
            text-align: center !important;
        }
        .q-text table tr:nth-child(even),
        #single-question-container table tr:nth-child(even),
        table.table-bordered tr:nth-child(even) {
            background-color: #f8fafc;
        }
        .q-text table tr:hover,
        #single-question-container table tr:hover,
        table.table-bordered tr:hover {
            background-color: #f1f5f9;
        }
    </style>
</head>
<body class="font-sans text-[#333333] antialiased">
    <div id="app" class="relative min-h-screen">
        
        <!-- LOGIN WRAPPER (HEADER + LOGIN CARD) -->
        <div id="login-wrapper" class="w-full">
            <!-- Blue Header Background -->
            <div class="absolute top-0 left-0 w-full h-[245px] sm:h-[255px] md:h-[270px] header-bg -z-10 shadow-inner"></div>

            <div class="min-h-screen flex flex-col items-center pt-5 sm:pt-8 md:pt-10 px-3 sm:px-4 pb-8">
                <!-- Logo and Title (Logo di sebelah kiri teks, posisi keseluruhan rata tengah) -->
                <div class="flex items-center justify-center gap-3 sm:gap-4 mb-4 sm:mb-6 text-white w-full max-w-[540px] px-2 text-left">
                    <?php if (!empty($settings['school_logo']) && file_exists($settings['school_logo'])): 
                        $logoVersion = filemtime($settings['school_logo']);
                    ?>
                        <img alt="Logo Sekolah" class="h-[60px] sm:h-[75px] md:h-[82px] w-auto drop-shadow-md object-contain shrink-0" src="<?= htmlspecialchars($settings['school_logo']) ?>?v=<?= $logoVersion ?>">
                    <?php else: ?>
                        <i class="bi bi-mortarboard-fill text-[52px] sm:text-[66px] md:text-[74px] text-sky-300 shrink-0"></i>
                    <?php endif; ?>
                    <div class="flex flex-col justify-center min-w-0">
                        <h1 class="text-[18px] sm:text-[22px] md:text-[25px] font-bold tracking-wide leading-tight drop-shadow-md">
                            <?= htmlspecialchars($school_name) ?>
                        </h1>
                        <?php if (!empty($school_desc)): ?>
                        <p class="text-[12px] sm:text-[14px] md:text-[15px] text-[#e0e0e0] drop-shadow-sm font-medium mt-0.5">
                            <?= htmlspecialchars($school_desc) ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Login Card -->
                <div id="login-screen" class="bg-white rounded-[8px] shadow-lg w-full max-w-[540px] border border-[#d2d6de] min-h-[472px] flex flex-col fade-in relative">
                    <div class="p-6 md:pt-[44px] md:px-[44px] md:pb-[24px] flex-grow">
                        <div class="px-1 md:px-2">
                            <h2 class="text-[26px] md:text-[30px] font-normal mb-1">Selamat Datang</h2>
                            <p class="text-[14px] md:text-[15px] text-[#777777] mb-6" id="login-subtitle">
                                <?= ($login_method === 'username') ? 'Silakan login menggunakan username dan password yang anda miliki' : ($disable_token ? 'Silakan pilih ujian dan masukkan data diri Anda' : 'Silakan masukkan token dan data diri Anda') ?>
                            </p>

                            <?php if ($login_method === 'username'): ?>
                                <!-- FORM LOGIN DENGAN USERNAME -->
                                <div id="username-login-container">
                                    <form id="username-login-form" class="space-y-4">
                                        <!-- Username Field -->
                                        <div class="custom-input-group">
                                            <div class="input-group-addon">
                                                <i class="bi bi-person text-[20px]"></i>
                                            </div>
                                            <input class="form-control" placeholder="Username Peserta" type="text" name="username" id="username" required autocomplete="username">
                                        </div>

                                        <!-- Password Field -->
                                        <div class="custom-input-group relative">
                                            <div class="input-group-addon">
                                                <i class="bi bi-key text-[20px]"></i>
                                            </div>
                                            <input class="form-control pr-10" placeholder="Kata Sandi Peserta" type="password" name="password" id="password" required autocomplete="current-password">
                                            <button type="button" class="absolute right-0 top-0 h-full px-3 flex items-center justify-center text-[#777777] hover:text-[#333333] transition-colors z-10" onclick="togglePassword()">
                                                <i class="bi bi-eye text-[19px]" id="togglePasswordIcon"></i>
                                            </button>
                                        </div>

                                        <!-- Mata Pelajaran Searchable Dropdown -->
                                        <div class="relative w-full" id="username-exam-dropdown-container">
                                            <div class="custom-input-group" id="username-exam-input-group">
                                                <div class="input-group-addon">
                                                    <i class="bi bi-book text-[18px]"></i>
                                                </div>
                                                <input type="text" id="username-exam-search" class="form-control cursor-pointer" placeholder="Pilih Mata Pelajaran" autocomplete="off" required>
                                                <select id="username-exam-select" class="hidden" tabindex="-1" aria-hidden="true">
                                                    <option value="" disabled selected>Pilih Mata Pelajaran</option>
                                                </select>
                                            </div>
                                            <div id="username-exam-list" class="exam-dropdown-list custom-dropdown-scroll hidden"></div>
                                        </div>

                                        <!-- Action Buttons -->
                                        <div class="pt-2 space-y-2">
                                            <button class="w-full py-2 btn-primary text-white font-medium rounded-sm text-[16px] border transition-colors shadow-sm" type="submit" id="btn-login-username">
                                                Login
                                            </button>

                                            <button class="w-full py-2 font-medium rounded-sm text-[16px] border border-[#e5b350] transition-colors shadow-sm text-[#333333] hover:opacity-90" style="background-color: #FFC759;" type="button" onclick="location.reload()">
                                                Refresh
                                            </button>
                                        </div>
                                    </form>
                                </div>

                                <!-- KONFIRMASI DATA PESERTA -->
                                <div id="confirm-data-container" class="hidden">
                                    <div class="bg-[#F8FAFC] border border-[#d2d6de] rounded-sm p-4 mb-4 text-[14px] space-y-2.5">
                                        <div class="flex justify-between items-center pb-2 border-b border-dashed border-[#d2d6de]">
                                            <span class="text-[#666666]">Nama Peserta:</span>
                                            <strong id="confirm-student-name" class="text-[#222222] font-semibold text-right">-</strong>
                                        </div>
                                        <div class="flex justify-between items-center pb-2 border-b border-dashed border-[#d2d6de]">
                                            <span class="text-[#666666]">Kelas:</span>
                                            <strong id="confirm-student-class" class="text-[#222222] font-semibold text-right">-</strong>
                                        </div>
                                        <div class="flex justify-between items-center pb-2 border-b border-dashed border-[#d2d6de]">
                                            <span class="text-[#666666]">Mata Pelajaran:</span>
                                            <strong id="confirm-exam-name" class="text-[#1F7FAB] font-bold text-right">-</strong>
                                        </div>
                                        <div class="flex justify-between items-center pb-2 border-b border-dashed border-[#d2d6de]">
                                            <span class="text-[#666666]">Alokasi Waktu:</span>
                                            <strong id="confirm-exam-duration" class="text-[#222222] font-semibold text-right">-</strong>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <span class="text-[#666666]">Jumlah Soal:</span>
                                            <strong id="confirm-exam-questions" class="text-[#222222] font-semibold text-right">-</strong>
                                        </div>
                                    </div>

                                    <form id="confirm-start-form" class="space-y-4">
                                        <?php if (!$disable_token): ?>
                                        <div>
                                            <label class="block text-[13px] font-semibold text-[#555555] mb-1">Token Ujian <span class="text-red-500">*</span></label>
                                            <div class="custom-input-group">
                                                <div class="input-group-addon">
                                                    <i class="bi bi-shield-lock text-[19px]"></i>
                                                </div>
                                                <input class="form-control text-center font-bold tracking-widest uppercase text-[#1F7FAB]" placeholder="Ketik Token Ujian" type="text" id="confirm-token-input" required autocomplete="off">
                                            </div>
                                            <small class="text-[#888888] text-[12px] mt-1 block text-center">Mintalah token ujian kepada guru / pengawas di ruangan Anda.</small>
                                        </div>
                                        <?php endif; ?>

                                        <div class="pt-2 flex gap-2">
                                            <button class="w-1/3 py-2 font-medium rounded-sm text-[15px] border border-[#e5b350] text-[#333333] hover:opacity-90 transition-colors shadow-sm" style="background-color: #FFC759;" type="button" id="btn-back-to-login">
                                                Batal / Ganti
                                            </button>
                                            <button class="w-2/3 py-2 btn-primary font-medium rounded-sm text-[15px] border transition-colors shadow-sm" type="submit" id="btn-start-from-confirm">
                                                Mulai Ujian
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            <?php else: ?>
                                <!-- FORM LOGIN METODE ASLI (name_select) -->
                                <form id="login-form" class="space-y-3">
                                    <!-- Mata Pelajaran Searchable Dropdown -->
                                    <div class="relative w-full" id="exam-dropdown-container">
                                        <div class="custom-input-group" id="exam-input-group">
                                            <div class="input-group-addon">
                                                <i class="bi bi-book text-[18px]"></i>
                                            </div>
                                            <input type="text" id="exam-search-input" class="form-control cursor-pointer" placeholder="Pilih Mata Pelajaran" autocomplete="off" required>
                                            <select id="exam-select" class="hidden" tabindex="-1" aria-hidden="true">
                                                <option value="" disabled selected>Memuat data ujian...</option>
                                            </select>
                                        </div>
                                        <div id="exam-dropdown-list" class="exam-dropdown-list custom-dropdown-scroll hidden"></div>
                                    </div>

                                    <?php if (!$disable_token): ?>
                                    <div class="custom-input-group relative" id="token-wrapper">
                                        <div class="input-group-addon">
                                            <i class="bi bi-shield-lock text-[19px]"></i>
                                        </div>
                                        <input type="text" id="token" placeholder="Masukkan Token" required autocomplete="off" class="form-control uppercase font-bold tracking-widest">
                                        <i id="token-status-icon" class="bi" style="position: absolute; right: 15px; top: 13px; font-size: 1rem; transition: all 0.2s ease; z-index: 10;"></i>
                                    </div>
                                    <?php endif; ?>

                                    <div class="custom-input-group">
                                        <div class="input-group-addon">
                                            <i class="bi bi-people text-[20px]"></i>
                                        </div>
                                        <select id="class-select" required disabled class="form-control">
                                            <option value="" disabled selected>Memuat data kelas...</option>
                                        </select>
                                    </div>

                                    <div class="relative">
                                        <div class="custom-input-group">
                                            <div class="input-group-addon">
                                                <i class="bi bi-person text-[20px]"></i>
                                            </div>
                                            <input type="text" id="student-search" placeholder="Ketik minimal 3 karakter nama..." autocomplete="off" required disabled class="form-control">
                                            <input type="hidden" id="student-id" required>
                                        </div>
                                        <div id="student-autocomplete-list" class="autocomplete-items hidden"></div>
                                    </div>

                                    <div id="student-password-container" style="display: none;">
                                        <div class="custom-input-group relative">
                                            <div class="input-group-addon">
                                                <i class="bi bi-key text-[20px]"></i>
                                            </div>
                                            <input type="password" id="student-password" placeholder="Masukkan Password Siswa" required autocomplete="current-password" class="form-control pr-10">
                                            <button type="button" class="absolute right-0 top-0 h-full px-3 flex items-center justify-center text-[#777777] hover:text-[#333333] transition-colors z-10" onclick="toggleStudentPassword()">
                                                <i class="bi bi-eye text-[19px]" id="toggleStudentPasswordIcon"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <div class="pt-2 space-y-2">
                                        <button type="submit" class="w-full py-2 btn-primary text-white font-medium rounded-sm text-[16px] border transition-colors shadow-sm" id="start-btn" disabled>
                                            Mulai Ujian
                                        </button>
                                        <button class="w-full py-2 font-medium rounded-sm text-[16px] border border-[#e5b350] transition-colors shadow-sm text-[#333333] hover:opacity-90" style="background-color: #FFC759;" type="button" onclick="location.reload()">
                                            Refresh
                                        </button>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- System Footer -->
                    <div class="bg-[#F7F7F7] border-t border-[#dddddd] py-3 text-center">
                        <p class="text-[13px] text-black leading-relaxed flex flex-col items-center justify-center">
                            <span><a href="https://ryuexamcbt.web.id" target="_blank" rel="noopener noreferrer" class="hover:underline font-semibold" title="Kunjungi Website Resmi RyuExam CBT"><span style="color: #DF2463;">Ryu</span><span style="color: #269DD8;">Exam</span> <span style="color: #1F7FAB;">CBT</span></a>. Versi : <span class="text-blue-600 font-medium">1.6.8</span>.</span>
                            <span class="flex items-center gap-1 mt-1 text-[#666666]">Developed with <i class="bi bi-cup-hot-fill text-[14px] text-amber-700"></i> by <span class="font-bold">Rudy Susanto</span></span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function togglePassword() {
                const pwd = document.getElementById("password") || document.getElementById("input-password");
                const icon = document.getElementById("togglePasswordIcon");
                if (pwd) {
                    if (pwd.type === "password") {
                        pwd.type = "text";
                        if (icon) icon.className = "bi bi-eye-slash text-[19px]";
                    } else {
                        pwd.type = "password";
                        if (icon) icon.className = "bi bi-eye text-[19px]";
                    }
                }
            }

            function toggleStudentPassword() {
                const pwd = document.getElementById("student-password");
                const icon = document.getElementById("toggleStudentPasswordIcon");
                if (pwd) {
                    if (pwd.type === "password") {
                        pwd.type = "text";
                        if (icon) icon.className = "bi bi-eye-slash text-[19px]";
                    } else {
                        pwd.type = "password";
                        if (icon) icon.className = "bi bi-eye text-[19px]";
                    }
                }
            }
        </script>

        <!-- EXAM SCREEN -->
        <div id="exam-screen" class="hidden w-full">
            <!-- Blue Header Background -->
            <div class="absolute top-0 left-0 w-full h-[240px] sm:h-[250px] md:h-[265px] header-bg -z-10 shadow-inner"></div>

            <div class="min-h-screen flex flex-col items-center pb-0 sm:pb-8 w-full">
                <!-- STICKY TOP CONTAINER -->
                <div class="sticky top-0 z-30 w-full flex flex-col items-center shadow-md">
                    <!-- Sticky Logo Section -->
                    <div class="w-full flex justify-center header-bg pt-3 sm:pt-4 pb-3 sm:pb-4 px-3 sm:px-4">
                        <div class="flex items-center justify-between text-white w-full max-w-[850px]">
                            <!-- Header Kiri: Nama Aplikasi RyuExam & Logo Monitor -->
                            <a href="https://ryuexamcbt.web.id" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 sm:gap-3 cursor-pointer hover:opacity-90 transition-opacity" title="Kunjungi Website Resmi RyuExam CBT">
                                <i class="bi bi-display text-[24px] sm:text-[30px] md:text-[34px] text-sky-300 drop-shadow-md"></i>
                                <span class="text-[18px] sm:text-[22px] md:text-[24px] font-extrabold tracking-wide drop-shadow-md">
                                    <span style="color: #DF2463;">Ryu</span><span style="color: #38bdf8;">Exam</span>
                                </span>
                            </a>
                            <!-- Header Kanan: Logo Sekolah & Nama Sekolah -->
                            <div class="flex items-center gap-2 sm:gap-3 text-right">
                                <div class="flex flex-col justify-center min-w-0">
                                    <h1 class="text-[13px] sm:text-[16px] md:text-[18px] font-bold tracking-wide leading-tight drop-shadow-md truncate max-w-[160px] sm:max-w-[320px]">
                                        <?= htmlspecialchars($school_name) ?>
                                    </h1>
                                    <?php if (!empty($school_desc)): ?>
                                    <p class="text-[10px] sm:text-[11px] text-[#e0e0e0] drop-shadow-sm font-medium truncate max-w-[160px] sm:max-w-[320px]">
                                        <?= htmlspecialchars($school_desc) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($settings['school_logo']) && file_exists($settings['school_logo'])): ?>
                                    <img alt="Logo Sekolah" class="h-[36px] sm:h-[46px] md:h-[52px] w-auto drop-shadow-md object-contain shrink-0 bg-white/10 rounded p-1" src="<?= htmlspecialchars($settings['school_logo']) ?>?v=<?= filemtime($settings['school_logo']) ?>">
                                <?php else: ?>
                                    <i class="bi bi-mortarboard-fill text-[28px] sm:text-[36px] text-sky-300 shrink-0"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Sticky Student Info & Timer -->
                    <div class="w-full max-w-[850px] bg-[#F8FAFC] px-4 sm:px-6 py-3 border-b border-gray-200 flex justify-between items-center exam-header sm:rounded-t-md">
                        <div class="student-info">
                            <span id="display-name" class="fw-700 text-gray-800 text-[14px] sm:text-lg block mb-1">Nama Siswa</span>
                            <span id="display-class" class="badge">Kelas</span>
                        </div>
                        <div class="flex items-center gap-2 sm:gap-4">
                            <div class="timer bg-indigo-50 border border-indigo-100 text-indigo-700 px-3 py-1.5 rounded-md font-bold text-[14px] sm:text-[16px] flex items-center gap-2 shadow-sm" id="timer-display">
                                <i class="bi bi-clock text-[16px] sm:text-[18px]"></i>
                                <span id="time-remaining">00:00:00</span>
                            </div>
                            <div class="header-action-btns flex gap-1 sm:gap-2">
                                <button type="button" class="bg-gray-100 hover:bg-gray-200 text-gray-600 p-2 rounded-md transition-colors" id="btn-toggle-map" title="Daftar Soal">
                                    <i class="bi bi-grid-3x3-gap-fill text-[16px] sm:text-[18px]"></i>
                                </button>
                                <button type="button" class="bg-red-50 hover:bg-red-100 text-red-600 p-2 rounded-md transition-colors" id="btn-logout" title="Keluar">
                                    <i class="bi bi-box-arrow-right text-[16px] sm:text-[18px]"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modals -->
                <div id="question-map-modal" class="hidden">
                    <div class="map-overlay"></div>
                    <div class="map-content">
                        <button type="button" id="btn-close-map" class="close-icon">&times;</button>
                        <h3 style="margin-top:0;">Daftar Soal</h3>
                        <div id="question-map-grid" class="map-grid"></div>
                    </div>
                </div>

                <!-- Modal Konfirmasi Selesai Ujian (In-Page) -->
                <div id="confirm-finish-modal" class="hidden" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 10000; display: flex; justify-content: center; align-items: center;">
                    <div class="map-overlay" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px);"></div>
                    <div style="background: white; padding: 2rem; border-radius: 16px; position: relative; max-width: 92%; width: 440px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25); text-align: center; z-index: 1;">
                        <div style="width: 64px; height: 64px; background: #EEF2FF; color: #4F46E5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.25rem; font-size: 1.8rem;">
                            <i class="bi bi-clipboard-check"></i>
                        </div>
                        <h3 style="margin: 0 0 0.5rem; font-size: 1.35rem; color: #1E293B; font-weight: 700;">Kumpulkan Ujian?</h3>
                        <p style="color: #64748B; font-size: 0.95rem; line-height: 1.5; margin-bottom: 1.25rem;">Apakah Anda yakin ingin menyelesaikan dan mengumpulkan ujian ini? Jawaban tidak dapat diubah lagi setelah dikumpulkan.</p>
                        
                        <div id="confirm-summary-box" style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 12px 16px; margin-bottom: 1.25rem; text-align: left; font-size: 0.9rem;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                                <span style="color: #64748B;">Total Soal:</span>
                                <strong id="confirm-total-q" style="color: #1E293B;">0</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                                <span style="color: #059669;">Sudah Dijawab:</span>
                                <strong id="confirm-answered-q" style="color: #059669;">0</strong>
                            </div>
                            <div id="confirm-unanswered-row" style="display: flex; justify-content: space-between;">
                                <span style="color: #DC2626;">Belum Dijawab:</span>
                                <strong id="confirm-unanswered-q" style="color: #DC2626;">0</strong>
                            </div>
                        </div>

                        <div id="confirm-warning-msg" class="hidden" style="background: #FEF2F2; border: 1px solid #FCA5A5; color: #991B1B; border-radius: 8px; padding: 10px; font-size: 0.88rem; margin-bottom: 1.25rem; text-align: left;">
                        </div>

                        <div style="display: flex; gap: 10px;">
                            <button type="button" id="btn-cancel-finish" style="flex: 1; padding: 0.75rem 1rem; border-radius: 10px; border: 1px solid #CBD5E1; background: #fff; color: #475569; font-weight: 600; cursor: pointer; transition: all 0.2s;">Periksa Lagi</button>
                            <button type="button" id="btn-confirm-finish" style="flex: 1; padding: 0.75rem 1rem; border-radius: 10px; border: none; background: #10B981; color: #fff; font-weight: 600; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 6px -1px rgba(16, 185, 129, 0.3);">Ya, Kumpulkan</button>
                        </div>
                    </div>
                </div>

                <!-- Exam Card -->
                <div class="w-full max-w-[850px] bg-white rounded-none sm:rounded-b-md shadow-lg flex flex-col flex-grow exam-screen-container fade-in">
                    


                    <form id="exam-form" class="flex-grow flex flex-col">
                        <div id="single-question-container" class="p-4 sm:p-6 min-h-[400px] flex-grow">
                            <!-- Single Question will be injected here -->
                        </div>

                        <div class="exam-navigation bg-[#F8FAFC] px-4 sm:px-6 py-4 border-t border-gray-200 sticky bottom-0 z-20">
                            <button type="button" id="btn-prev" class="btn-nav btn-nav-prev" title="Soal Sebelumnya">
                                <i class="bi bi-chevron-left"></i>
                                <span class="nav-text hidden sm:inline">Sebelumnya</span>
                            </button>

                            <button type="button" id="btn-refresh-q" class="btn-nav-refresh" title="Segarkan / Muat Ulang Soal" onclick="refreshStudentQuestion()">
                                <i class="bi bi-arrow-clockwise" id="icon-refresh-q"></i>
                                <span class="refresh-text hidden sm:inline">Segarkan</span>
                            </button>

                            <button type="button" id="btn-next" class="btn-nav btn-nav-next" title="Soal Selanjutnya">
                                <span class="nav-text hidden sm:inline">Selanjutnya</span>
                                <i class="bi bi-chevron-right"></i>
                            </button>

                            <button type="submit" class="btn-nav btn-nav-finish hidden" id="btn-finish" title="Selesai & Kumpulkan Ujian">
                                <i class="bi bi-check2-circle"></i>
                                <span class="finish-text hidden sm:inline">Selesai & Kumpulkan</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- RESULT SCREEN -->
        <div id="result-screen" class="card hidden fade-in text-center">
            <div class="success-icon">✓</div>
            <h2>Ujian Selesai!</h2>
            <div id="result-score-container" class="hidden" style="margin: 20px 0; padding: 20px; background: #f8fafc; border-radius: 12px;">
                <p style="margin: 0; color: #64748b; font-size: 0.9rem; text-transform: uppercase; font-weight: 600; letter-spacing: 1px;">Nilai Anda</p>
                <h1 id="result-score" style="font-size: 3.5rem; color: var(--primary); margin: 5px 0 0 0; font-weight: 800;">0</h1>
            </div>
            <p>Jawaban Anda telah berhasil disimpan. Silakan keluar ruangan atau tutup halaman ini.</p>
            <button class="btn-outline mt-4" onclick="location.reload()">Kembali ke Awal</button>
        </div>

    </div>
    
    <!-- Anti-Cheat Overlay -->
    <div id="anticheat-overlay" class="hidden">
        <div class="overlay-content text-center">
            <i id="anticheat-icon" class="bi bi-exclamation-triangle-fill" style="font-size: 4rem; color: #EF4444; margin-bottom: 20px;"></i>
            <h2 id="anticheat-title" style="color: #EF4444; margin-bottom: 10px;">Ujian Dihentikan Sementara!</h2>
            <div id="anticheat-badge-container" style="margin-bottom: 15px;">
                <span id="anticheat-badge" style="background: #FEF3C7; color: #B45309; padding: 6px 16px; border-radius: 20px; font-weight: 700; font-size: 0.95rem; display: inline-block;">Peringatan Pelanggaran</span>
            </div>
            <p id="anticheat-message" style="font-size: 1.1rem; margin-bottom: 15px;">Sistem mendeteksi Anda keluar dari mode layar penuh atau berpindah aplikasi.</p>
            <p id="anticheat-submsg" style="font-weight: 600; color: #64748b; margin-bottom: 25px;">Aktivitas ini telah dicatat oleh sistem.</p>
            <div id="anticheat-actions">
                <button id="btn-resume-exam" class="btn-primary" style="padding: 12px 24px; font-size: 1.1rem; width: auto; display: inline-block;"><i class="bi bi-arrows-fullscreen mr-1"></i> Kembali ke Ujian (Layar Penuh)</button>
            </div>
            <div id="anticheat-lock-info" class="hidden" style="margin-top: 15px;">
                <div id="anticheat-timer-box" class="hidden" style="margin-bottom: 15px; padding: 15px 20px; background: #FEF2F2; border: 2px dashed #EF4444; border-radius: 12px; display: inline-block; min-width: 260px;">
                    <div style="font-size: 0.85rem; color: #991B1B; font-weight: 700; text-transform: uppercase; letter-spacing: 1px;">Kunci Otomatis Terbuka Dalam:</div>
                    <div id="anticheat-countdown" style="font-size: 2.8rem; font-weight: 800; color: #DC2626; font-family: monospace; margin: 4px 0; letter-spacing: 2px;">00:00</div>
                    <div style="font-size: 0.8rem; color: #7F1D1D;">Atau minta Pengawas / Admin untuk membuka kunci sekarang.</div>
                </div>
                <div id="anticheat-admin-wait" style="color: #DC2626; font-weight: 600; font-size: 1rem; margin-top: 5px;">
                    <i class="bi bi-arrow-repeat animate-spin mr-2"></i> Menunggu pengawas / admin membuka kunci ujian Anda...
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        window.DISABLE_TOKEN = <?= $disable_token ? 'true' : 'false' ?>;
        window.LOGIN_METHOD = '<?= $login_method ?>';
        window.SERVER_SETTINGS = <?= json_encode($settings, JSON_UNESCAPED_UNICODE) ?>;
    </script>
    <script src="script.js?v=<?= file_exists('script.js') ? filemtime('script.js') : '1.6.8' ?>"></script>
</body>
</html>
