// Anti-Copas Protection
document.addEventListener('contextmenu', event => event.preventDefault()); // Disable right click
document.addEventListener('keydown', event => {
    // Disable Ctrl+C, Ctrl+V, Ctrl+X, Ctrl+U, Ctrl+P, F12
    if (
        event.key === 'F12' ||
        (event.ctrlKey && ['c', 'v', 'x', 'u', 'p', 's'].includes(event.key.toLowerCase())) ||
        (event.ctrlKey && event.shiftKey && ['i', 'j', 'c'].includes(event.key.toLowerCase()))
    ) {
        event.preventDefault();
        alert('Fitur ini dinonaktifkan demi keamanan ujian.');
    }
});

// Anti-cheat Detection & Violation Enforcer
function handleViolation(reason) {
    // Jangan pernah deteksi pelanggaran jika siswa sedang/sudah mengumpulkan ujian
    if (state.isSubmitting || state.isFinished || state.isConfirmingFinish) return;
    if (examScreen.classList.contains('hidden')) return;
    if (resultScreen && !resultScreen.classList.contains('hidden')) return;
    if (state.isLocked) return;
    
    // Debounce to prevent duplicate triggers within 2 seconds (e.g., blur + visibilitychange firing together)
    const now = Date.now();
    if (state.lastViolationTime && (now - state.lastViolationTime < 2000)) {
        return;
    }
    state.lastViolationTime = now;
    
    state.violations = (state.violations || 0) + 1;
    saveSession();
    
    // Asynchronously report to server
    if (state.selectedStudentId) {
        const fd = new FormData();
        fd.append('action', 'report_violation');
        fd.append('student_id', state.selectedStudentId);
        fd.append('reason', reason);
        fetch('api.php', { method: 'POST', body: fd }).catch(() => {});
    }
    
    let parsedMax = parseInt(state.settings.max_violations);
    const maxViolations = !isNaN(parsedMax) ? parsedMax : 3;
    const violationAction = state.settings.violation_action || 'lockout';
    
    const overlay = document.getElementById('anticheat-overlay');
    const icon = document.getElementById('anticheat-icon');
    const title = document.getElementById('anticheat-title');
    const badge = document.getElementById('anticheat-badge');
    const msg = document.getElementById('anticheat-message');
    const submsg = document.getElementById('anticheat-submsg');
    const actions = document.getElementById('anticheat-actions');
    const lockInfo = document.getElementById('anticheat-lock-info');
    
    if (state.violations >= maxViolations) {
        if (violationAction === 'auto_submit') {
            if (overlay) overlay.classList.add('hidden');
            alert(`Peringatan: Anda telah melakukan pelanggaran sebanyak ${state.violations} kali (mencapai batas toleransi ${maxViolations} kali). Ujian Anda otomatis dikumpulkan oleh sistem.`);
            finishExam(true);
            return;
        } else {
            // Lockout student screen
            state.isLocked = true;
            const lockoutSecs = parseInt(state.settings.lockout_duration);
            const duration = isNaN(lockoutSecs) ? 60 : lockoutSecs;
            if (duration > 0) {
                state.lockoutEndTime = Date.now() + (duration * 1000);
            } else {
                state.lockoutEndTime = null;
            }
            saveSession();
            showLockedOverlay();
            return;
        }
    }
    
    // Warning state (violations < maxViolations)
    if (icon) icon.className = 'bi bi-exclamation-triangle-fill text-warning';
    if (title) title.textContent = 'Peringatan Pelanggaran!';
    if (badge) {
        badge.className = 'badge badge-warning p-2 mb-3';
        badge.textContent = `Pelanggaran ke-${state.violations} dari batas ${maxViolations}`;
    }
    if (msg) msg.textContent = reason;
    if (submsg) {
        const actionLabel = violationAction === 'auto_submit' ? 'otomatis dikumpulkan' : 'dikunci dan harus dibuka oleh pengawas';
        submsg.textContent = `Perhatian: Jika Anda melanggar hingga ${maxViolations} kali, ujian akan ${actionLabel}.`;
    }
    if (actions) actions.classList.remove('hidden');
    if (lockInfo) lockInfo.classList.add('hidden');
    if (overlay) overlay.classList.remove('hidden');
}

function showLockedOverlay() {
    let parsedMax = parseInt(state.settings.max_violations);
    const maxViolations = !isNaN(parsedMax) ? parsedMax : 3;
    const overlay = document.getElementById('anticheat-overlay');
    const icon = document.getElementById('anticheat-icon');
    const title = document.getElementById('anticheat-title');
    const badge = document.getElementById('anticheat-badge');
    const msg = document.getElementById('anticheat-message');
    const submsg = document.getElementById('anticheat-submsg');
    const actions = document.getElementById('anticheat-actions');
    const lockInfo = document.getElementById('anticheat-lock-info');
    const timerBox = document.getElementById('anticheat-timer-box');
    const countdownEl = document.getElementById('anticheat-countdown');
    const adminWait = document.getElementById('anticheat-admin-wait');
    
    if (icon) icon.className = 'bi bi-lock-fill text-danger';
    if (title) title.textContent = 'Ujian Terkunci!';
    if (badge) {
        badge.className = 'badge badge-danger p-2 mb-3';
        badge.textContent = `Batas Pelanggaran Tercapai (${state.violations || maxViolations}/${maxViolations})`;
    }
    if (msg) msg.textContent = 'Layar ujian Anda telah dikunci karena mencapai batas maksimal toleransi pelanggaran.';
    if (submsg) submsg.textContent = 'Silakan tunggu hingga hitungan mundur selesai atau hubungi Pengawas/Admin untuk membuka kunci.';
    if (actions) actions.classList.add('hidden');
    if (lockInfo) lockInfo.classList.remove('hidden');
    if (overlay) overlay.classList.remove('hidden');
    
    // Clear any previous countdown interval
    if (state.lockoutTimerInterval) {
        clearInterval(state.lockoutTimerInterval);
        state.lockoutTimerInterval = null;
    }
    
    // Handle countdown timer display if lockoutEndTime is set
    if (state.lockoutEndTime && state.lockoutEndTime > Date.now()) {
        if (timerBox) timerBox.classList.remove('hidden');
        
        function updateCountdown() {
            const remainingSecs = Math.max(0, Math.ceil((state.lockoutEndTime - Date.now()) / 1000));
            const mins = Math.floor(remainingSecs / 60);
            const secs = remainingSecs % 60;
            if (countdownEl) {
                countdownEl.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
            }
            if (remainingSecs <= 0) {
                if (state.lockoutTimerInterval) {
                    clearInterval(state.lockoutTimerInterval);
                    state.lockoutTimerInterval = null;
                }
                unlockStudentLocally('Waktu terkunci telah berakhir. Silakan lanjutkan ujian Anda.');
            }
        }
        updateCountdown();
        state.lockoutTimerInterval = setInterval(updateCountdown, 1000);
    } else {
        if (timerBox) timerBox.classList.add('hidden');
        if (adminWait) adminWait.classList.remove('hidden');
    }
    
    startUnlockCheck();
}

function unlockStudentLocally(message) {
    state.isLocked = false;
    state.violations = 0;
    state.lockoutEndTime = null;
    saveSession();
    
    if (state.unlockInterval) {
        clearInterval(state.unlockInterval);
        state.unlockInterval = null;
    }
    if (state.lockoutTimerInterval) {
        clearInterval(state.lockoutTimerInterval);
        state.lockoutTimerInterval = null;
    }
    
    // Notify server to clear lock
    if (state.selectedStudentId) {
        const fd = new FormData();
        fd.append('action', 'clear_lock');
        fd.append('student_id', state.selectedStudentId);
        fetch('api.php', { method: 'POST', body: fd }).catch(() => {});
    }
    
    const overlay = document.getElementById('anticheat-overlay');
    const actions = document.getElementById('anticheat-actions');
    const lockInfo = document.getElementById('anticheat-lock-info');
    const title = document.getElementById('anticheat-title');
    const msgEl = document.getElementById('anticheat-message');
    const icon = document.getElementById('anticheat-icon');
    const badge = document.getElementById('anticheat-badge');
    const submsg = document.getElementById('anticheat-submsg');
    
    if (overlay) {
        overlay.classList.remove('hidden');
        if (actions) actions.classList.remove('hidden');
        if (lockInfo) lockInfo.classList.add('hidden');
        if (title) {
            title.textContent = 'Kunci Telah Dibuka';
            title.style.color = '#10B981';
        }
        if (icon) {
            icon.className = 'bi bi-check-circle-fill';
            icon.style.color = '#10B981';
        }
        if (msgEl) msgEl.textContent = message || 'Kunci ujian telah dibuka. Silakan lanjutkan ujian Anda.';
        if (badge) {
            badge.style.background = '#D1FAE5';
            badge.style.color = '#065F46';
            badge.textContent = 'Silakan Lanjutkan';
        }
        if (submsg) submsg.textContent = 'Klik tombol di bawah untuk kembali ke mode layar penuh.';
    }
}

function startUnlockCheck() {
    if (state.unlockInterval) clearInterval(state.unlockInterval);
    // Poll syncProgress every 2.5 seconds while locked to catch proctor unlock
    state.unlockInterval = setInterval(() => {
        if (!state.isLocked) {
            clearInterval(state.unlockInterval);
            state.unlockInterval = null;
            return;
        }
        syncProgress();
    }, 2500);
}

// Event Listeners for Anti-cheat
document.addEventListener("visibilitychange", () => {
    if (state.isSubmitting || state.isFinished || state.isConfirmingFinish) return;
    if (document.visibilityState === 'hidden' && !examScreen.classList.contains('hidden')) {
        handleViolation("Sistem mendeteksi Anda berpindah tab atau meminimalkan browser.");
    }
});

document.addEventListener('fullscreenchange', () => {
    if (state.isSubmitting || state.isFinished || state.isConfirmingFinish) return;
    if (!document.fullscreenElement && !examScreen.classList.contains('hidden')) {
        handleViolation("Sistem mendeteksi Anda keluar dari mode layar penuh (Fullscreen).");
    }
});

window.addEventListener('blur', () => {
    if (state.isSubmitting || state.isFinished || state.isConfirmingFinish) return;
    if (!examScreen.classList.contains('hidden')) {
        handleViolation("Sistem mendeteksi jendela ujian kehilangan fokus.");
    }
});

// Resume exam button
document.addEventListener('DOMContentLoaded', () => {
    const btnResume = document.getElementById('btn-resume-exam');
    if (btnResume) {
        btnResume.addEventListener('click', () => {
            if (state.isLocked) return;
            requestFullScreen();
            setTimeout(() => {
                const overlay = document.getElementById('anticheat-overlay');
                if (overlay) overlay.classList.add('hidden');
            }, 400);
        });
    }

    const btnCancelFinish = document.getElementById('btn-cancel-finish');
    if (btnCancelFinish) {
        btnCancelFinish.addEventListener('click', closeConfirmFinishModal);
    }

    const btnConfirmFinish = document.getElementById('btn-confirm-finish');
    if (btnConfirmFinish) {
        btnConfirmFinish.addEventListener('click', () => {
            btnConfirmFinish.disabled = true;
            btnConfirmFinish.innerHTML = '<i class="bi bi-arrow-repeat animate-spin mr-1"></i> Mengirim...';
            finishExam(false);
        });
    }

    // Inisialisasi PWA Service Worker & Install Banner
    initPwa();
});

// Progressive Web App (PWA) Initialization
function initPwa() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('sw.js').then((reg) => {
                console.log('[PWA] Service Worker registered:', reg.scope);
            }).catch((err) => {
                console.warn('[PWA] Service Worker registration failed:', err);
            });
        });
    }

    // Biarkan notifikasi instalasi bawaan browser HP (Android Chrome mini-infobar) muncul secara otomatis
    window.addEventListener('appinstalled', () => {
        console.log('[PWA] Aplikasi CBT berhasil dipasang ke Layar Utama.');
    });
}

let questionsData = []; // Store dynamically loaded questions

// App State
const state = {
    exams: [],
    classes: [],
    students: [],
    selectedExamId: null,
    selectedExamToken: null,
    selectedClassId: null,
    selectedStudentId: null,
    selectedStudentName: null,
    selectedClassName: null,
    timerInterval: null,
    syncInterval: null,
    unlockInterval: null,
    lockoutTimerInterval: null,
    startTime: null,
    endTime: null,
    lockoutEndTime: null,
    shuffledQuestions: [],
    currentQuestionIndex: 0,
    violations: 0,
    isLocked: false,
    isSubmitting: false,
    isFinished: false,
    isConfirmingFinish: false,
    lastViolationTime: 0,
    hasUnsavedChanges: false,
    batchSyncTimeout: null,
    isSyncing: false,
    settings: { require_all_answered: false, min_time_submit: 0, max_violations: 3, violation_action: 'lockout', lockout_duration: 60 }
};

// Local Storage Helper
function saveSession() {
    const sessionData = {
        selectedExamId: state.selectedExamId,
        selectedExam: state.selectedExam,
        selectedStudentId: state.selectedStudentId,
        selectedStudentName: state.selectedStudentName,
        selectedClassName: state.selectedClassName,
        startTime: state.startTime,
        endTime: state.endTime,
        lockoutEndTime: state.lockoutEndTime,
        shuffledQuestions: state.shuffledQuestions,
        currentQuestionIndex: state.currentQuestionIndex,
        violations: state.violations || 0,
        isLocked: !!state.isLocked
    };
    sessionStorage.setItem('cbt_exam_state', JSON.stringify(sessionData));
}

function clearSession() {
    sessionStorage.removeItem('cbt_exam_state');
}

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const examScreen = document.getElementById('exam-screen');
const resultScreen = document.getElementById('result-screen');

const loginForm = document.getElementById('login-form');
const examSelect = document.getElementById('exam-select');
const tokenInput = document.getElementById('token');
const classSelect = document.getElementById('class-select');
const studentSearch = document.getElementById('student-search');
const studentIdInput = document.getElementById('student-id');
const autocompleteList = document.getElementById('student-autocomplete-list');
const studentPasswordContainer = document.getElementById('student-password-container');
const studentPasswordInput = document.getElementById('student-password');
const startBtn = document.getElementById('start-btn');

const displayName = document.getElementById('display-name');
const displayClass = document.getElementById('display-class');
const singleQuestionContainer = document.getElementById('single-question-container');
const examForm = document.getElementById('exam-form');
const timerEl = document.getElementById('timer-display');
const timeRemainingEl = document.getElementById('time-remaining');
// Pagination & Map Elements
const btnPrev = document.getElementById('btn-prev');
const btnNext = document.getElementById('btn-next');
const btnFinish = document.getElementById('btn-finish');
const btnToggleMap = document.getElementById('btn-toggle-map');
const btnCloseMap = document.getElementById('btn-close-map');
const questionMapModal = document.getElementById('question-map-modal');
const questionMapGrid = document.getElementById('question-map-grid');
const btnLogout = document.getElementById('btn-logout');

// Initialize
async function init() {
    // 1. Muat pengaturan server yang diinjeksi langsung oleh PHP (seketika & selalu segar saat refresh)
    if (window.SERVER_SETTINGS && typeof window.SERVER_SETTINGS === 'object') {
        state.settings = Object.assign({}, state.settings, window.SERVER_SETTINGS);
    }

    try {
        const responseSettings = await fetch(`api.php?action=get_settings&_t=${Date.now()}`, { cache: 'no-store' });
        const resSettings = await responseSettings.json();
        if (resSettings.status === 'success' && resSettings.data) {
            state.settings = Object.assign({}, state.settings, resSettings.data);
        }
    } catch (e) {}

    // Check if there is an active session
    const saved = sessionStorage.getItem('cbt_exam_state');
    if (saved) {
        try {
            const parsed = JSON.parse(saved);
            if (parsed.endTime && parsed.endTime > Date.now()) {
                // Restore state
                state.selectedExamId = parsed.selectedExamId;
                state.selectedExam = parsed.selectedExam;
                state.selectedStudentId = parsed.selectedStudentId;
                state.selectedStudentName = parsed.selectedStudentName;
                state.selectedClassName = parsed.selectedClassName;
                state.startTime = parsed.startTime || Date.now();
                state.endTime = parsed.endTime;
                state.lockoutEndTime = parsed.lockoutEndTime || null;
                state.shuffledQuestions = parsed.shuffledQuestions;
                state.currentQuestionIndex = parsed.currentQuestionIndex;
                state.violations = parsed.violations || 0;
                state.isLocked = !!parsed.isLocked;
                
                // Show Exam Screen Directly
                const loginWrap = document.getElementById('login-wrapper');
                if (loginWrap) loginWrap.classList.add('hidden');
                loginScreen.classList.add('hidden');
                examScreen.classList.remove('hidden');
                displayName.textContent = state.selectedStudentName;
                displayClass.textContent = state.selectedClassName;
                
                renderQuestion(state.currentQuestionIndex);
                resumeTimer();
                if (state.isLocked) {
                    if (state.lockoutEndTime && Date.now() >= state.lockoutEndTime) {
                        unlockStudentLocally('Waktu terkunci telah berakhir. Silakan lanjutkan ujian.');
                    } else {
                        showLockedOverlay();
                    }
                }
                return; // skip loading classes for login
            } else {
                clearSession(); // Time expired
            }
        } catch (e) {
            clearSession();
        }
    }

    try {
        const responseSettings = await fetch('api.php?action=get_settings');
        const resSettings = await responseSettings.json();
        if (resSettings.status === 'success') {
            state.settings = resSettings.data;
        }

        const responseExams = await fetch('api.php?action=get_exams');
        const resExams = await responseExams.json();
        
        if (resExams.status === 'success') {
            state.exams = resExams.data;
            populateExams();
        }

        const responseClasses = await fetch('api.php?action=get_classes');
        const resClasses = await responseClasses.json();
        
        if (resClasses.status === 'success') {
            state.classes = resClasses.data;
            if (classSelect) populateClasses();
            
            // Event listeners for standard name_select mode
            if (examSelect) examSelect.addEventListener('change', handleExamChange);
            if (tokenInput) tokenInput.addEventListener('input', checkToken);
            if (classSelect) classSelect.addEventListener('change', handleClassChange);
            if (studentSearch) studentSearch.addEventListener('input', handleStudentSearch);
            document.addEventListener('click', function(e) {
                if (studentSearch && e.target !== studentSearch && autocompleteList) {
                    autocompleteList.classList.add('hidden');
                }
            });
            if (loginForm) loginForm.addEventListener('submit', startExam);
            
            // Event listeners for username login mode
            setupUsernameLoginHandlers();
        }
    } catch (err) {
        console.error('Failed to load initial data', err);
        if (examSelect) examSelect.innerHTML = '<option disabled selected>Gagal memuat data ujian.</option>';
        if (classSelect) classSelect.innerHTML = '<option disabled selected>Gagal memuat data kelas.</option>';
        if (window.examDropdownCtrl) window.examDropdownCtrl.disable('Gagal memuat data ujian.');
        if (window.usernameExamDropdownCtrl) window.usernameExamDropdownCtrl.disable('Gagal memuat data ujian.');
    }
}

let examDropdownCtrl = null;
let usernameExamDropdownCtrl = null;

function setupExamSearchableDropdown(config) {
    const container = document.getElementById(config.containerId);
    const input = document.getElementById(config.inputId);
    const selectEl = document.getElementById(config.selectId);
    const list = document.getElementById(config.listId);

    if (!input || !list) return null;

    let activeIndex = -1;

    function renderList(filterText = '') {
        list.innerHTML = '';
        activeIndex = -1;

        if (!state.exams || state.exams.length === 0) {
            list.innerHTML = '<div class="px-4 py-3 text-[13px] text-gray-500 text-center italic">Tidak ada ujian aktif</div>';
            return;
        }

        const q = filterText.trim().toLowerCase();
        const filtered = state.exams.filter(e => !q || (e.name && e.name.toLowerCase().includes(q)));

        if (filtered.length === 0) {
            list.innerHTML = '<div class="px-4 py-3 text-[13px] text-gray-500 text-center italic">Mata pelajaran tidak ditemukan</div>';
            return;
        }

        filtered.forEach((e, idx) => {
            const item = document.createElement('div');
            item.className = 'exam-dropdown-item';
            if (selectEl && selectEl.value == e.id) {
                item.classList.add('selected');
            }
            item.textContent = (e.name || '').toUpperCase();
            item.dataset.id = e.id;
            item.dataset.name = e.name;
            item.dataset.index = idx;

            item.addEventListener('mousedown', function(evt) {
                evt.preventDefault();
                selectExam(e);
            });

            list.appendChild(item);
        });
    }

    function selectExam(exam) {
        input.value = (exam.name || '').toUpperCase();
        if (selectEl) {
            selectEl.value = exam.id;
            selectEl.dispatchEvent(new Event('change'));
        }
        closeDropdown();
        if (typeof config.onSelect === 'function') {
            config.onSelect(exam);
        }
    }

    function clearSelection() {
        if (selectEl) {
            selectEl.value = '';
            selectEl.dispatchEvent(new Event('change'));
        }
        input.value = '';
        if (typeof config.onClear === 'function') {
            config.onClear();
        }
    }

    function openDropdown() {
        if (input.disabled) return;
        renderList(input.value);
        list.classList.remove('hidden');
        if (container) container.classList.add('dropdown-open');
    }

    function closeDropdown() {
        list.classList.add('hidden');
        if (container) container.classList.remove('dropdown-open');
        activeIndex = -1;
    }

    input.addEventListener('focus', function() {
        if (input.disabled) return;
        openDropdown();
        setTimeout(() => {
            try { input.select(); } catch(e) {}
        }, 50);
    });

    input.addEventListener('click', function() {
        if (input.disabled) return;
        if (list.classList.contains('hidden')) {
            openDropdown();
            setTimeout(() => {
                try { input.select(); } catch(e) {}
            }, 50);
        }
    });

    input.addEventListener('input', function() {
        if (selectEl && selectEl.value) {
            const cur = state.exams.find(e => e.id == selectEl.value);
            if (!cur || (cur.name && cur.name.toUpperCase() !== input.value.trim().toUpperCase())) {
                selectEl.value = '';
                if (typeof config.onClear === 'function') config.onClear();
            }
        }
        renderList(input.value);
        list.classList.remove('hidden');
    });

    input.addEventListener('keydown', function(e) {
        const items = list.querySelectorAll('.exam-dropdown-item');
        if (list.classList.contains('hidden')) {
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                openDropdown();
                return;
            }
        }

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (items.length === 0) return;
            activeIndex = (activeIndex + 1) % items.length;
            updateHighlight(items);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (items.length === 0) return;
            activeIndex = (activeIndex - 1 + items.length) % items.length;
            updateHighlight(items);
        } else if (e.key === 'Enter') {
            if (!list.classList.contains('hidden')) {
                e.preventDefault();
                if (activeIndex >= 0 && items[activeIndex]) {
                    const id = items[activeIndex].dataset.id;
                    const found = state.exams.find(ex => ex.id == id);
                    if (found) selectExam(found);
                } else if (items.length === 1) {
                    const id = items[0].dataset.id;
                    const found = state.exams.find(ex => ex.id == id);
                    if (found) selectExam(found);
                }
            }
        } else if (e.key === 'Escape') {
            closeDropdown();
        }
    });

    function updateHighlight(items) {
        items.forEach((it, idx) => {
            if (idx === activeIndex) {
                it.classList.add('active');
                it.scrollIntoView({ block: 'nearest' });
            } else {
                it.classList.remove('active');
            }
        });
    }

    // Close dropdown and normalize input only when clicking/tapping outside container
    document.addEventListener('pointerdown', function(e) {
        if (container && !container.contains(e.target)) {
            closeDropdown();
            if (selectEl && selectEl.value) {
                const found = state.exams.find(ex => ex.id == selectEl.value);
                if (found) {
                    input.value = (found.name || '').toUpperCase();
                } else {
                    clearSelection();
                }
            } else {
                input.value = '';
            }
        }
    });

    return {
        enable: () => {
            input.disabled = false;
            input.placeholder = 'Pilih Mata Pelajaran';
        },
        disable: (msg = 'Memuat data ujian...') => {
            input.disabled = true;
            input.value = '';
            input.placeholder = msg;
            if (selectEl) selectEl.value = '';
            closeDropdown();
        },
        refresh: () => {
            if (selectEl && selectEl.value) {
                const found = state.exams.find(e => e.id == selectEl.value);
                if (found) input.value = (found.name || '').toUpperCase();
            }
        },
        selectExam,
        clearSelection
    };
}

function initExamDropdowns() {
    if (!examDropdownCtrl) {
        examDropdownCtrl = setupExamSearchableDropdown({
            containerId: 'exam-dropdown-container',
            inputId: 'exam-search-input',
            selectId: 'exam-select',
            listId: 'exam-dropdown-list',
            onSelect: () => {
                handleExamChange();
            },
            onClear: () => {
                state.selectedExam = null;
                state.selectedExamId = null;
                if (classSelect) {
                    classSelect.disabled = true;
                    classSelect.innerHTML = '<option value="" disabled selected>Pilih Kelas</option>';
                }
                if (studentSearch) {
                    studentSearch.disabled = true;
                    studentSearch.value = '';
                }
                if (tokenInput) {
                    tokenInput.value = '';
                }
                if (startBtn) {
                    startBtn.disabled = true;
                }
            }
        });
        window.examDropdownCtrl = examDropdownCtrl;
    }

    if (!usernameExamDropdownCtrl) {
        usernameExamDropdownCtrl = setupExamSearchableDropdown({
            containerId: 'username-exam-dropdown-container',
            inputId: 'username-exam-search',
            selectId: 'username-exam-select',
            listId: 'username-exam-list'
        });
        window.usernameExamDropdownCtrl = usernameExamDropdownCtrl;
    }
}

function populateExams() {
    initExamDropdowns();

    if (examSelect) {
        examSelect.innerHTML = '<option value="" disabled selected>Pilih Ujian / Mata Pelajaran</option>';
        state.exams.forEach(e => {
            const opt = document.createElement('option');
            opt.value = e.id;
            opt.textContent = e.name;
            examSelect.appendChild(opt);
        });
        examSelect.disabled = false;
    }
    const usernameExamSelect = document.getElementById('username-exam-select');
    if (usernameExamSelect) {
        usernameExamSelect.innerHTML = '<option value="" disabled selected>Pilih Mata Pelajaran / Ujian</option>';
        state.exams.forEach(e => {
            const opt = document.createElement('option');
            opt.value = e.id;
            opt.textContent = e.name;
            usernameExamSelect.appendChild(opt);
        });
        usernameExamSelect.disabled = false;
    }

    if (examDropdownCtrl) examDropdownCtrl.enable();
    if (usernameExamDropdownCtrl) usernameExamDropdownCtrl.enable();
}

let tempUsernameLoginData = null;

function setupUsernameLoginHandlers() {
    const userForm = document.getElementById('username-login-form');
    const btnBack = document.getElementById('btn-back-to-login');
    const confirmForm = document.getElementById('confirm-start-form');

    if (userForm) {
        userForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const btn = document.getElementById('btn-login-username');
            const origHtml = btn ? btn.innerHTML : 'Masuk / Login';

            const usernameInp = document.getElementById('username') || document.getElementById('input-username');
            const passwordInp = document.getElementById('password') || document.getElementById('input-password');
            const examSelectInp = document.getElementById('username-exam-select');

            if (!examSelectInp || !examSelectInp.value) {
                alert('Silakan pilih mata pelajaran terlebih dahulu.');
                const searchInp = document.getElementById('username-exam-search');
                if (searchInp) searchInp.focus();
                return;
            }

            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="bi bi-arrow-repeat animate-spin mr-1"></i> Memeriksa data...';
            }

            const fd = new FormData();
            fd.append('action', 'student_username_login');
            fd.append('username', usernameInp ? usernameInp.value.trim() : '');
            fd.append('password', passwordInp ? passwordInp.value : '');
            fd.append('exam_id', examSelectInp ? examSelectInp.value : '');

            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const json = await res.json();

                if (json.status === 'success') {
                    tempUsernameLoginData = json;
                    tempUsernameLoginData.entered_password = passwordInp ? passwordInp.value : '';

                    // Fill Confirmation Screen
                    document.getElementById('confirm-student-name').textContent = json.student.name;
                    document.getElementById('confirm-student-class').textContent = json.student.class_name;
                    document.getElementById('confirm-exam-name').textContent = json.exam.name;
                    document.getElementById('confirm-exam-duration').textContent = json.exam.duration + ' Menit';
                    document.getElementById('confirm-exam-questions').textContent = (json.exam.question_count || 0) + ' Soal';

                    // Switch visible container
                    const loginBox = document.getElementById('username-login-container');
                    const confirmBox = document.getElementById('confirm-data-container');
                    if (loginBox) loginBox.classList.add('hidden');
                    if (confirmBox) confirmBox.classList.remove('hidden');

                    const subtitle = document.getElementById('login-subtitle');
                    if (subtitle) subtitle.textContent = 'Konfirmasi Data Peserta Ujian';

                    const tokenInputEl = document.getElementById('confirm-token-input');
                    if (tokenInputEl) {
                        tokenInputEl.value = '';
                        tokenInputEl.focus();
                    }
                } else {
                    alert(json.message || 'Login gagal. Periksa username dan password Anda.');
                }
            } catch (err) {
                alert('Terjadi kesalahan sistem saat menghubungi server.');
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = origHtml;
                }
            }
        });
    }

    if (btnBack) {
        btnBack.addEventListener('click', function() {
            const loginBox = document.getElementById('username-login-container');
            const confirmBox = document.getElementById('confirm-data-container');
            if (confirmBox) confirmBox.classList.add('hidden');
            if (loginBox) loginBox.classList.remove('hidden');

            const subtitle = document.getElementById('login-subtitle');
            if (subtitle) subtitle.textContent = 'Silakan masuk menggunakan Username dan Password Anda';

            tempUsernameLoginData = null;
        });
    }

    if (confirmForm) {
        confirmForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            if (!tempUsernameLoginData) {
                alert('Sesi konfirmasi tidak ditemukan. Silakan login kembali.');
                location.reload();
                return;
            }

            const tokenInputEl = document.getElementById('confirm-token-input');
            const tokenVal = tokenInputEl ? tokenInputEl.value.trim().toUpperCase() : '';

            // Setup current student and exam state
            state.selectedStudentId = tempUsernameLoginData.student.id;
            state.selectedStudentName = tempUsernameLoginData.student.name;
            state.selectedClassName = tempUsernameLoginData.student.class_name;
            state.selectedExamId = tempUsernameLoginData.exam.id;
            state.selectedExam = tempUsernameLoginData.exam;
            state.selectedExamToken = tempUsernameLoginData.exam.token;
            state.selectedExamPrevToken = tempUsernameLoginData.exam.prev_token || null;

            // Validate token if required
            if (tempUsernameLoginData.require_token) {
                if (!tokenVal) {
                    alert('Token ujian wajib diisi!');
                    if (tokenInputEl) tokenInputEl.focus();
                    return;
                }
            }

            const btnConfirmStart = document.getElementById('btn-start-from-confirm');
            await executeStartExam(tokenVal, btnConfirmStart);
        });
    }
}

function isTokenDisabled() {
    return !!(window.DISABLE_TOKEN || (state.settings && state.settings.disable_token) || !tokenInput);
}

function handleExamChange() {
    const selected = state.exams.find(e => e.id == examSelect.value);
    if (selected) {
        state.selectedExam = selected;
        state.selectedExamId = selected.id;
        state.selectedExamToken = selected.token;
        state.selectedExamPrevToken = selected.prev_token || null;
        
        // Reset pilihan kelas & siswa jika berganti ujian
        state.selectedClassId = null;
        state.selectedClassName = null;
        state.selectedStudentId = null;
        state.selectedStudentName = null;
        if (studentSearch) {
            studentSearch.disabled = true;
            studentSearch.value = '';
        }
        if (studentIdInput) studentIdInput.value = '';
        if (studentPasswordContainer) {
            studentPasswordContainer.style.display = 'none';
            studentPasswordInput.value = '';
        }
        if (startBtn) startBtn.disabled = true;
        
        if (isTokenDisabled()) {
            populateClasses(true);
            classSelect.disabled = false;
        } else {
            if (tokenInput) {
                tokenInput.value = ''; // Reset token
                tokenInput.style.borderColor = '';
                const tokenIcon = document.getElementById('token-status-icon');
                if (tokenIcon) tokenIcon.className = 'bi';
            }
            populateClasses(true);
            classSelect.disabled = true;
        }
    }
}

let tokenCheckDebounce = null;

async function checkToken() {
    if (isTokenDisabled()) {
        populateClasses(false);
        classSelect.disabled = false;
        return;
    }
    
    const tokenIcon = document.getElementById('token-status-icon');
    if (!tokenInput || !state.selectedExamId) return;
    
    const val = tokenInput.value.trim().toUpperCase();
    if (val === '') {
        tokenInput.style.borderColor = '';
        if (tokenIcon) tokenIcon.className = 'bi';
        classSelect.disabled = true;
        studentSearch.disabled = true;
        startBtn.disabled = true;
        return;
    }

    if (tokenCheckDebounce) clearTimeout(tokenCheckDebounce);
    tokenCheckDebounce = setTimeout(async () => {
        if (tokenIcon) {
            tokenIcon.className = 'bi bi-arrow-repeat animate-spin text-gray-400';
        }
        try {
            const fd = new FormData();
            fd.append('action', 'verify_exam_token');
            fd.append('exam_id', state.selectedExamId);
            fd.append('token', val);
            const resp = await fetch('api.php', { method: 'POST', body: fd });
            const res = await resp.json();
            const isValid = (res.status === 'success' && res.valid === true);

            if (isValid) {
                tokenInput.style.borderColor = 'var(--secondary)';
                if (tokenIcon) {
                    tokenIcon.className = 'bi bi-check-circle-fill';
                    tokenIcon.style.color = 'var(--secondary)';
                }
                // Pertahankan kelas yang sudah dipilih siswa (false = jangan reset)
                populateClasses(false);
                classSelect.disabled = false;
            } else {
                tokenInput.style.borderColor = '#EF4444';
                if (tokenIcon) {
                    tokenIcon.className = 'bi bi-x-circle-fill';
                    tokenIcon.style.color = '#EF4444';
                }
                classSelect.disabled = true;
                studentSearch.disabled = true;
                studentSearch.value = '';
                startBtn.disabled = true;
            }
        } catch(e) {
            if (tokenIcon) tokenIcon.className = 'fas';
        }
    }, 400);
}

function populateClasses(forceReset = false) {
    if (!classSelect) return;
    const currentSelectedId = forceReset ? null : (classSelect.value || state.selectedClassId);

    let classIds = [];
    if (state.selectedExam) {
        classIds = state.selectedExam.class_ids !== undefined ? state.selectedExam.class_ids : state.selectedExam.classes;
        if (typeof classIds === 'string') {
            try { classIds = JSON.parse(classIds); } catch(e) { classIds = []; }
        }
        if (!Array.isArray(classIds)) {
            classIds = (state.selectedExam.class_id && state.selectedExam.class_id != 0) ? [state.selectedExam.class_id] : [];
        }
        // convert to int
        classIds = classIds.map(id => parseInt(id));
    }

    const availableClasses = (state.classes || []).filter(c => classIds.length === 0 || classIds.includes(parseInt(c.id)));
    
    // Periksa apakah daftar option saat ini sudah identik dengan availableClasses
    const existingOptions = Array.from(classSelect.options).filter(o => o.value !== '');
    const isSameOptions = existingOptions.length === availableClasses.length && 
        existingOptions.every((opt, idx) => opt.value == availableClasses[idx].id && opt.textContent === availableClasses[idx].name);

    // Hanya ubah innerHTML jika daftar option memang belum dibuat atau berbeda
    if (!isSameOptions) {
        classSelect.innerHTML = '<option value="" disabled selected>Pilih Kelas</option>';
        availableClasses.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c.id;
            opt.textContent = c.name;
            classSelect.appendChild(opt);
        });
    }

    // Selalu pertahankan dan pulihkan kelas yang telah dipilih sebelumnya
    if (currentSelectedId && availableClasses.some(c => String(c.id) === String(currentSelectedId))) {
        classSelect.value = currentSelectedId;
        state.selectedClassId = currentSelectedId;
    } else if (forceReset) {
        classSelect.value = '';
        state.selectedClassId = null;
        state.selectedClassName = null;
    }
}

async function handleClassChange() {
    state.selectedClassId = classSelect.value;
    const selOption = classSelect.options[classSelect.selectedIndex];
    state.selectedClassName = selOption ? selOption.text : '';
    
    studentSearch.value = '';
    studentIdInput.value = '';
    studentSearch.placeholder = 'Memuat siswa...';
    studentSearch.disabled = true;
    startBtn.disabled = true;
    
    if (studentPasswordContainer) {
        studentPasswordContainer.style.display = 'none';
        studentPasswordInput.required = false;
        studentPasswordInput.value = '';
    }

    try {
        const examParam = state.selectedExamId ? `&exam_id=${state.selectedExamId}` : '';
        const response = await fetch(`api.php?action=get_students&class_id=${state.selectedClassId}${examParam}`);
        const res = await response.json();
        
        if (res.status === 'success') {
            state.students = res.data;
            studentSearch.disabled = false;
            studentSearch.placeholder = 'Ketik minimal 3 karakter nama...';
        }
    } catch(err) {
        console.error('Failed to load students');
        studentSearch.placeholder = 'Gagal memuat data siswa.';
    }
}

function handleStudentSearch(e) {
    const val = e.target.value;
    autocompleteList.innerHTML = '';
    studentIdInput.value = '';
    startBtn.disabled = true;
    state.selectedStudentId = null;
    state.selectedStudentName = null;
    state.selectedStudentPassword = null;
    
    if (studentPasswordContainer) {
        studentPasswordContainer.style.display = 'none';
        studentPasswordInput.required = false;
        studentPasswordInput.value = '';
    }
    
    if (val.length < 3) {
        autocompleteList.classList.add('hidden');
        return;
    }
    
    let matches = state.students.filter(s => s.name.toLowerCase().includes(val.toLowerCase()));
    
    if (matches.length === 0) {
        autocompleteList.classList.add('hidden');
        return;
    }
    
    autocompleteList.classList.remove('hidden');
    matches.forEach(s => {
        const div = document.createElement('div');
        let text = s.name;
        if (s.has_finished) {
            text += ' (Sudah Selesai)';
            div.classList.add('disabled');
        }
        
        // Highlight matching part
        const regex = new RegExp(`(${val})`, "gi");
        div.innerHTML = text.replace(regex, "<strong>$1</strong>");
        
        div.addEventListener('click', function() {
            if (s.has_finished) return; // do nothing
            
            studentSearch.value = s.name;
            studentIdInput.value = s.id;
            state.selectedStudentId = s.id;
            state.selectedStudentName = s.name;
            state.selectedStudentHasPassword = true;
            autocompleteList.classList.add('hidden');
            
            // Password selalu wajib bagi seluruh siswa
            studentPasswordContainer.style.display = 'block';
            studentPasswordInput.required = true;
            studentPasswordInput.value = '';
            studentPasswordInput.focus();
            
            startBtn.disabled = false;
        });
        
        autocompleteList.appendChild(div);
    });
}

// Utility to shuffle array
function shuffleArray(array) {
    let curId = array.length;
    while (0 !== curId) {
        let randId = Math.floor(Math.random() * curId);
        curId -= 1;
        let tmp = array[curId];
        array[curId] = array[randId];
        array[randId] = tmp;
    }
    return array;
}

function isOptionContentEmpty(str) {
    if (str === null || str === undefined) return true;
    const s = String(str).trim();
    if (!s) return true;
    if (s.includes('<img') || s.includes('<audio') || s.includes('<video')) return false;
    const textOnly = s.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, '').replace(/&#160;/g, '').trim();
    return textOnly === '';
}

function prepareQuestions() {
    let shouldShuffleQuestions = true;
    let shouldShuffleOptions = true;
    
    if (state.selectedExam) {
        if (state.selectedExam.shuffle_questions !== undefined && state.selectedExam.shuffle_questions !== null) {
            shouldShuffleQuestions = (state.selectedExam.shuffle_questions == 1 || state.selectedExam.shuffle_questions === true || state.selectedExam.shuffle_questions === 'true');
        }
        if (state.selectedExam.shuffle_options !== undefined && state.selectedExam.shuffle_options !== null) {
            shouldShuffleOptions = (state.selectedExam.shuffle_options == 1 || state.selectedExam.shuffle_options === true || state.selectedExam.shuffle_options === 'true');
        }
    }

    state.shuffledQuestions = questionsData.map((q, idx) => {
        const qType = q.type || 'multiple_choice';
        let optionsWithIndex = [];
        
        if ((qType === 'multiple_choice' || qType === 'complex_mc') && q.options) {
            // Pangkas opsi kosong di bagian akhir (misal soal 4 opsi tapi tersisa opsi ke-5 kosong)
            let validOpts = [...q.options];
            while (validOpts.length > 2 && isOptionContentEmpty(validOpts[validOpts.length - 1])) {
                validOpts.pop();
            }
            optionsWithIndex = validOpts.map((opt, optIdx) => ({
                text: opt,
                value: optIdx
            }));
            if (shouldShuffleOptions) {
                shuffleArray(optionsWithIndex);
            }
        }
        
        return {
            originalId: idx,
            type: qType,
            question: q.question,
            options: (qType === 'matching') ? (q.options || []) : optionsWithIndex,
            premises: q.premises || [],
            statements: q.statements || [],
            selectedOption: (qType === 'complex_mc') ? [] : ((qType === 'true_false' || qType === 'matching') ? {} : (qType === 'essay' ? '' : null)),
            points: q.points !== undefined ? parseFloat(q.points) : 2
        };
    });
    
    if (shouldShuffleQuestions) {
        shuffleArray(state.shuffledQuestions);
    }

    const maxQ = (state.selectedExam && state.selectedExam.max_questions) ? parseInt(state.selectedExam.max_questions) : 0;
    if (maxQ > 0 && maxQ < state.shuffledQuestions.length) {
        state.shuffledQuestions = state.shuffledQuestions.slice(0, maxQ);
    }
}

function renderQuestion(index) {
    singleQuestionContainer.innerHTML = '';
    const q = state.shuffledQuestions[index];
    
    const card = document.createElement('div');
    card.className = 'question-card fade-in';
    
    let contentHtml = '';
    if (q.type === 'essay') {
        const textValue = q.selectedOption || '';
        contentHtml = `
            <textarea id="essay_q_${q.originalId}" class="form-control mt-3 essay-input" rows="6" placeholder="Ketik jawaban uraian Anda di sini...">${textValue}</textarea>
        `;
    } else if (q.type === 'complex_mc') {
        let optsHtml = '';
        const selectedArr = Array.isArray(q.selectedOption) ? q.selectedOption : [];
        q.options.forEach((opt) => {
            const isChecked = selectedArr.includes(opt.value) ? 'checked' : '';
            optsHtml += `
                <label class="option-label complex-option-label">
                    <input type="checkbox" name="q_${q.originalId}" value="${opt.value}" class="option-input complex-input" ${isChecked}>
                    <div class="option-text">${opt.text}</div>
                </label>
            `;
        });
        contentHtml = `
            <div class="complex-badge-info">
                <i class="bi bi-check-all"></i> Pilihan Ganda Kompleks: Anda dapat memilih lebih dari satu jawaban benar.
            </div>
            <div class="options-container">
                ${optsHtml}
            </div>
        `;
    } else if (q.type === 'true_false') {
        let rowsHtml = '';
        const selectedObj = (q.selectedOption && typeof q.selectedOption === 'object') ? q.selectedOption : {};
        (q.statements || []).forEach((stmt, sIdx) => {
            const isTrueChecked = selectedObj[sIdx] === true || selectedObj[sIdx] === 'true' ? 'checked' : '';
            const isFalseChecked = selectedObj[sIdx] === false || selectedObj[sIdx] === 'false' ? 'checked' : '';
            rowsHtml += `
                <tr>
                    <td class="text-center font-weight-bold align-middle">${sIdx + 1}</td>
                    <td class="align-middle">${stmt.text}</td>
                    <td class="text-center align-middle" style="width: 85px;">
                        <label class="tf-radio-label">
                            <input type="radio" name="tf_${q.originalId}_${sIdx}" data-stmt="${sIdx}" value="true" class="tf-radio radio-true" ${isTrueChecked}>
                        </label>
                    </td>
                    <td class="text-center align-middle" style="width: 85px;">
                        <label class="tf-radio-label">
                            <input type="radio" name="tf_${q.originalId}_${sIdx}" data-stmt="${sIdx}" value="false" class="tf-radio radio-false" ${isFalseChecked}>
                        </label>
                    </td>
                </tr>
            `;
        });
        contentHtml = `
            <div class="complex-badge-info" style="color: #047857; background: #ECFDF5; border-color: #A7F3D0;">
                <i class="bi bi-list-check"></i> Tentukan Benar atau Salah untuk setiap pernyataan berikut:
            </div>
            <div class="table-responsive">
                <table class="tf-statement-table">
                    <thead>
                        <tr>
                            <th style="width: 45px;" class="text-center">No</th>
                            <th>Pernyataan</th>
                            <th style="width: 85px;" class="text-center text-success font-weight-bold">Benar</th>
                            <th style="width: 85px;" class="text-center text-danger font-weight-bold">Salah</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rowsHtml}
                    </tbody>
                </table>
            </div>
        `;
    } else if (q.type === 'matching') {
        const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
        const selectedObj = (q.selectedOption && typeof q.selectedOption === 'object') ? q.selectedOption : {};
        
        let rowsHtml = '';
        (q.premises || []).forEach((premiseText, pIdx) => {
            const userChoice = selectedObj[pIdx] !== undefined ? parseInt(selectedObj[pIdx]) : null;
            const isAnsweredRow = userChoice !== null;
            
            let selectOptionsHtml = '<option value="">-- Pilih Pasangan Jawaban --</option>';
            (q.options || []).forEach((opt, optIdx) => {
                const letter = letters[optIdx] || (optIdx + 1);
                const isSel = (userChoice !== null && userChoice === optIdx) ? 'selected' : '';
                selectOptionsHtml += `<option value="${optIdx}" ${isSel}>${letter}. ${opt}</option>`;
            });
            
            rowsHtml += `
                <div class="match-item ${isAnsweredRow ? 'is-matched' : ''}" data-pidx="${pIdx}">
                    <div class="match-left">
                        <span class="match-badge">${pIdx + 1}</span>
                        <div class="match-premise-text">${premiseText}</div>
                    </div>
                    <div class="match-connector">
                        <i class="bi bi-arrow-right"></i>
                    </div>
                    <div class="match-right">
                        <select class="matching-select" data-pidx="${pIdx}">
                            ${selectOptionsHtml}
                        </select>
                    </div>
                </div>
            `;
        });
        
        contentHtml = `
            <div class="match-clean-wrapper">
                <div class="match-clean-hint">
                    <i class="bi bi-link-45deg text-primary mr-1"></i> Pasangkan setiap pernyataan dengan jawaban yang tepat:
                </div>
                <div class="match-items-list">
                    ${rowsHtml}
                </div>
            </div>
        `;
    } else {
        let optsHtml = '';
        q.options.forEach((opt) => {
            const isChecked = q.selectedOption == opt.value ? 'checked' : '';
            optsHtml += `
                <label class="option-label">
                    <input type="radio" name="q_${q.originalId}" value="${opt.isCorrect ? '1' : '0'}" data-optval="${opt.value}" class="option-input single-mc-input" ${isChecked}>
                    <div class="option-text">${opt.text}</div>
                </label>
            `;
        });
        contentHtml = `
            <div class="options-container">
                ${optsHtml}
            </div>
        `;
    }

    const examName = (state.selectedExam && state.selectedExam.name) ? state.selectedExam.name : '';
    const examBadgeHtml = examName ? `
        <span class="q-exam-badge" title="${examName.replace(/"/g, '&quot;')}">
            <i class="bi bi-book"></i>
            <span class="exam-title">${examName}</span>
        </span>
    ` : '';

    card.innerHTML = `
        <div class="q-header">
            <span class="q-number">Soal ${index + 1} dari ${state.shuffledQuestions.length}</span>
            ${examBadgeHtml}
        </div>
        <div class="q-text">${q.question}</div>
        ${contentHtml}
    `;
    
    singleQuestionContainer.appendChild(card);
    
    // Render rumus matematika MathJax / KaTeX
    if (window.renderMath) {
        window.renderMath(singleQuestionContainer);
    }
    
    // Save selected answer when clicked/typed
    if (q.type === 'essay') {
        const essayInput = card.querySelector('.essay-input');
        if (essayInput) {
            essayInput.addEventListener('input', (e) => {
                state.shuffledQuestions[index].selectedOption = e.target.value;
                saveSession();
                scheduleBatchSync();
                renderQuestionMap();
            });
        }
    } else if (q.type === 'complex_mc') {
        const cbs = card.querySelectorAll('.complex-input');
        cbs.forEach(cb => {
            cb.addEventListener('change', () => {
                const checked = Array.from(card.querySelectorAll('.complex-input:checked')).map(el => parseInt(el.value));
                state.shuffledQuestions[index].selectedOption = checked;
                saveSession();
                scheduleBatchSync();
                renderQuestionMap();
            });
        });
    } else if (q.type === 'true_false') {
        const radios = card.querySelectorAll('.tf-radio');
        radios.forEach(r => {
            r.addEventListener('change', (e) => {
                const stmtIdx = parseInt(e.target.dataset.stmt);
                const isTrue = e.target.value === 'true';
                if (!state.shuffledQuestions[index].selectedOption || typeof state.shuffledQuestions[index].selectedOption !== 'object') {
                    state.shuffledQuestions[index].selectedOption = {};
                }
                state.shuffledQuestions[index].selectedOption[stmtIdx] = isTrue;
                saveSession();
                scheduleBatchSync();
                renderQuestionMap();
            });
        });
    } else if (q.type === 'matching') {
        const selects = card.querySelectorAll('.matching-select');
        selects.forEach(sel => {
            sel.addEventListener('change', (e) => {
                const pIdx = parseInt(e.target.dataset.pidx);
                const val = e.target.value !== '' ? parseInt(e.target.value) : null;
                const itemEl = e.target.closest('.match-item');
                
                if (!state.shuffledQuestions[index].selectedOption || typeof state.shuffledQuestions[index].selectedOption !== 'object') {
                    state.shuffledQuestions[index].selectedOption = {};
                }
                if (val !== null) {
                    state.shuffledQuestions[index].selectedOption[pIdx] = val;
                    if (itemEl) itemEl.classList.add('is-matched');
                } else {
                    delete state.shuffledQuestions[index].selectedOption[pIdx];
                    if (itemEl) itemEl.classList.remove('is-matched');
                }
                saveSession();
                scheduleBatchSync();
                renderQuestionMap();
            });
        });
    } else {
        const inputs = card.querySelectorAll('.single-mc-input');
        inputs.forEach(input => {
            input.addEventListener('change', (e) => {
                state.shuffledQuestions[index].selectedOption = e.target.dataset.optval;
                saveSession();
                scheduleBatchSync();
                renderQuestionMap();
            });
        });
    }

    updateNavigationButtons();
    renderQuestionMap();
}

function updateNavigationButtons() {
    btnPrev.disabled = state.currentQuestionIndex === 0;
    
    if (state.currentQuestionIndex === state.shuffledQuestions.length - 1) {
        btnNext.classList.add('hidden');
        btnFinish.classList.remove('hidden');
    } else {
        btnNext.classList.remove('hidden');
        btnFinish.classList.add('hidden');
    }
}

function renderQuestionMap() {
    questionMapGrid.innerHTML = '';
    state.shuffledQuestions.forEach((q, idx) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'map-btn';
        
        let isAnswered = false;
        if (q.type === 'essay') {
            isAnswered = q.selectedOption && typeof q.selectedOption === 'string' && q.selectedOption.trim() !== '';
        } else if (q.type === 'complex_mc') {
            isAnswered = Array.isArray(q.selectedOption) && q.selectedOption.length > 0;
        } else if (q.type === 'true_false') {
            isAnswered = q.selectedOption && typeof q.selectedOption === 'object' && 
                         q.statements && Object.keys(q.selectedOption).length === q.statements.length;
        } else if (q.type === 'matching') {
            isAnswered = q.selectedOption && typeof q.selectedOption === 'object' && 
                         q.premises && q.premises.length > 0 && Object.keys(q.selectedOption).length === q.premises.length;
        } else {
            isAnswered = q.selectedOption !== null && q.selectedOption !== undefined;
        }

        if (isAnswered) btn.classList.add('answered');
        if (idx === state.currentQuestionIndex) btn.classList.add('active');
        btn.textContent = idx + 1;
        
        btn.addEventListener('click', () => {
            state.currentQuestionIndex = idx;
            renderQuestion(state.currentQuestionIndex);
            questionMapModal.classList.add('hidden');
        });
        
        questionMapGrid.appendChild(btn);
    });
}

// Event Listeners for Nav
if(btnPrev) {
    btnPrev.addEventListener('click', () => {
        if (state.currentQuestionIndex > 0) {
            state.currentQuestionIndex--;
            saveSession();
            renderQuestion(state.currentQuestionIndex);
        }
    });
}

if(btnNext) {
    btnNext.addEventListener('click', () => {
        if (state.currentQuestionIndex < state.shuffledQuestions.length - 1) {
            state.currentQuestionIndex++;
            saveSession();
            renderQuestion(state.currentQuestionIndex);
        }
    });
}

async function refreshStudentQuestion() {
    const icon = document.getElementById('icon-refresh-q') || document.querySelector('#btn-refresh-q i');
    if (icon) {
        icon.classList.add('spin-refresh-anim');
    }
    
    // Simpan progres ke session storage
    saveSession();
    
    // Sinkronkan ke server secara aman
    try {
        scheduleBatchSync();
    } catch(e) {}
    
    try {
        // Ambil soal terbaru dari server
        const qResponse = await fetch(`api.php?action=get_questions&exam_id=${state.selectedExamId}`);
        const qRes = await qResponse.json();
        
        if (qRes.status === 'success' && qRes.data && qRes.data.length > 0) {
            questionsData = qRes.data;
            
            // Re-inject text ke shuffledQuestions agar jawaban siswa (selectedOption) tidak hilang
            let fullShuffled = state.shuffledQuestions.map(q => {
                let originalQuestion = questionsData[q.originalId];
                if (!originalQuestion) return null; // Soal mungkin dihapus
                
                let fullOptions = [];
                if (q.options && originalQuestion.options) {
                    fullOptions = q.options.map(o => ({
                        value: o.value,
                        text: originalQuestion.options[o.value] || o.text
                    }));
                }
                
                return {
                    originalId: q.originalId,
                    question: originalQuestion.question,
                    type: originalQuestion.type || q.type || 'multiple_choice',
                    selectedOption: q.selectedOption,
                    points: q.points,
                    statements: originalQuestion.statements || q.statements || [],
                    premises: originalQuestion.premises || q.premises || [],
                    options: originalQuestion.type === 'matching' ? (originalQuestion.options || q.options || []) : fullOptions
                };
            }).filter(q => q !== null);
            
            // Cari originalId yang sudah ada di shuffledQuestions
            const existingIds = fullShuffled.map(q => q.originalId);
            
            // Tambahkan soal baru yang belum ada di shuffledQuestions (jika ada penambahan soal di bank)
            questionsData.forEach((qData, idx) => {
                if (!existingIds.includes(idx)) {
                    const qType = qData.type || 'multiple_choice';
                    let optionsWithIndex = [];
                    
                    if ((qType === 'multiple_choice' || qType === 'complex_mc') && qData.options) {
                        optionsWithIndex = qData.options.map((opt, optIdx) => ({
                            text: opt,
                            value: optIdx
                        }));
                        // Jika shuffle opsi aktif, idealnya diacak. Di sini fallback ke urutan default agar stabil.
                    }
                    
                    fullShuffled.push({
                        originalId: idx,
                        type: qType,
                        question: qData.question,
                        options: (qType === 'matching') ? (qData.options || []) : optionsWithIndex,
                        premises: qData.premises || [],
                        statements: qData.statements || [],
                        selectedOption: (qType === 'complex_mc') ? [] : ((qType === 'true_false' || qType === 'matching') ? {} : (qType === 'essay' ? '' : null)),
                        points: qData.points !== undefined ? parseFloat(qData.points) : 2
                    });
                }
            });
            
            state.shuffledQuestions = fullShuffled;
            
            // Perbaiki index jika soal berkurang
            if (state.currentQuestionIndex >= state.shuffledQuestions.length) {
                state.currentQuestionIndex = Math.max(0, state.shuffledQuestions.length - 1);
            }
            
            saveSession();
        }
    } catch (e) {
        console.error('Gagal memuat ulang soal:', e);
    }
    
    // Re-render soal dan peta nomor soal
    if (state.shuffledQuestions && state.shuffledQuestions.length > 0) {
        renderQuestion(state.currentQuestionIndex);
        renderQuestionMap();
    }
    
    setTimeout(() => {
        if (icon) {
            icon.classList.remove('spin-refresh-anim');
        }
    }, 700);
}
window.refreshStudentQuestion = refreshStudentQuestion;

const btnRefreshQ = document.getElementById('btn-refresh-q');
if (btnRefreshQ) {
    btnRefreshQ.addEventListener('click', (e) => {
        e.preventDefault();
        refreshStudentQuestion();
    });
}

if(btnToggleMap) {
    btnToggleMap.addEventListener('click', () => {
        renderQuestionMap();
        questionMapModal.classList.remove('hidden');
    });
}

if(btnCloseMap) {
    btnCloseMap.addEventListener('click', () => {
        questionMapModal.classList.add('hidden');
    });
}

if(btnLogout) {
    btnLogout.addEventListener('click', async () => {
        state.isConfirmingFinish = true;
        if(confirm('Apakah Anda yakin ingin logout? Jika Anda logout sekarang, ujian Anda akan dihentikan dan Anda harus mulai dari awal.')) {
            state.isSubmitting = true;
            state.isFinished = true;
            if (state.selectedStudentId) {
                const fd = new FormData();
                fd.append('action', 'reset_login');
                fd.append('student_id', state.selectedStudentId);
                try { await fetch('api.php', { method: 'POST', body: fd }); } catch(e) {}
            }
            clearSession();
            location.reload();
        } else {
            setTimeout(() => {
                state.isConfirmingFinish = false;
            }, 800);
        }
    });
}

function startTimer(durationMinutes) {
    state.endTime = Date.now() + (durationMinutes * 60 * 1000);
    saveSession();
    resumeTimer();
}

function resumeTimer() {
    if (state.timerInterval) clearInterval(state.timerInterval);
    if (state.syncInterval) clearInterval(state.syncInterval);
    if (state.batchSyncTimeout) clearTimeout(state.batchSyncTimeout);
    
    // Immediate full sync on start/resume
    state.hasUnsavedChanges = true;
    syncProgress(true);
    
    // Auto Batch Sync dinamis (dari Pengaturan Admin) dengan random jitter agar request 1000 siswa tersebar merata
    let syncIntervalSec = parseInt(state.settings && state.settings.sync_interval_seconds);
    if (isNaN(syncIntervalSec) || syncIntervalSec < 10) {
        syncIntervalSec = 60; // Default santai untuk cloud hosting (60 detik)
    }
    // Jitter acak ±10% dari interval agar 1.000 siswa tidak sinkron di detik yang sama persis (anti thundering herd)
    const jitterRange = Math.max(3000, Math.floor(syncIntervalSec * 200));
    const syncJitter = (syncIntervalSec * 1000) + Math.floor(Math.random() * jitterRange) - Math.floor(jitterRange / 2);
    const finalIntervalMs = Math.max(10000, syncJitter);

    state.currentSyncIntervalMs = finalIntervalMs;
    state.syncInterval = setInterval(() => {
        if (!state.isSubmitting && !state.isFinished) {
            syncProgress();
        }
    }, finalIntervalMs);
    
    state.timerInterval = setInterval(() => {
        let timeRemaining = Math.floor((state.endTime - Date.now()) / 1000);
        
        if (timeRemaining <= 0) {
            clearInterval(state.timerInterval);
            alert("Waktu habis! Ujian otomatis dikumpulkan.");
            finishExam(true);
            return;
        }
        
        let hrs = Math.floor(timeRemaining / 3600);
        let mins = Math.floor((timeRemaining % 3600) / 60);
        let secs = timeRemaining % 60;
        
        if (timeRemainingEl) {
            timeRemainingEl.textContent = 
                `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        } else if (timerEl) {
            timerEl.textContent = `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
            
        if (timeRemaining < 300 && timerEl) {
            timerEl.style.animation = 'pulse 1s infinite alternate';
        }
    }, 1000);
}

// Global pulse animation for timer
const styleSheet = document.createElement("style");
styleSheet.innerText = `
  @keyframes pulse {
    0% { transform: scale(1); background: #FEF2F2; color: #EF4444; }
    100% { transform: scale(1.05); background: #EF4444; color: #fff; }
  }
`;
document.head.appendChild(styleSheet);

function calculateCurrentScore() {
    // Penilaian resmi CBT dilakukan secara terverifikasi 100% di server
    return 0;
}

// Debounced batch sync trigger: panggil setiap ada perubahan jawaban
function scheduleBatchSync() {
    state.hasUnsavedChanges = true;
    if (state.batchSyncTimeout) {
        clearTimeout(state.batchSyncTimeout);
    }
    // Tunggu 5 detik setelah interaksi terakhir siswa (typing/clicking) lalu kirim batch
    state.batchSyncTimeout = setTimeout(() => {
        if (!state.isSubmitting && !state.isFinished) {
            syncProgress();
        }
    }, 5000);
}

async function syncProgress(forceFull = false) {
    if (!state.selectedStudentId || state.isSubmitting || state.isFinished) return;
    if (state.isSyncing) return; // Mencegah request tumpang-tindih (concurrent collision)
    
    state.isSyncing = true;
    const shouldSendFull = forceFull || state.hasUnsavedChanges;
    const postData = new FormData();
    postData.append('action', 'sync_progress');
    postData.append('student_id', state.selectedStudentId);
    postData.append('exam_id', state.selectedExamId);
    postData.append('score', 0);
    postData.append('violations', state.violations || 0);
    postData.append('is_locked', state.isLocked ? 1 : 0);
    
    // Hanya kirim payload besar state_json jika ada perubahan jawaban atau inisialisasi awal
    // Ini menghemat 80%+ bandwidth & CPU server saat 500 siswa aktif
    if (shouldSendFull && state.shuffledQuestions && state.shuffledQuestions.length > 0) {
        const simplifiedQuestions = state.shuffledQuestions.map(q => ({
            originalId: q.originalId,
            selectedOption: q.selectedOption,
            points: q.points,
            type: q.type || 'multiple_choice',
            statements: q.statements || [],
            premises: q.premises || [],
            options: q.type === 'matching' ? (q.options || []) : (q.options ? q.options.map(o => ({
                value: o.value
            })) : [])
        }));

        const sessionData = {
            selectedExamId: state.selectedExamId,
            selectedExam: state.selectedExam,
            selectedStudentId: state.selectedStudentId,
            selectedStudentName: state.selectedStudentName,
            selectedClassName: state.selectedClassName,
            startTime: state.startTime,
            endTime: state.endTime,
            shuffledQuestions: simplifiedQuestions,
            currentQuestionIndex: state.currentQuestionIndex,
            violations: state.violations || 0,
            isLocked: !!state.isLocked
        };
        postData.append('state_json', JSON.stringify(sessionData));
    }
    
    try {
        const res = await fetch('api.php', { method: 'POST', body: postData });
        const json = await res.json();
        
        if (shouldSendFull) {
            state.hasUnsavedChanges = false;
        }
        
        if (json.status === 'force_logout') {
            alert(json.message || 'Sesi Anda telah direset oleh Admin.');
            clearSession();
            window.location.reload();
            return;
        }

        if (json.settings && typeof json.settings === 'object') {
            const prevSyncSec = state.settings ? parseInt(state.settings.sync_interval_seconds) : 60;
            state.settings = Object.assign({}, state.settings, json.settings);
            const newSyncSec = parseInt(json.settings.sync_interval_seconds);

            // Jika admin mengubah interval di pengaturan saat ujian sedang berlangsung, sesuaikan interval klien seketika
            if (newSyncSec && newSyncSec !== prevSyncSec && state.syncInterval && !state.isSubmitting && !state.isFinished) {
                clearInterval(state.syncInterval);
                const jitterRange = Math.max(3000, Math.floor(newSyncSec * 200));
                const newJitter = (newSyncSec * 1000) + Math.floor(Math.random() * jitterRange) - Math.floor(jitterRange / 2);
                const newIntervalMs = Math.max(10000, newJitter);
                state.currentSyncIntervalMs = newIntervalMs;
                state.syncInterval = setInterval(() => {
                    if (!state.isSubmitting && !state.isFinished) {
                        syncProgress();
                    }
                }, newIntervalMs);
            }
        }

        if (json.status === 'unlocked') {
            unlockStudentLocally('Ujian Anda telah dibuka kembali oleh Pengawas/Admin. Silakan lanjutkan pengerjaan.');
        }
    } catch(e) {
    } finally {
        state.isSyncing = false;
    }
}

function requestFullScreen() {
    const docElm = document.documentElement;
    if (docElm.requestFullscreen) {
        docElm.requestFullscreen();
    } else if (docElm.webkitRequestFullScreen) {
        docElm.webkitRequestFullScreen();
    } else if (docElm.msRequestFullscreen) {
        docElm.msRequestFullscreen();
    }
}

async function startExam(e) {
    e.preventDefault();
    
    startBtn.disabled = true;
    startBtn.textContent = 'Memvalidasi...';
    
    // Refresh settings in case they were updated by admin
    try {
        const responseSettings = await fetch('api.php?action=get_settings');
        const resSettings = await responseSettings.json();
        if (resSettings.status === 'success') {
            state.settings = resSettings.data;
        }
    } catch(err) {}

    // Validate Selected Exam
    if (!state.selectedExam) {
        alert('Silakan pilih mata pelajaran terlebih dahulu!');
        const examInp = document.getElementById('exam-search-input');
        if (examInp) examInp.focus();
        startBtn.disabled = false;
        startBtn.textContent = 'Mulai Ujian';
        return;
    }

    // Validate Password (Selalu Wajib)
    if (!studentPasswordInput || !studentPasswordInput.value.trim()) {
        alert('Password peserta ujian wajib diisi!');
        if (studentPasswordInput) {
            studentPasswordContainer.style.display = 'block';
            studentPasswordInput.focus();
        }
        startBtn.disabled = false;
        startBtn.textContent = 'Mulai Ujian';
        return;
    }
    
    // Validate Schedule
    const now = new Date();
    const startTime = new Date(state.selectedExam.start_time);
    const endTime = new Date(state.selectedExam.end_time);
    
    if (now < startTime) {
        alert('Ujian belum dimulai. Waktu mulai: ' + startTime.toLocaleString('id-ID'));
        startBtn.disabled = false;
        startBtn.textContent = 'Mulai Ujian';
        return;
    }
    if (now > endTime) {
        alert('Waktu ujian telah berakhir.');
        startBtn.disabled = false;
        startBtn.textContent = 'Mulai Ujian';
        return;
    }
    
    if (classSelect && classSelect.selectedIndex >= 0) {
        state.selectedClassName = classSelect.options[classSelect.selectedIndex].text;
    }

    const tokenVal = tokenInput ? tokenInput.value.trim().toUpperCase() : '';
    await executeStartExam(tokenVal, startBtn);
}

async function executeStartExam(tokenValue, triggerBtn) {
    const btn = triggerBtn || startBtn;
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Memeriksa sesi...';
    }

    try {
        const sessionFd = new FormData();
        sessionFd.append('action', 'start_session');
        sessionFd.append('student_id', state.selectedStudentId);
        sessionFd.append('exam_id', state.selectedExamId);
        sessionFd.append('token', tokenValue || '');
        const enteredPassword = (studentPasswordInput && studentPasswordInput.value) 
            ? studentPasswordInput.value.trim() 
            : (tempUsernameLoginData ? (tempUsernameLoginData.entered_password || '') : '');
        sessionFd.append('password', enteredPassword);
        
        const sessionRes = await fetch('api.php', { method: 'POST', body: sessionFd });
        const sessionJson = await sessionRes.json();
        if (sessionJson.status === 'error') {
            alert(sessionJson.message);
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Mulai Ujian';
            }
            return;
        }
        
        if (sessionJson.status === 'success' && sessionJson.data) {
            // Restore state from server
            const saved = sessionJson.data;
            if (saved.endTime && saved.endTime > Date.now()) {
                if (btn) {
                    btn.disabled = true;
                    btn.textContent = 'Memulihkan sesi...';
                }
                
                // Fetch questions to reinject text
                try {
                    const qResponse = await fetch(`api.php?action=get_questions&exam_id=${saved.selectedExamId}`);
                    const qRes = await qResponse.json();
                    if (qRes.status === 'success' && qRes.data && qRes.data.length > 0) {
                        questionsData = qRes.data;
                    } else {
                        alert('Gagal memulihkan soal ujian (Soal tidak ditemukan).');
                        if (btn) {
                            btn.disabled = false;
                            btn.textContent = 'Mulai Ujian';
                        }
                        return;
                    }
                } catch(e) {
                    alert('Gagal memulihkan soal ujian (Koneksi error).');
                    if (btn) {
                        btn.disabled = false;
                        btn.textContent = 'Mulai Ujian';
                    }
                    return;
                }
                
                // Re-inject text into simplified shuffledQuestions
                let fullShuffled = saved.shuffledQuestions.map(q => {
                    let originalQuestion = questionsData[q.originalId];
                    if (!originalQuestion) return null;
                    
                    let fullOptions = [];
                    if (q.options && originalQuestion.options) {
                        fullOptions = q.options.map(o => ({
                            value: o.value,
                            text: originalQuestion.options[o.value]
                        }));
                    }
                    
                    return {
                        originalId: q.originalId,
                        question: originalQuestion.question,
                        type: originalQuestion.type || q.type || 'multiple_choice',
                        selectedOption: q.selectedOption !== undefined ? q.selectedOption : ((originalQuestion.type === 'complex_mc') ? [] : ((originalQuestion.type === 'true_false' || originalQuestion.type === 'matching') ? {} : null)),
                        points: q.points,
                        statements: originalQuestion.statements || q.statements || [],
                        premises: originalQuestion.premises || q.premises || [],
                        options: originalQuestion.type === 'matching' ? (originalQuestion.options || q.options || []) : fullOptions
                    };
                }).filter(q => q !== null);

                state.selectedExamId = saved.selectedExamId;
                state.selectedExam = saved.selectedExam;
                state.selectedStudentId = saved.selectedStudentId;
                state.selectedStudentName = saved.selectedStudentName;
                state.selectedClassName = saved.selectedClassName;
                state.startTime = saved.startTime || Date.now();
                state.endTime = saved.endTime;
                state.shuffledQuestions = fullShuffled;
                state.currentQuestionIndex = saved.currentQuestionIndex || 0;
                state.violations = saved.violations || 0;
                state.isLocked = !!saved.is_locked;
                
                try { requestFullScreen(); } catch(err) {}
                const loginWrap = document.getElementById('login-wrapper');
                if (loginWrap) loginWrap.classList.add('hidden');
                loginScreen.classList.add('hidden');
                examScreen.classList.remove('hidden');
                window.scrollTo(0, 0);
                
                displayName.textContent = state.selectedStudentName;
                displayClass.textContent = state.selectedClassName;
                
                saveSession();
                resumeTimer();
                renderQuestion(state.currentQuestionIndex);
                if (state.isLocked) {
                    if (state.lockoutEndTime && Date.now() >= state.lockoutEndTime) {
                        unlockStudentLocally('Waktu terkunci telah berakhir. Silakan lanjutkan ujian.');
                    } else {
                        showLockedOverlay();
                    }
                }
                
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = 'Mulai Ujian';
                }
                return;
            } else {
                alert('Waktu ujian Anda telah habis.');
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = 'Mulai Ujian';
                }
                return;
            }
        }
    } catch (err) {
        alert('Gagal menghubungi server.');
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Mulai Ujian';
        }
        return;
    }
    
    // Fetch questions for the selected exam
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Memuat soal...';
    }
    try {
        const qResponse = await fetch(`api.php?action=get_questions&exam_id=${state.selectedExamId}`);
        const qRes = await qResponse.json();
        if (qRes.status === 'success' && qRes.data && qRes.data.length > 0) {
            questionsData = qRes.data;
        } else {
            alert('Soal ujian untuk mata pelajaran ini belum tersedia. Silakan hubungi admin.');
            if (btn) {
                btn.disabled = false;
                btn.textContent = 'Mulai Ujian';
            }
            return;
        }
    } catch (err) {
        alert('Gagal memuat soal ujian.');
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Mulai Ujian';
        }
        return;
    }

    // Minta Fullscreen saat mulai ujian
    try { requestFullScreen(); } catch(err) {}
    
    const loginWrap = document.getElementById('login-wrapper');
    if (loginWrap) loginWrap.classList.add('hidden');
    loginScreen.classList.add('hidden');
    examScreen.classList.remove('hidden');
    window.scrollTo(0, 0);
    
    displayName.textContent = state.selectedStudentName;
    displayClass.textContent = state.selectedClassName;
    
    prepareQuestions();
    const duration = state.selectedExam.duration ? parseInt(state.selectedExam.duration) : 90;
    if (!state.startTime) state.startTime = Date.now();
    startTimer(duration); // Dynamic duration
    renderQuestion(state.currentQuestionIndex);
}

async function openConfirmFinishModal() {
    state.isConfirmingFinish = true;
    
    // Refresh pengaturan terkini dari server seketika saat tombol diklik
    try {
        const res = await fetch(`api.php?action=get_settings&_t=${Date.now()}`, { cache: 'no-store' });
        const json = await res.json();
        if (json.status === 'success' && json.data) {
            state.settings = Object.assign({}, state.settings, json.data);
        }
    } catch(e) {}
    
    const modal = document.getElementById('confirm-finish-modal');
    if (!modal) {
        finishExam(false);
        return;
    }
    
    // Hitung soal terjawab
    let answeredCount = 0;
    const totalCount = state.shuffledQuestions.length;
    
    state.shuffledQuestions.forEach(q => {
        let isAnswered = false;
        if (q.type === 'essay') {
            isAnswered = q.selectedOption && typeof q.selectedOption === 'string' && q.selectedOption.trim() !== '';
        } else if (q.type === 'complex_mc') {
            isAnswered = Array.isArray(q.selectedOption) && q.selectedOption.length > 0;
        } else if (q.type === 'true_false') {
            isAnswered = q.selectedOption && typeof q.selectedOption === 'object' && 
                         q.statements && Object.keys(q.selectedOption).length >= q.statements.length;
        } else if (q.type === 'matching') {
            isAnswered = q.selectedOption && typeof q.selectedOption === 'object' && 
                         q.premises && q.premises.length > 0 && Object.keys(q.selectedOption).length >= q.premises.length;
        } else {
            isAnswered = q.selectedOption !== null && q.selectedOption !== undefined && q.selectedOption !== '';
        }
        if (isAnswered) answeredCount++;
    });
    
    const unansweredCount = Math.max(0, totalCount - answeredCount);
    
    const totalEl = document.getElementById('confirm-total-q');
    const ansEl = document.getElementById('confirm-answered-q');
    const unansEl = document.getElementById('confirm-unanswered-q');
    if (totalEl) totalEl.textContent = totalCount;
    if (ansEl) ansEl.textContent = answeredCount;
    if (unansEl) unansEl.textContent = unansweredCount;
    
    const warningMsg = document.getElementById('confirm-warning-msg');
    const btnConfirm = document.getElementById('btn-confirm-finish');
    
    if (warningMsg) {
        warningMsg.classList.add('hidden');
        warningMsg.textContent = '';
        warningMsg.style.background = '#FEF2F2';
        warningMsg.style.borderColor = '#FCA5A5';
        warningMsg.style.color = '#991B1B';
    }
    if (btnConfirm) {
        btnConfirm.disabled = false;
        btnConfirm.style.opacity = '1';
        btnConfirm.style.cursor = 'pointer';
        btnConfirm.innerHTML = '<i class="bi bi-check-circle-fill mr-1"></i> Ya, Kumpulkan';
    }
    
    const isRequireAll = state.settings.require_all_answered === true || state.settings.require_all_answered === 'true' || state.settings.require_all_answered === 1 || state.settings.require_all_answered === '1';
    const minTimeMinutes = parseInt(state.settings.min_time_submit || 0);

    // Validasi require_all_answered
    if (isRequireAll && unansweredCount > 0) {
        if (warningMsg) {
            warningMsg.innerHTML = `<i class="bi bi-exclamation-circle-fill mr-1"></i> Pengawas mewajibkan seluruh soal dijawab. Anda belum menjawab <strong>${unansweredCount}</strong> soal.`;
            warningMsg.classList.remove('hidden');
        }
        if (btnConfirm) {
            btnConfirm.disabled = true;
            btnConfirm.style.opacity = '0.5';
            btnConfirm.style.cursor = 'not-allowed';
        }
    } 
    // Validasi min_time_submit
    else if (minTimeMinutes > 0 && state.startTime) {
        const minTimeMs = minTimeMinutes * 60 * 1000;
        const timeSpent = Date.now() - state.startTime;
        if (timeSpent < minTimeMs) {
            const minsLeft = Math.ceil((minTimeMs - timeSpent) / 60000);
            if (warningMsg) {
                warningMsg.innerHTML = `<i class="bi bi-clock mr-1"></i> Batas waktu minimal pengerjaan belum terpenuhi. Silakan tunggu <strong>${minsLeft} menit lagi</strong>.`;
                warningMsg.classList.remove('hidden');
            }
            if (btnConfirm) {
                btnConfirm.disabled = true;
                btnConfirm.style.opacity = '0.5';
                btnConfirm.style.cursor = 'not-allowed';
            }
        }
    } else if (unansweredCount > 0) {
        if (warningMsg) {
            warningMsg.innerHTML = `<i class="bi bi-exclamation-triangle-fill mr-1"></i> Perhatian: Masih ada <strong>${unansweredCount}</strong> soal yang belum Anda jawab. Tetap ingin mengumpulkan?`;
            warningMsg.classList.remove('hidden');
            warningMsg.style.background = '#FFFBEB';
            warningMsg.style.borderColor = '#FCD34D';
            warningMsg.style.color = '#B45309';
        }
    }
    
    modal.classList.remove('hidden');
}

function closeConfirmFinishModal() {
    const modal = document.getElementById('confirm-finish-modal');
    if (modal) modal.classList.add('hidden');
    
    // Toleransi agar event blur saat modal tutup tidak memicu pelanggaran
    setTimeout(() => {
        if (!state.isSubmitting && !state.isFinished) {
            state.isConfirmingFinish = false;
        }
    }, 800);
}

async function finishExam(isForced = false) {
    state.isSubmitting = true;
    state.isFinished = true;
    state.isConfirmingFinish = false;
    
    // Pastikan anticheat overlay tertutup
    const anticheatOverlay = document.getElementById('anticheat-overlay');
    if (anticheatOverlay) anticheatOverlay.classList.add('hidden');
    
    const confirmModal = document.getElementById('confirm-finish-modal');
    if (confirmModal) confirmModal.classList.add('hidden');
    
    if (state.timerInterval) clearInterval(state.timerInterval);
    if (state.syncInterval) clearInterval(state.syncInterval);
    if (state.unlockInterval) clearInterval(state.unlockInterval);
    if (state.lockoutTimerInterval) clearInterval(state.lockoutTimerInterval);
    if (state.batchSyncTimeout) clearTimeout(state.batchSyncTimeout);
    
    let score = 0;

    const answersLog = state.shuffledQuestions.map(q => ({
        originalId: q.originalId,
        type: q.type,
        question: q.question,
        selected: q.selectedOption
    }));
    
    const postData = new FormData();
    postData.append('action', 'submit_test');
    postData.append('student_id', state.selectedStudentId);
    postData.append('exam_id', state.selectedExamId);
    postData.append('violations', state.violations || 0);
    postData.append('start_time', Math.floor((state.startTime || Date.now()) / 1000));
    postData.append('answers', JSON.stringify(answersLog));
    
    try {
        const response = await fetch('api.php', {
            method: 'POST',
            body: postData
        });
        const res = await response.json();
        
        if (res.status === 'success') {
            clearSession(); // Clear session upon successful submit
            examScreen.classList.add('hidden');
            
            const finalScore = (res.score !== undefined) ? res.score : 0;
            // Tampilkan nilai terverifikasi server jika diizinkan di pengaturan
            if (state.settings.show_score === true || state.settings.show_score === 'true') {
                document.getElementById('result-score').textContent = finalScore;
                document.getElementById('result-score-container').classList.remove('hidden');
            } else {
                document.getElementById('result-score-container').classList.add('hidden');
            }
            
            resultScreen.classList.remove('hidden');
            
            // Pastikan anticheat overlay benar-benar tidak tampil
            if (anticheatOverlay) anticheatOverlay.classList.add('hidden');
            
            // Keluar dari mode layar penuh secara halus tanpa memicu pelanggaran
            try {
                if (document.fullscreenElement && document.exitFullscreen) {
                    document.exitFullscreen().catch(() => {});
                }
            } catch(e) {}
        } else {
            state.isSubmitting = false;
            state.isFinished = false;
            alert(res.message);
        }
    } catch (err) {
        state.isSubmitting = false;
        state.isFinished = false;
        alert('Terjadi kesalahan saat menyimpan nilai. Silakan coba lagi.');
    }
}

examForm.addEventListener('submit', (e) => {
    e.preventDefault();
    openConfirmFinishModal();
});

// Start
init();

// Auto-poll exams to keep dynamic tokens synchronized on login screen
setInterval(async () => {
    if (loginScreen && !loginScreen.classList.contains('hidden') && state.selectedExamId) {
        try {
            const res = await fetch('api.php?action=get_exams');
            const json = await res.json();
            if (json.status === 'success' && json.data) {
                state.exams = json.data;
                const cur = state.exams.find(e => e.id == state.selectedExamId);
                if (cur) {
                    const prevToken = state.selectedExamToken;
                    state.selectedExam = cur;
                    state.selectedExamToken = cur.token;
                    state.selectedExamPrevToken = cur.prev_token || null;
                    
                    // Hanya panggil checkToken jika token ujian di server benar-benar berubah/berotasi 
                    // dan siswa belum memilih nama peserta agar proses pengisian form tidak terganggu
                    if (prevToken && prevToken !== cur.token && tokenInput && tokenInput.value.trim() !== '' && !state.selectedStudentId) {
                        checkToken();
                    }
                }
            }
        } catch(e) {}
    }
}, 15000);

// Otomatis sinkronisasi seketika saat koneksi internet/sinyal siswa pulih kembali
window.addEventListener('online', () => {
    if (state.selectedStudentId && !state.isFinished && !state.isSubmitting) {
        syncProgress(true);
    }
});

